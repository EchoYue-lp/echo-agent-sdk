//! Extension schema, digest and golden fixtures.
//!
//! The extension contract is generated from the Rust DTOs and the method
//! catalog — never hand-written — so the schema cannot drift from the code.
//! The generator is deterministic: the same source revision produces the
//! same canonical JSON, the same sha256 contract digest and the same
//! fixture bytes (design §20.2: regeneration leaves the worktree clean).
//!
//! Only echo-agent extension types appear here. Official ACP schemas
//! (JSON-RPC envelope, initialize, Session, Prompt, ContentBlock, stop
//! reasons) stay external: `validate_schema_boundaries` rejects any
//! generated definition that would shadow an official ACP concept.

use serde::{Deserialize, Serialize};
use sha2::{Digest as _, Sha256};

use crate::capability::{EchoAgentCapability, EchoAgentClientHello};
use crate::catalog::METHOD_CATALOG;
use crate::error::{
    AgentFailureWire, EchoSdkError, ErrorDetails, ExtensionErrorCode, FacadeFailureDetail,
    Retryability,
};
use crate::event::{
    EventCursor, EventGap, EventNotification, GapNotification, ReplayRequest, ReplayResponse,
    WireEventEnvelope, WireEventPayload,
};
use crate::handle::{HandleKind, WireHandle};
use crate::methods::*;
use crate::scalar::{
    ABSOLUTE_UNIX_PATH_FORMAT, ABSOLUTE_UTF8_PATH_FORMAT, ABSOLUTE_WINDOWS_PATH_FORMAT,
    BASE64_NO_PAD_FORMAT, WireBytes, WireDuration, WireField, WireI64, WireMapEntry,
    WireNonZeroU64, WirePath, WireTimestamp, WireU64, WireValue, is_absolute_unix_path_base64,
    is_absolute_utf8_path, is_absolute_windows_path_base64, is_base64_no_pad,
};

/// Names that would signal the schema is re-defining official ACP concepts.
/// The generated definitions must not contain any of these titles.
const FORBIDDEN_ACP_TITLES: &[&str] = &[
    "JsonRpcMessage",
    "JsonRpcRequest",
    "JsonRpcResponse",
    "JsonRpcNotification",
    "InitializeRequest",
    "InitializeResponse",
    "Session",
    "SessionNewRequest",
    "SessionPromptRequest",
    "ContentBlock",
    "StopReason",
    "ProtocolVersion",
];

/// Canonical JSON rendering: `serde_json` maps are BTree-ordered here (the
/// workspace does not enable `preserve_order`), so pretty printing yields a
/// byte-stable document.
pub fn canonical_json(value: &serde_json::Value) -> String {
    serde_json::to_string_pretty(value).unwrap_or_default()
}

/// sha256 digest over the canonical document, hex-encoded.
pub fn digest_of(value: &serde_json::Value) -> String {
    let canonical = canonical_json(value);
    let mut hasher = Sha256::new();
    hasher.update(canonical.as_bytes());
    format!("sha256:{}", hex(&hasher.finalize()))
}

fn hex(bytes: &[u8]) -> String {
    const TABLE: &[u8; 16] = b"0123456789abcdef";
    let mut out = String::with_capacity(bytes.len() * 2);
    for byte in bytes {
        out.push(TABLE[(byte >> 4) as usize] as char);
        out.push(TABLE[(byte & 0x0f) as usize] as char);
    }
    out
}

fn insert_schema<T: schemars::JsonSchema>(
    definitions: &mut serde_json::Map<String, serde_json::Value>,
    name: &str,
) {
    let schema = schemars::schema_for!(T);
    let mut value = serde_json::to_value(&schema).unwrap_or(serde_json::Value::Null);
    if let Some(object) = value.as_object_mut() {
        object.remove("$schema");
        if let Some(nested) = object
            .remove("definitions")
            .and_then(|definitions| definitions.as_object().cloned())
        {
            for (nested_name, nested_schema) in nested {
                definitions.entry(nested_name).or_insert(nested_schema);
            }
        }
    }
    definitions.insert(name.to_string(), value);
}

macro_rules! schema_entry {
    ($map:expr, $ty:ty) => {
        insert_schema::<$ty>(&mut $map, stringify!($ty));
    };
}

/// Build the full extension schema document.
pub fn build_extension_schema_doc() -> serde_json::Value {
    let mut definitions = serde_json::Map::new();
    // Scalars.
    schema_entry!(definitions, WireU64);
    schema_entry!(definitions, WireNonZeroU64);
    schema_entry!(definitions, WireI64);
    schema_entry!(definitions, WireDuration);
    schema_entry!(definitions, WireTimestamp);
    schema_entry!(definitions, WirePath);
    schema_entry!(definitions, WireBytes);
    schema_entry!(definitions, WireField);
    schema_entry!(definitions, WireMapEntry);
    schema_entry!(definitions, WireValue);
    // Handles.
    schema_entry!(definitions, WireHandle);
    schema_entry!(definitions, HandleKind);
    // Errors.
    schema_entry!(definitions, EchoSdkError);
    schema_entry!(definitions, ExtensionErrorCode);
    schema_entry!(definitions, Retryability);
    schema_entry!(definitions, ErrorDetails);
    // Events.
    schema_entry!(definitions, WireEventEnvelope);
    schema_entry!(definitions, WireEventPayload);
    schema_entry!(definitions, EventNotification);
    schema_entry!(definitions, EventCursor);
    schema_entry!(definitions, ReplayRequest);
    schema_entry!(definitions, ReplayResponse);
    schema_entry!(definitions, EventGap);
    schema_entry!(definitions, GapNotification);
    // Capability.
    schema_entry!(definitions, EchoAgentCapability);
    schema_entry!(definitions, EchoAgentClientHello);
    // Core profile typed payloads (agent config / run input / terminal /
    // receipt / recovery descriptions).
    schema_entry!(definitions, AgentConfigWire);
    schema_entry!(definitions, AgentConfigExplicitWire);
    schema_entry!(definitions, ModelConfigWire);
    schema_entry!(definitions, LlmApiProtocolWire);
    schema_entry!(definitions, CredentialSourceWire);
    schema_entry!(definitions, AgentSettingsWire);
    schema_entry!(definitions, AgentSnapshotWire);
    schema_entry!(definitions, AgentFailureWire);
    schema_entry!(definitions, RunStatus);
    schema_entry!(definitions, RunTerminal);
    schema_entry!(definitions, RunReceiptWire);
    schema_entry!(definitions, RecoveredRunWire);
    schema_entry!(definitions, EventAck);
    schema_entry!(definitions, EventAckNotification);
    // Method payloads (request/response DTOs of the frozen catalog families).
    schema_entry!(definitions, AgentCreateRequest);
    schema_entry!(definitions, AgentCreateResponse);
    schema_entry!(definitions, AgentDescribeRequest);
    schema_entry!(definitions, AgentDescribeResponse);
    schema_entry!(definitions, AgentCloseRequest);
    schema_entry!(definitions, AgentCloseResponse);
    schema_entry!(definitions, SessionCreateRequest);
    schema_entry!(definitions, SessionCreateResponse);
    schema_entry!(definitions, SessionLoadRequest);
    schema_entry!(definitions, SessionLoadResponse);
    schema_entry!(definitions, SessionCloseRequest);
    schema_entry!(definitions, SessionCloseResponse);
    schema_entry!(definitions, RunInput);
    schema_entry!(definitions, RunStartRequest);
    schema_entry!(definitions, RunStartResponse);
    schema_entry!(definitions, RunGetRequest);
    schema_entry!(definitions, RunGetResponse);
    schema_entry!(definitions, RunWaitRequest);
    schema_entry!(definitions, RunWaitResponse);
    schema_entry!(definitions, RunCancelRequest);
    schema_entry!(definitions, RunCancelResponse);
    schema_entry!(definitions, RunSteerRequest);
    schema_entry!(definitions, RunSteerResponse);
    schema_entry!(definitions, TaskCreateRequest);
    schema_entry!(definitions, TaskCreateResponse);
    schema_entry!(definitions, TaskUpdateRequest);
    schema_entry!(definitions, TaskUpdateResponse);
    schema_entry!(definitions, TaskListRequest);
    schema_entry!(definitions, TaskListResponse);
    schema_entry!(definitions, TaskSummary);
    schema_entry!(definitions, TaskExecuteRequest);
    schema_entry!(definitions, TaskExecuteResponse);
    schema_entry!(definitions, TaskControlRequest);
    schema_entry!(definitions, TaskControlResponse);
    schema_entry!(definitions, SubagentDispatchRequest);
    schema_entry!(definitions, SubagentDispatchResponse);
    schema_entry!(definitions, SubagentAwaitRequest);
    schema_entry!(definitions, SubagentAwaitResponse);
    schema_entry!(definitions, SubagentControlRequest);
    schema_entry!(definitions, SubagentControlResponse);
    schema_entry!(definitions, ExtensionRegisterRequest);
    schema_entry!(definitions, ExtensionRegisterResponse);
    schema_entry!(definitions, ExtensionUnregisterRequest);
    schema_entry!(definitions, ExtensionUnregisterResponse);
    schema_entry!(definitions, ExtensionInvokeCall);
    schema_entry!(definitions, ExtensionInvocation);
    schema_entry!(definitions, ExtensionInvokeOutcome);
    schema_entry!(definitions, ExtensionResult);
    schema_entry!(definitions, ExtensionCancelNotice);
    schema_entry!(definitions, ExtensionStreamEvent);
    schema_entry!(definitions, ExtensionStreamChunkValue);
    schema_entry!(definitions, ExtensionStreamCompleteValue);
    schema_entry!(definitions, AgentEventWire);
    schema_entry!(definitions, AgentStreamChunkWire);
    schema_entry!(definitions, AgentStreamTerminalWire);
    schema_entry!(definitions, ExtensionKind);
    schema_entry!(definitions, ExtensionDescriptor);
    schema_entry!(definitions, ExtensionOperation);
    schema_entry!(definitions, ExtensionInvocationContext);
    schema_entry!(definitions, ModelModalityWire);
    schema_entry!(definitions, SearchModeWire);
    schema_entry!(definitions, FeatureOperationRequest);
    schema_entry!(definitions, FeatureOperationResponse);
    schema_entry!(definitions, WorkingDirectory);
    schema_entry!(definitions, DeliveryClaimWire);
    schema_entry!(definitions, DeliveryClaimNextResultWire);
    schema_entry!(definitions, DeliveryMutationResultWire);
    // Facade adapter catalog types (plan 07 todo 1).
    schema_entry!(definitions, FacadeFailureDetail);

    let catalog: Vec<serde_json::Value> = METHOD_CATALOG
        .iter()
        .map(|method| {
            serde_json::json!({
                "name": method.name,
                "direction": method.direction.as_str(),
                "capability": method.capability.as_str(),
                "summary": method.summary,
                "params_schema": format!("#/definitions/{}", method.params_schema()),
                "result_schema": method
                    .result_schema()
                    .map(|name| format!("#/definitions/{name}")),
                "error_schema": method
                    .error_schema()
                    .map(|name| format!("#/definitions/{name}")),
            })
        })
        .collect();

    serde_json::json!({
        "$schema": "http://json-schema.org/draft-07/schema#",
        "title": "echo-agent-extension-v1",
        "type": "object",
        "extension_protocol_version": crate::EXTENSION_PROTOCOL_VERSION,
        "namespace": crate::EXTENSION_NAMESPACE,
        "acp_wire_protocol_version": 1,
        "description": "echo-agent SDK extension contract over stable ACP v1. \
                        Standard ACP types are owned by the official \
                        agent-client-protocol-schema artifact and are intentionally \
                        absent from this document.",
        "method_catalog": catalog,
        "definitions": definitions,
    })
}

pub fn build_extension_validator(
    schema: &serde_json::Value,
) -> Result<jsonschema::Validator, jsonschema::ValidationError<'static>> {
    jsonschema::options()
        .with_format(BASE64_NO_PAD_FORMAT, is_base64_no_pad)
        .with_format(ABSOLUTE_UNIX_PATH_FORMAT, is_absolute_unix_path_base64)
        .with_format(
            ABSOLUTE_WINDOWS_PATH_FORMAT,
            is_absolute_windows_path_base64,
        )
        .with_format(ABSOLUTE_UTF8_PATH_FORMAT, is_absolute_utf8_path)
        .build(schema)
}

/// Contract digest of the extension schema (design §18: extension version,
/// wire version and crate versions are governed independently).
pub fn extension_contract_digest() -> String {
    digest_of(&build_extension_schema_doc())
}

// ── Source contract ─────────────────────────────────────────────────────────

/// Algorithm identifier of the source-compatibility digest.
pub const SOURCE_CONTRACT_ALGORITHM: &str = "sha256-length-prefixed-v1";

/// Fixed input order of the source contract. Only accepted external artifacts
/// participate in runtime compatibility; Cargo.lock and full Rust inventory
/// remain provenance/telemetry inputs.
pub const SOURCE_CONTRACT_INPUTS: &[&str] = &[
    "contracts/sdk/accepted-external-contract.json",
    "contracts/sdk/accepted-facade-operation-catalog.json",
];

/// Aggregate digest over the source-contract inputs: for every entry in the
/// fixed [`SOURCE_CONTRACT_INPUTS`] order, hash the u64 big-endian length of
/// the relative path, the path bytes, the u64 big-endian content length, and
/// the content bytes. Length prefixes make the stream unambiguous without
/// relying on delimiters.
pub fn aggregate_source_digest(entries: &[(&str, &[u8])]) -> String {
    let mut hasher = Sha256::new();
    for (path, content) in entries {
        let path_bytes = path.as_bytes();
        hasher.update((path_bytes.len() as u64).to_be_bytes());
        hasher.update(path_bytes);
        hasher.update((content.len() as u64).to_be_bytes());
        hasher.update(content);
    }
    format!("sha256:{}", hex(&hasher.finalize()))
}

/// Build the `contracts/sdk/source-contract.json` document. `entries` must
/// be given in the [`SOURCE_CONTRACT_INPUTS`] order; each entry is hashed
/// individually so a drift in one input is attributable.
pub fn build_source_contract_doc(entries: &[(&str, &[u8])]) -> serde_json::Value {
    let items: Vec<serde_json::Value> = entries
        .iter()
        .map(|(path, content)| {
            let mut hasher = Sha256::new();
            hasher.update(content);
            serde_json::json!({
                "path": path,
                "bytes": content.len(),
                "sha256": format!("sha256:{}", hex(&hasher.finalize())),
            })
        })
        .collect();
    serde_json::json!({
        "algorithm": SOURCE_CONTRACT_ALGORITHM,
        "inputs": items,
        "aggregate_digest": aggregate_source_digest(entries),
    })
}

/// Fail if the generated schema would shadow official ACP concepts.
pub fn validate_schema_boundaries(doc: &serde_json::Value) -> Vec<String> {
    let mut problems = Vec::new();
    if let Some(definitions) = doc.get("definitions").and_then(|v| v.as_object()) {
        for title in definitions.keys() {
            if FORBIDDEN_ACP_TITLES.contains(&title.as_str()) {
                problems.push(format!(
                    "definition {title} shadows an official ACP schema concept"
                ));
            }
        }
    }
    if let Some(catalog) = doc.get("method_catalog").and_then(|v| v.as_array()) {
        for method in catalog {
            let name = method
                .get("name")
                .and_then(|v| v.as_str())
                .unwrap_or_default();
            if !name.starts_with(crate::EXTENSION_NAMESPACE) {
                problems.push(format!(
                    "catalog method {name} outside the extension namespace"
                ));
            }
        }
    }
    problems
}

// ── Fixtures ────────────────────────────────────────────────────────────────

/// One golden fixture. Valid fixtures must round-trip losslessly through the
/// named DTO; invalid fixtures must be rejected by the DTO's validation (or
/// serde) with the expected error family.
#[derive(Debug, Clone, Serialize, Deserialize, schemars::JsonSchema)]
pub struct Fixture {
    pub name: String,
    pub kind: FixtureKind,
    /// Which DTO the fixture targets (Rust type name).
    pub target: String,
    pub description: String,
    pub payload: serde_json::Value,
    /// For invalid fixtures: the expected failure family.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub expect_error: Option<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, schemars::JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum FixtureKind {
    Valid,
    Invalid,
}

/// Render the fixture directory content: `(relative_path, canonical_json)`.
pub fn build_fixtures() -> Vec<(String, String)> {
    let mut files = Vec::new();
    for fixture in all_fixtures() {
        let value = serde_json::to_value(&fixture).unwrap_or(serde_json::Value::Null);
        let path = format!("contracts/sdk/fixtures/extension/v1/{}.json", fixture.name);
        files.push((path, canonical_json(&value)));
    }
    files.sort();
    files
}

/// The full fixture set. Ordering is part of the contract; keep entries
/// grouped by DTO family.
pub fn all_fixtures() -> Vec<Fixture> {
    let mut fixtures = Vec::new();
    push_scalar_fixtures(&mut fixtures);
    push_handle_fixtures(&mut fixtures);
    push_error_fixtures(&mut fixtures);
    push_event_fixtures(&mut fixtures);
    push_ack_fixtures(&mut fixtures);
    push_bridge_fixtures(&mut fixtures);
    push_governance_fixtures(&mut fixtures);
    push_capability_fixtures(&mut fixtures);
    push_hello_fixtures(&mut fixtures);
    push_agent_config_fixtures(&mut fixtures);
    push_run_fixtures(&mut fixtures);
    push_facade_fixtures(&mut fixtures);
    push_channel_forward_fixtures(&mut fixtures);
    push_boundary_fixtures(&mut fixtures);
    fixtures
}

fn fixture(
    name: &str,
    kind: FixtureKind,
    target: &str,
    description: &str,
    payload: serde_json::Value,
    expect_error: Option<&str>,
) -> Fixture {
    Fixture {
        name: name.to_string(),
        kind,
        target: target.to_string(),
        description: description.to_string(),
        payload,
        expect_error: expect_error.map(str::to_string),
    }
}

fn push_scalar_fixtures(fixtures: &mut Vec<Fixture>) {
    fixtures.push(fixture(
        "scalar-u64-max-valid",
        FixtureKind::Valid,
        "WireU64",
        "u64::MAX round-trips as a decimal string untouched.",
        serde_json::json!("18446744073709551615"),
        None,
    ));
    fixtures.push(fixture(
        "scalar-u64-leading-zeros-invalid",
        FixtureKind::Invalid,
        "WireU64",
        "Non-canonical decimal spellings are rejected.",
        serde_json::json!("007"),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "scalar-u64-float-invalid",
        FixtureKind::Invalid,
        "WireU64",
        "Floats never substitute for integer strings.",
        serde_json::json!("1.5"),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "scalar-u64-overflow-invalid",
        FixtureKind::Invalid,
        "WireU64",
        "Decimal strings above u64::MAX are rejected by Rust and JSON Schema.",
        serde_json::json!("18446744073709551616"),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "scalar-path-unix-lossless-valid",
        FixtureKind::Valid,
        "WirePath",
        "Non-UTF-8 Unix path bytes survive via base64 with display fallback.",
        serde_json::json!({
            "encoding": "unix",
            "bytes_base64": "L3RtcC/DkfCvMPIh",
            "display": "/tmp/<lossy>"
        }),
        None,
    ));
    fixtures.push(fixture(
        "scalar-path-windows-valid",
        FixtureKind::Valid,
        "WirePath",
        "Windows UTF-16 unit sequence preserved verbatim.",
        serde_json::json!({
            "encoding": "windows",
            "utf16_base64": "QwA6AFwAXAA"
        }),
        None,
    ));
    fixtures.push(fixture(
        "scalar-path-root-valid",
        FixtureKind::Valid,
        "WirePath",
        "Filesystem roots are valid absolute paths.",
        serde_json::json!({"encoding": "utf8", "path": "/"}),
        None,
    ));
    fixtures.push(fixture(
        "scalar-duration-nanos-valid",
        FixtureKind::Valid,
        "WireDuration",
        "Full duration range uses decimal seconds plus sub-second nanos.",
        serde_json::json!({"seconds": "9007199", "nanos": 254740993}),
        None,
    ));
    fixtures.push(fixture(
        "scalar-unknown-additive-valid",
        FixtureKind::Valid,
        "WireValue",
        "Unknown additive values keep their type tag and bounded payload.",
        serde_json::json!({
            "kind": "unknown",
            "value": {
                "type_tag": "agent_event/tool_progress_v2",
                "payload": {"kind": "bool", "value": true}
            }
        }),
        None,
    ));
    fixtures.push(fixture(
        "scalar-path-relative-invalid",
        FixtureKind::Invalid,
        "WirePath",
        "Relative paths are not accepted by the lossless path contract.",
        serde_json::json!({"encoding": "utf8", "path": "relative/file"}),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "scalar-path-base64-invalid",
        FixtureKind::Invalid,
        "WirePath",
        "Encoded native paths must contain canonical base64.",
        serde_json::json!({"encoding": "unix", "bytes_base64": "not base64"}),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "scalar-path-unix-relative-encoded-invalid",
        FixtureKind::Invalid,
        "WirePath",
        "Canonical base64 is still invalid when its Unix path is relative.",
        serde_json::json!({"encoding": "unix", "bytes_base64": "cmVsYXRpdmU"}),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "scalar-path-windows-relative-encoded-invalid",
        FixtureKind::Invalid,
        "WirePath",
        "Canonical UTF-16 base64 is invalid when its Windows path is relative.",
        serde_json::json!({"encoding": "windows", "utf16_base64": "ZgBvAG8A"}),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "scalar-path-native-empty-invalid",
        FixtureKind::Invalid,
        "WirePath",
        "An empty native path cannot be absolute.",
        serde_json::json!({"encoding": "unix", "bytes_base64": ""}),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "scalar-bytes-base64-invalid",
        FixtureKind::Invalid,
        "WireBytes",
        "Binary payloads reject malformed base64.",
        serde_json::json!({"base64": "***"}),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "scalar-bytes-empty-valid",
        FixtureKind::Valid,
        "WireBytes",
        "An empty binary payload has the empty canonical no-pad base64 encoding.",
        serde_json::json!({"base64": ""}),
        None,
    ));
    fixtures.push(fixture(
        "scalar-bytes-length-invalid",
        FixtureKind::Invalid,
        "WireBytes",
        "A one-character no-pad base64 value cannot encode complete bytes.",
        serde_json::json!({"base64": "A"}),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "scalar-unknown-empty-tag-invalid",
        FixtureKind::Invalid,
        "WireValue",
        "Unknown additive values require a non-empty type identity.",
        serde_json::json!({"kind": "unknown", "value": {"type_tag": "", "payload": null}}),
        Some("invalid_value"),
    ));
}

fn push_handle_fixtures(fixtures: &mut Vec<Fixture>) {
    fixtures.push(fixture(
        "handle-run-valid",
        FixtureKind::Valid,
        "WireHandle",
        "Run handle with generation fence.",
        serde_json::json!({"id": "run-42", "generation": "7", "kind": "run"}),
        None,
    ));
    fixtures.push(fixture(
        "handle-empty-id-invalid",
        FixtureKind::Invalid,
        "WireHandle",
        "Empty domain identities are rejected (never borrowed request ids).",
        serde_json::json!({"id": "", "generation": "1", "kind": "agent"}),
        Some("invalid_value"),
    ));
}

fn push_error_fixtures(fixtures: &mut Vec<Fixture>) {
    fixtures.push(fixture(
        "error-stale-handle-valid",
        FixtureKind::Valid,
        "EchoSdkError",
        "Typed stale-handle error with operation identity and retryability.",
        serde_json::json!({
            "code": "stale_handle",
            "message": "run handle predates host restart",
            "retryable": "never",
            "operation": "run/start",
            "handle": {"id": "run-9", "generation": "1", "kind": "run"}
        }),
        None,
    ));
    fixtures.push(fixture(
        "error-feature-unavailable-valid",
        FixtureKind::Valid,
        "EchoSdkError",
        "Missing compiled feature fails closed.",
        serde_json::json!({
            "code": "feature_unavailable",
            "message": "feature `mcp` is not compiled into this host",
            "retryable": "never",
            "operation": "memory/op"
        }),
        None,
    ));
    fixtures.push(fixture(
        "error-event-gap-valid",
        FixtureKind::Valid,
        "EchoSdkError",
        "Gap errors carry the snapshot watermark.",
        serde_json::json!({
            "code": "event_gap",
            "message": "consumer fell below the retention floor",
            "retryable": "never"
        }),
        None,
    ));
    fixtures.push(fixture(
        "error-details-duplicate-invalid",
        FixtureKind::Invalid,
        "EchoSdkError",
        "Error detail keys are bounded and unique.",
        serde_json::json!({
            "code": "invalid_value",
            "message": "duplicate detail key",
            "retryable": "never",
            "details": {"fields": [
                {"key": "field", "value": "one"},
                {"key": "field", "value": "two"}
            ]}
        }),
        Some("invalid_value"),
    ));
}

fn push_event_fixtures(fixtures: &mut Vec<Fixture>) {
    fixtures.push(fixture(
        "event-envelope-full-valid",
        FixtureKind::Valid,
        "WireEventEnvelope",
        "Complete envelope: every framework identity fact plus typed AgentEvent payload.",
        serde_json::json!({
            "schema_version": 4,
            "event_id": "event-3",
            "content_hash": "sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
            "sequence": "3",
            "stream_id": "stream-1",
            "run_id": "run-1",
            "turn_id": "turn-1",
            "timestamp": {"unix_seconds": "1757000000", "nanos": 0},
            "payload": {
                "event_type": "token",
                "data": {"kind": "string", "value": "hello"}
            }
        }),
        None,
    ));
    fixtures.push(fixture(
        "event-envelope-sequence-zero-invalid",
        FixtureKind::Invalid,
        "WireEventEnvelope",
        "Framework sequences start at one; zero is rejected.",
        serde_json::json!({
            "schema_version": 4,
            "event_id": "event-0",
            "content_hash": "sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
            "sequence": "0",
            "stream_id": "stream-1",
            "turn_id": "turn-1",
            "timestamp": {"unix_seconds": "0", "nanos": 1},
            "payload": {"event_type": "think_start"}
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "event-replay-gap-valid",
        FixtureKind::Valid,
        "ReplayResponse",
        "Replay below the watermark returns bounded events plus a typed gap.",
        serde_json::json!({
            "requested_after_sequence": "4",
            "events": [],
            "next_cursor": {"stream_id": "stream-1", "last_processed_sequence": "9"},
            "gap": {
                "from_sequence": "5",
                "to_sequence": "9",
                "reason": "retention floor",
                "snapshot_watermark": "9"
            }
        }),
        None,
    ));
    fixtures.push(fixture(
        "event-live-gap-valid",
        FixtureKind::Valid,
        "GapNotification",
        "A live gap is explicitly associated with one stream handle.",
        serde_json::json!({
            "stream": {"id": "stream-1", "generation": "3", "kind": "stream"},
            "gap": {
                "from_sequence": "5",
                "to_sequence": "9",
                "reason": "retention floor",
                "snapshot_watermark": "9"
            }
        }),
        None,
    ));
    fixtures.push(fixture(
        "event-live-gap-watermark-invalid",
        FixtureKind::Invalid,
        "GapNotification",
        "A recovery snapshot cannot precede the missing range.",
        serde_json::json!({
            "stream": {"id": "stream-1", "generation": "3", "kind": "stream"},
            "gap": {
                "from_sequence": "5",
                "to_sequence": "9",
                "reason": "retention floor",
                "snapshot_watermark": "4"
            }
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "event-replay-request-valid",
        FixtureKind::Valid,
        "ReplayRequest",
        "Replay is addressed by a generation-fenced stream handle.",
        serde_json::json!({
            "stream": {"id": "stream-1", "generation": "3", "kind": "stream"},
            "after_sequence": "0",
            "max_events": "16"
        }),
        None,
    ));
    fixtures.push(fixture(
        "event-replay-request-wrong-kind-invalid",
        FixtureKind::Invalid,
        "ReplayRequest",
        "Replay requires a stream handle; run handles are rejected by kind.",
        serde_json::json!({
            "stream": {"id": "run-1", "generation": "3", "kind": "run"},
            "after_sequence": "0"
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "event-replay-empty-stream-invalid",
        FixtureKind::Invalid,
        "ReplayRequest",
        "Replay requests require a stream identity.",
        serde_json::json!({
            "stream": {"id": "", "generation": "3", "kind": "stream"},
            "after_sequence": "0",
            "max_events": "1"
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "event-replay-zero-limit-invalid",
        FixtureKind::Invalid,
        "ReplayRequest",
        "A present replay limit must be positive.",
        serde_json::json!({
            "stream": {"id": "stream-1", "generation": "3", "kind": "stream"},
            "after_sequence": "0",
            "max_events": "0"
        }),
        Some("invalid_value"),
    ));
}

fn push_ack_fixtures(fixtures: &mut Vec<Fixture>) {
    fixtures.push(fixture(
        "event-ack-valid",
        FixtureKind::Valid,
        "EventAckNotification",
        "Client acknowledges one contiguous cursor on a stream handle.",
        serde_json::json!({
            "ack": {
                "stream": {"id": "stream-1", "generation": "3", "kind": "stream"},
                "last_processed_sequence": "12"
            }
        }),
        None,
    ));
    fixtures.push(fixture(
        "event-ack-zero-cursor-invalid",
        FixtureKind::Invalid,
        "EventAckNotification",
        "Acknowledged sequences start at one.",
        serde_json::json!({
            "ack": {
                "stream": {"id": "stream-1", "generation": "3", "kind": "stream"},
                "last_processed_sequence": "0"
            }
        }),
        Some("invalid_value"),
    ));
}

fn push_bridge_fixtures(fixtures: &mut Vec<Fixture>) {
    fixtures.push(fixture(
        "extension-register-tool-valid",
        FixtureKind::Valid,
        "ExtensionRegisterRequest",
        "A Tool registration carries the full typed descriptor the Host dispatches on.",
        serde_json::json!({
            "kind": "tool",
            "implementation_id": "sdk-tool-1",
            "descriptor": {
                "kind": "tool",
                "descriptor_version": 1,
                "name": "search_docs",
                "description": "Search the host-language documentation index.",
                "parameters": {
                    "kind": "record",
                    "value": {
                        "type_id": "json_schema",
                        "fields": [
                            {"name": "type", "value": {"kind": "string", "value": "object"}}
                        ]
                    }
                },
                "schema_revision": "3",
                "required_input_modalities": ["text"],
                "supports_streaming": false,
                "exempt_from_batch_timeout": false,
                "allows_parallel_batch_execution": true,
                "manages_own_timeout": false
            },
            "timeout": {"seconds": "20", "nanos": 0}
        }),
        None,
    ));
    fixtures.push(fixture(
        "extension-register-llm-client-valid",
        FixtureKind::Valid,
        "ExtensionRegisterRequest",
        "An LlmClient registration names the model it implements.",
        serde_json::json!({
            "kind": "llm_client",
            "implementation_id": "sdk-llm-1",
            "descriptor": {
                "kind": "llm_client",
                "descriptor_version": 1,
                "model_name": "fixture-chat",
                "supports_streaming": true
            }
        }),
        None,
    ));
    fixtures.push(fixture(
        "extension-register-intervention-valid",
        FixtureKind::Valid,
        "ExtensionRegisterRequest",
        "InterventionCallback is an explicit registration kind, never an AgentCallback alias.",
        serde_json::json!({
            "kind": "intervention_callback",
            "implementation_id": "sdk-intervention-1",
            "descriptor": {
                "kind": "intervention_callback",
                "descriptor_version": 1
            }
        }),
        None,
    ));
    fixtures.push(fixture(
        "extension-register-kind-mismatch-invalid",
        FixtureKind::Invalid,
        "ExtensionRegisterRequest",
        "The descriptor kind must equal the registration kind.",
        serde_json::json!({
            "kind": "tool",
            "implementation_id": "sdk-tool-1",
            "descriptor": {
                "kind": "llm_client",
                "descriptor_version": 1,
                "model_name": "fixture-chat",
                "supports_streaming": false
            }
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "extension-register-unknown-version-invalid",
        FixtureKind::Invalid,
        "ExtensionRegisterRequest",
        "Unknown descriptor versions fail closed instead of being partially applied.",
        serde_json::json!({
            "kind": "store",
            "implementation_id": "sdk-store-1",
            "descriptor": {
                "kind": "store",
                "descriptor_version": 99,
                "search_modes": ["keyword"]
            }
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "extension-register-empty-identity-invalid",
        FixtureKind::Invalid,
        "ExtensionRegisterRequest",
        "Implementation identities must be non-empty and bounded.",
        serde_json::json!({
            "kind": "hook",
            "implementation_id": "  ",
            "descriptor": {"kind": "hook", "descriptor_version": 1, "events": ["PreToolUse"]}
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "extension-invoke-tool-valid",
        FixtureKind::Valid,
        "ExtensionInvokeCall",
        "A reverse call carries its own invocation identity, operation and deadline.",
        serde_json::json!({
            "extension": {"id": "extension-1", "generation": "2", "kind": "extension"},
            "invocation_id": "invocation-41",
            "context": {"session_id": "session-9", "run_id": "run-7"},
            "invocation": {
                "operation": "tool_execute",
                "input": {
                    "parameters": {
                        "kind": "record",
                        "value": {
                            "type_id": "ToolParameters",
                            "fields": [
                                {"name": "query", "value": {"kind": "string", "value": "rust async"}}
                            ]
                        }
                    },
                    "context": {"conversation_id": "session-9", "run_id": "run-7"}
                }
            },
            "deadline": {"seconds": "20", "nanos": 0}
        }),
        None,
    ));
    fixtures.push(fixture(
        "extension-invoke-stream-handle-valid",
        FixtureKind::Valid,
        "ExtensionInvokeCall",
        "Streaming operations carry the Host-minted stream handle.",
        serde_json::json!({
            "extension": {"id": "extension-2", "generation": "2", "kind": "extension"},
            "invocation_id": "invocation-42",
            "invocation": {"operation": "llm_chat_stream", "input": {"messages": []}},
            "deadline": {"seconds": "30", "nanos": 0},
            "stream": {"id": "stream-9", "generation": "2", "kind": "stream"}
        }),
        None,
    ));
    fixtures.push(fixture(
        "extension-invoke-wrong-handle-kind-invalid",
        FixtureKind::Invalid,
        "ExtensionInvokeCall",
        "Reverse calls require an extension-kind handle.",
        serde_json::json!({
            "extension": {"id": "run-1", "generation": "2", "kind": "run"},
            "invocation_id": "invocation-43",
            "invocation": {
                "operation": "tool_execute",
                "input": {"parameters": {"kind": "record", "value": {"type_id": "ToolParameters", "fields": []}}}
            },
            "deadline": {"seconds": "20", "nanos": 0}
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "extension-invoke-stream-without-handle-invalid",
        FixtureKind::Invalid,
        "ExtensionInvokeCall",
        "Streaming operations must name the stream handle they deliver to.",
        serde_json::json!({
            "extension": {"id": "extension-2", "generation": "2", "kind": "extension"},
            "invocation_id": "invocation-44",
            "invocation": {"operation": "llm_chat_stream", "input": {"messages": []}},
            "deadline": {"seconds": "30", "nanos": 0}
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "extension-outcome-result-valid",
        FixtureKind::Valid,
        "ExtensionInvokeOutcome",
        "A non-streaming callback settles with exactly one result value.",
        serde_json::json!({
            "outcome": "result",
            "result": {"operation": "agent_execute", "value": "3 documents"}
        }),
        None,
    ));
    fixtures.push(fixture(
        "extension-outcome-stream-valid",
        FixtureKind::Valid,
        "ExtensionInvokeOutcome",
        "A streaming callback returns one stream handle instead of a large response.",
        serde_json::json!({
            "outcome": "stream",
            "stream": {"id": "stream-9", "generation": "2", "kind": "stream"}
        }),
        None,
    ));
    fixtures.push(fixture(
        "extension-outcome-typed-error-valid",
        FixtureKind::Valid,
        "ExtensionInvokeOutcome",
        "Callback failures use the typed extension error contract without fallback.",
        serde_json::json!({
            "outcome": "error",
            "error": {
                "code": "extension_failed",
                "message": "implementation raised before producing a value",
                "retryable": "never"
            }
        }),
        None,
    ));
    fixtures.push(fixture(
        "extension-outcome-empty-invalid",
        FixtureKind::Invalid,
        "ExtensionInvokeOutcome",
        "A callback outcome must choose exactly one tagged variant.",
        serde_json::json!({}),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "extension-cancel-notice-valid",
        FixtureKind::Valid,
        "ExtensionCancelNotice",
        "Cancellation names the invocation identity and a stable reason.",
        serde_json::json!({
            "invocation_id": "invocation-41",
            "reason": "cancelled"
        }),
        None,
    ));
    fixtures.push(fixture(
        "extension-cancel-notice-empty-reason-invalid",
        FixtureKind::Invalid,
        "ExtensionCancelNotice",
        "Cancel reasons are bounded non-empty diagnostics.",
        serde_json::json!({"invocation_id": "invocation-41", "reason": ""}),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "extension-stream-chunk-valid",
        FixtureKind::Valid,
        "ExtensionStreamEvent",
        "Callback stream chunks preserve stream identity and monotonic sequence.",
        serde_json::json!({
            "event": "chunk",
            "stream": {"id": "stream-9", "generation": "2", "kind": "stream"},
            "sequence": "1",
            "value": {"kind": "llm", "value": {"content": "token"}}
        }),
        None,
    ));
    fixtures.push(fixture(
        "extension-stream-complete-terminal-valid",
        FixtureKind::Valid,
        "ExtensionStreamEvent",
        "A complete terminal carries the final payload of the stream.",
        serde_json::json!({
            "event": "complete",
            "stream": {"id": "stream-9", "generation": "2", "kind": "stream"},
            "sequence": "4",
            "value": {"kind": "llm", "value": {"finish_reason": "stop"}}
        }),
        None,
    ));
    fixtures.push(fixture(
        "extension-stream-sequence-zero-invalid",
        FixtureKind::Invalid,
        "ExtensionStreamEvent",
        "Callback stream sequences start at one.",
        serde_json::json!({
            "event": "chunk",
            "stream": {"id": "stream-9", "generation": "2", "kind": "stream"},
            "sequence": "0",
            "value": {"kind": "llm", "value": {"content": "token"}}
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "extension-stream-tool-progress-terminal-invalid",
        FixtureKind::Invalid,
        "ExtensionStreamEvent",
        "A Tool progress event cannot masquerade as the outer stream terminal.",
        serde_json::json!({
            "event": "complete",
            "stream": {"id": "stream-9", "generation": "2", "kind": "stream"},
            "sequence": "2",
            "value": {"kind": "tool", "value": {"event": "progress", "message": "halfway", "percent": 50}}
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "extension-stream-tool-complete-chunk-invalid",
        FixtureKind::Invalid,
        "ExtensionStreamEvent",
        "A Tool terminal result cannot be emitted as an ordinary chunk.",
        serde_json::json!({
            "event": "chunk",
            "stream": {"id": "stream-9", "generation": "2", "kind": "stream"},
            "sequence": "2",
            "value": {"kind": "tool", "value": {"event": "complete", "result": {"kind": {"kind": "text"}, "success": true, "output": "done", "truncated": false, "metadata": {}, "model_content": []}}}
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "extension-stream-agent-token-terminal-invalid",
        FixtureKind::Invalid,
        "ExtensionStreamEvent",
        "A CustomAgent token cannot terminate the outer stream.",
        serde_json::json!({
            "event": "complete",
            "stream": {"id": "stream-9", "generation": "2", "kind": "stream"},
            "sequence": "2",
            "value": {"kind": "agent", "value": {"event": "token", "data": {"text": "not terminal"}}}
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "extension-stream-agent-final-chunk-invalid",
        FixtureKind::Invalid,
        "ExtensionStreamEvent",
        "A CustomAgent final answer must use the outer complete terminal.",
        serde_json::json!({
            "event": "chunk",
            "stream": {"id": "stream-9", "generation": "2", "kind": "stream"},
            "sequence": "2",
            "value": {"kind": "agent", "value": {"event": "final_answer", "data": {"text": "done"}}}
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "extension-stream-llm-empty-finish-invalid",
        FixtureKind::Invalid,
        "ExtensionStreamEvent",
        "An LLM completion must carry a non-empty finish reason.",
        serde_json::json!({
            "event": "complete",
            "stream": {"id": "stream-9", "generation": "2", "kind": "stream"},
            "sequence": "2",
            "value": {"kind": "llm", "value": {"finish_reason": ""}}
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "extension-stream-agent-tool-complete-chunk-invalid",
        FixtureKind::Invalid,
        "ExtensionStreamEvent",
        "A CustomAgent ToolStream event cannot hide a Tool complete terminal inside a chunk.",
        serde_json::json!({
            "event": "chunk",
            "stream": {"id": "stream-9", "generation": "2", "kind": "stream"},
            "sequence": "2",
            "value": {
                "kind": "agent",
                "value": {
                    "event": "tool_stream",
                    "data": {
                        "call_id": "call-1",
                        "name": "search",
                        "event": {"event": "complete", "result": {"kind": {"kind": "text"}, "success": true, "output": "done", "truncated": false, "metadata": {}, "model_content": []}}
                    }
                }
            }
        }),
        Some("invalid_value"),
    ));
}

fn push_capability_fixtures(fixtures: &mut Vec<Fixture>) {
    fixtures.push(fixture(
        "capability-meta-valid",
        FixtureKind::Valid,
        "EchoAgentCapability",
        "initialize._meta payload a Host publishes for the extension profile.",
        serde_json::json!({
            "extension_protocol_version": 1,
            "contract_digest": "sha256:0000000000000000000000000000000000000000000000000000000000000000",
            "source_contract_digest": "sha256:1111111111111111111111111111111111111111111111111111111111111111",
            "features": ["mcp", "subagent"],
            "capabilities": [
                {"capability": "runs", "required": true},
                {"capability": "event_replay", "required": false}
            ],
            "limits": {
                "max_message_bytes": "1048576",
                "max_stream_buffer_events": "1024",
                "max_callback_concurrency": 8,
                "callback_timeout": {"seconds": "30", "nanos": 0},
                "max_replay_events": "512",
                "max_structured_output_bytes": "262144",
                "max_outstanding_live_events": "256",
                "max_stream_buffer_bytes": "4194304",
                "max_replay_bytes": "4194304",
                "max_open_handles": "512",
                "max_registered_extensions": "64",
                "max_extension_descriptor_bytes": "65536",
                "max_extension_payload_bytes": "1048576",
                "max_extension_stream_bytes": "262144",
                "max_inflight_extension_invocations": "8",
                "max_facade_resources": "256",
                "max_facade_streams": "128",
                "max_facade_page_items": "512",
                "max_facade_operation_args": "64"
            }
        }),
        None,
    ));
    fixtures.push(fixture(
        "capability-unsorted-features-invalid",
        FixtureKind::Invalid,
        "EchoAgentCapability",
        "Feature sets must be sorted/deduplicated for deterministic negotiation.",
        serde_json::json!({
            "extension_protocol_version": 1,
            "contract_digest": "sha256:0",
            "source_contract_digest": "sha256:1111111111111111111111111111111111111111111111111111111111111111",
            "features": ["subagent", "mcp"],
            "capabilities": [{"capability": "runs", "required": true}],
            "limits": {
                "max_message_bytes": "1",
                "max_stream_buffer_events": "1",
                "max_callback_concurrency": 1,
                "callback_timeout": {"seconds": "0", "nanos": 1},
                "max_replay_events": "1",
                "max_structured_output_bytes": "1",
                "max_outstanding_live_events": "1",
                "max_stream_buffer_bytes": "1",
                "max_replay_bytes": "1",
                "max_open_handles": "1",
                "max_registered_extensions": "1",
                "max_extension_descriptor_bytes": "1",
                "max_extension_payload_bytes": "1",
                "max_extension_stream_bytes": "1",
                "max_inflight_extension_invocations": "1",
                "max_facade_resources": "1",
                "max_facade_streams": "1",
                "max_facade_page_items": "1",
                "max_facade_operation_args": "1"
            }
        }),
        Some("invalid_value"),
    ));
}

fn push_hello_fixtures(fixtures: &mut Vec<Fixture>) {
    fixtures.push(fixture(
        "hello-client-valid",
        FixtureKind::Valid,
        "EchoAgentClientHello",
        "clientCapabilities._meta payload requesting Extended mode.",
        serde_json::json!({
            "extension_protocol_version": 1,
            "contract_digest": "sha256:0000000000000000000000000000000000000000000000000000000000000000",
            "source_contract_digest": "sha256:1111111111111111111111111111111111111111111111111111111111111111",
            "required_features": ["mcp"],
            "required_capabilities": ["runs"]
        }),
        None,
    ));
    fixtures.push(fixture(
        "hello-duplicate-capability-invalid",
        FixtureKind::Invalid,
        "EchoAgentClientHello",
        "Required capabilities must be unique.",
        serde_json::json!({
            "extension_protocol_version": 1,
            "contract_digest": "sha256:0000000000000000000000000000000000000000000000000000000000000000",
            "source_contract_digest": "sha256:1111111111111111111111111111111111111111111111111111111111111111",
            "required_features": [],
            "required_capabilities": ["runs", "runs"]
        }),
        Some("invalid_value"),
    ));
}

fn push_agent_config_fixtures(fixtures: &mut Vec<Fixture>) {
    fixtures.push(fixture(
        "agent-config-host-default-valid",
        FixtureKind::Valid,
        "AgentCreateRequest",
        "Bind the Host default definition; no credential crosses the wire.",
        serde_json::json!({
            "config": {"variant": "host_default"}
        }),
        None,
    ));
    fixtures.push(fixture(
        "agent-config-explicit-env-credential-valid",
        FixtureKind::Valid,
        "AgentCreateRequest",
        "Explicit construction with environment credential sourcing.",
        serde_json::json!({
            "config": {
                "variant": "explicit",
                "config_version": 1,
                "model": {
                    "provider": "openai",
                    "name": "g-test",
                    "base_url": "https://api.example.com/v1/chat/completions",
                    "api_protocol": "chat_completions",
                    "credential": {"source": "env", "variable": "ECHO_MODEL_TOKEN"}
                },
                "agent": {
                    "name": "worker",
                    "system_prompt": "Do the task.",
                    "max_iterations": 8
                }
            },
            "idempotency_id": "cli-agent-1"
        }),
        None,
    ));
    fixtures.push(fixture(
        "agent-config-unsupported-knob-invalid",
        FixtureKind::Invalid,
        "AgentCreateRequest",
        "Unsupported builder knobs fail closed via deny_unknown_fields.",
        serde_json::json!({
            "config": {
                "variant": "explicit",
                "config_version": 1,
                "model": {
                    "provider": "openai",
                    "name": "g-test",
                    "base_url": "https://api.example.com/v1/chat/completions",
                    "api_protocol": "chat_completions"
                },
                "agent": {
                    "name": "worker",
                    "system_prompt": "Do the task.",
                    "max_iterations": 8,
                    "enable_memory": true
                }
            }
        }),
        Some("invalid_value"),
    ));
}

fn push_run_fixtures(fixtures: &mut Vec<Fixture>) {
    fixtures.push(fixture(
        "run-input-chat-valid",
        FixtureKind::Valid,
        "RunInput",
        "Chat runs carry exactly one typed text message.",
        serde_json::json!({"kind": "chat", "text": "Summarize the report."}),
        None,
    ));
    fixtures.push(fixture(
        "run-input-execute-valid",
        FixtureKind::Valid,
        "RunInput",
        "Execute runs carry the task directive.",
        serde_json::json!({"kind": "execute", "task": "run the benchmark"}),
        None,
    ));
    fixtures.push(fixture(
        "run-input-execute-message-valid",
        FixtureKind::Valid,
        "RunInput",
        "Execute runs can carry the lossless provider-neutral message shape.",
        serde_json::json!({
            "kind": "execute_message",
            "message": {
                "role": "user",
                "content": {"kind": "string", "value": "run the benchmark"}
            }
        }),
        None,
    ));
    fixtures.push(fixture(
        "run-input-empty-text-invalid",
        FixtureKind::Invalid,
        "RunInput",
        "Empty turn input cannot start a run.",
        serde_json::json!({"kind": "chat", "text": ""}),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "run-terminal-completed-valid",
        FixtureKind::Valid,
        "RunTerminal",
        "A completed terminal carries the optional final answer.",
        serde_json::json!({"status": "completed", "final_answer": "done"}),
        None,
    ));
    fixtures.push(fixture(
        "run-terminal-failed-valid",
        FixtureKind::Valid,
        "RunTerminal",
        "A failed terminal carries the lossless framework failure.",
        serde_json::json!({
            "status": "failed",
            "failure": {
                "category": "llm",
                "terminal_kind": "failed",
                "retryable": true,
                "code": "llm_network",
                "http_status": 503,
                "message": "connection reset by peer"
            }
        }),
        None,
    ));
    fixtures.push(fixture(
        "run-receipt-completed-valid",
        FixtureKind::Valid,
        "RunReceiptWire",
        "Receipt counters use lossless integer strings.",
        serde_json::json!({
            "turn_id": "run-7",
            "outcome": "completed",
            "delivery": "delivered",
            "final_answer": "done",
            "final_message_id": "msg-7",
            "prompt_tokens": "120",
            "completion_tokens": "48",
            "llm_calls": "2",
            "compaction_count": "0",
            "last_event_sequence": "14",
            "elapsed_ms": "1834"
        }),
        None,
    ));
    fixtures.push(fixture(
        "run-receipt-delivery-failed",
        FixtureKind::Valid,
        "RunReceiptWire",
        "Execution completion and delivery failure remain independently observable.",
        serde_json::json!({
            "turn_id": "run-8",
            "outcome": "completed",
            "delivery": "failed",
            "delivery_error": {
                "category": "io",
                "terminal_kind": "failed",
                "retryable": true,
                "code": "delivery",
                "message": "projection unavailable"
            },
            "final_answer": "done",
            "prompt_tokens": "120",
            "completion_tokens": "48",
            "llm_calls": "2",
            "compaction_count": "0",
            "last_event_sequence": "14",
            "elapsed_ms": "1834"
        }),
        None,
    ));
    fixtures.push(fixture(
        "run-recovered-interrupted-valid",
        FixtureKind::Valid,
        "RecoveredRunWire",
        "Interrupted runs expose fresh-generation handles without terminal.",
        serde_json::json!({
            "run": {"id": "run-9", "generation": "4", "kind": "run"},
            "stream": {"id": "stream-9", "generation": "4", "kind": "stream"},
            "status": "interrupted",
            "last_sequence": "21"
        }),
        None,
    ));
}

fn push_channel_forward_fixtures(fixtures: &mut Vec<Fixture>) {
    let session = WireHandle {
        id: "session-channel-forward".to_string(),
        generation: WireU64::from_u64(7),
        kind: HandleKind::Session,
    };
    let manager = WireHandle {
        id: "manager-channel-forward".to_string(),
        generation: WireU64::from_u64(7),
        kind: HandleKind::FacadeResource,
    };
    let stream = WireHandle {
        id: "stream-channel-forward".to_string(),
        generation: WireU64::from_u64(7),
        kind: HandleKind::Stream,
    };
    let inbound = serde_json::json!({
        "channel_id":"channel-中文", "sender_id":"sender", "chat_id":"chat", "chat_type":"direct",
        "text":"入站🌊", "message_id":"message", "timestamp":"18446744073709551615",
        "attachments":[{"kind":"image","data_base64":"AP9BgA==","filename":""}]
    });
    let outbound = serde_json::json!({
        "channel_id":"channel-中文", "to":"chat", "chat_type":"group", "text":"回复🌊", "reply_to":"",
        "attachments":[{"kind":"file","data_base64":"AP9BgA==","filename":null}]
    });
    for (name, operation, message) in [
        ("handle", "channels.handler.handle", Some(&inbound)),
        (
            "handle-stream",
            "channels.handler.handle_stream",
            Some(&inbound),
        ),
        ("reply", "channels.handler.reply", Some(&outbound)),
        ("stream-next", "channels.stream.next", None),
        ("stream-cancel", "channels.stream.cancel", None),
        ("stream-close", "channels.stream.close", None),
    ] {
        let arguments = if let Some(message) = message {
            // These literal DTO samples only use the supported closed JSON projection.
            let Ok(message) = WireValue::from_json(message.clone()) else {
                continue;
            };
            vec![
                WireValue::Handle(manager.clone()),
                WireValue::String("channel-中文".to_string()),
                message,
            ]
        } else {
            vec![WireValue::Handle(stream.clone())]
        };
        let request = FeatureOperationRequest {
            operation: operation.to_string(),
            signature_digest: crate::facade::family_operation_signature_digest(
                "channels", operation,
            ),
            handle: Some(session.clone()),
            arguments,
        };
        let Ok(payload) = serde_json::to_value(request) else {
            continue;
        };
        fixtures.push(fixture(
            &format!("channel-forward-{name}-valid"), FixtureKind::Valid, "FeatureOperationRequest",
            "Original Session and complete generation-fenced manager/stream addresses consume the existing channels handler contract.",
            payload, None,
        ));
    }
}

fn push_facade_fixtures(fixtures: &mut Vec<Fixture>) {
    fixtures.push(fixture(
        "facade-operation-request-valid",
        FixtureKind::Valid,
        "FeatureOperationRequest",
        "Exact facade identity plus matching sha256 signature digest, an optional receiver handle and typed wire arguments.",
        serde_json::json!({
            "operation": "echo_agent::evolution::review::ReviewEngine",
            "signature_digest": "sha256:0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
            "handle": {
                "id": "facade-memory-ns-1",
                "generation": "1",
                "kind": "facade_resource"
            },
            "arguments": [
                {"kind": "string", "value": "namespace-a"},
                {"kind": "u64", "value": "42"}
            ]
        }),
        None,
    ));
    fixtures.push(fixture(
        "facade-operation-empty-invalid",
        FixtureKind::Invalid,
        "FeatureOperationRequest",
        "Blank operation identities are rejected before any handler runs.",
        serde_json::json!({
            "operation": "   ",
            "signature_digest": "sha256:0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "facade-operation-wildcard-invalid",
        FixtureKind::Invalid,
        "FeatureOperationRequest",
        "Wildcard operations are never executable routes; the catalog only freezes exact identities.",
        serde_json::json!({
            "operation": "_echo_agent/task/*",
            "signature_digest": "sha256:0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "facade-operation-signature-invalid",
        FixtureKind::Invalid,
        "FeatureOperationRequest",
        "Signature digests must be sha256 plus 64 hex characters.",
        serde_json::json!({
            "operation": "echo_agent::evolution::review::ReviewEngine",
            "signature_digest": "sha256:zz"
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "facade-failure-detail-valid",
        FixtureKind::Valid,
        "FacadeFailureDetail",
        "Typed admission-failure facts: operation identity, expected receiver kind and the missing feature.",
        serde_json::json!({
            "operation": "echo_agent::eval::runner::EvalRunner",
            "signature_digest": "sha256:0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
            "receiver_kind": "facade_resource",
            "required_feature": "eval"
        }),
        None,
    ));
    fixtures.push(fixture(
        "facade-failure-detail-digest-invalid",
        FixtureKind::Invalid,
        "FacadeFailureDetail",
        "A claimed digest inside failure details must still be a sha256 digest.",
        serde_json::json!({
            "operation": "echo_agent::eval::runner::EvalRunner",
            "signature_digest": "not-a-digest"
        }),
        Some("invalid_value"),
    ));
    fixtures.push(fixture(
        "facade-resource-handle-valid",
        FixtureKind::Valid,
        "WireHandle",
        "A facade resource handle (memory namespace, workflow, journal, ledger, ...).",
        serde_json::json!({
            "id": "facade-workflow-wf-7",
            "generation": "3",
            "kind": "facade_resource"
        }),
        None,
    ));
}

fn push_boundary_fixtures(fixtures: &mut Vec<Fixture>) {
    fixtures.push(fixture(
        "boundary-standard-method-rejected-invalid",
        FixtureKind::Invalid,
        "MethodCatalog",
        "Standard ACP method names cannot be re-registered as extension methods.",
        serde_json::json!({"method": "session/prompt"}),
        Some("invalid_request"),
    ));
    fixtures.push(fixture(
        "boundary-unnegotiated-method-rejected-invalid",
        FixtureKind::Invalid,
        "MethodCatalog",
        "Methods outside _echo_agent/* are not part of the extension contract.",
        serde_json::json!({"method": "run/start"}),
        Some("invalid_request"),
    ));
}

fn push_governance_fixtures(fixtures: &mut Vec<Fixture>) {
    fixtures.push(fixture("task-store-execution-cas-opt-in-valid", FixtureKind::Valid,
        "ExtensionRegisterRequest", "A revisioned task store explicitly declares execution CAS before runtime dispatch.",
        serde_json::json!({"kind":"agent_component","implementation_id":"task-store","descriptor":{
            "kind":"agent_component","descriptor_version":1,"component":"revisioned_task_store","name":"task-store",
            "capabilities":{"execution_cas_v1":true}}}), None));
    fixtures.push(fixture("task-store-execution-cas-string-invalid", FixtureKind::Invalid,
        "ExtensionRegisterRequest", "A string cannot opt a store into execution CAS.",
        serde_json::json!({"kind":"agent_component","implementation_id":"task-store","descriptor":{
            "kind":"agent_component","descriptor_version":1,"component":"revisioned_task_store","name":"task-store",
            "capabilities":{"execution_cas_v1":"true"}}}), Some("invalid_value")));
    fixtures.push(fixture("task-execution-claim-result-null-valid", FixtureKind::Valid,
        "TaskExecutionWire", "A supplied null result remains distinct from absent output, and the exact claim revision survives.",
        serde_json::json!({"task_id":"任务","status":{"status":"completed"},"retry_count":0,"failure_fingerprint":null,
            "claim":{"claim_id":"claim-1","revision":"9007199254740993","attempt":1,"spec_hash":"digest"},
            "result":{"kind":"null"}}), None));
    fixtures.push(fixture("task-execution-unsafe-claim-revision-invalid", FixtureKind::Invalid,
        "TaskExecutionWire", "A JSON number cannot replace an exact execution claim revision.",
        serde_json::json!({"task_id":"任务","status":{"status":"running"},"retry_count":0,"failure_fingerprint":null,
            "claim":{"claim_id":"claim-1","revision":9007199254740993_u64,"attempt":1,"spec_hash":"digest"}}), Some("invalid_value")));
    fixtures.push(fixture("factory-create-reserved-instance-valid", FixtureKind::Valid,
        "ExtensionInvokeCall", "The reserved child handle identifies the actual constructed object before its descriptor commits.",
        serde_json::json!({"extension":{"id":"factory","generation":"7","kind":"extension"},
            "invocation_id":"create-1","invocation":{"operation":"factory_create_agent","input":{
                "instance":{"id":"child","generation":"7","kind":"extension"},
                "model":"model","name":"agent","system_prompt":"prompt","tool_count":"0"}},
            "deadline":{"seconds":"20","nanos":0}}), None));
    fixtures.push(fixture(
        "factory-create-missing-instance-invalid",
        FixtureKind::Invalid,
        "ExtensionInvokeCall",
        "A descriptor without construction-instance identity cannot bind the created object.",
        serde_json::json!({"extension":{"id":"factory","generation":"7","kind":"extension"},
            "invocation_id":"create-1","invocation":{"operation":"factory_create_agent","input":{
                "model":"model","name":"agent","system_prompt":"prompt","tool_count":"0"}},
            "deadline":{"seconds":"20","nanos":0}}),
        Some("invalid_value"),
    ));
    fixtures.push(fixture("tool-result-authoritative-effects-valid", FixtureKind::Valid,
        "ToolResultWire", "Tool effects preserve producer facts, Unicode and exact failure counts.",
        serde_json::json!({"kind":{"kind":"text"},"success":true,"output":"已完成 🧪","truncated":false,
            "effects":[{"effect":"file_read","path":"文档/计划.md"},
                {"effect":"test_run","command":"cargo test","passed":false,"failure_count":"9007199254740993"}]}), None));
    fixtures.push(fixture(
        "tool-result-unknown-effect-invalid",
        FixtureKind::Invalid,
        "ToolResultWire",
        "Unknown execution facts cannot silently disappear at a bridge boundary.",
        serde_json::json!({"kind":{"kind":"text"},"success":true,"output":"done","truncated":false,
            "effects":[{"effect":"unknown_effect","path":"x"}]}),
        Some("invalid_value"),
    ));
    fixtures.push(fixture("transcript-projection-settlement-observation-valid", FixtureKind::Valid,
        "AgentEventWire", "Transcript settlement is a typed framework observation before the invocation terminal.",
        serde_json::json!({"event":"transcript_projection_settlement","data":{"settlement":{
            "status":"deferred","operation_id":"projection-1","conversation_id":"会话","generation_id":"generation-1",
            "attempt":2,"error_class":"outcome_unknown","detail":"receipt lookup required"}}}), None));
    fixtures.push(fixture("extension-factory-instance-origin-valid", FixtureKind::Valid,
        "ExtensionInvokeCall", "A returned Agent instance retains its own handle and exact original factory.",
        serde_json::json!({"extension":{"id":"child","generation":"7","kind":"extension"},
            "factory_origin":{"id":"factory","generation":"7","kind":"extension"},
            "invocation_id":"invocation","invocation":{"operation":"agent_execute","input":{"task":"任务"}},
            "deadline":{"seconds":"20","nanos":0}}), None));
    fixtures.push(fixture("extension-callback-interrupted-canonical-id-valid", FixtureKind::Valid,
        "ExtensionInvocation", "Interruption preserves admitted input and canonical tool identity without fabricating a start.",
        serde_json::json!({"operation":"callback_on_tool_interrupted","input":{"agent":"智能体","call_id":"call-1",
            "tool":"edit","input":{"kind":"null"},"error":"取消"}}), None));
    fixtures.push(fixture("managed-projection-authority-u64-valid", FixtureKind::Valid,
        "ConversationProjectionAuthorityWire", "Managed revisions and epochs are decimal strings beyond the JavaScript safe integer range.",
        serde_json::json!({"conversation_id":"会话","epoch":"9007199254740993","revision":"18446744073709551615",
            "lifecycle":"live","delete_receipt_retention_floor_epoch":"0"}), None));
    fixtures.push(fixture(
        "managed-deadline-context-i64-valid",
        FixtureKind::Valid,
        "PersistenceCallContextWire",
        "Absolute deadlines remain typed i64 decimal strings.",
        serde_json::json!({"absolute_deadline_unix_ms":"9223372036854775807"}),
        None,
    ));
    fixtures.push(fixture(
        "managed-deadline-context-number-invalid",
        FixtureKind::Invalid,
        "PersistenceCallContextWire",
        "A JSON number cannot replace an exact persistence deadline.",
        serde_json::json!({"absolute_deadline_unix_ms":9223372036854775807_i64}),
        Some("invalid_value"),
    ));
    fixtures.push(fixture("delivery-complete-claim-valid", FixtureKind::Valid,
        "DeliveryClaimWire", "Delivery continuation carries the exact claim returned by the framework ledger.",
        serde_json::json!({"message_id":"消息","route":"inbox","payload":{"text":"数据"},"attempt_id":"attempt-1",
            "attempt":1,"claimed_at":"2026-10-12T00:00:00Z"}), None));
    fixtures.push(fixture(
        "delivery-id-only-claim-invalid",
        FixtureKind::Invalid,
        "DeliveryClaimWire",
        "Message identity alone cannot authorize a later delivery attempt.",
        serde_json::json!("消息"),
        Some("invalid_value"),
    ));
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn schema_is_deterministic() {
        let first = canonical_json(&build_extension_schema_doc());
        let second = canonical_json(&build_extension_schema_doc());
        assert_eq!(first, second);
        assert!(!first.is_empty());
    }

    #[test]
    fn schema_respects_acp_boundaries() {
        let doc = build_extension_schema_doc();
        assert!(validate_schema_boundaries(&doc).is_empty());
    }

    #[test]
    fn digest_is_stable_sha256() {
        let digest = extension_contract_digest();
        assert!(digest.starts_with("sha256:"));
        assert_eq!(digest.len(), "sha256:".len() + 64);
        assert_eq!(digest, extension_contract_digest());
    }

    #[test]
    fn fixture_names_are_unique() {
        let fixtures = all_fixtures();
        let names: Vec<&str> = fixtures.iter().map(|f| f.name.as_str()).collect();
        let mut sorted = names.clone();
        sorted.sort();
        sorted.dedup();
        assert_eq!(names.len(), sorted.len());
    }

    #[test]
    fn fixtures_cover_required_families() {
        let fixtures = all_fixtures();
        let targets: Vec<&str> = fixtures.iter().map(|f| f.target.as_str()).collect();
        for target in [
            "WireU64",
            "WirePath",
            "WireBytes",
            "WireValue",
            "WireHandle",
            "EchoSdkError",
            "WireEventEnvelope",
            "ReplayRequest",
            "ReplayResponse",
            "GapNotification",
            "EventAckNotification",
            "EchoAgentCapability",
            "EchoAgentClientHello",
            "AgentCreateRequest",
            "RunInput",
            "RunTerminal",
            "RunReceiptWire",
            "RecoveredRunWire",
            "ExtensionInvokeOutcome",
            "ExtensionStreamEvent",
            "MethodCatalog",
        ] {
            assert!(targets.contains(&target), "fixtures missing {target}");
        }
        let kinds: Vec<FixtureKind> = all_fixtures().iter().map(|f| f.kind).collect();
        assert!(kinds.contains(&FixtureKind::Valid));
        assert!(kinds.contains(&FixtureKind::Invalid));
    }
}
