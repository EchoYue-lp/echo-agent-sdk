use echo_agent::config::FrameworkConfig;
use echo_agent::error::ReactError;
use echo_agent::llm::{LlmClient, LlmConfig};
#[cfg(feature = "sdk-core-profile")]
use echo_sdk_protocol::methods::{
    MAX_EXTENSION_DESCRIPTOR_BYTES, MAX_EXTENSION_PAYLOAD_BYTES, MAX_EXTENSION_STREAM_CHUNK_BYTES,
};
use serde::Deserialize;
use std::io::Read as _;
use std::path::{Path, PathBuf};
use std::sync::Arc;

use crate::HostError;

/// Host configuration schema version accepted by this source revision.
pub const HOST_CONFIG_SCHEMA_VERSION: u32 = 1;
/// Maximum number of bytes read from one Host configuration file.
pub const MAX_HOST_CONFIG_BYTES: u64 = 1024 * 1024;

/// Versioned, product-neutral configuration for `echo-agent-sdk-host`.
///
/// This type intentionally does not implement `Debug`: `FrameworkConfig`
/// contains an optional resolved credential.
#[derive(Clone, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SdkHostConfig {
    /// Version of this Host configuration document.
    pub schema_version: u32,
    /// Product-neutral framework configuration used to construct each Session Agent.
    pub default_agent: FrameworkConfig,
    /// Optional environment variable containing the model credential.
    #[serde(default)]
    pub api_key_env: Option<String>,
    /// Optional negotiated `_echo_agent/*` core profile. Absent means the
    /// Host serves the standard ACP profile only and never advertises the
    /// extension; present, it must point at an explicit absolute state root.
    #[serde(default)]
    pub sdk_profile: Option<SdkProfileConfig>,
}

/// Explicit configuration for the negotiated core profile. The state root is
/// deliberately an absolute path that the operator wrote down: the Host never
/// searches the working directory, home, `.env`, or product configuration for
/// a default (design §16 — persistence is only ever opt-in and visible).
#[derive(Clone, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SdkProfileConfig {
    /// Absolute directory owning generation counters, run journals and the
    /// run index. Must be a path; created on demand.
    pub state_root: PathBuf,
    /// Resource bounds; every field is validated positive.
    #[serde(default)]
    pub limits: SdkProfileLimits,
}

/// Bounds enforced by the core profile (mirrors the negotiated
/// `EchoLimits`-adjacent host-side knobs, design §10.2/§16).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct SdkProfileLimits {
    /// Maximum bytes of one newline-delimited stdin frame; larger frames
    /// fail the connection before any business side effect.
    pub max_frame_bytes: u64,
    /// Maximum serialized bytes of one live event delivery.
    pub max_event_bytes: usize,
    /// Maximum not-yet-acknowledged live events per stream before the single
    /// gap notification pauses live delivery.
    pub max_outstanding_live_events: usize,
    /// Maximum events returned by one replay request.
    pub max_replay_events: usize,
    /// Maximum cumulative serialized bytes returned by one replay request.
    pub max_replay_bytes: usize,
    /// Maximum simultaneously open Agent/Session/Run/Stream handles.
    pub max_open_handles: usize,
    /// Maximum simultaneously registered extension implementations. Extension
    /// registrations are connection-owned and never persist across a Host
    /// restart or reconnect.
    pub max_registered_extensions: usize,
    /// Maximum serialized bytes of one extension registration descriptor.
    pub max_extension_descriptor_bytes: usize,
    /// Maximum serialized bytes of one extension invocation input/result.
    pub max_extension_payload_bytes: usize,
    /// Maximum serialized bytes of one extension stream chunk payload.
    pub max_extension_stream_bytes: usize,
    /// Maximum simultaneously in-flight extension reverse invocations.
    pub max_extension_invocations: usize,
    /// Maximum concurrently executing extension reverse callbacks (the
    /// connection-level lease concurrency).
    pub max_callback_concurrency: usize,
    /// Default reverse-callback deadline in seconds when a registration does
    /// not declare its own timeout.
    pub callback_timeout_secs: u64,
    /// Seconds allowed for the bounded shutdown chain.
    pub shutdown_timeout_secs: u64,
    /// Maximum simultaneously open facade resources (memory namespaces,
    /// workflows, journals, ledgers, run stores, MCP/A2A clients, …).
    pub max_facade_resources: usize,
    /// Maximum simultaneously open facade event/data streams.
    pub max_facade_streams: usize,
    /// Maximum items returned by one paginated facade query.
    pub max_facade_page_items: usize,
    /// Maximum typed arguments accepted by one facade family operation.
    pub max_facade_operation_args: usize,
}

impl Default for SdkProfileLimits {
    fn default() -> Self {
        Self {
            max_frame_bytes: 1024 * 1024,
            max_event_bytes: 1024 * 1024,
            max_outstanding_live_events: 128,
            max_replay_events: 512,
            max_replay_bytes: 8 * 1024 * 1024,
            max_open_handles: 512,
            max_registered_extensions: 64,
            max_extension_descriptor_bytes: 65_536,
            max_extension_payload_bytes: 1_048_576,
            max_extension_stream_bytes: 262_144,
            max_extension_invocations: 16,
            max_callback_concurrency: 8,
            callback_timeout_secs: 30,
            shutdown_timeout_secs: 5,
            max_facade_resources: 256,
            max_facade_streams: 128,
            max_facade_page_items: 512,
            max_facade_operation_args: 64,
        }
    }
}

impl SdkProfileLimits {
    fn validate(&self) -> Result<(), HostError> {
        if self.max_frame_bytes == 0
            || self.max_event_bytes == 0
            || self.max_outstanding_live_events == 0
            || self.max_replay_events == 0
            || self.max_replay_bytes == 0
            || self.max_open_handles == 0
            || self.max_registered_extensions == 0
            || self.max_extension_descriptor_bytes == 0
            || self.max_extension_payload_bytes == 0
            || self.max_extension_stream_bytes == 0
            || self.max_extension_invocations == 0
            || self.max_callback_concurrency == 0
            || self.callback_timeout_secs == 0
            || self.shutdown_timeout_secs == 0
            || self.max_facade_resources == 0
            || self.max_facade_streams == 0
            || self.max_facade_page_items == 0
            || self.max_facade_operation_args == 0
            || self.max_callback_concurrency > u32::MAX as usize
        {
            return Err(HostError::Config(
                "sdk_profile.limits values must all be positive".to_string(),
            ));
        }
        #[cfg(feature = "sdk-core-profile")]
        if self.max_extension_descriptor_bytes > MAX_EXTENSION_DESCRIPTOR_BYTES
            || self.max_extension_payload_bytes > MAX_EXTENSION_PAYLOAD_BYTES
            || self.max_extension_stream_bytes > MAX_EXTENSION_STREAM_CHUNK_BYTES
        {
            return Err(HostError::Config(
                "sdk_profile extension limits exceed the protocol bounds".to_string(),
            ));
        }
        Ok(())
    }
}

impl SdkProfileConfig {
    pub(crate) fn validate(&self) -> Result<(), HostError> {
        if !self.state_root.is_absolute() {
            return Err(HostError::Config(
                "sdk_profile.state_root must be an absolute path".to_string(),
            ));
        }
        self.limits.validate()
    }
}

#[allow(dead_code)]
pub(crate) struct PreparedHostConfig {
    pub framework: FrameworkConfig,
    pub llm_client: Arc<dyn LlmClient>,
    pub sdk_profile: Option<SdkProfileConfig>,
}

impl SdkHostConfig {
    /// Read and deserialize a bounded JSON configuration file.
    pub fn from_path(path: impl AsRef<Path>) -> Result<Self, HostError> {
        let path = path.as_ref();
        let file = std::fs::File::open(path).map_err(|error| HostError::ConfigFile {
            path: path.to_path_buf(),
            message: error.to_string(),
        })?;
        let metadata = file.metadata().map_err(|error| HostError::ConfigFile {
            path: path.to_path_buf(),
            message: error.to_string(),
        })?;
        if !metadata.is_file() {
            return Err(HostError::Config(
                "Host config path must be a regular file".to_string(),
            ));
        }
        if metadata.len() > MAX_HOST_CONFIG_BYTES {
            return Err(HostError::Config(format!(
                "Host config exceeds the {MAX_HOST_CONFIG_BYTES} byte limit"
            )));
        }
        let bytes = read_bounded(file, path)?;
        serde_json::from_slice(&bytes)
            .map_err(|error| HostError::Config(format!("invalid Host config JSON: {error}")))
    }

    /// Validate the configuration and construct its model client without starting ACP.
    pub fn validate(self) -> Result<(), HostError> {
        let prepared = self.prepare()?;
        drop(prepared);
        Ok(())
    }

    pub(crate) fn prepare(self) -> Result<PreparedHostConfig, HostError> {
        self.validate_with_env(|name| std::env::var(name).map_err(|error| error.to_string()))
    }

    pub(crate) fn validate_with_env(
        mut self,
        read_env: impl FnOnce(&str) -> Result<String, String>,
    ) -> Result<PreparedHostConfig, HostError> {
        if self.schema_version != HOST_CONFIG_SCHEMA_VERSION {
            return Err(HostError::Config(format!(
                "unsupported Host config schema_version {}; expected {HOST_CONFIG_SCHEMA_VERSION}",
                self.schema_version
            )));
        }
        if let Some(profile) = &self.sdk_profile {
            profile.validate()?;
        }
        validate_agent_settings(&self.default_agent)?;
        let api_protocol = self.default_agent.model.api_protocol.ok_or_else(|| {
            HostError::Config("default_agent.model.api_protocol is required".to_string())
        })?;
        let base_url = self.default_agent.model.get_base_url().ok_or_else(|| {
            HostError::Config("default_agent.model.base_url is required".to_string())
        })?;
        let model = self.default_agent.model.get_model_name();
        if model.trim().is_empty() {
            return Err(HostError::Config(
                "default_agent.model.name must not be empty".to_string(),
            ));
        }
        let provider = self.default_agent.model.provider.trim().to_string();
        if provider.is_empty() {
            return Err(HostError::Config(
                "default_agent.model.provider must not be empty".to_string(),
            ));
        }
        let inline_token = self.default_agent.model.get_auth_token();
        let env_name = self.api_key_env.take().map(|name| name.trim().to_string());
        if env_name.as_deref() == Some("") {
            return Err(HostError::Config(
                "api_key_env must not be empty when provided".to_string(),
            ));
        }
        if inline_token.is_some() && env_name.is_some() {
            return Err(HostError::Config(
                "default_agent.model.auth_token and api_key_env are mutually exclusive".to_string(),
            ));
        }
        let api_key = if let Some(token) = inline_token {
            token
        } else if let Some(name) = env_name {
            read_env(&name).map_err(|_| {
                HostError::Config(format!(
                    "credential environment variable {name} is unavailable"
                ))
            })?
        } else {
            String::new()
        };
        self.default_agent.model.auth_token = None;
        let llm_config = LlmConfig::for_provider(provider, base_url, api_key, model, api_protocol)
            .map_err(framework_error)?;
        let llm_client: Arc<dyn LlmClient> =
            Arc::from(llm_config.build_client().map_err(framework_error)?);
        Ok(PreparedHostConfig {
            framework: self.default_agent,
            llm_client,
            sdk_profile: self.sdk_profile,
        })
    }
}

fn read_bounded(reader: impl std::io::Read, path: &Path) -> Result<Vec<u8>, HostError> {
    let mut bytes = Vec::new();
    reader
        .take(MAX_HOST_CONFIG_BYTES.saturating_add(1))
        .read_to_end(&mut bytes)
        .map_err(|error| HostError::ConfigFile {
            path: path.to_path_buf(),
            message: error.to_string(),
        })?;
    if u64::try_from(bytes.len()).unwrap_or(u64::MAX) > MAX_HOST_CONFIG_BYTES {
        return Err(HostError::Config(format!(
            "Host config exceeds the {MAX_HOST_CONFIG_BYTES} byte limit"
        )));
    }
    Ok(bytes)
}

fn validate_agent_settings(config: &FrameworkConfig) -> Result<(), HostError> {
    if config.agent.name.trim().is_empty() {
        return Err(HostError::Config(
            "default_agent.agent.name must not be empty".to_string(),
        ));
    }
    if config.agent.system_prompt.trim().is_empty() {
        return Err(HostError::Config(
            "default_agent.agent.system_prompt must not be empty".to_string(),
        ));
    }
    if config.agent.max_iterations == 0 {
        return Err(HostError::Config(
            "default_agent.agent.max_iterations must be positive".to_string(),
        ));
    }
    if !config.agent.enable_tools {
        return Err(HostError::Config(
            "default_agent.agent.enable_tools must be true for ACP stdio MCP support".to_string(),
        ));
    }
    // `enable_memory` needs no Host-side gate: the framework's AgentConfig
    // serves it with a plain store in every build (the facade memory family
    // captures that same store); rejecting it per profile only made the
    // config contract drift across feature combinations.
    #[cfg(not(feature = "sdk-extension-bridge"))]
    if config.agent.enable_human_in_loop {
        return Err(HostError::Config(
            "default_agent.agent.enable_human_in_loop requires a later ACP callback profile"
                .to_string(),
        ));
    }
    Ok(())
}

fn framework_error(error: ReactError) -> HostError {
    HostError::Config(error.to_string())
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Command selected from the Host's deliberately small command-line surface.
pub enum HostCommand {
    /// Validate configuration, then serve ACP over stdio.
    Run { config: PathBuf },
    /// Validate configuration and exit without opening ACP stdio.
    CheckConfig { config: PathBuf },
    /// Print command help outside ACP mode.
    Help,
    /// Print the source-built Host crate version outside ACP mode.
    Version,
}

/// Parse Host command-line arguments after the executable name.
pub fn parse_args<I, S>(args: I) -> Result<HostCommand, HostError>
where
    I: IntoIterator<Item = S>,
    S: Into<String>,
{
    let mut args = args.into_iter().map(Into::into);
    let mut config = None;
    let mut check_config = false;
    while let Some(argument) = args.next() {
        match argument.as_str() {
            "--config" => {
                if config.is_some() {
                    return Err(HostError::Argument(
                        "--config may appear only once".to_string(),
                    ));
                }
                let value = args
                    .next()
                    .ok_or_else(|| HostError::Argument("--config requires a path".to_string()))?;
                config = Some(PathBuf::from(value));
            }
            "--check-config" => check_config = true,
            "--help" | "-h" => return Ok(HostCommand::Help),
            "--version" | "-V" => return Ok(HostCommand::Version),
            other => {
                return Err(HostError::Argument(format!(
                    "unknown Host argument: {other}"
                )));
            }
        }
    }
    let config = config.ok_or_else(|| {
        HostError::Argument("--config <path> is required for Host startup".to_string())
    })?;
    if check_config {
        Ok(HostCommand::CheckConfig { config })
    } else {
        Ok(HostCommand::Run { config })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use echo_agent::config::{AgentSettings, ModelConfig};
    use echo_agent::llm::LlmApiProtocol;

    static_assertions::assert_not_impl_any!(SdkHostConfig: serde::Serialize);

    fn config() -> SdkHostConfig {
        SdkHostConfig {
            schema_version: HOST_CONFIG_SCHEMA_VERSION,
            default_agent: FrameworkConfig {
                model: ModelConfig {
                    provider: "local".to_string(),
                    name: "test-model".to_string(),
                    base_url: Some("http://127.0.0.1:11434/v1/chat/completions".to_string()),
                    api_protocol: Some(LlmApiProtocol::ChatCompletions),
                    ..ModelConfig::default()
                },
                agent: AgentSettings {
                    enable_tools: true,
                    ..AgentSettings::default()
                },
            },
            api_key_env: None,
            sdk_profile: None,
        }
    }

    #[test]
    fn valid_local_config_prepares_without_a_secret() {
        assert!(
            config()
                .validate_with_env(|_| Err("unused".to_string()))
                .is_ok()
        );
    }

    #[test]
    fn credential_sources_are_exclusive_and_secret_is_not_in_error() {
        let mut config = config();
        config.default_agent.model.auth_token = Some("sentinel-secret".to_string());
        config.api_key_env = Some("TEST_TOKEN".to_string());
        let error = config
            .validate_with_env(|_| Ok("environment-secret".to_string()))
            .err()
            .map(|error| error.to_string())
            .unwrap_or_default();
        assert!(error.contains("mutually exclusive"));
        assert!(!error.contains("sentinel-secret"));
        assert!(!error.contains("environment-secret"));
    }

    #[test]
    fn blank_environment_credential_name_is_rejected() {
        let mut config = config();
        config.api_key_env = Some("  ".to_string());
        assert!(
            config
                .validate_with_env(|_| Ok("unused".to_string()))
                .is_err()
        );
    }

    #[test]
    fn environment_credential_is_resolved_without_entering_framework_config()
    -> Result<(), HostError> {
        let mut config = config();
        config.api_key_env = Some(" TEST_TOKEN ".to_string());
        let prepared = config.validate_with_env(|name| {
            if name == "TEST_TOKEN" {
                Ok("environment-secret".to_string())
            } else {
                Err("unexpected environment variable".to_string())
            }
        })?;
        assert!(prepared.framework.model.auth_token.is_none());
        Ok(())
    }

    #[test]
    fn schema_and_required_model_fields_fail_fast() {
        let mut wrong_schema = config();
        wrong_schema.schema_version = 2;
        assert!(
            wrong_schema
                .validate_with_env(|_| Err("unused".to_string()))
                .is_err()
        );

        let mut missing_provider = config();
        missing_provider.default_agent.model.provider.clear();
        assert!(
            missing_provider
                .validate_with_env(|_| Err("unused".to_string()))
                .is_err()
        );

        let mut missing_model = config();
        missing_model.default_agent.model.name.clear();
        assert!(
            missing_model
                .validate_with_env(|_| Err("unused".to_string()))
                .is_err()
        );

        let mut missing_endpoint = config();
        missing_endpoint.default_agent.model.base_url = None;
        assert!(
            missing_endpoint
                .validate_with_env(|_| Err("unused".to_string()))
                .is_err()
        );

        let mut missing_protocol = config();
        missing_protocol.default_agent.model.api_protocol = None;
        assert!(
            missing_protocol
                .validate_with_env(|_| Err("unused".to_string()))
                .is_err()
        );

        let mut invalid_endpoint = config();
        invalid_endpoint.default_agent.model.base_url = Some("not a URL".to_string());
        assert!(
            invalid_endpoint
                .validate_with_env(|_| Err("unused".to_string()))
                .is_err()
        );
    }

    #[test]
    fn unsupported_profile_settings_fail_before_stdio() {
        let mut no_tools = config();
        no_tools.default_agent.agent.enable_tools = false;
        assert!(
            no_tools
                .validate_with_env(|_| Err("unused".to_string()))
                .is_err()
        );
        // `enable_memory` is served by the framework in every build (see
        // validate_agent_settings); only human-in-loop stays profile-bound.
        let mut with_memory = config();
        with_memory.default_agent.agent.enable_memory = true;
        assert!(
            with_memory
                .validate_with_env(|_| Err("unused".to_string()))
                .is_ok()
        );
        #[cfg(not(feature = "sdk-extension-bridge"))]
        {
            let mut human_loop = config();
            human_loop.default_agent.agent.enable_human_in_loop = true;
            assert!(
                human_loop
                    .validate_with_env(|_| Err("unused".to_string()))
                    .is_err()
            );
        }
    }

    #[test]
    fn cli_requires_one_explicit_config_path() {
        assert!(parse_args(Vec::<String>::new()).is_err());
        assert!(parse_args(["--config", "host.json", "--config", "other.json"]).is_err());
        assert_eq!(
            parse_args(["--config", "host.json", "--check-config"]),
            Ok(HostCommand::CheckConfig {
                config: PathBuf::from("host.json")
            })
        );
    }

    #[test]
    fn checked_in_example_is_current_and_valid() -> Result<(), Box<dyn std::error::Error>> {
        let parsed: SdkHostConfig = serde_json::from_str(include_str!("../config.example.json"))?;
        parsed.validate_with_env(|_| Err("unused".to_string()))?;
        Ok(())
    }

    #[test]
    fn unknown_top_level_config_field_is_rejected() {
        let encoded = r#"{
            "schema_version": 1,
            "default_agent": {},
            "unexpected": true
        }"#;
        assert!(serde_json::from_str::<SdkHostConfig>(encoded).is_err());
    }

    #[test]
    fn bounded_reader_stops_after_limit_plus_one() {
        let error = read_bounded(std::io::repeat(b'x'), Path::new("streaming-config"));
        assert!(matches!(error, Err(HostError::Config(message)) if message.contains("byte limit")));
    }

    #[test]
    fn config_path_must_be_a_regular_file() -> Result<(), Box<dyn std::error::Error>> {
        let directory = tempfile::tempdir()?;
        assert!(SdkHostConfig::from_path(directory.path()).is_err());
        Ok(())
    }
}
