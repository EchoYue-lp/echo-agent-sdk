//! ChannelManager — one lifecycle authority per original IM channel plugin.

use super::types::{
    ChannelCapabilities, ChannelPlugin, InboundMessage, MessageHandler, OutboundMessage,
};
use async_trait::async_trait;
use echo_core::agent::CancellationToken;
use echo_core::error::{ChannelError, ReactError, Result};
use futures::future::BoxFuture;
use futures::stream::{BoxStream, Stream, StreamExt};
use std::collections::HashMap;
use std::future::Future;
use std::pin::Pin;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{Arc, Mutex as StdMutex};
use std::task::{Context, Poll};
use tokio::sync::{Notify, RwLock, mpsc, oneshot};
use tracing::{info, warn};

/// Identity-bearing lifecycle result for one channel.
pub struct ChannelLifecycleResult {
    pub channel_id: String,
    pub result: Result<()>,
}

/// An owned stream and the exact admitted invocation's cancellation signal.
///
/// Adapters with their own bounded output buffer must also watch this token
/// while sending, so entry stop cannot leave them blocked on an old item.
/// It is a generation child: cancelling it never cancels a sibling invocation.
pub struct ChannelMessageStream {
    pub stream: BoxStream<'static, Result<OutboundMessage>>,
    pub cancellation: CancellationToken,
}

impl ChannelMessageStream {
    pub fn into_parts(
        self,
    ) -> (
        BoxStream<'static, Result<OutboundMessage>>,
        CancellationToken,
    ) {
        (self.stream, self.cancellation)
    }
}

impl Stream for ChannelMessageStream {
    type Item = Result<OutboundMessage>;

    fn poll_next(mut self: Pin<&mut Self>, context: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.stream.as_mut().poll_next(context)
    }
}

fn channel_error(message: String) -> ReactError {
    ReactError::Channel(Box::new(ChannelError::Other(message)))
}

fn invocation_cancelled() -> ReactError {
    channel_error("channel handler invocation cancelled".into())
}

fn invocation_inactive(message: &str) -> ReactError {
    ReactError::Channel(Box::new(ChannelError::InvalidConfig(message.to_string())))
}

// These receipts extend the original entry, following SessionStreamReceipt's
// short synchronous admission/drop accounting. They never own another handler.
struct InvocationGeneration {
    admission: StdMutex<InvocationAdmission>,
    cancellation: CancellationToken,
    settled: Notify,
}

struct InvocationAdmission {
    ready: bool,
    active: usize,
}

impl InvocationGeneration {
    fn new() -> Self {
        Self {
            admission: StdMutex::new(InvocationAdmission {
                ready: false,
                active: 0,
            }),
            cancellation: CancellationToken::new(),
            settled: Notify::new(),
        }
    }

    fn open(&self) -> bool {
        let mut admission = self
            .admission
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        if self.cancellation.is_cancelled() {
            return false;
        }
        admission.ready = true;
        true
    }

    fn retire(&self) {
        self.retire_and_signal(|| self.cancellation.cancel());
    }

    fn retire_and_signal(&self, signal: impl FnOnce()) {
        // Keep both changes under the same admission lock. Otherwise a
        // concurrent successful start can reopen ready before token.cancel.
        let mut admission = self
            .admission
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        admission.ready = false;
        signal();
    }

    fn begin(self: &Arc<Self>, entry: Arc<ChannelEntry>) -> Result<InvocationReceipt> {
        let mut admission = self
            .admission
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        if !admission.ready || self.cancellation.is_cancelled() {
            return Err(invocation_inactive(
                "channel handler generation is not active",
            ));
        }
        admission.active = admission
            .active
            .checked_add(1)
            .ok_or_else(|| channel_error("channel invocation capacity exhausted".into()))?;
        Ok(InvocationReceipt {
            generation: Arc::clone(self),
            _entry: entry,
        })
    }

    async fn wait(&self) {
        loop {
            let settled = self.settled.notified();
            tokio::pin!(settled);
            settled.as_mut().enable();
            if self
                .admission
                .lock()
                .unwrap_or_else(|error| error.into_inner())
                .active
                == 0
            {
                return;
            }
            settled.await;
        }
    }
}

struct InvocationReceipt {
    generation: Arc<InvocationGeneration>,
    _entry: Arc<ChannelEntry>,
}

impl Drop for InvocationReceipt {
    fn drop(&mut self) {
        let mut admission = self
            .generation
            .admission
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        admission.active = admission.active.saturating_sub(1);
        if admission.active == 0 {
            self.generation.settled.notify_waiters();
        }
    }
}

struct CancelInvocationOnDrop {
    cancellation: CancellationToken,
    armed: bool,
}

impl CancelInvocationOnDrop {
    fn new(cancellation: CancellationToken) -> Self {
        Self {
            cancellation,
            armed: true,
        }
    }
    fn disarm(&mut self) {
        self.armed = false;
    }
}

impl Drop for CancelInvocationOnDrop {
    fn drop(&mut self) {
        // A cancelled waiter signals its exact child; the driver's receipt is
        // retained until local legacy drop or the driven operation truly ends.
        if self.armed {
            self.cancellation.cancel();
        }
    }
}

pub(super) async fn drive_call<T>(
    operation: impl Future<Output = Result<T>>,
    cancellation: &CancellationToken,
    caller: &CancellationToken,
    driven: bool,
) -> Result<T> {
    tokio::pin!(operation);
    if driven {
        tokio::select! {
            biased;
            () = caller.cancelled() => {
                cancellation.cancel();
                operation.await
            }
            result = &mut operation => result,
        }
    } else {
        tokio::select! {
            biased;
            () = caller.cancelled() => { cancellation.cancel(); Err(invocation_cancelled()) }
            () = cancellation.cancelled() => Err(invocation_cancelled()),
            result = &mut operation => result,
        }
    }
}

struct ChannelState {
    plugin: Box<dyn ChannelPlugin>,
    handler: Option<Arc<dyn MessageHandler>>,
    stopped_at_epoch: Option<u64>,
}

struct ChannelEntry {
    id: String,
    label: String,
    capabilities: ChannelCapabilities,
    state: RwLock<ChannelState>,
    // The original entry's current generation. No handler is stored here.
    generation: StdMutex<Option<Arc<InvocationGeneration>>>,
    mutation_epoch: AtomicU64,
    // Diagnostic projection only. All cleanup decisions use state.handler.
    unsettled_handler: AtomicBool,
}

/// Owned access to the same registered plugin and its cleanup responsibility.
///
/// Metadata is the registration-time declaration, fixed for this registration.
/// Operations retain the original instance after the manager borrow ends. A
/// callback may query manager metadata; recursively awaiting another mutation
/// of this same channel is unsupported because lifecycle operations serialize.
#[derive(Clone)]
pub struct ChannelHandle {
    entry: Arc<ChannelEntry>,
}

impl ChannelHandle {
    pub fn id(&self) -> &str {
        &self.entry.id
    }

    pub fn label(&self) -> &str {
        &self.entry.label
    }

    pub fn capabilities(&self) -> &ChannelCapabilities {
        &self.entry.capabilities
    }

    fn generation(&self) -> Option<Arc<InvocationGeneration>> {
        self.entry
            .generation
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .clone()
    }

    async fn admit(
        &self,
        captured: Option<Arc<InvocationGeneration>>,
        message_channel: &str,
    ) -> Result<(
        Arc<dyn MessageHandler>,
        InvocationReceipt,
        CancellationToken,
    )> {
        if message_channel != self.id() {
            return Err(invocation_inactive(
                "message channel_id does not match the registered entry",
            ));
        }
        let generation =
            captured.ok_or_else(|| invocation_inactive("channel handler has not started"))?;
        if !self
            .generation()
            .is_some_and(|current| Arc::ptr_eq(&current, &generation))
        {
            return Err(ReactError::Channel(Box::new(
                ChannelError::StaleInvocation {
                    channel_id: self.id().to_string(),
                },
            )));
        }
        // Fail before awaiting the lifecycle lock during start/rollback/stop.
        let ready = generation
            .admission
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .ready;
        if !ready || generation.cancellation.is_cancelled() {
            return Err(invocation_inactive(
                "channel handler generation is not active",
            ));
        }
        let state = self.entry.state.read().await;
        if !self
            .generation()
            .is_some_and(|current| Arc::ptr_eq(&current, &generation))
        {
            return Err(ReactError::Channel(Box::new(
                ChannelError::StaleInvocation {
                    channel_id: self.id().to_string(),
                },
            )));
        }
        let handler = state
            .handler
            .as_ref()
            .cloned()
            .ok_or_else(|| invocation_inactive("channel handler is unavailable"))?;
        let receipt = generation.begin(Arc::clone(&self.entry))?;
        let cancel = generation.cancellation.child_token();
        Ok((handler, receipt, cancel))
    }

    /// Invoke the original successfully started handler with a caller-local token.
    /// Dropping the waiter signals cancellation; shutdown still waits its driver.
    pub fn handle_message(
        &self,
        message: InboundMessage,
        caller: CancellationToken,
    ) -> BoxFuture<'static, Result<OutboundMessage>> {
        let channel = self.clone();
        let generation = self.generation();
        Box::pin(async move {
            let runtime = tokio::runtime::Handle::try_current().map_err(|error| {
                channel_error(format!("channel invocation requires a runtime: {error}"))
            })?;
            if caller.is_cancelled() {
                return Err(invocation_cancelled());
            }
            let (handler, receipt, cancellation) =
                channel.admit(generation, &message.channel_id).await?;
            let mut cancel_on_drop = CancelInvocationOnDrop::new(cancellation.clone());
            let (sender, receiver) = oneshot::channel();
            let driver = runtime.spawn(async move {
                let _receipt = receipt;
                let result = drive_call(
                    handler.handle_with_cancel(message, cancellation.clone()),
                    &cancellation,
                    &caller,
                    handler.settles_on_cancel(),
                )
                .await;
                let _ = sender.send(result);
            });
            let result = receiver.await;
            driver.await.map_err(|error| {
                channel_error(format!("channel handler driver failed: {error}"))
            })?;
            cancel_on_drop.disarm();
            result
                .map_err(|error| channel_error(format!("channel handler driver ended: {error}")))?
        })
    }

    /// Invoke reply on the same original handler; it is distinct from plugin.send.
    pub fn reply_message(
        &self,
        message: OutboundMessage,
        caller: CancellationToken,
    ) -> BoxFuture<'static, Result<()>> {
        let channel = self.clone();
        let generation = self.generation();
        Box::pin(async move {
            let runtime = tokio::runtime::Handle::try_current().map_err(|error| {
                channel_error(format!("channel invocation requires a runtime: {error}"))
            })?;
            if caller.is_cancelled() {
                return Err(invocation_cancelled());
            }
            let (handler, receipt, cancellation) =
                channel.admit(generation, &message.channel_id).await?;
            let mut cancel_on_drop = CancelInvocationOnDrop::new(cancellation.clone());
            let (sender, receiver) = oneshot::channel();
            let driver = runtime.spawn(async move {
                let _receipt = receipt;
                let result = drive_call(
                    handler.reply_with_cancel(message, cancellation.clone()),
                    &cancellation,
                    &caller,
                    handler.settles_on_cancel(),
                )
                .await;
                let _ = sender.send(result);
            });
            let result = receiver.await;
            driver
                .await
                .map_err(|error| channel_error(format!("channel reply driver failed: {error}")))?;
            cancel_on_drop.disarm();
            result.map_err(|error| channel_error(format!("channel reply driver ended: {error}")))?
        })
    }

    /// Return an owned stream tied to the captured original handler generation.
    /// Its bounded driver owns the trait's borrowed inner stream and receipt.
    pub fn handle_message_stream(
        &self,
        message: InboundMessage,
        caller: CancellationToken,
    ) -> BoxFuture<'static, Result<ChannelMessageStream>> {
        let channel = self.clone();
        let generation = self.generation();
        Box::pin(async move {
            let runtime = tokio::runtime::Handle::try_current().map_err(|error| {
                channel_error(format!("channel invocation requires a runtime: {error}"))
            })?;
            if caller.is_cancelled() {
                return Err(invocation_cancelled());
            }
            let (handler, receipt, cancellation) =
                channel.admit(generation, &message.channel_id).await?;
            let invocation_cancellation = cancellation.clone();
            let cancel_on_drop = CancelInvocationOnDrop::new(cancellation.clone());
            let (setup_sender, setup_receiver) = oneshot::channel();
            let (sender, mut receiver) = mpsc::channel(1);
            let driver = runtime.spawn(async move {
                let _receipt = receipt;
                let driven = handler.settles_on_cancel();
                let setup = drive_call(
                    handler.handle_stream_with_cancel(message, cancellation.clone()),
                    &cancellation,
                    &caller,
                    driven,
                )
                .await;
                let mut inner = match setup {
                    Ok(inner) => inner,
                    Err(error) => {
                        let _ = setup_sender.send(Err(error));
                        return;
                    }
                };
                if setup_sender.send(Ok(())).is_err() {
                    cancellation.cancel();
                }
                loop {
                    let item = drive_call(
                        async { Ok(inner.next().await) },
                        &cancellation,
                        &caller,
                        driven,
                    )
                    .await;
                    let item = match item {
                        Ok(Some(item)) => item,
                        Ok(None) | Err(_) => break,
                    };
                    // Driven cancellation continues polling to actual completion;
                    // it never blocks on an abandoned/full consumer buffer.
                    if cancellation.is_cancelled() {
                        continue;
                    }
                    tokio::select! {
                        biased;
                        () = caller.cancelled() => { cancellation.cancel(); }
                        () = cancellation.cancelled() => {},
                        sent = sender.send(item) => { if sent.is_err() { cancellation.cancel(); } }
                    }
                }
                drop(inner);
            });
            setup_receiver.await.map_err(|error| {
                channel_error(format!("channel stream driver ended during setup: {error}"))
            })??;
            let stream = async_stream::stream! {
                let mut cancel_on_drop = cancel_on_drop;
                loop {
                    let item = tokio::select! {
                        biased;
                        () = cancel_on_drop.cancellation.cancelled() => break,
                        item = receiver.recv() => item,
                    };
                    let Some(item) = item else { break };
                    yield item;
                }
                let exit = driver.await;
                cancel_on_drop.disarm();
                if let Err(error) = exit {
                    yield Err(channel_error(format!("channel stream driver failed: {error}")));
                }
            };
            Ok(ChannelMessageStream {
                stream: Box::pin(stream),
                cancellation: invocation_cancellation,
            })
        })
    }

    fn invalidate_stopped(&self) {
        // MAX remains permanently conservative, including concurrent invalidation
        // while stop awaits a plugin callback. Never wrap into an old epoch.
        let mut epoch = self.entry.mutation_epoch.load(Ordering::Acquire);
        loop {
            match self.entry.mutation_epoch.compare_exchange_weak(
                epoch,
                epoch.saturating_add(1),
                Ordering::AcqRel,
                Ordering::Acquire,
            ) {
                Ok(_) => break,
                Err(current) => epoch = current,
            }
        }
    }

    async fn start_with(
        &self,
        handler_factory: impl FnOnce() -> Arc<dyn MessageHandler> + Send,
    ) -> Result<()> {
        let mut state = self.entry.state.write().await;
        if state.handler.is_some() {
            return Err(channel_error(format!(
                "Channel '{}' still owns a handler; stop it before restarting",
                self.id()
            )));
        }
        state.stopped_at_epoch = None;
        let generation = Arc::new(InvocationGeneration::new());
        *self
            .entry
            .generation
            .lock()
            .unwrap_or_else(|error| error.into_inner()) = Some(Arc::clone(&generation));
        let handler = handler_factory();
        state.handler = Some(Arc::clone(&handler));
        self.entry.unsettled_handler.store(true, Ordering::Release);
        match state.plugin.start(Arc::clone(&handler)).await {
            Ok(()) => {
                // Transport start succeeded even if a concurrent stop already
                // retired admission. The queued stop retains cleanup ownership;
                // preserve the original start result without reopening the gate.
                generation.open();
                Ok(())
            }
            Err(start_error) => {
                generation.retire();
                // Publish responsibility before the first plugin await. Future
                // cancellation leaves that same handler available to stop.
                let epoch = self.entry.mutation_epoch.load(Ordering::Acquire);
                match state.plugin.stop().await {
                    Ok(()) => {
                        state.stopped_at_epoch = Some(epoch);
                        match handler.close().await {
                            Ok(()) => {
                                state.handler = None;
                                self.entry.unsettled_handler.store(false, Ordering::Release);
                                Err(start_error)
                            }
                            Err(close_error) => Err(channel_error(format!(
                                "Channel '{}' start failed: {start_error}; handler close failed: {close_error}",
                                self.id()
                            ))),
                        }
                    }
                    Err(stop_error) => Err(channel_error(format!(
                        "Channel '{}' start failed: {start_error}; rollback stop failed: {stop_error}",
                        self.id()
                    ))),
                }
            }
        }
    }

    /// Start using the original plugin, retaining handler responsibility on failure or cancellation.
    pub fn start(&self, handler: Arc<dyn MessageHandler>) -> BoxFuture<'static, Result<()>> {
        let channel = self.clone();
        Box::pin(async move { channel.start_with(|| handler).await })
    }

    /// Await transport stop and handler close. Retry does not repeat a confirmed stop.
    pub fn stop(&self) -> BoxFuture<'static, Result<()>> {
        let channel = self.clone();
        Box::pin(async move {
            if let Some(generation) = channel.generation() {
                generation.retire();
            }
            let mut state = channel.entry.state.write().await;
            let generation = channel.generation();
            if let Some(generation) = &generation {
                generation.retire();
            }
            let epoch = channel.entry.mutation_epoch.load(Ordering::Acquire);
            if epoch == u64::MAX || state.stopped_at_epoch != Some(epoch) {
                state.plugin.stop().await?;
                state.stopped_at_epoch = Some(epoch);
            }
            if let Some(handler) = &state.handler {
                if let Some(generation) = &generation {
                    generation.wait().await;
                }
                handler.close().await?;
                state.handler = None;
                channel
                    .entry
                    .unsettled_handler
                    .store(false, Ordering::Release);
            }
            Ok(())
        })
    }

    pub fn send(&self, message: OutboundMessage) -> BoxFuture<'static, Result<()>> {
        let channel = self.clone();
        Box::pin(async move { channel.entry.state.read().await.plugin.send(message).await })
    }

    pub fn health_check(&self) -> BoxFuture<'static, Result<()>> {
        let channel = self.clone();
        Box::pin(async move { channel.entry.state.read().await.plugin.health_check().await })
    }
}

#[async_trait]
impl ChannelPlugin for ChannelHandle {
    fn id(&self) -> &str {
        self.id()
    }
    fn label(&self) -> &str {
        self.label()
    }
    fn capabilities(&self) -> &ChannelCapabilities {
        self.capabilities()
    }
    async fn start(&mut self, handler: Arc<dyn MessageHandler>) -> Result<()> {
        ChannelHandle::start(self, handler).await
    }
    async fn stop(&mut self) -> Result<()> {
        ChannelHandle::stop(self).await
    }
    async fn send(&self, message: OutboundMessage) -> Result<()> {
        ChannelHandle::send(self, message).await
    }
    async fn health_check(&self) -> Result<()> {
        ChannelHandle::health_check(self).await
    }
}

/// Registry and lifecycle access for IM channel plugins.
///
/// `id`, `label` and `capabilities` are fixed registration declarations. The old
/// borrowed accessors delegate to the same entry as owned access; they do not
/// expose later dynamic changes to a third-party plugin's metadata.
/// Obtain an owned operation under an external manager lock, release that lock,
/// then await. Explicit awaited shutdown is required; dropping is not shutdown.
pub struct ChannelManager {
    channels: HashMap<String, ChannelHandle>,
}

impl Default for ChannelManager {
    fn default() -> Self {
        Self::new()
    }
}

impl ChannelManager {
    pub fn new() -> Self {
        Self {
            channels: HashMap::new(),
        }
    }

    /// Register the original plugin with its fixed metadata declaration.
    pub fn register(&mut self, plugin: Box<dyn ChannelPlugin>) -> Result<()> {
        let id = plugin.id().to_string();
        if self.channels.contains_key(&id) {
            return Err(channel_error(format!(
                "Channel '{id}' is already registered"
            )));
        }
        let capabilities = plugin.capabilities();
        let capabilities = ChannelCapabilities {
            chat_types: capabilities.chat_types,
            supports_media: capabilities.supports_media,
            supports_threads: capabilities.supports_threads,
        };
        let entry = Arc::new(ChannelEntry {
            id: id.clone(),
            label: plugin.label().to_string(),
            capabilities,
            state: RwLock::new(ChannelState {
                plugin,
                handler: None,
                stopped_at_epoch: None,
            }),
            generation: StdMutex::new(None),
            mutation_epoch: AtomicU64::new(0),
            unsettled_handler: AtomicBool::new(false),
        });
        info!("Registering channel: {}", id);
        self.channels.insert(id, ChannelHandle { entry });
        Ok(())
    }

    pub fn len(&self) -> usize {
        self.channels.len()
    }
    pub fn is_empty(&self) -> bool {
        self.channels.is_empty()
    }

    /// Retain the original entry independently of the manager borrow.
    pub fn get_owned(&self, id: &str) -> Option<ChannelHandle> {
        self.channels.get(id).cloned()
    }

    fn snapshot(&self) -> Vec<ChannelHandle> {
        self.channels.values().cloned().collect()
    }

    async fn start_entries(
        entries: Vec<ChannelHandle>,
        handler_factory: impl Fn(&str) -> Arc<dyn MessageHandler> + Sync,
    ) -> Vec<ChannelLifecycleResult> {
        let mut results = Vec::with_capacity(entries.len());
        for channel in entries {
            let result = channel.start_with(|| handler_factory(channel.id())).await;
            results.push(ChannelLifecycleResult {
                channel_id: channel.id().to_string(),
                result,
            });
        }
        results
    }

    /// Capture current registrations now; invoke the factory only when polled.
    /// Channels registered later are considered by the next batch.
    pub fn start_all_owned(
        &self,
        handler_factory: impl Fn(&str) -> Arc<dyn MessageHandler> + Send + Sync + 'static,
    ) -> BoxFuture<'static, Vec<ChannelLifecycleResult>> {
        let entries = self.snapshot();
        Box::pin(Self::start_entries(entries, handler_factory))
    }

    /// Start the current channels sequentially and retain per-channel results.
    pub async fn start_all(
        &mut self,
        handler_factory: impl Fn(&str) -> Arc<dyn MessageHandler> + Sync,
    ) -> Vec<ChannelLifecycleResult> {
        Self::start_entries(self.snapshot(), &handler_factory).await
    }

    pub fn stop_owned(&self, channel_id: &str) -> BoxFuture<'static, Result<()>> {
        let channel = self.get_owned(channel_id);
        let id = channel_id.to_string();
        Box::pin(async move {
            channel
                .ok_or_else(|| channel_error(format!("Channel '{id}' not found")))?
                .stop()
                .await
        })
    }

    pub async fn stop(&mut self, channel_id: &str) -> Result<()> {
        self.stop_owned(channel_id).await
    }

    /// Capture current registrations now and attempt every channel on poll.
    pub fn stop_all_owned(&self) -> BoxFuture<'static, Result<()>> {
        let entries = self.snapshot();
        Box::pin(async move {
            let mut failures = Vec::new();
            for channel in entries {
                if let Err(error) = channel.stop().await {
                    warn!("Failed to stop channel '{}': {}", channel.id(), error);
                    failures.push(format!("{}: {error}", channel.id()));
                }
            }
            if failures.is_empty() {
                Ok(())
            } else {
                Err(channel_error(format!(
                    "failed to stop channels: {}",
                    failures.join("; ")
                )))
            }
        })
    }

    pub async fn stop_all(&mut self) -> Result<()> {
        self.stop_all_owned().await
    }

    pub fn get(&self, id: &str) -> Option<&(dyn ChannelPlugin + '_)> {
        self.channels
            .get(id)
            .map(|channel| channel as &dyn ChannelPlugin)
    }

    /// Mutable borrowed access conservatively invalidates a prior stop fact.
    /// Availability does not change when an owned handle is also retained.
    pub fn get_mut(&mut self, id: &str) -> Option<&mut (dyn ChannelPlugin + '_)> {
        match self.channels.get_mut(id) {
            Some(channel) => {
                channel.invalidate_stopped();
                Some(channel as &mut dyn ChannelPlugin)
            }
            None => None,
        }
    }

    pub fn channel_ids(&self) -> Vec<&str> {
        self.channels.keys().map(String::as_str).collect()
    }
}

impl Drop for ChannelManager {
    fn drop(&mut self) {
        let unsettled = self
            .channels
            .values()
            .filter(|channel| channel.entry.unsettled_handler.load(Ordering::Acquire))
            .count();
        if unsettled != 0 {
            info!(
                "ChannelManager dropped with {} unsettled handlers remaining; await stop_all() for shutdown",
                unsettled
            );
        }
    }
}

impl Drop for ChannelEntry {
    fn drop(&mut self) {
        if self.state.get_mut().handler.is_some() {
            warn!(
                "Channel '{}' final owner dropped with an unsettled handler; shutdown was not awaited",
                self.id
            );
        }
    }
}

#[cfg(test)]
mod invocation_tests {
    use super::super::types::ChatType;
    use super::*;
    use std::sync::atomic::AtomicUsize;
    use std::time::Duration;
    use tokio::sync::Semaphore;
    use tokio::time::timeout;

    const LIMIT: Duration = Duration::from_secs(2);
    type TestResult = std::result::Result<(), Box<dyn std::error::Error>>;

    #[derive(Default)]
    struct Facts {
        calls: AtomicUsize,
        replies: AtomicUsize,
        closes: AtomicUsize,
        drops: AtomicUsize,
        entered: Notify,
        cancelled: Notify,
    }

    struct DropFact(Arc<Facts>);
    impl Drop for DropFact {
        fn drop(&mut self) {
            self.0.drops.fetch_add(1, Ordering::AcqRel);
        }
    }

    struct ForwardHandler {
        facts: Arc<Facts>,
        driven: bool,
        setup_error: bool,
        close_error_once: bool,
        release: Arc<Semaphore>,
    }

    impl ForwardHandler {
        fn plain(facts: Arc<Facts>) -> Self {
            Self {
                facts,
                driven: false,
                setup_error: false,
                close_error_once: false,
                release: Arc::new(Semaphore::new(0)),
            }
        }

        async fn run(
            &self,
            message: InboundMessage,
            cancel: CancellationToken,
        ) -> Result<OutboundMessage> {
            self.facts.calls.fetch_add(1, Ordering::AcqRel);
            let _drop = DropFact(Arc::clone(&self.facts));
            if message.text == "park" {
                self.facts.entered.notify_one();
                cancel.cancelled().await;
                self.facts.cancelled.notify_one();
                if self.driven {
                    self.release
                        .acquire()
                        .await
                        .map_err(|error| channel_error(error.to_string()))?
                        .forget();
                }
                return Err(invocation_cancelled());
            }
            Ok(OutboundMessage::new(
                message.channel_id,
                message.chat_id,
                message.chat_type,
                message.text,
            ))
        }
    }

    #[async_trait]
    impl MessageHandler for ForwardHandler {
        async fn handle(&self, message: InboundMessage) -> Result<OutboundMessage> {
            self.run(message, CancellationToken::new()).await
        }
        async fn handle_with_cancel(
            &self,
            message: InboundMessage,
            cancel: CancellationToken,
        ) -> Result<OutboundMessage> {
            self.run(message, cancel).await
        }
        async fn reply(&self, _message: OutboundMessage) -> Result<()> {
            self.facts.replies.fetch_add(1, Ordering::AcqRel);
            Ok(())
        }
        fn settles_on_cancel(&self) -> bool {
            self.driven
        }
        async fn close(&self) -> Result<()> {
            let n = self.facts.closes.fetch_add(1, Ordering::AcqRel);
            if self.close_error_once && n == 0 {
                return Err(channel_error("retry close".into()));
            }
            Ok(())
        }
        async fn handle_stream_with_cancel<'a>(
            &'a self,
            message: InboundMessage,
            cancel: CancellationToken,
        ) -> Result<BoxStream<'a, Result<OutboundMessage>>> {
            if self.setup_error {
                return Err(channel_error("setup failed".into()));
            }
            if message.text == "setup-park" {
                let _drop = DropFact(Arc::clone(&self.facts));
                self.facts.entered.notify_one();
                cancel.cancelled().await;
                return Err(invocation_cancelled());
            }
            let stream = async_stream::stream! {
                let _drop = DropFact(Arc::clone(&self.facts));
                self.facts.entered.notify_one();
                if message.text == "park" {
                    cancel.cancelled().await;
                    self.facts.cancelled.notify_one();
                    if self.driven
                        && let Err(error) = self.release.acquire().await.map(|permit| permit.forget()) {
                        yield Err(channel_error(error.to_string()));
                    }
                } else {
                    for text in ["第一段😀", "second", "third"] {
                        yield Ok(OutboundMessage::new(&message.channel_id, &message.chat_id, message.chat_type, text));
                    }
                }
            };
            Ok(Box::pin(stream))
        }
    }

    struct ForwardPlugin {
        fail_start: bool,
        fail_stop: bool,
        start_gate: Option<(Arc<Notify>, Arc<Semaphore>)>,
    }

    #[async_trait]
    impl ChannelPlugin for ForwardPlugin {
        fn id(&self) -> &str {
            "forward"
        }
        fn capabilities(&self) -> &ChannelCapabilities {
            static CAPS: ChannelCapabilities = ChannelCapabilities {
                chat_types: &[ChatType::Direct],
                supports_media: true,
                supports_threads: false,
            };
            &CAPS
        }
        async fn start(&mut self, _handler: Arc<dyn MessageHandler>) -> Result<()> {
            if let Some((entered, gate)) = &self.start_gate {
                entered.notify_one();
                gate.acquire()
                    .await
                    .map_err(|error| channel_error(error.to_string()))?
                    .forget();
            }
            if self.fail_start {
                return Err(channel_error("start failed".into()));
            }
            Ok(())
        }
        async fn stop(&mut self) -> Result<()> {
            if self.fail_stop {
                self.fail_stop = false;
                return Err(channel_error("stop failed".into()));
            }
            Ok(())
        }
        async fn send(&self, _message: OutboundMessage) -> Result<()> {
            Ok(())
        }
    }

    fn registered(plugin: ForwardPlugin) -> Result<ChannelHandle> {
        let mut manager = ChannelManager::new();
        manager.register(Box::new(plugin))?;
        manager
            .get_owned("forward")
            .ok_or_else(|| channel_error("missing entry".into()))
    }

    async fn started(handler: Arc<dyn MessageHandler>) -> Result<ChannelHandle> {
        let channel = registered(ForwardPlugin {
            fail_start: false,
            fail_stop: false,
            start_gate: None,
        })?;
        channel.start(handler).await?;
        Ok(channel)
    }

    fn message(text: &str) -> InboundMessage {
        InboundMessage::new("forward", "sender", "chat", ChatType::Direct, text, "id")
    }

    #[tokio::test]
    async fn forward_original_handler_single_and_reply_are_distinct() -> TestResult {
        let facts = Arc::new(Facts::default());
        let channel = started(Arc::new(ForwardHandler::plain(Arc::clone(&facts)))).await?;
        let output = channel
            .handle_message(message("中文😀"), CancellationToken::new())
            .await?;
        assert_eq!(output.text, "中文😀");
        assert_eq!(facts.calls.load(Ordering::Acquire), 1);
        assert_eq!(facts.replies.load(Ordering::Acquire), 0);
        channel
            .reply_message(output, CancellationToken::new())
            .await?;
        assert_eq!(facts.replies.load(Ordering::Acquire), 1);
        channel.stop().await?;
        Ok(())
    }

    #[tokio::test]
    async fn forward_owned_stream_keeps_original_handler_and_order() -> TestResult {
        let facts = Arc::new(Facts::default());
        let channel = started(Arc::new(ForwardHandler::plain(Arc::clone(&facts)))).await?;
        let mut stream = channel
            .handle_message_stream(message("stream"), CancellationToken::new())
            .await?;
        let invocation_cancel = stream.cancellation.clone();
        for expected in ["第一段😀", "second", "third"] {
            let output = timeout(LIMIT, stream.next())
                .await?
                .ok_or("missing stream item")??;
            assert_eq!(output.text, expected);
        }
        assert!(stream.next().await.is_none());
        assert!(!invocation_cancel.is_cancelled());
        assert_eq!(facts.drops.load(Ordering::Acquire), 1);
        assert_eq!(facts.replies.load(Ordering::Acquire), 0);
        channel.stop().await?;
        Ok(())
    }

    #[tokio::test]
    async fn forward_unstarted_entry_rejects_before_handler() -> TestResult {
        let channel = registered(ForwardPlugin {
            fail_start: false,
            fail_stop: false,
            start_gate: None,
        })?;
        assert!(
            channel
                .handle_message(message("hello"), CancellationToken::new())
                .await
                .is_err()
        );
        assert!(
            channel
                .handle_message_stream(message("hello"), CancellationToken::new())
                .await
                .is_err()
        );
        Ok(())
    }

    #[tokio::test]
    async fn forward_wrong_channel_rejects_before_side_effect() -> TestResult {
        let facts = Arc::new(Facts::default());
        let channel = started(Arc::new(ForwardHandler::plain(Arc::clone(&facts)))).await?;
        let mut wrong = message("hello");
        wrong.channel_id = "other".into();
        assert!(
            channel
                .handle_message(wrong, CancellationToken::new())
                .await
                .is_err()
        );
        assert_eq!(facts.calls.load(Ordering::Acquire), 0);
        channel.stop().await?;
        Ok(())
    }

    #[tokio::test]
    async fn forward_starting_entry_rejects_without_waiting_write_lock() -> TestResult {
        let entered = Arc::new(Notify::new());
        let gate = Arc::new(Semaphore::new(0));
        let channel = registered(ForwardPlugin {
            fail_start: false,
            fail_stop: false,
            start_gate: Some((Arc::clone(&entered), Arc::clone(&gate))),
        })?;
        let start = tokio::spawn(
            channel.start(Arc::new(ForwardHandler::plain(Arc::new(Facts::default())))),
        );
        timeout(LIMIT, entered.notified()).await?;
        assert!(
            timeout(
                LIMIT,
                channel.handle_message(message("hello"), CancellationToken::new())
            )
            .await?
            .is_err()
        );
        gate.add_permits(1);
        start.await??;
        channel.stop().await?;
        Ok(())
    }

    #[tokio::test]
    async fn forward_failed_start_cleanup_debt_never_admits() -> TestResult {
        let facts = Arc::new(Facts::default());
        let channel = registered(ForwardPlugin {
            fail_start: true,
            fail_stop: true,
            start_gate: None,
        })?;
        assert!(
            channel
                .start(Arc::new(ForwardHandler::plain(Arc::clone(&facts))))
                .await
                .is_err()
        );
        assert!(
            channel
                .handle_message(message("hello"), CancellationToken::new())
                .await
                .is_err()
        );
        assert_eq!(facts.calls.load(Ordering::Acquire), 0);
        channel.stop().await?;
        assert_eq!(facts.closes.load(Ordering::Acquire), 1);
        Ok(())
    }

    #[tokio::test]
    async fn forward_cancelled_start_retains_only_cleanup_owner() -> TestResult {
        let entered = Arc::new(Notify::new());
        let channel = registered(ForwardPlugin {
            fail_start: false,
            fail_stop: false,
            start_gate: Some((Arc::clone(&entered), Arc::new(Semaphore::new(0)))),
        })?;
        let start = tokio::spawn(
            channel.start(Arc::new(ForwardHandler::plain(Arc::new(Facts::default())))),
        );
        timeout(LIMIT, entered.notified()).await?;
        start.abort();
        let _ = start.await;
        assert!(
            channel
                .handle_message(message("hello"), CancellationToken::new())
                .await
                .is_err()
        );
        channel.stop().await?;
        Ok(())
    }

    #[tokio::test]
    async fn forward_captured_generation_does_not_rebind_after_restart() -> TestResult {
        let first = Arc::new(Facts::default());
        let second = Arc::new(Facts::default());
        let channel = started(Arc::new(ForwardHandler::plain(Arc::clone(&first)))).await?;
        let old = channel.handle_message(message("old"), CancellationToken::new());
        channel.stop().await?;
        channel
            .start(Arc::new(ForwardHandler::plain(Arc::clone(&second))))
            .await?;
        assert!(
            matches!(old.await, Err(ReactError::Channel(error)) if matches!(error.as_ref(), ChannelError::StaleInvocation { channel_id } if channel_id == "forward"))
        );
        assert_eq!(second.calls.load(Ordering::Acquire), 0);
        assert_eq!(
            channel
                .handle_message(message("new"), CancellationToken::new())
                .await?
                .text,
            "new"
        );
        channel.stop().await?;
        Ok(())
    }

    #[tokio::test]
    async fn forward_caller_child_cancellation_does_not_cancel_sibling() -> TestResult {
        let facts = Arc::new(Facts::default());
        let channel = started(Arc::new(ForwardHandler::plain(Arc::clone(&facts)))).await?;
        let cancel = CancellationToken::new();
        let first = tokio::spawn(channel.handle_message(message("park"), cancel.clone()));
        timeout(LIMIT, facts.entered.notified()).await?;
        cancel.cancel();
        assert!(timeout(LIMIT, first).await??.is_err());
        assert_eq!(
            channel
                .handle_message(message("sibling"), CancellationToken::new())
                .await?
                .text,
            "sibling"
        );
        channel.stop().await?;
        Ok(())
    }

    #[tokio::test]
    async fn forward_setup_failure_releases_real_invocation_receipt() -> TestResult {
        let facts = Arc::new(Facts::default());
        let mut handler = ForwardHandler::plain(Arc::clone(&facts));
        handler.setup_error = true;
        let channel = started(Arc::new(handler)).await?;
        assert!(
            channel
                .handle_message_stream(message("hello"), CancellationToken::new())
                .await
                .is_err()
        );
        timeout(LIMIT, channel.stop()).await??;
        assert_eq!(facts.closes.load(Ordering::Acquire), 1);
        Ok(())
    }

    #[tokio::test]
    async fn forward_slow_legacy_stream_stop_drops_inner_before_close() -> TestResult {
        let facts = Arc::new(Facts::default());
        let channel = started(Arc::new(ForwardHandler::plain(Arc::clone(&facts)))).await?;
        let mut stream = channel
            .handle_message_stream(message("park"), CancellationToken::new())
            .await?;
        let invocation_cancel = stream.cancellation.clone();
        timeout(LIMIT, facts.entered.notified()).await?;
        timeout(LIMIT, channel.stop()).await??;
        assert!(invocation_cancel.is_cancelled());
        assert_eq!(facts.drops.load(Ordering::Acquire), 1);
        assert!(timeout(LIMIT, stream.next()).await?.is_none());
        Ok(())
    }

    #[tokio::test]
    async fn forward_full_unpolled_stream_stop_cancels_bounded_sender() -> TestResult {
        let facts = Arc::new(Facts::default());
        let channel = started(Arc::new(ForwardHandler::plain(Arc::clone(&facts)))).await?;
        let stream = channel
            .handle_message_stream(message("stream"), CancellationToken::new())
            .await?;
        timeout(LIMIT, facts.entered.notified()).await?;
        timeout(LIMIT, channel.stop()).await??;
        assert_eq!(facts.drops.load(Ordering::Acquire), 1);
        assert_eq!(facts.closes.load(Ordering::Acquire), 1);
        drop(stream);
        Ok(())
    }

    #[tokio::test]
    async fn forward_dropped_single_waiter_preserves_driven_actual_settlement() -> TestResult {
        let facts = Arc::new(Facts::default());
        let mut handler = ForwardHandler::plain(Arc::clone(&facts));
        handler.driven = true;
        let release = Arc::clone(&handler.release);
        let channel = started(Arc::new(handler)).await?;
        let call = tokio::spawn(channel.handle_message(message("park"), CancellationToken::new()));
        timeout(LIMIT, facts.entered.notified()).await?;
        call.abort();
        let _ = call.await;
        timeout(LIMIT, facts.cancelled.notified()).await?;
        assert!(
            timeout(Duration::from_millis(20), channel.stop())
                .await
                .is_err()
        );
        assert_eq!(facts.closes.load(Ordering::Acquire), 0);
        assert_eq!(facts.drops.load(Ordering::Acquire), 0);
        release.add_permits(1);
        timeout(LIMIT, channel.stop()).await??;
        assert_eq!(facts.drops.load(Ordering::Acquire), 1);
        assert_eq!(facts.closes.load(Ordering::Acquire), 1);
        Ok(())
    }

    #[tokio::test]
    async fn forward_handler_close_failure_keeps_admission_closed_for_retry() -> TestResult {
        let facts = Arc::new(Facts::default());
        let mut handler = ForwardHandler::plain(Arc::clone(&facts));
        handler.close_error_once = true;
        let channel = started(Arc::new(handler)).await?;
        assert!(channel.stop().await.is_err());
        assert!(
            channel
                .handle_message(message("late"), CancellationToken::new())
                .await
                .is_err()
        );
        channel.stop().await?;
        assert_eq!(facts.closes.load(Ordering::Acquire), 2);
        Ok(())
    }

    #[tokio::test]
    async fn forward_setup_cancellation_releases_legacy_future() -> TestResult {
        let facts = Arc::new(Facts::default());
        let channel = started(Arc::new(ForwardHandler::plain(Arc::clone(&facts)))).await?;
        let caller = CancellationToken::new();
        let setup =
            tokio::spawn(channel.handle_message_stream(message("setup-park"), caller.clone()));
        timeout(LIMIT, facts.entered.notified()).await?;
        caller.cancel();
        assert!(timeout(LIMIT, setup).await??.is_err());
        timeout(LIMIT, channel.stop()).await??;
        assert_eq!(facts.drops.load(Ordering::Acquire), 1);
        Ok(())
    }

    #[tokio::test]
    async fn forward_session_single_drains_inner_real_receipt_after_waiter_drop() -> TestResult {
        use super::super::session::{SessionConfig, SessionHandler};
        let facts = Arc::new(Facts::default());
        let release = Arc::new(Semaphore::new(0));
        let session = Arc::new(SessionHandler::new(SessionConfig::default(), {
            let facts = Arc::clone(&facts);
            let release = Arc::clone(&release);
            move |_instance: &super::super::session::ChannelSessionInstance| -> Box<dyn MessageHandler> {
                let mut handler = ForwardHandler::plain(Arc::clone(&facts));
                handler.driven = true; handler.release = Arc::clone(&release);
                Box::new(handler)
            }
        }));
        let channel = started(session.clone()).await?;
        let call = tokio::spawn(channel.handle_message(message("park"), CancellationToken::new()));
        timeout(LIMIT, facts.entered.notified()).await?;
        call.abort();
        let _ = call.await;
        timeout(LIMIT, facts.cancelled.notified()).await?;
        assert!(
            timeout(Duration::from_millis(20), channel.stop())
                .await
                .is_err()
        );
        assert_eq!(facts.drops.load(Ordering::Acquire), 0);
        assert_eq!(facts.closes.load(Ordering::Acquire), 0);
        release.add_permits(1);
        timeout(LIMIT, channel.stop()).await??;
        assert_eq!(facts.drops.load(Ordering::Acquire), 1);
        assert_eq!(session.active_sessions(), 0);
        Ok(())
    }

    #[tokio::test]
    async fn forward_session_stream_child_cancel_keeps_same_sender_sibling_alive() -> TestResult {
        use super::super::session::{SessionConfig, SessionHandler};
        let facts = Arc::new(Facts::default());
        let release = Arc::new(Semaphore::new(0));
        let session = Arc::new(SessionHandler::new(SessionConfig::default(), {
            let facts = Arc::clone(&facts);
            let release = Arc::clone(&release);
            move |_instance: &super::super::session::ChannelSessionInstance| -> Box<dyn MessageHandler> {
                let mut handler = ForwardHandler::plain(Arc::clone(&facts));
                handler.driven = true; handler.release = Arc::clone(&release); Box::new(handler)
            }
        }));
        let channel = started(session.clone()).await?;
        let cancel = CancellationToken::new();
        let mut first = channel
            .handle_message_stream(message("park"), cancel.clone())
            .await?;
        timeout(LIMIT, facts.entered.notified()).await?;
        cancel.cancel();
        timeout(LIMIT, facts.cancelled.notified()).await?;
        assert_eq!(
            channel
                .handle_message(message("sibling"), CancellationToken::new())
                .await?
                .text,
            "sibling"
        );
        assert_eq!(session.active_sessions(), 1);
        assert_eq!(facts.closes.load(Ordering::Acquire), 0);
        release.add_permits(1);
        assert!(timeout(LIMIT, first.next()).await?.is_none());
        timeout(LIMIT, channel.stop()).await??;
        assert_eq!(facts.closes.load(Ordering::Acquire), 1);
        Ok(())
    }

    #[tokio::test]
    async fn forward_session_legacy_setup_cancel_does_not_retire_sender_generation() -> TestResult {
        use super::super::session::{SessionConfig, SessionHandler};
        let facts = Arc::new(Facts::default());
        let session = Arc::new(SessionHandler::new(SessionConfig::default(), {
            let facts = Arc::clone(&facts);
            move |_instance: &super::super::session::ChannelSessionInstance| -> Box<dyn MessageHandler> {
                Box::new(ForwardHandler::plain(Arc::clone(&facts)))
            }
        }));
        let channel = started(session.clone()).await?;
        let cancel = CancellationToken::new();
        let mut stream = channel
            .handle_message_stream(message("setup-park"), cancel.clone())
            .await?;
        timeout(LIMIT, facts.entered.notified()).await?;
        cancel.cancel();
        // The wrapper's lazy inner setup publishes the legacy cancellation as an
        // item error, while keeping the same session available for another call.
        assert!(timeout(LIMIT, stream.next()).await?.is_none());
        assert_eq!(
            channel
                .handle_message(message("after"), CancellationToken::new())
                .await?
                .text,
            "after"
        );
        assert_eq!(session.active_sessions(), 1);
        timeout(LIMIT, channel.stop()).await??;
        Ok(())
    }

    #[tokio::test]
    async fn forward_metadata_reentry_does_not_hold_registry_or_entry_guard() -> TestResult {
        struct MetadataHandler(Arc<tokio::sync::Mutex<ChannelManager>>);
        #[async_trait]
        impl MessageHandler for MetadataHandler {
            async fn handle(&self, message: InboundMessage) -> Result<OutboundMessage> {
                let guard = self.0.lock().await;
                let ids = guard.channel_ids();
                if !ids.contains(&"forward") {
                    return Err(channel_error("lost entry".into()));
                }
                Ok(OutboundMessage::new(
                    message.channel_id,
                    message.chat_id,
                    message.chat_type,
                    "metadata",
                ))
            }
            async fn reply(&self, _message: OutboundMessage) -> Result<()> {
                Ok(())
            }
        }
        let manager = Arc::new(tokio::sync::Mutex::new(ChannelManager::new()));
        manager.lock().await.register(Box::new(ForwardPlugin {
            fail_start: false,
            fail_stop: false,
            start_gate: None,
        }))?;
        let channel = manager
            .lock()
            .await
            .get_owned("forward")
            .ok_or("missing entry")?;
        channel
            .start(Arc::new(MetadataHandler(Arc::clone(&manager))))
            .await?;
        assert_eq!(
            timeout(
                LIMIT,
                channel.handle_message(message("read"), CancellationToken::new())
            )
            .await??
            .text,
            "metadata"
        );
        channel.stop().await?;
        Ok(())
    }

    async fn queued_reset_preserves_incarnation(stream_reset: bool) -> TestResult {
        use super::super::session::{ChannelSessionInstance, SessionConfig, SessionHandler};
        let facts = Arc::new(Facts::default());
        let release = Arc::new(Semaphore::new(0));
        let instances = Arc::new(StdMutex::new(Vec::<String>::new()));
        let session = Arc::new(SessionHandler::new(SessionConfig::default(), {
            let facts = Arc::clone(&facts);
            let release = Arc::clone(&release);
            let instances = Arc::clone(&instances);
            move |instance: &ChannelSessionInstance| -> Box<dyn MessageHandler> {
                instances
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .push(instance.incarnation_id());
                let mut handler = ForwardHandler::plain(Arc::clone(&facts));
                handler.driven = true;
                handler.release = Arc::clone(&release);
                Box::new(handler)
            }
        }));
        let channel = started(session.clone()).await?;
        let first_cancel = CancellationToken::new();
        let first = tokio::spawn(channel.handle_message(message("park"), first_cancel.clone()));
        timeout(LIMIT, facts.entered.notified()).await?;
        let old = instances
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .first()
            .cloned()
            .ok_or("missing instance")?;
        let reset_cancel = CancellationToken::new();
        let reset_token = reset_cancel.clone();
        let reset_session = session.clone();
        let mut reset = Box::pin(async move {
            if stream_reset {
                reset_session
                    .handle_stream_with_cancel(message("/reset"), reset_token)
                    .await
                    .map(|_| ())
            } else {
                reset_session
                    .handle_with_cancel(message("/reset"), reset_token)
                    .await
                    .map(|_| ())
            }
        });
        // Poll B into A's held sender lock deterministically before cancelling;
        // no scheduler sleep is used as evidence that the reset was queued.
        assert!(futures::poll!(reset.as_mut()).is_pending());
        reset_cancel.cancel();
        first_cancel.cancel();
        timeout(LIMIT, facts.cancelled.notified()).await?;
        release.add_permits(1);
        assert!(timeout(LIMIT, first).await??.is_err());
        assert!(timeout(LIMIT, reset).await?.is_err());
        assert_eq!(
            instances
                .lock()
                .unwrap_or_else(|error| error.into_inner())
                .as_slice(),
            &[old]
        );
        assert_eq!(facts.closes.load(Ordering::Acquire), 0);
        assert_eq!(session.active_sessions(), 1);
        assert_eq!(
            channel
                .handle_message(message("same incarnation"), CancellationToken::new())
                .await?
                .text,
            "same incarnation"
        );
        channel.stop().await?;
        Ok(())
    }

    #[tokio::test]
    async fn forward_cancelled_queued_single_reset_preserves_sender_incarnation() -> TestResult {
        queued_reset_preserves_incarnation(false).await
    }

    #[tokio::test]
    async fn forward_cancelled_queued_stream_reset_preserves_sender_incarnation() -> TestResult {
        queued_reset_preserves_incarnation(true).await
    }

    #[test]
    fn forward_without_tokio_runtime_returns_error_without_admission_or_panic() -> TestResult {
        let facts = Arc::new(Facts::default());
        let runtime = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()?;
        let channel =
            runtime.block_on(started(Arc::new(ForwardHandler::plain(Arc::clone(&facts)))))?;
        // The entry is genuinely active; these calls would reach spawn without
        // the runtime precondition, rather than fail early for an absent handler.
        let result = futures::executor::block_on(
            channel.handle_message(message("hello"), CancellationToken::new()),
        );
        assert!(result.is_err());
        assert!(
            futures::executor::block_on(channel.reply_message(
                OutboundMessage::new("forward", "chat", ChatType::Direct, "reply"),
                CancellationToken::new(),
            ))
            .is_err()
        );
        assert!(
            futures::executor::block_on(
                channel.handle_message_stream(message("stream"), CancellationToken::new())
            )
            .is_err()
        );
        assert_eq!(facts.calls.load(Ordering::Acquire), 0);
        assert_eq!(facts.replies.load(Ordering::Acquire), 0);
        let generation = channel.generation().ok_or("missing active generation")?;
        assert_eq!(
            generation
                .admission
                .lock()
                .unwrap_or_else(|error| error.into_inner())
                .active,
            0
        );
        assert!(
            generation
                .admission
                .lock()
                .unwrap_or_else(|error| error.into_inner())
                .ready
        );
        runtime.block_on(channel.stop())?;
        Ok(())
    }

    #[test]
    fn forward_retirement_and_open_linearize_under_one_admission_guard() -> TestResult {
        use std::sync::Barrier;
        let generation = Arc::new(InvocationGeneration::new());
        assert!(generation.open());
        let retirement_entered = Arc::new(Barrier::new(2));
        let allow_cancel = Arc::new(Barrier::new(2));
        let retiring = Arc::clone(&generation);
        let entered = Arc::clone(&retirement_entered);
        let release = Arc::clone(&allow_cancel);
        let retire = std::thread::spawn(move || {
            // Park at the exact signal boundary after ready=false. This uses
            // the same private critical section as production retirement.
            retiring.retire_and_signal(|| {
                entered.wait();
                release.wait();
                retiring.cancellation.cancel();
            });
        });
        retirement_entered.wait();
        assert!(generation.admission.try_lock().is_err());
        let opening = Arc::clone(&generation);
        let open_entered = Arc::new(Barrier::new(2));
        let entered = Arc::clone(&open_entered);
        let open = std::thread::spawn(move || {
            entered.wait();
            opening.open()
        });
        open_entered.wait();
        allow_cancel.wait();
        retire.join().map_err(|_| "retirement thread failed")?;
        assert!(!open.join().map_err(|_| "start thread failed")?);
        assert!(generation.cancellation.is_cancelled());
        assert!(
            !generation
                .admission
                .lock()
                .unwrap_or_else(|error| error.into_inner())
                .ready
        );
        Ok(())
    }
}

#[cfg(test)]
mod close_tests {
    use super::*;
    use crate::channels::types::{ChannelCapabilities, ChatType, InboundMessage, OutboundMessage};
    use async_trait::async_trait;
    use echo_core::error::{ChannelError, ReactError};
    use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
    use std::time::Duration;
    use tokio::sync::Notify;

    struct ClosingHandler {
        stopped: Arc<AtomicBool>,
        closes: Arc<AtomicUsize>,
    }

    #[async_trait]
    impl MessageHandler for ClosingHandler {
        async fn handle(&self, _msg: InboundMessage) -> Result<OutboundMessage> {
            Err(ReactError::Other("not used".to_string()))
        }

        async fn reply(&self, _msg: OutboundMessage) -> Result<()> {
            Ok(())
        }

        async fn close(&self) -> Result<()> {
            if !self.stopped.load(Ordering::Acquire) {
                return Err(ReactError::Other("transport still accepting".to_string()));
            }
            let attempt = self.closes.fetch_add(1, Ordering::AcqRel);
            if attempt == 0 {
                Err(ReactError::Other("transient close failure".to_string()))
            } else {
                Ok(())
            }
        }
    }

    struct ClosingPlugin {
        stopped: Arc<AtomicBool>,
        stops: Arc<AtomicUsize>,
        fail_repeated_stop: bool,
        handler: Option<Arc<dyn MessageHandler>>,
    }

    #[async_trait]
    impl ChannelPlugin for ClosingPlugin {
        fn id(&self) -> &str {
            "close-test"
        }

        fn capabilities(&self) -> &ChannelCapabilities {
            static CAPABILITIES: ChannelCapabilities = ChannelCapabilities {
                chat_types: &[ChatType::Direct],
                supports_media: false,
                supports_threads: false,
            };
            &CAPABILITIES
        }

        async fn start(&mut self, handler: Arc<dyn MessageHandler>) -> Result<()> {
            self.stopped.store(false, Ordering::Release);
            self.handler = Some(handler);
            Ok(())
        }

        async fn stop(&mut self) -> Result<()> {
            let attempt = self.stops.fetch_add(1, Ordering::AcqRel);
            if self.fail_repeated_stop && attempt > 0 {
                return Err(ReactError::Other("transport already stopped".to_string()));
            }
            self.stopped.store(true, Ordering::Release);
            self.handler = None;
            Ok(())
        }

        async fn send(&self, _msg: OutboundMessage) -> Result<()> {
            Err(ReactError::Channel(Box::new(ChannelError::Other(
                "not used".to_string(),
            ))))
        }
    }

    #[tokio::test]
    async fn stop_retains_handler_until_awaited_close_succeeds() -> Result<()> {
        let stopped = Arc::new(AtomicBool::new(false));
        let stops = Arc::new(AtomicUsize::new(0));
        let closes = Arc::new(AtomicUsize::new(0));
        let mut manager = ChannelManager::new();
        manager.register(Box::new(ClosingPlugin {
            stopped: Arc::clone(&stopped),
            stops: Arc::clone(&stops),
            fail_repeated_stop: true,
            handler: None,
        }))?;
        let results = manager
            .start_all(|_| {
                Arc::new(ClosingHandler {
                    stopped: Arc::clone(&stopped),
                    closes: Arc::clone(&closes),
                })
            })
            .await;
        assert_eq!(results.len(), 1);
        assert!(results.iter().all(|result| result.result.is_ok()));

        let first = manager.stop("close-test").await;
        assert!(first.is_err());
        assert_eq!(closes.load(Ordering::Acquire), 1);
        manager.stop("close-test").await?;
        assert_eq!(closes.load(Ordering::Acquire), 2);
        assert_eq!(stops.load(Ordering::Acquire), 1);
        assert!(
            manager
                .channels
                .values()
                .all(|channel| !channel.entry.unsettled_handler.load(Ordering::Acquire))
        );
        Ok(())
    }

    #[tokio::test]
    async fn cancelled_stop_keeps_handler_for_retry() -> Result<()> {
        struct InterruptedHandler {
            entered: Arc<Notify>,
            closes: Arc<AtomicUsize>,
        }

        #[async_trait]
        impl MessageHandler for InterruptedHandler {
            async fn handle(&self, _msg: InboundMessage) -> Result<OutboundMessage> {
                Err(ReactError::Other("not used".to_string()))
            }
            async fn reply(&self, _msg: OutboundMessage) -> Result<()> {
                Ok(())
            }
            async fn close(&self) -> Result<()> {
                if self.closes.fetch_add(1, Ordering::AcqRel) == 0 {
                    self.entered.notify_one();
                    std::future::pending::<()>().await;
                }
                Ok(())
            }
        }

        let stopped = Arc::new(AtomicBool::new(false));
        let stops = Arc::new(AtomicUsize::new(0));
        let entered = Arc::new(Notify::new());
        let closes = Arc::new(AtomicUsize::new(0));
        let mut manager = ChannelManager::new();
        manager.register(Box::new(ClosingPlugin {
            stopped,
            stops: Arc::clone(&stops),
            fail_repeated_stop: true,
            handler: None,
        }))?;
        let results = manager
            .start_all(|_| {
                Arc::new(InterruptedHandler {
                    entered: Arc::clone(&entered),
                    closes: Arc::clone(&closes),
                })
            })
            .await;
        assert!(results.iter().all(|result| result.result.is_ok()));

        assert!(
            tokio::time::timeout(Duration::from_millis(20), manager.stop("close-test"))
                .await
                .is_err()
        );
        assert_eq!(closes.load(Ordering::Acquire), 1);
        manager.stop("close-test").await?;
        assert_eq!(closes.load(Ordering::Acquire), 2);
        assert_eq!(stops.load(Ordering::Acquire), 1);
        Ok(())
    }

    #[tokio::test]
    async fn cancelled_start_keeps_published_handler_for_stop_all() -> Result<()> {
        struct ParkedStartPlugin {
            started: Arc<Notify>,
            stopped: Arc<AtomicBool>,
            handler: Option<Arc<dyn MessageHandler>>,
        }

        #[async_trait]
        impl ChannelPlugin for ParkedStartPlugin {
            fn id(&self) -> &str {
                "parked-start"
            }
            fn capabilities(&self) -> &ChannelCapabilities {
                static CAPABILITIES: ChannelCapabilities = ChannelCapabilities {
                    chat_types: &[ChatType::Direct],
                    supports_media: false,
                    supports_threads: false,
                };
                &CAPABILITIES
            }
            async fn start(&mut self, handler: Arc<dyn MessageHandler>) -> Result<()> {
                self.handler = Some(handler);
                self.started.notify_one();
                std::future::pending::<Result<()>>().await
            }
            async fn stop(&mut self) -> Result<()> {
                self.stopped.store(true, Ordering::Release);
                self.handler = None;
                Ok(())
            }
            async fn send(&self, _msg: OutboundMessage) -> Result<()> {
                Ok(())
            }
        }

        struct ParkedStartHandler {
            stopped: Arc<AtomicBool>,
            closes: Arc<AtomicUsize>,
        }
        #[async_trait]
        impl MessageHandler for ParkedStartHandler {
            async fn handle(&self, _msg: InboundMessage) -> Result<OutboundMessage> {
                Err(ReactError::Other("not used".to_string()))
            }
            async fn reply(&self, _msg: OutboundMessage) -> Result<()> {
                Ok(())
            }
            async fn close(&self) -> Result<()> {
                if !self.stopped.load(Ordering::Acquire) {
                    return Err(ReactError::Other("transport still running".to_string()));
                }
                self.closes.fetch_add(1, Ordering::AcqRel);
                Ok(())
            }
        }

        let started = Arc::new(Notify::new());
        let stopped = Arc::new(AtomicBool::new(false));
        let closes = Arc::new(AtomicUsize::new(0));
        let mut manager = ChannelManager::new();
        manager.register(Box::new(ParkedStartPlugin {
            started: Arc::clone(&started),
            stopped: Arc::clone(&stopped),
            handler: None,
        }))?;
        assert!(
            tokio::time::timeout(
                Duration::from_millis(20),
                manager.start_all(|_| {
                    Arc::new(ParkedStartHandler {
                        stopped: Arc::clone(&stopped),
                        closes: Arc::clone(&closes),
                    })
                })
            )
            .await
            .is_err()
        );
        started.notified().await;
        manager.stop_all().await?;
        assert_eq!(closes.load(Ordering::Acquire), 1);
        Ok(())
    }
}

#[cfg(test)]
mod owned_tests {
    use super::*;
    use crate::channels::types::{ChatType, InboundMessage};
    use std::sync::Weak;
    use std::sync::atomic::AtomicUsize;
    use std::time::Duration;
    use tokio::sync::{Mutex, Notify};

    const CAPS: ChannelCapabilities = ChannelCapabilities {
        chat_types: &[ChatType::Direct],
        supports_media: false,
        supports_threads: false,
    };

    struct Probe {
        manager: Weak<Mutex<ChannelManager>>,
        calls: Mutex<Vec<&'static str>>,
        starts: AtomicUsize,
        stops: AtomicUsize,
        closes: AtomicUsize,
        fail_start: bool,
        fail_first_stop: bool,
        start_gate: Option<(Arc<Notify>, Arc<Notify>)>,
        stop_gate: Option<(Arc<Notify>, Arc<Notify>)>,
    }

    impl Probe {
        fn new(manager: &Arc<Mutex<ChannelManager>>) -> Arc<Self> {
            Arc::new(Self {
                manager: Arc::downgrade(manager),
                calls: Mutex::new(Vec::new()),
                starts: AtomicUsize::new(0),
                stops: AtomicUsize::new(0),
                closes: AtomicUsize::new(0),
                fail_start: false,
                fail_first_stop: false,
                start_gate: None,
                stop_gate: None,
            })
        }
        async fn callback(&self, operation: &'static str) -> Result<()> {
            if let Some(manager) = self.manager.upgrade() {
                let guard = manager.lock().await;
                assert!(!guard.channel_ids().is_empty());
                for id in guard.channel_ids() {
                    let plugin = guard
                        .get(id)
                        .ok_or_else(|| channel_error("missing registered plugin".into()))?;
                    assert!(!plugin.label().is_empty());
                    assert_eq!(plugin.capabilities().chat_types, &[ChatType::Direct]);
                }
            }
            self.calls.lock().await.push(operation);
            Ok(())
        }
    }

    struct ProbePlugin {
        id: &'static str,
        probe: Arc<Probe>,
    }
    #[async_trait]
    impl ChannelPlugin for ProbePlugin {
        fn id(&self) -> &str {
            self.id
        }
        fn capabilities(&self) -> &ChannelCapabilities {
            &CAPS
        }
        async fn start(&mut self, _handler: Arc<dyn MessageHandler>) -> Result<()> {
            self.probe.starts.fetch_add(1, Ordering::AcqRel);
            self.probe.callback("start").await?;
            if let Some((entered, release)) = &self.probe.start_gate {
                entered.notify_one();
                release.notified().await;
            }
            if self.probe.fail_start {
                Err(channel_error("probe start failure".into()))
            } else {
                Ok(())
            }
        }
        async fn stop(&mut self) -> Result<()> {
            let attempt = self.probe.stops.fetch_add(1, Ordering::AcqRel);
            self.probe.callback("stop").await?;
            if let Some((entered, release)) = &self.probe.stop_gate {
                entered.notify_one();
                release.notified().await;
            }
            if self.probe.fail_first_stop && attempt == 0 {
                Err(channel_error("probe stop failure".into()))
            } else {
                Ok(())
            }
        }
        async fn send(&self, _message: OutboundMessage) -> Result<()> {
            self.probe.callback("send").await
        }
        async fn health_check(&self) -> Result<()> {
            self.probe.callback("health").await
        }
    }
    struct ProbeHandler(Arc<Probe>);
    #[async_trait]
    impl MessageHandler for ProbeHandler {
        async fn handle(&self, _message: InboundMessage) -> Result<OutboundMessage> {
            Err(channel_error("unused handle".into()))
        }
        async fn reply(&self, _message: OutboundMessage) -> Result<()> {
            Ok(())
        }
        async fn close(&self) -> Result<()> {
            self.0.closes.fetch_add(1, Ordering::AcqRel);
            self.0.callback("close").await
        }
    }

    async fn registered(
        manager: &Arc<Mutex<ChannelManager>>,
        id: &'static str,
        probe: Arc<Probe>,
    ) -> Result<ChannelHandle> {
        let mut guard = manager.lock().await;
        guard.register(Box::new(ProbePlugin { id, probe }))?;
        guard
            .get_owned(id)
            .ok_or_else(|| channel_error("registration missing".into()))
    }

    #[tokio::test]
    async fn owned_callbacks_reenter_manager_metadata_on_every_async_path() -> Result<()> {
        let manager = Arc::new(Mutex::new(ChannelManager::new()));
        let probe = Probe::new(&manager);
        let channel = registered(&manager, "reentrant", Arc::clone(&probe)).await?;
        let start = {
            let guard = manager.lock().await;
            let probe = Arc::clone(&probe);
            guard.start_all_owned(move |_| Arc::new(ProbeHandler(Arc::clone(&probe))))
        };
        let sequence = async {
            assert!(
                start
                    .await
                    .into_iter()
                    .all(|row| row.channel_id == "reentrant" && row.result.is_ok())
            );
            channel.health_check().await?;
            channel
                .send(OutboundMessage::new(
                    "reentrant",
                    "chat",
                    ChatType::Direct,
                    "你好🌍",
                ))
                .await?;
            let stop = manager.lock().await.stop_owned("reentrant");
            stop.await
        };
        tokio::time::timeout(Duration::from_secs(2), sequence)
            .await
            .map_err(|_| channel_error("callback could not reenter manager metadata".into()))??;
        assert_eq!(
            *probe.calls.lock().await,
            vec!["start", "health", "send", "stop", "close"]
        );
        assert_eq!(probe.stops.load(Ordering::Acquire), 1);
        assert_eq!(probe.closes.load(Ordering::Acquire), 1);
        assert_eq!(manager.lock().await.len(), 1);
        Ok(())
    }

    #[tokio::test]
    async fn owned_batch_snapshots_synchronously_and_unpolled_drop_has_no_side_effects()
    -> Result<()> {
        let manager = Arc::new(Mutex::new(ChannelManager::new()));
        let a = Probe::new(&manager);
        let b = Probe::new(&manager);
        registered(&manager, "a", Arc::clone(&a)).await?;
        let factories = Arc::new(AtomicUsize::new(0));
        let make_batch = || {
            let a = Arc::clone(&a);
            let b = Arc::clone(&b);
            let factories = Arc::clone(&factories);
            move |id: &str| -> Arc<dyn MessageHandler> {
                factories.fetch_add(1, Ordering::AcqRel);
                Arc::new(ProbeHandler(Arc::clone(if id == "a" { &a } else { &b })))
            }
        };
        let dropped = manager.lock().await.start_all_owned(make_batch());
        drop(dropped);
        assert_eq!(factories.load(Ordering::Acquire), 0);
        assert_eq!(a.starts.load(Ordering::Acquire), 0);
        let first = manager.lock().await.start_all_owned(make_batch());
        registered(&manager, "b", Arc::clone(&b)).await?;
        let rows = first.await;
        assert_eq!(rows.len(), 1);
        assert!(
            rows.into_iter()
                .all(|row| row.channel_id == "a" && row.result.is_ok())
        );
        assert_eq!(b.starts.load(Ordering::Acquire), 0);
        let next = manager.lock().await.start_all_owned(make_batch());
        let rows = next.await;
        assert_eq!(rows.len(), 2);
        assert!(
            rows.iter()
                .any(|row| row.channel_id == "a" && row.result.is_err())
        );
        assert!(
            rows.iter()
                .any(|row| row.channel_id == "b" && row.result.is_ok())
        );
        assert_eq!(factories.load(Ordering::Acquire), 2);
        let shutdown = manager.lock().await.stop_all_owned();
        shutdown.await?;
        Ok(())
    }

    #[tokio::test]
    async fn owned_stop_batch_excludes_later_registration_and_drop_does_not_stop() -> Result<()> {
        let manager = Arc::new(Mutex::new(ChannelManager::new()));
        let a = Probe::new(&manager);
        let b = Probe::new(&manager);
        registered(&manager, "a", Arc::clone(&a)).await?;
        let unpolled = manager.lock().await.stop_all_owned();
        drop(unpolled);
        assert_eq!(a.stops.load(Ordering::Acquire), 0);
        let first = manager.lock().await.stop_all_owned();
        registered(&manager, "b", Arc::clone(&b)).await?;
        first.await?;
        assert_eq!(a.stops.load(Ordering::Acquire), 1);
        assert_eq!(b.stops.load(Ordering::Acquire), 0);
        let next = manager.lock().await.stop_all_owned();
        next.await?;
        assert_eq!(a.stops.load(Ordering::Acquire), 1);
        assert_eq!(b.stops.load(Ordering::Acquire), 1);
        Ok(())
    }

    #[tokio::test]
    async fn parked_channel_does_not_block_other_entry_or_registry_and_stop_serializes()
    -> Result<()> {
        let manager = Arc::new(Mutex::new(ChannelManager::new()));
        let entered = Arc::new(Notify::new());
        let release = Arc::new(Notify::new());
        let mut a = Probe::new(&manager);
        Arc::get_mut(&mut a)
            .ok_or_else(|| channel_error("probe unexpectedly shared".into()))?
            .start_gate = Some((Arc::clone(&entered), Arc::clone(&release)));
        let a_handle = registered(&manager, "a", Arc::clone(&a)).await?;
        let b = Probe::new(&manager);
        let b_handle = registered(&manager, "b", Arc::clone(&b)).await?;
        let task = tokio::spawn(a_handle.start(Arc::new(ProbeHandler(Arc::clone(&a)))));
        entered.notified().await;
        assert!(a_handle.entry.state.try_write().is_err());
        let stop = tokio::spawn(a_handle.stop());
        tokio::time::timeout(Duration::from_secs(2), b_handle.health_check())
            .await
            .map_err(|_| channel_error("other entry blocked by parked start".into()))??;
        assert_eq!(a.stops.load(Ordering::Acquire), 0);
        assert_eq!(manager.lock().await.channel_ids().len(), 2);
        release.notify_one();
        task.await
            .map_err(|error| channel_error(error.to_string()))??;
        stop.await
            .map_err(|error| channel_error(error.to_string()))??;
        assert_eq!(a.stops.load(Ordering::Acquire), 1);
        assert_eq!(a.closes.load(Ordering::Acquire), 1);
        Ok(())
    }

    #[tokio::test]
    async fn failed_start_and_rollback_retain_original_handler_until_retry() -> Result<()> {
        let manager = Arc::new(Mutex::new(ChannelManager::new()));
        let mut probe = Probe::new(&manager);
        let state = Arc::get_mut(&mut probe).ok_or_else(|| channel_error("probe shared".into()))?;
        state.fail_start = true;
        state.fail_first_stop = true;
        let channel = registered(&manager, "rollback", Arc::clone(&probe)).await?;
        assert!(
            channel
                .start(Arc::new(ProbeHandler(Arc::clone(&probe))))
                .await
                .is_err()
        );
        assert_eq!(probe.closes.load(Ordering::Acquire), 0);
        assert!(
            channel
                .start(Arc::new(ProbeHandler(Arc::clone(&probe))))
                .await
                .is_err()
        );
        assert_eq!(probe.starts.load(Ordering::Acquire), 1);
        channel.stop().await?;
        assert_eq!(probe.stops.load(Ordering::Acquire), 2);
        assert_eq!(probe.closes.load(Ordering::Acquire), 1);
        assert!(!channel.entry.unsettled_handler.load(Ordering::Acquire));
        Ok(())
    }

    #[tokio::test]
    async fn owned_handle_survives_manager_and_mutable_borrow_invalidates_prior_stop() -> Result<()>
    {
        let mut manager = ChannelManager::new();
        let outside = Arc::new(Mutex::new(ChannelManager::new()));
        let probe = Probe::new(&outside);
        manager.register(Box::new(ProbePlugin {
            id: "retained",
            probe: Arc::clone(&probe),
        }))?;
        let channel = manager
            .get_owned("retained")
            .ok_or_else(|| channel_error("missing retained channel".into()))?;
        // No actual registry is retained by the probe, so callbacks do not reenter an empty manager.
        drop(outside);
        channel
            .start(Arc::new(ProbeHandler(Arc::clone(&probe))))
            .await?;
        channel.stop().await?;
        channel.stop().await?;
        assert_eq!(probe.stops.load(Ordering::Acquire), 1);
        assert!(manager.get_mut("retained").is_some());
        channel.stop().await?;
        assert_eq!(probe.stops.load(Ordering::Acquire), 2);
        let health = channel.health_check();
        drop(manager);
        health.await?;
        channel
            .start(Arc::new(ProbeHandler(Arc::clone(&probe))))
            .await?;
        channel.stop().await?;
        assert_eq!(probe.starts.load(Ordering::Acquire), 2);
        assert_eq!(probe.closes.load(Ordering::Acquire), 2);
        Ok(())
    }

    #[tokio::test]
    async fn concurrent_mutable_borrow_cannot_be_cleared_by_inflight_stop_and_epoch_saturates()
    -> Result<()> {
        let manager = Arc::new(Mutex::new(ChannelManager::new()));
        let entered = Arc::new(Notify::new());
        let release = Arc::new(Notify::new());
        let mut probe = Probe::new(&manager);
        Arc::get_mut(&mut probe)
            .ok_or_else(|| channel_error("probe shared".into()))?
            .stop_gate = Some((Arc::clone(&entered), Arc::clone(&release)));
        let channel = registered(&manager, "epoch", Arc::clone(&probe)).await?;
        let first = tokio::spawn(channel.stop());
        entered.notified().await;
        assert!(manager.lock().await.get_mut("epoch").is_some());
        release.notify_one();
        first
            .await
            .map_err(|error| channel_error(error.to_string()))??;
        let second = tokio::spawn(channel.stop());
        entered.notified().await;
        release.notify_one();
        second
            .await
            .map_err(|error| channel_error(error.to_string()))??;
        assert_eq!(probe.stops.load(Ordering::Acquire), 2);
        channel
            .entry
            .mutation_epoch
            .store(u64::MAX, Ordering::Release);
        assert!(manager.lock().await.get_mut("epoch").is_some());
        assert_eq!(
            channel.entry.mutation_epoch.load(Ordering::Acquire),
            u64::MAX
        );
        for _ in 0..2 {
            let task = tokio::spawn(channel.stop());
            entered.notified().await;
            release.notify_one();
            task.await
                .map_err(|error| channel_error(error.to_string()))??;
        }
        assert_eq!(probe.stops.load(Ordering::Acquire), 4);
        Ok(())
    }

    #[tokio::test]
    async fn registration_metadata_is_fixed_while_async_calls_reach_original_plugin() -> Result<()>
    {
        struct DynamicDeclaration {
            started: bool,
        }
        #[async_trait]
        impl ChannelPlugin for DynamicDeclaration {
            fn id(&self) -> &str {
                "declared"
            }
            fn label(&self) -> &str {
                if self.started {
                    "changed"
                } else {
                    "registered"
                }
            }
            fn capabilities(&self) -> &ChannelCapabilities {
                static CHANGED: ChannelCapabilities = ChannelCapabilities {
                    chat_types: &[ChatType::Group],
                    supports_media: true,
                    supports_threads: true,
                };
                if self.started { &CHANGED } else { &CAPS }
            }
            async fn start(&mut self, _handler: Arc<dyn MessageHandler>) -> Result<()> {
                self.started = true;
                Ok(())
            }
            async fn stop(&mut self) -> Result<()> {
                Ok(())
            }
            async fn send(&self, _message: OutboundMessage) -> Result<()> {
                if self.started {
                    Ok(())
                } else {
                    Err(channel_error("original instance not started".into()))
                }
            }
        }
        let outside = Arc::new(Mutex::new(ChannelManager::new()));
        let probe = Probe::new(&outside);
        drop(outside);
        let mut manager = ChannelManager::new();
        manager.register(Box::new(DynamicDeclaration { started: false }))?;
        let channel = manager
            .get_owned("declared")
            .ok_or_else(|| channel_error("missing declaration".into()))?;
        let borrowed = manager
            .get_mut("declared")
            .ok_or_else(|| channel_error("missing mutable declaration".into()))?;
        borrowed.start(Arc::new(ProbeHandler(probe))).await?;
        assert_eq!(borrowed.label(), "registered");
        assert_eq!(borrowed.capabilities().chat_types, &[ChatType::Direct]);
        assert!(!borrowed.capabilities().supports_media);
        assert_eq!(channel.label(), "registered");
        channel
            .send(OutboundMessage::new(
                "declared",
                "chat",
                ChatType::Direct,
                "original",
            ))
            .await?;
        channel.stop().await?;
        Ok(())
    }
}
