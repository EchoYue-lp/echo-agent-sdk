//! Eval runner — executes eval cases against an agent.

use crate::agent::{
    AGENT_CANCELLATION_SETTLE_PERIOD, Agent, AgentInvocationContext, EventEnvelope, EventIdentity,
};
use crate::eval::{EvalCase, EvalConstraints, EvalReport, EvalResult, SuccessCriteria};
use crate::eval::{LlmGrader, TrajectoryReplay};
use crate::runtime::{
    AgentTurnDriver, EventSink, SinkControl, TurnDeliveryOutcome, TurnMode, TurnOutcome,
    TurnReceipt, TurnRequest,
};
use crate::trace::{Run, RunEvent};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::Instant;
use tokio_util::sync::CancellationToken;

struct EvalEventSink;

#[async_trait::async_trait]
impl EventSink for EvalEventSink {
    async fn on_event(&self, _envelope: EventEnvelope) -> crate::error::Result<SinkControl> {
        Ok(SinkControl::Continue)
    }
}

fn record_delivery_result(result: &mut EvalResult, receipt: &TurnReceipt) {
    match &receipt.delivery {
        TurnDeliveryOutcome::Delivered => {}
        TurnDeliveryOutcome::Failed(failure) => {
            result.success = false;
            result.violations.push(format!(
                "Turn delivery failed ({}): {}",
                failure.code, failure.message
            ));
        }
        TurnDeliveryOutcome::NotAttempted => {
            result.success = false;
            result
                .violations
                .push("Turn delivery was not attempted".to_string());
        }
        TurnDeliveryOutcome::Closed => {
            result.success = false;
            result
                .violations
                .push("Turn delivery closed before acceptance".to_string());
        }
    }
}

struct EvalWorkspaceGeneration {
    directory: Option<tempfile::TempDir>,
}

impl EvalWorkspaceGeneration {
    fn create(parent: &Path) -> std::io::Result<Self> {
        std::fs::create_dir_all(parent)?;
        let mut builder = tempfile::Builder::new();
        builder.prefix("eval-").disable_cleanup(true);
        let directory = builder.tempdir_in(parent)?;
        Ok(Self {
            directory: Some(directory),
        })
    }

    fn path(&self) -> Option<&Path> {
        self.directory.as_ref().map(tempfile::TempDir::path)
    }

    fn close(mut self) -> std::io::Result<()> {
        match self.directory.take() {
            Some(directory) => directory.close(),
            None => Ok(()),
        }
    }

    fn retain(mut self) -> Option<PathBuf> {
        self.directory.take().map(tempfile::TempDir::keep)
    }
}

impl Drop for EvalWorkspaceGeneration {
    fn drop(&mut self) {
        if let Some(directory) = self.directory.as_ref() {
            tracing::warn!(
                path = %directory.path().display(),
                "Retaining unsettled eval workspace generation"
            );
        }
    }
}

/// Runs eval cases against agents.
#[derive(Clone)]
pub struct EvalRunner {
    /// Parent directory for unique per-run workspace generations.
    pub workspace_root: PathBuf,
    /// Maximum time per eval case in seconds.
    pub timeout_secs: u64,
    /// Optional LLM grader for assertion-based evaluation.
    pub grader: Option<Arc<LlmGrader>>,
    /// Optional grading agent (shared across cases, used by LlmGraded criteria).
    pub grading_agent: Option<Arc<dyn crate::agent::Agent>>,
    /// Optional run store for populating metrics from trace.
    pub run_store: Option<Arc<dyn crate::trace::RunStore>>,
}

impl EvalRunner {
    /// Create a new runner.
    pub fn new(workspace_root: PathBuf) -> Self {
        std::fs::create_dir_all(&workspace_root).ok();
        Self {
            workspace_root,
            timeout_secs: 300,
            grader: None,
            grading_agent: None,
            run_store: None,
        }
    }

    /// Attach a run store for metrics population from trace.
    pub fn with_run_store(mut self, store: Arc<dyn crate::trace::RunStore>) -> Self {
        self.run_store = Some(store);
        self
    }

    /// Attach an LLM grader for assertion-based evaluation.
    pub fn with_grader(mut self, grader: LlmGrader, agent: Arc<dyn crate::agent::Agent>) -> Self {
        self.grader = Some(Arc::new(grader));
        self.grading_agent = Some(agent);
        self
    }

    /// Run a single eval case against the given agent.
    pub async fn run(&self, case: &EvalCase, agent: &dyn Agent) -> EvalResult {
        let started = Instant::now();
        let generation = match EvalWorkspaceGeneration::create(&self.workspace_root) {
            Ok(generation) => generation,
            Err(error) => {
                let mut result = EvalResult::new(&case.id, false);
                result
                    .violations
                    .push(format!("Workspace generation failed: {error}"));
                return result;
            }
        };
        let Some(cwd) = generation.path().map(Path::to_path_buf) else {
            let mut result = EvalResult::new(&case.id, false);
            result
                .violations
                .push("Workspace generation has no active directory".to_string());
            return result;
        };
        if let Err(error) = self.setup_fixture(case, &cwd) {
            let mut result = EvalResult::new(&case.id, false);
            result
                .violations
                .push(format!("Fixture setup failed: {error}"));
            Self::record_workspace_cleanup(&mut result, generation.close());
            result.recompute_score();
            return result;
        }
        let mut result = EvalResult::new(&case.id, true);
        let mut final_output = None;

        let cancel = CancellationToken::new();
        let identity_value = format!("eval-{}", uuid::Uuid::new_v4());
        let identity = match EventIdentity::for_run(identity_value.clone()) {
            Ok(identity) => identity,
            Err(error) => {
                result.success = false;
                result
                    .violations
                    .push(format!("Eval turn identity failed: {error}"));
                Self::record_workspace_cleanup(&mut result, generation.close());
                result.recompute_score();
                return result;
            }
        };
        let invocation = AgentInvocationContext {
            runtime: Some(crate::tools::ExternalRunContext {
                run_id: Some(identity_value.clone()),
                turn_id: Some(identity_value.clone()),
                execution_id: Some(identity_value.clone()),
                ..crate::tools::ExternalRunContext::default()
            }),
            working_dir: Some(cwd.clone()),
            cancel: Some(cancel.clone()),
            ..AgentInvocationContext::default()
        };
        let request = TurnRequest::new(identity, case.task.clone())
            .mode(TurnMode::Execute)
            .cancel(cancel.clone())
            .invocation(invocation);
        let mut drive = Box::pin(AgentTurnDriver.drive(agent, request, &EvalEventSink));
        let deadline_result = tokio::time::timeout(
            std::time::Duration::from_secs(self.timeout_secs),
            &mut drive,
        )
        .await;
        let (receipt, timed_out) = match deadline_result {
            Ok(receipt) => (Some(receipt), false),
            Err(_) => {
                cancel.cancel();
                match tokio::time::timeout(AGENT_CANCELLATION_SETTLE_PERIOD, &mut drive).await {
                    Ok(receipt) => (Some(receipt), true),
                    Err(_) => (None, true),
                }
            }
        };
        drop(drive);
        let turn_settled = receipt.is_some();

        result.duration_ms = u64::try_from(started.elapsed().as_millis()).unwrap_or(u64::MAX);

        if timed_out {
            result.success = false;
            result.violations.push("Timeout".to_string());
            match receipt.as_ref() {
                Some(receipt) => result
                    .violations
                    .push(format!("Turn settled after timeout: {}", receipt.status())),
                None => result.violations.push(format!(
                    "Turn did not settle within {} ms cancellation grace",
                    AGENT_CANCELLATION_SETTLE_PERIOD.as_millis()
                )),
            }
        } else if let Some(receipt) = receipt.as_ref() {
            record_delivery_result(&mut result, receipt);
            match &receipt.outcome {
                TurnOutcome::Completed => match receipt.final_answer.as_ref() {
                    Some(output) => final_output = Some(output.clone()),
                    None => {
                        result.success = false;
                        result
                            .violations
                            .push("Completed turn did not include a final answer".to_string());
                    }
                },
                TurnOutcome::Cancelled => {
                    result.success = false;
                    result.violations.push("Agent cancelled".to_string());
                }
                TurnOutcome::Failed(failure) => {
                    result.success = false;
                    result.violations.push(format!(
                        "Agent error ({}): {}",
                        failure.code, failure.message
                    ));
                }
            }
        }

        // Resolve the producer-owned trace through this invocation's correlation.
        // EvalResult and all trace-based scoring then consume the same verified Run.
        let run = if turn_settled && let Some(ref store) = self.run_store {
            match Self::load_correlated_trace(store.as_ref(), &identity_value).await {
                Ok(run) => {
                    result.run_id = run.as_ref().map(|run| run.run_id.clone());
                    run
                }
                Err(error) => {
                    result.success = false;
                    result
                        .violations
                        .push(format!("Trace lookup failed: {error}"));
                    None
                }
            }
        } else {
            None
        };

        if let Some(output) = final_output.as_deref() {
            let criteria_result = self
                .check_criteria(
                    &case.success_criteria,
                    output,
                    &case.task,
                    &cwd,
                    run.as_ref(),
                )
                .await;
            if !criteria_result.success {
                result.success = false;
            }
            result.metrics.extend(criteria_result.metrics);
            result.violations.extend(criteria_result.violations);
        }

        // Populate metrics from trace (all branches — errors/timeouts also have diagnostic trace value)
        if let Some(run) = run.as_ref() {
            let replay = TrajectoryReplay::new(run.clone());
            let violations = self.evaluate_run_constraints(&case.constraints, run);
            if !violations.is_empty() {
                result.violations.extend(violations);
                result.success = false;
            }
            result.tool_calls = replay.total_tool_calls();
            result.tokens_in = run.token_usage.prompt_tokens;
            result.tokens_out = run.token_usage.completion_tokens;
            result.cached_tokens_in = run.token_usage.cached_prompt_tokens;
            result.cache_creation_tokens_in = run.token_usage.cache_creation_prompt_tokens;
            result.cache_hit_rate = run.token_usage.cache_hit_rate();
            result.tool_errors = replay.tool_error_count();
            result.max_protected_context_tokens = run
                .events
                .iter()
                .filter_map(|event| match event {
                    crate::trace::RunEvent::LlmCall {
                        protected_context_tokens,
                        ..
                    } => Some(*protected_context_tokens),
                    _ => None,
                })
                .max()
                .unwrap_or(0);
            result.file_changes = replay.written_files().len();
        }

        if turn_settled {
            Self::record_workspace_cleanup(&mut result, generation.close());
        } else {
            if let Some(path) = generation.retain() {
                result.violations.push(format!(
                    "Workspace retained after timeout: {}",
                    path.display()
                ));
            }
        }
        result.recompute_score();
        result
    }

    async fn load_correlated_trace(
        store: &dyn crate::trace::RunStore,
        correlation_id: &str,
    ) -> std::result::Result<Option<Run>, String> {
        let summaries = store
            .list_by_parent_run(correlation_id)
            .await
            .map_err(|error| format!("could not list correlation {correlation_id}: {error}"))?;
        let mut exact = summaries.into_iter().filter(|summary| {
            summary.parent_run_id.as_deref() == Some(correlation_id)
                && summary.turn_id.as_deref() == Some(correlation_id)
                && summary.execution_id.as_deref() == Some(correlation_id)
        });
        let Some(summary) = exact.next() else {
            return Ok(None);
        };
        if exact.next().is_some() {
            return Err(format!(
                "multiple traces matched correlation {correlation_id}"
            ));
        }
        let trace_run_id = summary.run_id;
        let run = store
            .load(&trace_run_id)
            .await
            .map_err(|error| format!("could not load trace {trace_run_id}: {error}"))?
            .ok_or_else(|| format!("trace summary {trace_run_id} has no loadable Run"))?;
        if run.run_id != trace_run_id
            || run.parent_run_id.as_deref() != Some(correlation_id)
            || run.turn_id.as_deref() != Some(correlation_id)
            || run.execution_id.as_deref() != Some(correlation_id)
        {
            return Err(format!(
                "loaded trace {trace_run_id} does not match correlation {correlation_id}"
            ));
        }
        Ok(Some(run))
    }

    /// Run all cases against agents created by the factory.
    /// Each case gets a fresh agent.
    pub async fn run_all(
        &self,
        cases: &[EvalCase],
        mut agent_factory: impl FnMut() -> Box<dyn Agent>,
    ) -> EvalReport {
        self.run_all_async(cases, || std::future::ready(agent_factory()))
            .await
    }

    /// Run every case with an Agent created lazily by an asynchronous factory.
    /// This shares the per-case execution path with [`Self::run_all`].
    pub async fn run_all_async<F, Fut>(
        &self,
        cases: &[EvalCase],
        mut agent_factory: F,
    ) -> EvalReport
    where
        F: FnMut() -> Fut,
        Fut: std::future::Future<Output = Box<dyn Agent>>,
    {
        let mut results = Vec::with_capacity(cases.len());
        for case in cases {
            let agent = agent_factory().await;
            let result = self.run(case, &*agent).await;
            results.push(result);
        }
        EvalReport::new(results)
    }

    // ── Private helpers ────────────────────────────────────────────

    fn setup_fixture(
        &self,
        case: &EvalCase,
        destination: &Path,
    ) -> std::result::Result<(), String> {
        let Some(fixture) = case.project_fixture.as_ref() else {
            return Ok(());
        };
        if !fixture.exists() {
            return Err(format!("fixture does not exist: {}", fixture.display()));
        }
        if let Err(e) = copy_dir(fixture, destination) {
            return Err(format!("failed to copy fixture {}: {e}", fixture.display()));
        }
        Ok(())
    }

    fn record_workspace_cleanup(result: &mut EvalResult, cleanup: std::io::Result<()>) {
        if let Err(error) = cleanup {
            result.success = false;
            result
                .violations
                .push(format!("Workspace cleanup failed: {error}"));
        }
    }

    async fn record_test_run(
        &self,
        result: &mut EvalResult,
        run: Option<&Run>,
        command: &str,
        passed: bool,
    ) {
        let (Some(store), Some(run)) = (self.run_store.as_ref(), run) else {
            return;
        };
        // A command's exit status is authoritative for this test criterion,
        // not for the number of failing assertions inside its test runner.
        let mut event = RunEvent::TestRun {
            command: command.to_string(),
            passed,
            failure_count: None,
        };
        event.apply_retention(&echo_core::utils::retention::ContentRetentionPolicy::default());
        if let Err(error) = store.append_event(&run.run_id, event).await {
            result.success = false;
            result
                .violations
                .push(format!("TestRun trace append failed: {error}"));
        }
    }

    async fn check_criteria(
        &self,
        criteria: &SuccessCriteria,
        output: &str,
        task: &str,
        cwd: &Path,
        run: Option<&Run>,
    ) -> EvalResult {
        match criteria {
            SuccessCriteria::LlmGraded { assertions } => {
                if let (Some(grader), Some(grading_agent)) = (&self.grader, &self.grading_agent) {
                    let report = grader
                        .grade(grading_agent.as_ref(), task, output, assertions)
                        .await;
                    let mut result = EvalResult::new("criteria", report.pass_rate >= 0.5);
                    result.metrics.push(crate::eval::EvalMetric {
                        name: "llm_graded".into(),
                        score: report.pass_rate,
                        detail: format!(
                            "{} assertions, {:.0}% pass rate",
                            assertions.len(),
                            report.pass_rate * 100.0
                        ),
                    });
                    result
                } else {
                    let mut r = EvalResult::new("criteria", false);
                    r.violations
                        .push("LlmGraded criteria set but no grader configured".into());
                    r
                }
            }
            SuccessCriteria::TestPass { command } => {
                let command_result = run_command(command, cwd).await;
                let passed = command_result.as_ref().is_ok_and(|status| *status);
                let mut result = EvalResult::new("criteria", passed);
                if let Err(error) = command_result {
                    result
                        .violations
                        .push(format!("Test command could not be launched: {error}"));
                } else {
                    self.record_test_run(&mut result, run, command, passed)
                        .await;
                }
                result.metrics.push(crate::eval::EvalMetric {
                    name: "test_pass".into(),
                    score: if passed { 1.0 } else { 0.0 },
                    detail: format!("Command: {command}"),
                });
                result
            }
            SuccessCriteria::OutputContains { substring } => {
                let found = output.contains(substring.as_str());
                let mut result = EvalResult::new("criteria", found);
                result.metrics.push(crate::eval::EvalMetric {
                    name: "output_contains".into(),
                    score: if found { 1.0 } else { 0.0 },
                    detail: format!("Looking for: {substring}"),
                });
                if !found {
                    result.violations.push(format!(
                        "Output missing: {substring}. Got: {}",
                        output.chars().take(200).collect::<String>()
                    ));
                }
                result
            }
            SuccessCriteria::ToolUsed { tool_name } => {
                let used = run
                    .is_some_and(|run| TrajectoryReplay::new(run.clone()).tool_was_used(tool_name));
                let mut result = EvalResult::new("criteria", used);
                result.metrics.push(crate::eval::EvalMetric {
                    name: "tool_used".into(),
                    score: if used { 1.0 } else { 0.0 },
                    detail: format!("Required tool: {tool_name}"),
                });
                if !used {
                    result.violations.push(if run.is_some() {
                        format!("Required tool was not used: {tool_name}")
                    } else {
                        format!("Cannot verify required tool without trace: {tool_name}")
                    });
                }
                result
            }
            SuccessCriteria::ToolNotUsed { tool_name } => {
                let trace_available = run.is_some();
                let used = run
                    .is_some_and(|run| TrajectoryReplay::new(run.clone()).tool_was_used(tool_name));
                let passed = trace_available && !used;
                let mut result = EvalResult::new("criteria", passed);
                result.metrics.push(crate::eval::EvalMetric {
                    name: "tool_not_used".into(),
                    score: if passed { 1.0 } else { 0.0 },
                    detail: format!("Forbidden tool: {tool_name}"),
                });
                if !passed {
                    result.violations.push(if trace_available {
                        format!("Forbidden tool was used: {tool_name}")
                    } else {
                        format!("Cannot verify forbidden tool without trace: {tool_name}")
                    });
                }
                result
            }
            SuccessCriteria::AllOf(items) => {
                let mut all_pass = true;
                let mut metrics = Vec::new();
                let mut violations = Vec::new();
                for item in items {
                    let r = Box::pin(self.check_criteria(item, output, task, cwd, run)).await;
                    if !r.success {
                        all_pass = false;
                        violations.extend(r.violations);
                    }
                    metrics.extend(r.metrics);
                }
                let mut result = EvalResult::new("criteria", all_pass);
                result.metrics = metrics;
                result.violations = violations;
                result
            }
            SuccessCriteria::AnyOf(items) => {
                let mut any_pass = false;
                let mut metrics = Vec::new();
                let mut violations = Vec::new();
                for item in items {
                    let r = Box::pin(self.check_criteria(item, output, task, cwd, run)).await;
                    if r.success {
                        any_pass = true;
                    } else {
                        violations.extend(r.violations);
                    }
                    metrics.extend(r.metrics);
                }
                let mut result = EvalResult::new("criteria", any_pass);
                result.metrics = metrics;
                if !any_pass {
                    result.violations = violations;
                }
                result
            }
            SuccessCriteria::SweBench {
                repo_url,
                base_commit,
                test_patch,
                test_command,
            } => {
                // Validate repo_url: only allow https:// scheme
                if !repo_url.starts_with("https://") {
                    return EvalResult::new("criteria", false).with_metric(
                        "swe_bench",
                        0.0,
                        "Only https:// URLs are allowed for repository cloning",
                    );
                }

                // Validate test_command: reject shell metacharacters that could
                // lead to command injection when passed to `sh -c`
                if let Err(msg) = validate_shell_command(test_command) {
                    return EvalResult::new("criteria", false).with_metric("swe_bench", 0.0, &msg);
                }

                // SWE-bench eval workflow:
                // 1. Clone repo (if not already cloned)
                // 2. Checkout base commit
                // 3. Agent runs (already done by the time we check criteria)
                // 4. Apply test patch
                // 5. Run test command
                let repo_dir = cwd.join("repo");
                if !repo_dir.exists() {
                    let clone_result = std::process::Command::new("git")
                        .args(["clone", repo_url, repo_dir.to_str().unwrap_or("repo")])
                        .current_dir(cwd)
                        .output();
                    match clone_result {
                        Ok(output) if output.status.success() => {}
                        Ok(output) => {
                            let stderr = String::from_utf8_lossy(&output.stderr);
                            tracing::warn!("git clone failed for {}: {}", repo_url, stderr);
                            return EvalResult::new("criteria", false).with_metric(
                                "swe_bench",
                                0.0,
                                &format!("Clone failed: {}", stderr),
                            );
                        }
                        Err(e) => {
                            tracing::warn!("git clone error for {}: {}", repo_url, e);
                            return EvalResult::new("criteria", false).with_metric(
                                "swe_bench",
                                0.0,
                                &format!("Clone failed: {e}"),
                            );
                        }
                    }
                }

                let checkout_result = std::process::Command::new("git")
                    .args(["checkout", base_commit])
                    .current_dir(&repo_dir)
                    .output();
                match checkout_result {
                    Ok(output) if output.status.success() => {}
                    Ok(output) => {
                        let stderr = String::from_utf8_lossy(&output.stderr);
                        tracing::warn!("git checkout {} failed: {}", base_commit, stderr);
                        return EvalResult::new("criteria", false).with_metric(
                            "swe_bench",
                            0.0,
                            &format!("Checkout failed: {}", stderr),
                        );
                    }
                    Err(e) => {
                        tracing::warn!("git checkout error: {}", e);
                        return EvalResult::new("criteria", false).with_metric(
                            "swe_bench",
                            0.0,
                            &format!("Checkout failed: {e}"),
                        );
                    }
                }

                let apply_result = std::process::Command::new("git")
                    .args(["apply", test_patch])
                    .current_dir(&repo_dir)
                    .output();
                match apply_result {
                    Ok(output) if output.status.success() => {}
                    Ok(output) => {
                        let stderr = String::from_utf8_lossy(&output.stderr);
                        tracing::warn!("git apply failed: {}", stderr);
                        return EvalResult::new("criteria", false).with_metric(
                            "swe_bench",
                            0.0,
                            &format!("Apply failed: {}", stderr),
                        );
                    }
                    Err(e) => {
                        tracing::warn!("git apply error: {}", e);
                        return EvalResult::new("criteria", false).with_metric(
                            "swe_bench",
                            0.0,
                            &format!("Apply failed: {e}"),
                        );
                    }
                }

                let command_result = run_command(test_command, &repo_dir).await;
                let passed = command_result.as_ref().is_ok_and(|status| *status);

                let mut result = EvalResult::new("criteria", passed);
                if let Err(error) = command_result {
                    result
                        .violations
                        .push(format!("Test command could not be launched: {error}"));
                } else {
                    self.record_test_run(&mut result, run, test_command, passed)
                        .await;
                }
                result.metrics.push(crate::eval::EvalMetric {
                    name: "swe_bench".into(),
                    score: if passed { 1.0 } else { 0.0 },
                    detail: format!("{repo_url} @ {base_commit}: {test_command}"),
                });
                result
            }
            SuccessCriteria::SafetyCheck {
                forbidden_patterns,
                required_patterns,
            } => {
                let mut violations = Vec::new();
                let mut checks_total = 0;
                let mut checks_passed = 0;

                // Check forbidden patterns — none should appear
                for pattern in forbidden_patterns {
                    checks_total += 1;
                    if output.contains(pattern.as_str()) {
                        violations.push(format!(
                            "SAFETY VIOLATION: output contains forbidden pattern '{}'",
                            pattern
                        ));
                    } else {
                        checks_passed += 1;
                    }
                }

                // Check required patterns — all must appear
                for pattern in required_patterns {
                    checks_total += 1;
                    if output.contains(pattern.as_str()) {
                        checks_passed += 1;
                    } else {
                        violations.push(format!(
                            "SAFETY VIOLATION: output missing required pattern '{}'",
                            pattern
                        ));
                    }
                }

                let score = if checks_total > 0 {
                    checks_passed as f64 / checks_total as f64
                } else {
                    1.0
                };
                let passed = violations.is_empty();

                let mut result = EvalResult::new("criteria", passed);
                result.violations = violations;
                result.metrics.push(crate::eval::EvalMetric {
                    name: "safety_check".into(),
                    score,
                    detail: format!("{}/{} safety checks passed", checks_passed, checks_total),
                });
                result
            }
            SuccessCriteria::CitationValid {
                min_citations,
                format,
            } => {
                let citation_patterns: Vec<&str> = match format.as_str() {
                    "pmid" => vec![r"(?i)PMID:?\s*\d+"],
                    "doi" => vec![r"(?i)10\.\d{4,9}/[-._;()/:A-Z0-9]+"],
                    "url" => vec![r"https?://[^\s)\]}>]+"],
                    _ => vec![
                        r"(?i)PMID:?\s*\d+",
                        r"(?i)10\.\d{4,9}/[-._;()/:A-Z0-9]+",
                        r"https?://[^\s)\]}>]+",
                    ],
                };

                let mut citations = Vec::new();
                for pattern in &citation_patterns {
                    if let Ok(re) = regex::Regex::new(pattern) {
                        citations.extend(re.find_iter(output).map(|matched| {
                            matched
                                .as_str()
                                .trim_end_matches(|character: char| {
                                    matches!(character, '.' | ',' | ';' | ':')
                                })
                                .to_lowercase()
                        }));
                    }
                }
                citations.sort();
                citations.dedup();
                let source_text = run.map(|run| {
                    run.events
                        .iter()
                        .filter_map(|event| match event {
                            crate::trace::RunEvent::ToolResult {
                                output_preview: Some(preview),
                                ..
                            } => Some(preview.as_str()),
                            _ => None,
                        })
                        .collect::<Vec<_>>()
                        .join("\n")
                        .to_lowercase()
                });
                let verified_count = source_text.as_ref().map_or(0, |source| {
                    citations
                        .iter()
                        .filter(|citation| source.contains(citation.as_str()))
                        .count()
                });

                let passed = run.is_some() && verified_count >= *min_citations;
                let score = if *min_citations > 0 {
                    (verified_count as f64 / *min_citations as f64).min(1.0)
                } else {
                    1.0
                };

                let mut result = EvalResult::new("criteria", passed);
                result.metrics.push(crate::eval::EvalMetric {
                    name: "citation_valid".into(),
                    score,
                    detail: format!(
                        "Found {} citations, verified {} against tool result previews (format: {}, required: {})",
                        citations.len(), verified_count, format, min_citations
                    ),
                });
                if !passed {
                    result.violations.push(if run.is_some() {
                        format!(
                            "Insufficient citations backed by tool result previews: verified {} but need at least {} (format: {})",
                            verified_count, min_citations, format
                        )
                    } else {
                        "Cannot verify citations without an execution trace".to_string()
                    });
                }
                result
            }
            SuccessCriteria::ValueMatch {
                expected,
                tolerance,
            } => {
                let mut checks_total = 0;
                let mut checks_passed = 0;
                let mut details = Vec::new();

                for (key, expected_val) in expected {
                    checks_total += 1;
                    // Try to find the value in the output by looking for
                    // patterns like "key: value" or "key = value" or just the number
                    let found = extract_number_near_key(output, key);
                    match found {
                        Some(actual) => {
                            let diff = (actual - expected_val).abs();
                            let threshold = expected_val.abs() * tolerance + tolerance;
                            if diff <= threshold {
                                checks_passed += 1;
                                details.push(format!("{}: {} ≈ {} ✓", key, actual, expected_val));
                            } else {
                                details.push(format!(
                                    "{}: {} ≠ {} (diff={:.4}) ✗",
                                    key, actual, expected_val, diff
                                ));
                            }
                        }
                        None => {
                            details.push(format!("{}: not found in output ✗", key));
                        }
                    }
                }

                let score = if checks_total > 0 {
                    checks_passed as f64 / checks_total as f64
                } else {
                    1.0
                };
                let passed = checks_passed == checks_total;

                let mut result = EvalResult::new("criteria", passed);
                result.metrics.push(crate::eval::EvalMetric {
                    name: "value_match".into(),
                    score,
                    detail: format!(
                        "{}/{} values matched (tolerance: {}): {}",
                        checks_passed,
                        checks_total,
                        tolerance,
                        details.join("; ")
                    ),
                });
                if !passed {
                    for d in &details {
                        if d.contains('✗') {
                            result.violations.push(d.clone());
                        }
                    }
                }
                result
            }
        }
    }

    /// Evaluate constraints using a completed run trace.
    pub fn evaluate_run_constraints(
        &self,
        constraints: &EvalConstraints,
        run: &Run,
    ) -> Vec<String> {
        let replay = TrajectoryReplay::new(run.clone());
        let mut violations = replay.evaluate_constraints(constraints);

        // Check forbidden paths against written files
        if !constraints.forbidden_paths.is_empty() {
            for file in replay.written_files() {
                for forbidden in &constraints.forbidden_paths {
                    if file.contains(forbidden.as_str()) {
                        violations.push(format!("Forbidden path modified: {file}"));
                    }
                }
            }
        }

        // Check max files changed
        if let Some(max) = constraints.max_files_changed {
            let written = replay.written_files();
            if written.len() > max {
                violations.push(format!(
                    "Too many files changed: {} (max {})",
                    written.len(),
                    max
                ));
            }
        }

        violations
    }
}

/// Validate a shell command for dangerous metacharacters.
///
/// Rejects commands containing characters that could be used for command injection
/// or unintended shell expansion when passed to `sh -c`.
fn validate_shell_command(cmd: &str) -> std::result::Result<(), String> {
    let dangerous_chars = [';', '|', '&', '$', '`', '>', '<'];
    for c in &dangerous_chars {
        if cmd.contains(*c) {
            return Err(format!(
                "Test command rejected: contains '{}' which is not allowed (shell metacharacters are blocked for security)",
                c
            ));
        }
    }
    Ok(())
}

/// Run a test command and distinguish a completed failure from an unproven launch.
async fn run_command(cmd: &str, cwd: &Path) -> std::io::Result<bool> {
    let output = tokio::process::Command::new("sh")
        .arg("-c")
        .arg(cmd)
        .current_dir(cwd)
        .output()
        .await?;
    match output.status.code() {
        Some(0) => Ok(true),
        // sh reserves these statuses for command lookup/exec failures. A test
        // process can also return them, so omit the fact rather than asserting
        // that the configured test runner definitely executed.
        Some(126 | 127) => Err(std::io::Error::new(
            std::io::ErrorKind::NotFound,
            "test command execution could not be confirmed",
        )),
        Some(_) => Ok(false),
        None => Err(std::io::Error::new(
            std::io::ErrorKind::Interrupted,
            "test command ended without an exit status",
        )),
    }
}

/// Try to extract a numeric value near a given key in the output text.
///
/// Searches for patterns like "key: 0.85", "key = 0.85", "key 0.85"
/// or just the first number after the key within a small window.
fn extract_number_near_key(text: &str, key: &str) -> Option<f64> {
    // Build a pattern that matches "key" followed by separators and a number
    let escaped_key = regex::escape(key);
    let pattern = format!(r"(?i){escaped_key}\s*[:=：]\s*(-?\d+\.?\d*(?:\s*%|e[+-]?\d+)?)");
    if let Ok(re) = regex::Regex::new(&pattern)
        && let Some(captures) = re.captures(text)
    {
        let num_str = captures
            .get(1)
            .map(|m| m.as_str().replace(['%', '，'], ""))
            .unwrap_or_default();
        return num_str.trim().parse::<f64>().ok();
    }

    // Fallback: find the key and look for a number in the next 50 chars
    let lower_text = text.to_lowercase();
    let lower_key = key.to_lowercase();
    if let Some(pos) = lower_text.find(&lower_key) {
        let prefix_chars = lower_text.get(..pos)?.chars().count();
        let after: String = text
            .chars()
            .skip(prefix_chars)
            .take(key.chars().count().saturating_add(50))
            .collect();
        if let Ok(re) = regex::Regex::new(r"(-?\d+\.?\d*(?:e[+-]?\d+)?)")
            && let Some(m) = re.find(&after)
        {
            return m.as_str().parse::<f64>().ok();
        }
    }
    None
}

/// Simple recursive directory copy.
fn copy_dir(src: &Path, dest: &Path) -> std::io::Result<()> {
    std::fs::create_dir_all(dest)?;
    for entry in std::fs::read_dir(src)? {
        let entry = entry?;
        let ty = entry.file_type()?;
        let dest_path = dest.join(entry.file_name());
        if ty.is_dir() {
            copy_dir(&entry.path(), &dest_path)?;
        } else {
            std::fs::copy(entry.path(), &dest_path)?;
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::agent::AgentEvent;
    use crate::eval::EvalCase;
    use crate::trace::{RunEvent, RunStatus, RunSummary, RunTimings, TokenUsage};
    use chrono::Utc;
    use std::sync::atomic::{AtomicUsize, Ordering};

    #[test]
    fn eval_records_delivery_failure_independently_from_execution() -> crate::error::Result<()> {
        let mut result = EvalResult::new("delivery-failure", true);
        let receipt = TurnReceipt {
            turn_id: echo_core::agent::TurnId::new("eval-delivery-failure")?,
            outcome: TurnOutcome::Completed,
            delivery: TurnDeliveryOutcome::Failed(crate::error::AgentFailure::from(
                &crate::error::ReactError::Other("projection failed".to_string()),
            )),
            final_answer: Some("done".to_string()),
            final_message_id: None,
            prompt_tokens: 0,
            completion_tokens: 0,
            llm_calls: 0,
            compaction_count: 0,
            last_event_sequence: 1,
            elapsed: std::time::Duration::ZERO,
        };

        record_delivery_result(&mut result, &receipt);
        assert!(!result.success);
        assert!(
            result
                .violations
                .iter()
                .any(|violation| violation.contains("Turn delivery failed"))
        );
        Ok(())
    }

    struct WorkspaceRecordingAgent {
        cwd_tx: tokio::sync::mpsc::UnboundedSender<PathBuf>,
        release: Option<Arc<tokio::sync::Notify>>,
        fail_after_recording: bool,
        run_id: Option<String>,
    }

    struct CancellationSettlingAgent {
        cwd_tx: tokio::sync::mpsc::UnboundedSender<PathBuf>,
        settled_tx: tokio::sync::Mutex<Option<tokio::sync::oneshot::Sender<()>>>,
        terminal_answer: Option<String>,
        stream_invocations: Arc<AtomicUsize>,
    }

    struct CountingRunStore {
        lists: AtomicUsize,
        loads: AtomicUsize,
    }

    #[derive(Clone, Copy)]
    enum TraceLookupFailure {
        List,
        Load,
        Dangling,
        MismatchedRun,
    }

    struct FaultingTraceRunStore {
        summary: RunSummary,
        mode: TraceLookupFailure,
    }

    impl WorkspaceRecordingAgent {
        fn new(
            cwd_tx: tokio::sync::mpsc::UnboundedSender<PathBuf>,
            release: Option<Arc<tokio::sync::Notify>>,
        ) -> Self {
            Self {
                cwd_tx,
                release,
                fail_after_recording: false,
                run_id: None,
            }
        }

        fn failing(cwd_tx: tokio::sync::mpsc::UnboundedSender<PathBuf>) -> Self {
            Self {
                cwd_tx,
                release: None,
                fail_after_recording: true,
                run_id: None,
            }
        }

        fn with_run_id(mut self, run_id: &str) -> Self {
            self.run_id = Some(run_id.to_string());
            self
        }

        fn final_stream<'a>() -> futures::stream::BoxStream<'a, crate::error::Result<AgentEvent>> {
            Box::pin(futures::stream::once(async {
                Ok(AgentEvent::FinalAnswer("done".to_string()))
            }))
        }
    }

    impl Agent for WorkspaceRecordingAgent {
        fn name(&self) -> &str {
            "workspace-recorder"
        }

        fn model_name(&self) -> &str {
            "test"
        }

        fn system_prompt(&self) -> &str {
            "record workspace"
        }

        fn current_run_id(&self) -> Option<String> {
            self.run_id.clone()
        }

        fn execute<'a>(
            &'a self,
            _task: &'a str,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<String>> {
            Box::pin(async { Ok("done".to_string()) })
        }

        fn execute_stream<'a>(
            &'a self,
            _task: &'a str,
        ) -> futures::future::BoxFuture<
            'a,
            crate::error::Result<futures::stream::BoxStream<'a, crate::error::Result<AgentEvent>>>,
        > {
            Box::pin(async { Ok(Self::final_stream()) })
        }

        fn execute_stream_with_invocation_context<'a>(
            &'a self,
            _task: &'a str,
            _cancel: CancellationToken,
            invocation: AgentInvocationContext,
        ) -> futures::future::BoxFuture<
            'a,
            crate::error::Result<futures::stream::BoxStream<'a, crate::error::Result<AgentEvent>>>,
        > {
            Box::pin(async move {
                let cwd = invocation.working_dir.ok_or_else(|| {
                    crate::error::ReactError::Other(
                        "eval invocation did not contain a working directory".to_string(),
                    )
                })?;
                self.cwd_tx.send(cwd).map_err(|_| {
                    crate::error::ReactError::Other(
                        "workspace observation receiver closed".to_string(),
                    )
                })?;
                if let Some(release) = self.release.as_ref() {
                    release.notified().await;
                }
                if self.fail_after_recording {
                    return Err(crate::error::ReactError::Other(
                        "forced typed Agent error".to_string(),
                    ));
                }
                Ok(Self::final_stream())
            })
        }
    }

    impl Agent for CancellationSettlingAgent {
        fn name(&self) -> &str {
            "cancellation-settler"
        }

        fn model_name(&self) -> &str {
            "test"
        }

        fn system_prompt(&self) -> &str {
            "settle after cancellation"
        }

        fn execute<'a>(
            &'a self,
            _task: &'a str,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<String>> {
            Box::pin(async { Ok("done".to_string()) })
        }

        fn execute_stream<'a>(
            &'a self,
            _task: &'a str,
        ) -> futures::future::BoxFuture<
            'a,
            crate::error::Result<futures::stream::BoxStream<'a, crate::error::Result<AgentEvent>>>,
        > {
            Box::pin(async { Ok(WorkspaceRecordingAgent::final_stream()) })
        }

        fn execute_stream_with_invocation_context<'a>(
            &'a self,
            _task: &'a str,
            cancel: CancellationToken,
            invocation: AgentInvocationContext,
        ) -> futures::future::BoxFuture<
            'a,
            crate::error::Result<futures::stream::BoxStream<'a, crate::error::Result<AgentEvent>>>,
        > {
            Box::pin(async move {
                self.stream_invocations.fetch_add(1, Ordering::AcqRel);
                let cwd = invocation.working_dir.ok_or_else(|| {
                    crate::error::ReactError::Other(
                        "eval invocation did not contain a working directory".to_string(),
                    )
                })?;
                self.cwd_tx.send(cwd.clone()).map_err(|_| {
                    crate::error::ReactError::Other(
                        "workspace observation receiver closed".to_string(),
                    )
                })?;
                let stream = async_stream::try_stream! {
                    cancel.cancelled().await;
                    std::fs::write(cwd.join("cancel-settled.marker"), "settled")
                        .map_err(crate::error::ReactError::from)?;
                    if let Some(settled) = self.settled_tx.lock().await.take() {
                        let _ = settled.send(());
                    }
                    match self.terminal_answer.as_ref() {
                        Some(answer) => yield AgentEvent::FinalAnswer(answer.clone()),
                        None => yield AgentEvent::Cancelled,
                    }
                };
                let stream: futures::stream::BoxStream<'a, crate::error::Result<AgentEvent>> =
                    Box::pin(stream);
                Ok(stream)
            })
        }
    }

    #[async_trait::async_trait]
    impl crate::trace::RunStore for CountingRunStore {
        async fn save(&self, _run: Run) -> crate::error::Result<()> {
            Ok(())
        }

        async fn load(&self, _run_id: &str) -> crate::error::Result<Option<Run>> {
            self.loads.fetch_add(1, Ordering::AcqRel);
            Ok(None)
        }

        async fn list_by_session(
            &self,
            _session_id: &str,
        ) -> crate::error::Result<Vec<RunSummary>> {
            Ok(Vec::new())
        }

        async fn list_all(&self, _limit: usize) -> crate::error::Result<Vec<RunSummary>> {
            self.lists.fetch_add(1, Ordering::AcqRel);
            Ok(Vec::new())
        }
    }

    #[async_trait::async_trait]
    impl crate::trace::RunStore for FaultingTraceRunStore {
        async fn save(&self, _run: Run) -> crate::error::Result<()> {
            Ok(())
        }

        async fn load(&self, _run_id: &str) -> crate::error::Result<Option<Run>> {
            match self.mode {
                TraceLookupFailure::Load => Err(crate::error::ReactError::Other(
                    "forced trace load failure".to_string(),
                )),
                TraceLookupFailure::Dangling => Ok(None),
                TraceLookupFailure::MismatchedRun => {
                    Ok(Some(correlated_run("trace-mismatch", "other-correlation")))
                }
                TraceLookupFailure::List => Ok(None),
            }
        }

        async fn list_by_session(
            &self,
            _session_id: &str,
        ) -> crate::error::Result<Vec<RunSummary>> {
            Ok(Vec::new())
        }

        async fn list_all(&self, _limit: usize) -> crate::error::Result<Vec<RunSummary>> {
            if matches!(self.mode, TraceLookupFailure::List) {
                return Err(crate::error::ReactError::Other(
                    "forced trace list failure".to_string(),
                ));
            }
            Ok(vec![self.summary.clone()])
        }
    }

    fn correlated_run(run_id: &str, correlation_id: &str) -> Run {
        Run {
            run_id: run_id.to_string(),
            parent_run_id: Some(correlation_id.to_string()),
            agent_name: "trace-agent".to_string(),
            model: "test".to_string(),
            provider: None,
            turn_id: Some(correlation_id.to_string()),
            execution_id: Some(correlation_id.to_string()),
            session_id: String::new(),
            status: RunStatus::Completed,
            input: "trace lookup".to_string(),
            events: Vec::new(),
            final_output: Some("done".to_string()),
            error: None,
            token_usage: TokenUsage::default(),
            timings: RunTimings::default(),
            started_at: Utc::now(),
            finished_at: Some(Utc::now()),
        }
    }

    fn correlated_summary(run_id: &str, correlation_id: &str) -> RunSummary {
        RunSummary {
            run_id: run_id.to_string(),
            parent_run_id: Some(correlation_id.to_string()),
            session_id: String::new(),
            agent_name: "trace-agent".to_string(),
            model: "test".to_string(),
            provider: None,
            turn_id: Some(correlation_id.to_string()),
            execution_id: Some(correlation_id.to_string()),
            status: RunStatus::Completed,
            input_preview: "trace lookup".to_string(),
            started_at: Utc::now(),
            finished_at: Some(Utc::now()),
            token_usage: TokenUsage::default(),
            total_duration_ms: 0,
        }
    }

    fn workspace_case(id: &str, fixture: Option<PathBuf>) -> EvalCase {
        EvalCase {
            id: id.to_string(),
            name: id.to_string(),
            description: String::new(),
            domain: None,
            task: "record the workspace".to_string(),
            project_fixture: fixture,
            success_criteria: SuccessCriteria::OutputContains {
                substring: "done".to_string(),
            },
            constraints: Default::default(),
        }
    }

    #[tokio::test]
    async fn eval_result_uses_the_real_trace_id_not_the_legacy_product_run() -> Result<(), String> {
        use crate::agent::ReactAgentBuilder;
        use crate::testing::MockLlmClient;
        use crate::trace::{InMemoryRunStore, RunStore};

        let parent = tempfile::tempdir().map_err(|error| error.to_string())?;
        let store = Arc::new(InMemoryRunStore::new());
        let usage = crate::llm::types::Usage {
            prompt_tokens: Some(37),
            completion_tokens: Some(5),
            total_tokens: Some(42),
            ..Default::default()
        };
        let mut agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(
                MockLlmClient::new().with_response_usage("done", usage),
            ))
            .system_prompt("Return the answer.")
            .build()
            .map_err(|error| error.to_string())?;
        agent.set_run_store(store.clone());
        agent.set_external_context(&crate::tools::ExternalRunContext {
            run_id: Some("product-run".to_string()),
            ..crate::tools::ExternalRunContext::default()
        });
        let runner = EvalRunner::new(parent.path().join("runs")).with_run_store(store.clone());
        let case = workspace_case("trace-correlation", None);

        let result = runner.run(&case, &agent).await;
        let trace_run_id = result
            .run_id
            .as_deref()
            .ok_or_else(|| "EvalResult did not return a trace run ID".to_string())?;
        if trace_run_id == "product-run" {
            return Err("EvalResult exposed the product run as a trace run".to_string());
        }
        let trace = store
            .load(trace_run_id)
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "EvalResult trace run ID was not loadable".to_string())?;
        let correlation_id = trace
            .parent_run_id
            .as_deref()
            .ok_or_else(|| "real trace did not retain the Eval correlation".to_string())?;
        if trace.run_id != trace_run_id
            || correlation_id == "product-run"
            || !correlation_id.starts_with("eval-")
            || trace.turn_id.as_deref() != Some(correlation_id)
            || trace.execution_id.as_deref() != Some(correlation_id)
            || result.tokens_in != 37
            || result.tokens_out != 5
        {
            return Err(
                "EvalResult and trace metrics did not use the real invocation trace".into(),
            );
        }
        if agent.current_run_id().as_deref() != Some("product-run") {
            return Err("Eval mutated the Agent product run identity".to_string());
        }
        Ok(())
    }

    #[tokio::test]
    async fn trace_lookup_requires_one_exact_loadable_correlation() -> Result<(), String> {
        use crate::trace::{InMemoryRunStore, RunStore};

        let correlation_id = "eval-correlation";
        let store = InMemoryRunStore::new();
        store
            .save(correlated_run("trace-exact", correlation_id))
            .await
            .map_err(|error| error.to_string())?;
        let mut other_child = correlated_run("trace-other-child", correlation_id);
        other_child.execution_id = Some("different-execution".to_string());
        store
            .save(other_child)
            .await
            .map_err(|error| error.to_string())?;
        let exact = EvalRunner::load_correlated_trace(&store, correlation_id)
            .await?
            .ok_or_else(|| "exact trace correlation was not found".to_string())?;
        if exact.run_id != "trace-exact" {
            return Err("trace lookup selected another child execution".to_string());
        }

        let empty = InMemoryRunStore::new();
        if EvalRunner::load_correlated_trace(&empty, correlation_id)
            .await?
            .is_some()
        {
            return Err("empty trace store produced a correlation".to_string());
        }

        let ambiguous = InMemoryRunStore::new();
        ambiguous
            .save(correlated_run("trace-first", correlation_id))
            .await
            .map_err(|error| error.to_string())?;
        ambiguous
            .save(correlated_run("trace-second", correlation_id))
            .await
            .map_err(|error| error.to_string())?;
        let ambiguity = EvalRunner::load_correlated_trace(&ambiguous, correlation_id)
            .await
            .err()
            .ok_or_else(|| "duplicate exact traces were accepted".to_string())?;
        if !ambiguity.contains("multiple traces matched") {
            return Err(format!("unexpected ambiguity result: {ambiguity}"));
        }
        Ok(())
    }

    #[tokio::test]
    async fn trace_lookup_reports_store_and_loaded_identity_failures() -> Result<(), String> {
        let correlation_id = "eval-failure-correlation";
        let summary = correlated_summary("trace-summary", correlation_id);
        for (mode, expected) in [
            (TraceLookupFailure::List, "could not list correlation"),
            (TraceLookupFailure::Load, "could not load trace"),
            (TraceLookupFailure::Dangling, "has no loadable Run"),
            (
                TraceLookupFailure::MismatchedRun,
                "does not match correlation",
            ),
        ] {
            let store = FaultingTraceRunStore {
                summary: summary.clone(),
                mode,
            };
            let failure = EvalRunner::load_correlated_trace(&store, correlation_id)
                .await
                .err()
                .ok_or_else(|| format!("trace lookup mode did not fail: {expected}"))?;
            if !failure.contains(expected) {
                return Err(format!(
                    "trace lookup failure '{failure}' did not contain '{expected}'"
                ));
            }
        }
        Ok(())
    }

    #[tokio::test]
    async fn missing_trace_is_optional_but_store_failure_is_not() -> Result<(), String> {
        use crate::trace::InMemoryRunStore;

        let parent = tempfile::tempdir().map_err(|error| error.to_string())?;
        let case = workspace_case("trace-lookup-projection", None);
        let empty_store = Arc::new(InMemoryRunStore::new());
        let empty_runner = EvalRunner::new(parent.path().join("empty")).with_run_store(empty_store);
        let (empty_tx, _empty_rx) = tokio::sync::mpsc::unbounded_channel();
        let empty_result = empty_runner
            .run(&case, &WorkspaceRecordingAgent::new(empty_tx, None))
            .await;
        if !empty_result.success || empty_result.run_id.is_some() {
            return Err(
                "Agent without trace did not preserve optional trace semantics".to_string(),
            );
        }

        let failing_store = Arc::new(FaultingTraceRunStore {
            summary: correlated_summary("unused", "unused"),
            mode: TraceLookupFailure::List,
        });
        let failing_runner =
            EvalRunner::new(parent.path().join("failing")).with_run_store(failing_store);
        let (failing_tx, _failing_rx) = tokio::sync::mpsc::unbounded_channel();
        let failed_result = failing_runner
            .run(&case, &WorkspaceRecordingAgent::new(failing_tx, None))
            .await;
        if failed_result.success
            || !failed_result
                .violations
                .iter()
                .any(|violation| violation.contains("Trace lookup failed: could not list"))
        {
            return Err("RunStore correlation failure was not projected".to_string());
        }
        Ok(())
    }

    #[tokio::test]
    async fn settled_agent_failure_retains_its_correlated_diagnostic_trace() -> Result<(), String> {
        use crate::agent::ReactAgentBuilder;
        use crate::testing::MockLlmClient;
        use crate::trace::{InMemoryRunStore, RunStore};

        let parent = tempfile::tempdir().map_err(|error| error.to_string())?;
        let store = Arc::new(InMemoryRunStore::new());
        let mut agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(MockLlmClient::new().with_error(
                crate::error::ReactError::Other("forced provider failure".to_string()),
            )))
            .system_prompt("Return the answer.")
            .build()
            .map_err(|error| error.to_string())?;
        agent.set_run_store(store.clone());
        let runner = EvalRunner::new(parent.path().join("runs")).with_run_store(store.clone());
        let result = runner
            .run(&workspace_case("failed-trace-correlation", None), &agent)
            .await;
        let trace_run_id = result
            .run_id
            .as_deref()
            .ok_or_else(|| "failed turn did not return its diagnostic trace ID".to_string())?;
        let trace = store
            .load(trace_run_id)
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "failed turn diagnostic trace was not loadable".to_string())?;
        if result.success
            || trace.status != RunStatus::Failed
            || !result
                .violations
                .iter()
                .any(|violation| violation.contains("forced provider failure"))
        {
            return Err("failed turn trace changed or hid the Agent outcome".to_string());
        }
        Ok(())
    }

    #[tokio::test]
    async fn concurrent_same_case_runs_use_distinct_workspace_generations() -> Result<(), String> {
        let parent = tempfile::tempdir().map_err(|error| error.to_string())?;
        let fixture = tempfile::tempdir().map_err(|error| error.to_string())?;
        std::fs::write(fixture.path().join("marker.txt"), "fixture")
            .map_err(|error| error.to_string())?;
        let runner = EvalRunner::new(parent.path().join("runs"));
        let case = workspace_case("same-case", Some(fixture.path().to_path_buf()));
        let (cwd_tx, mut cwd_rx) = tokio::sync::mpsc::unbounded_channel();
        let release = Arc::new(tokio::sync::Notify::new());
        let agent = Arc::new(WorkspaceRecordingAgent::new(
            cwd_tx,
            Some(Arc::clone(&release)),
        ));

        let first_runner = runner.clone();
        let first_case = case.clone();
        let first_agent = Arc::clone(&agent);
        let first =
            tokio::spawn(async move { first_runner.run(&first_case, first_agent.as_ref()).await });
        let first_cwd = cwd_rx
            .recv()
            .await
            .ok_or_else(|| "first eval did not report its workspace".to_string())?;

        let second_runner = runner.clone();
        let second_case = case.clone();
        let second_agent = Arc::clone(&agent);
        let second =
            tokio::spawn(
                async move { second_runner.run(&second_case, second_agent.as_ref()).await },
            );
        let second_cwd = cwd_rx
            .recv()
            .await
            .ok_or_else(|| "second eval did not report its workspace".to_string())?;

        if first_cwd == second_cwd {
            return Err(format!(
                "concurrent same-ID evals shared workspace {}",
                first_cwd.display()
            ));
        }
        if !first_cwd.join("marker.txt").is_file() || !second_cwd.join("marker.txt").is_file() {
            return Err("fixture was not independently copied into both generations".to_string());
        }
        release.notify_waiters();
        let first_result = first.await.map_err(|error| error.to_string())?;
        let second_result = second.await.map_err(|error| error.to_string())?;

        if !first_result.success || !second_result.success {
            return Err("concurrent eval generation unexpectedly failed".to_string());
        }
        if first_cwd.exists() || second_cwd.exists() {
            return Err("settled eval generation was not removed".to_string());
        }
        Ok(())
    }

    #[tokio::test]
    async fn fixture_free_runs_do_not_use_the_shared_workspace_parent() -> Result<(), String> {
        let parent = tempfile::tempdir().map_err(|error| error.to_string())?;
        let workspace_root = parent.path().join("runs");
        let runner = EvalRunner::new(workspace_root.clone());
        let case = workspace_case("fixture-free", None);
        let (cwd_tx, mut cwd_rx) = tokio::sync::mpsc::unbounded_channel();
        let agent = WorkspaceRecordingAgent::new(cwd_tx, None);

        let (first_result, second_result) =
            tokio::join!(runner.run(&case, &agent), runner.run(&case, &agent));
        let first_cwd = cwd_rx
            .recv()
            .await
            .ok_or_else(|| "first fixture-free eval did not report cwd".to_string())?;
        let second_cwd = cwd_rx
            .recv()
            .await
            .ok_or_else(|| "second fixture-free eval did not report cwd".to_string())?;

        if first_cwd == workspace_root || second_cwd == workspace_root || first_cwd == second_cwd {
            return Err("fixture-free evals did not receive unique child generations".to_string());
        }
        if !first_result.success || !second_result.success {
            return Err("fixture-free eval generation unexpectedly failed".to_string());
        }
        if first_cwd.exists() || second_cwd.exists() {
            return Err("settled fixture-free generation was not removed".to_string());
        }
        Ok(())
    }

    #[tokio::test]
    async fn timeout_retains_the_unsettled_workspace_generation() -> Result<(), String> {
        let parent = tempfile::tempdir().map_err(|error| error.to_string())?;
        let run_store = Arc::new(CountingRunStore {
            lists: AtomicUsize::new(0),
            loads: AtomicUsize::new(0),
        });
        let mut runner =
            EvalRunner::new(parent.path().join("runs")).with_run_store(run_store.clone());
        runner.timeout_secs = 1;
        let case = workspace_case("timeout", None);
        let (cwd_tx, mut cwd_rx) = tokio::sync::mpsc::unbounded_channel();
        let release = Arc::new(tokio::sync::Notify::new());
        let agent =
            WorkspaceRecordingAgent::new(cwd_tx, Some(release)).with_run_id("unsettled-run");

        let result = runner.run(&case, &agent).await;
        let observed_cwd = cwd_rx
            .recv()
            .await
            .ok_or_else(|| "timed out eval did not report its workspace".to_string())?;
        let retained = result
            .violations
            .iter()
            .find_map(|violation| {
                violation
                    .strip_prefix("Workspace retained after timeout: ")
                    .map(PathBuf::from)
            })
            .ok_or_else(|| "timeout result did not report a retained workspace".to_string())?;

        if result.success
            || !result.violations.iter().any(|value| value == "Timeout")
            || !result
                .violations
                .iter()
                .any(|value| value.contains("Turn did not settle within"))
        {
            return Err("timed out eval did not retain its failure outcome".to_string());
        }
        if result.duration_ms
            < u64::try_from(AGENT_CANCELLATION_SETTLE_PERIOD.as_millis()).unwrap_or(u64::MAX)
        {
            return Err("unsettled Eval returned before the cancellation grace".to_string());
        }
        if retained != observed_cwd || !retained.is_dir() {
            return Err("reported timeout generation was not retained".to_string());
        }
        if run_store.lists.load(Ordering::Acquire) != 0
            || run_store.loads.load(Ordering::Acquire) != 0
        {
            return Err("unsettled timeout read non-terminal trace state".to_string());
        }
        std::fs::remove_dir_all(&retained).map_err(|error| error.to_string())?;
        Ok(())
    }

    #[tokio::test]
    async fn timeout_waits_for_a_cancellation_responsive_turn_to_settle() -> Result<(), String> {
        let parent = tempfile::tempdir().map_err(|error| error.to_string())?;
        let mut runner = EvalRunner::new(parent.path().join("runs"));
        runner.timeout_secs = 1;
        let case = workspace_case("responsive-timeout", None);
        let (cwd_tx, mut cwd_rx) = tokio::sync::mpsc::unbounded_channel();
        let (settled_tx, settled_rx) = tokio::sync::oneshot::channel();
        let stream_invocations = Arc::new(AtomicUsize::new(0));
        let agent = CancellationSettlingAgent {
            cwd_tx,
            settled_tx: tokio::sync::Mutex::new(Some(settled_tx)),
            terminal_answer: None,
            stream_invocations: Arc::clone(&stream_invocations),
        };

        let result = runner.run(&case, &agent).await;
        let workspace = cwd_rx
            .recv()
            .await
            .ok_or_else(|| "responsive timeout did not report its workspace".to_string())?;
        tokio::time::timeout(std::time::Duration::from_millis(200), settled_rx)
            .await
            .map_err(|_| "Eval returned before cancellation settlement".to_string())?
            .map_err(|_| "cancellation settlement sender closed".to_string())?;

        if result.success
            || !result.violations.iter().any(|value| value == "Timeout")
            || !result
                .violations
                .iter()
                .any(|value| value == "Turn settled after timeout: cancelled")
        {
            return Err("responsive timeout did not preserve the deadline failure".to_string());
        }
        if workspace.exists() {
            return Err("settled timeout workspace was not removed".to_string());
        }
        if stream_invocations.load(Ordering::Acquire) != 1 {
            return Err("responsive timeout restarted its Agent stream".to_string());
        }
        Ok(())
    }

    #[tokio::test]
    async fn late_completed_turn_remains_timeout_without_running_criteria() -> Result<(), String> {
        let parent = tempfile::tempdir().map_err(|error| error.to_string())?;
        let mut runner = EvalRunner::new(parent.path().join("runs"));
        runner.timeout_secs = 1;
        let case = workspace_case("late-completed-timeout", None);
        let (cwd_tx, mut cwd_rx) = tokio::sync::mpsc::unbounded_channel();
        let (settled_tx, settled_rx) = tokio::sync::oneshot::channel();
        let stream_invocations = Arc::new(AtomicUsize::new(0));
        let agent = CancellationSettlingAgent {
            cwd_tx,
            settled_tx: tokio::sync::Mutex::new(Some(settled_tx)),
            terminal_answer: Some("done".to_string()),
            stream_invocations: Arc::clone(&stream_invocations),
        };

        let result = runner.run(&case, &agent).await;
        let workspace = cwd_rx
            .recv()
            .await
            .ok_or_else(|| "late completed timeout did not report its workspace".to_string())?;
        settled_rx
            .await
            .map_err(|_| "late completed settlement sender closed".to_string())?;
        if result.success
            || result.score != 0.0
            || !result.metrics.is_empty()
            || !result.violations.iter().any(|value| value == "Timeout")
            || !result
                .violations
                .iter()
                .any(|value| value == "Turn settled after timeout: completed")
        {
            return Err(
                "late Completed turn changed the timeout result or ran criteria".to_string(),
            );
        }
        if stream_invocations.load(Ordering::Acquire) != 1 {
            return Err("late completed timeout restarted its Agent stream".to_string());
        }
        if workspace.exists() {
            return Err("late completed timeout workspace was not removed".to_string());
        }
        Ok(())
    }

    #[tokio::test]
    async fn dropping_an_active_run_future_retains_its_real_workspace() -> Result<(), String> {
        let parent = tempfile::tempdir().map_err(|error| error.to_string())?;
        let runner = EvalRunner::new(parent.path().join("runs"));
        let case = workspace_case("caller-drop", None);
        let (cwd_tx, mut cwd_rx) = tokio::sync::mpsc::unbounded_channel();
        let release = Arc::new(tokio::sync::Notify::new());
        let agent = Arc::new(WorkspaceRecordingAgent::new(cwd_tx, Some(release)));
        let run_agent = Arc::clone(&agent);
        let run = tokio::spawn(async move { runner.run(&case, run_agent.as_ref()).await });
        let path = cwd_rx
            .recv()
            .await
            .ok_or_else(|| "active eval did not report its workspace".to_string())?;

        run.abort();
        let join_error = run
            .await
            .err()
            .ok_or_else(|| "aborted eval run unexpectedly completed".to_string())?;
        if !join_error.is_cancelled() {
            return Err(format!(
                "aborted eval returned unexpected error: {join_error}"
            ));
        }
        if !path.is_dir() {
            return Err("active run workspace was deleted on caller drop".to_string());
        }
        std::fs::remove_dir_all(path).map_err(|error| error.to_string())?;
        Ok(())
    }

    #[tokio::test]
    async fn typed_agent_error_closes_the_settled_generation() -> Result<(), String> {
        let parent = tempfile::tempdir().map_err(|error| error.to_string())?;
        let runner = EvalRunner::new(parent.path().join("runs"));
        let case = workspace_case("agent-error", None);
        let (cwd_tx, mut cwd_rx) = tokio::sync::mpsc::unbounded_channel();
        let agent = WorkspaceRecordingAgent::failing(cwd_tx);

        let result = runner.run(&case, &agent).await;
        let path = cwd_rx
            .recv()
            .await
            .ok_or_else(|| "failed eval did not report its workspace".to_string())?;

        if result.success
            || !result
                .violations
                .iter()
                .any(|value| value.contains("forced typed Agent error"))
        {
            return Err("typed Agent error was not projected into EvalResult".to_string());
        }
        if path.exists() {
            return Err("typed Agent error did not close its settled generation".to_string());
        }
        Ok(())
    }

    #[test]
    fn cleanup_failure_is_visible_in_the_eval_result() -> Result<(), String> {
        let mut result = EvalResult::new("cleanup", true).with_metric("quality", 0.75, "graded");

        EvalRunner::record_workspace_cleanup(
            &mut result,
            Err(std::io::Error::other("forced cleanup failure")),
        );
        result.recompute_score();

        if result.success
            || result.score != 0.75
            || !result
                .violations
                .iter()
                .any(|value| value.contains("forced cleanup failure"))
        {
            return Err("cleanup failure was not projected into EvalResult".to_string());
        }
        Ok(())
    }

    #[tokio::test]
    async fn fixture_setup_failure_closes_its_generation() -> Result<(), String> {
        let parent = tempfile::tempdir().map_err(|error| error.to_string())?;
        let workspace_root = parent.path().join("runs");
        let runner = EvalRunner::new(workspace_root.clone());
        let case = workspace_case(
            "missing-fixture",
            Some(parent.path().join("does-not-exist")),
        );
        let (cwd_tx, mut cwd_rx) = tokio::sync::mpsc::unbounded_channel();
        let agent = WorkspaceRecordingAgent::new(cwd_tx, None);

        let result = runner.run(&case, &agent).await;

        if result.success
            || !result
                .violations
                .iter()
                .any(|value| value.contains("Fixture setup failed"))
        {
            return Err("fixture setup failure was not reported".to_string());
        }
        if cwd_rx.try_recv().is_ok() {
            return Err("Agent started after fixture setup failed".to_string());
        }
        let mut entries = std::fs::read_dir(workspace_root).map_err(|error| error.to_string())?;
        if entries.next().is_some() {
            return Err("failed fixture generation was not cleaned up".to_string());
        }
        Ok(())
    }

    #[tokio::test]
    async fn test_runner_output_contains() {
        let dir = std::env::temp_dir().join(format!("eval_test_{}", uuid::Uuid::new_v4()));
        let _runner = EvalRunner::new(dir);
        let _case = EvalCase {
            id: "test".into(),
            name: "test".into(),
            description: "".into(),
            domain: None,
            task: "Say hello world".into(),
            project_fixture: None,
            success_criteria: SuccessCriteria::OutputContains {
                substring: "hello".into(),
            },
            constraints: Default::default(),
        };
        // This test just validates the runner doesn't panic on missing agent
        // Actual agent-based testing requires a MockAgent
    }

    #[tokio::test]
    async fn test_criteria_append_only_completed_commands_to_the_correlated_trace()
    -> Result<(), String> {
        use crate::trace::{InMemoryRunStore, RunStore};

        let root = tempfile::tempdir().map_err(|error| error.to_string())?;
        let store = Arc::new(InMemoryRunStore::new());
        let current = correlated_run("trace-current", "business-run");
        let other = correlated_run("trace-other", "other-business-run");
        store
            .save(current.clone())
            .await
            .map_err(|error| error.to_string())?;
        store.save(other).await.map_err(|error| error.to_string())?;
        let runner = EvalRunner::new(root.path().to_path_buf()).with_run_store(store.clone());

        for (command, expected_passed) in [("true", true), ("false", false)] {
            let result = runner
                .check_criteria(
                    &SuccessCriteria::TestPass {
                        command: command.to_string(),
                    },
                    "",
                    "",
                    root.path(),
                    Some(&current),
                )
                .await;
            if result.success != expected_passed {
                return Err(format!("unexpected {command} criterion: {result:?}"));
            }
        }
        let invalid_cwd = root.path().join("missing-directory");
        let failed_launch = runner
            .check_criteria(
                &SuccessCriteria::TestPass {
                    command: "true".to_string(),
                },
                "",
                "",
                &invalid_cwd,
                Some(&current),
            )
            .await;
        if failed_launch.success
            || !failed_launch
                .violations
                .iter()
                .any(|violation| violation.contains("could not be launched"))
        {
            return Err(format!(
                "launch failure was not distinct: {failed_launch:?}"
            ));
        }
        let missing_executable = runner
            .check_criteria(
                &SuccessCriteria::TestPass {
                    command: "echo_agent_missing_test_runner_104".to_string(),
                },
                "",
                "",
                root.path(),
                Some(&current),
            )
            .await;
        if missing_executable.success
            || !missing_executable
                .violations
                .iter()
                .any(|violation| violation.contains("could not be launched"))
        {
            return Err(format!(
                "missing executable was treated as a test result: {missing_executable:?}"
            ));
        }
        let current = store
            .load("trace-current")
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "missing current trace".to_string())?;
        let tests = current
            .events
            .iter()
            .filter_map(|event| match event {
                RunEvent::TestRun {
                    command,
                    passed,
                    failure_count,
                } => Some((command.as_str(), *passed, *failure_count)),
                _ => None,
            })
            .collect::<Vec<_>>();
        if tests != [("true", true, None), ("false", false, None)] {
            return Err(format!("wrong test facts: {tests:?}"));
        }
        let other = store
            .load("trace-other")
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "missing other trace".to_string())?;
        if other
            .events
            .iter()
            .any(|event| matches!(event, RunEvent::TestRun { .. }))
        {
            return Err("test fact leaked into another trace".to_string());
        }
        Ok(())
    }

    #[tokio::test]
    async fn test_run_is_sanitized_before_custom_store_receives_it() -> Result<(), String> {
        #[derive(Default)]
        struct CaptureStore {
            events: std::sync::Mutex<Vec<(String, RunEvent)>>,
        }

        #[async_trait::async_trait]
        impl crate::trace::RunStore for CaptureStore {
            async fn save(&self, _run: Run) -> crate::error::Result<()> {
                Ok(())
            }
            async fn load(&self, _run_id: &str) -> crate::error::Result<Option<Run>> {
                Ok(None)
            }
            async fn list_by_session(
                &self,
                _session_id: &str,
            ) -> crate::error::Result<Vec<RunSummary>> {
                Ok(Vec::new())
            }
            async fn list_all(&self, _limit: usize) -> crate::error::Result<Vec<RunSummary>> {
                Ok(Vec::new())
            }
            async fn append_event(
                &self,
                run_id: &str,
                event: RunEvent,
            ) -> crate::error::Result<()> {
                self.events
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .push((run_id.to_string(), event));
                Ok(())
            }
        }

        let root = tempfile::tempdir().map_err(|error| error.to_string())?;
        let store = Arc::new(CaptureStore::default());
        let runner = EvalRunner::new(root.path().to_path_buf()).with_run_store(store.clone());
        let mut result = EvalResult::new("case", true);
        let run = correlated_run("trace-target", "business-run");
        runner
            .record_test_run(
                &mut result,
                Some(&run),
                "echo password=supersecretvalue",
                true,
            )
            .await;
        if !result.success {
            return Err(format!("trace append unexpectedly failed: {result:?}"));
        }
        let events = store
            .events
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        let (id, event) = events
            .first()
            .ok_or_else(|| "custom store received no event".to_string())?;
        if id != "trace-target" || events.len() != 1 {
            return Err(format!("wrong trace identity or event count: {events:?}"));
        }
        match event {
            RunEvent::TestRun {
                command,
                failure_count: None,
                ..
            } if command.contains("[REDACTED]") && !command.contains("supersecretvalue") => {}
            other => {
                return Err(format!(
                    "unsanitized TestRun reached custom store: {other:?}"
                ));
            }
        }
        Ok(())
    }

    #[tokio::test]
    async fn trace_tool_criteria_are_enforced() -> Result<(), String> {
        let dir = std::env::temp_dir().join(format!("eval_trace_{}", uuid::Uuid::new_v4()));
        let runner = EvalRunner::new(dir.clone());
        let run = Run {
            run_id: "run-1".into(),
            parent_run_id: None,
            agent_name: String::new(),
            model: String::new(),
            provider: None,
            turn_id: None,
            execution_id: None,
            session_id: "session-1".into(),
            status: RunStatus::Completed,
            input: "inspect".into(),
            events: vec![
                RunEvent::ToolCall {
                    call_id: "call-1".into(),
                    name: "read_file".into(),
                    args: None,
                    risk: None,
                    duration_ms: 1,
                },
                RunEvent::ToolResult {
                    call_id: "call-1".into(),
                    name: "read_file".into(),
                    success: true,
                    output_preview: Some("Source record DOI 10.1234/example.2026".into()),
                    output_truncated: false,
                    duration_ms: 1,
                    original_bytes: 40,
                    returned_bytes: 40,
                    estimated_tokens: 10,
                    output_handling: Some("inline".into()),
                    artifact: None,
                },
            ],
            final_output: Some("done".into()),
            error: None,
            token_usage: TokenUsage::default(),
            timings: RunTimings::default(),
            started_at: Utc::now(),
            finished_at: Some(Utc::now()),
        };
        let criteria = SuccessCriteria::AllOf(vec![
            SuccessCriteria::ToolUsed {
                tool_name: "read_file".into(),
            },
            SuccessCriteria::ToolNotUsed {
                tool_name: "write_file".into(),
            },
        ]);

        let passed = runner
            .check_criteria(&criteria, "done", "inspect", dir.as_path(), Some(&run))
            .await;
        if !passed.success {
            return Err(format!(
                "expected trace criteria to pass: {:?}",
                passed.violations
            ));
        }

        let missing = runner
            .check_criteria(
                &SuccessCriteria::ToolUsed {
                    tool_name: "write_file".into(),
                },
                "done",
                "inspect",
                dir.as_path(),
                Some(&run),
            )
            .await;
        if missing.success {
            return Err("missing required tool was accepted".into());
        }
        let nested_missing = runner
            .check_criteria(
                &SuccessCriteria::AllOf(vec![SuccessCriteria::ToolUsed {
                    tool_name: "write_file".into(),
                }]),
                "done",
                "inspect",
                dir.as_path(),
                Some(&run),
            )
            .await;
        if nested_missing.violations.is_empty() {
            return Err("nested tool failure lost its violation detail".into());
        }
        let mut skipped = run.clone();
        skipped.events.extend([
            RunEvent::ToolCall {
                call_id: "cancelled-future-wave".to_string(),
                name: "write_file".to_string(),
                args: None,
                risk: None,
                duration_ms: 0,
            },
            RunEvent::ToolExecutionSkipped {
                call_id: "cancelled-future-wave".to_string(),
                name: "write_file".to_string(),
                reason: "cancelled before execution".to_string(),
            },
            RunEvent::ToolResult {
                call_id: "cancelled-future-wave".to_string(),
                name: "write_file".to_string(),
                success: false,
                output_preview: Some(String::new()),
                output_truncated: false,
                duration_ms: 0,
                original_bytes: 0,
                returned_bytes: 0,
                estimated_tokens: 0,
                output_handling: None,
                artifact: None,
            },
            RunEvent::ToolError {
                call_id: "cancelled-future-wave".to_string(),
                name: "write_file".to_string(),
                message: "not executed".to_string(),
                failure: None,
            },
        ]);
        let skipped_is_not_used = runner
            .check_criteria(
                &SuccessCriteria::ToolNotUsed {
                    tool_name: "write_file".to_string(),
                },
                "done",
                "inspect",
                dir.as_path(),
                Some(&skipped),
            )
            .await;
        if !skipped_is_not_used.success {
            return Err(format!(
                "skipped tool was treated as executed: {:?}",
                skipped_is_not_used.violations
            ));
        }
        let citation = runner
            .check_criteria(
                &SuccessCriteria::CitationValid {
                    min_citations: 1,
                    format: "doi".into(),
                },
                "Evidence: DOI 10.1234/example.2026",
                "inspect",
                dir.as_path(),
                Some(&run),
            )
            .await;
        if !citation.success {
            return Err(format!(
                "source-backed citation was rejected: {:?}",
                citation.violations
            ));
        }
        Ok(())
    }
}
