//! Agent evaluation framework — measurable, repeatable agent testing.
//!
//! # Overview
//!
//! The eval system lets you define test cases, run them against an agent,
//! and score the results. It builds on the trace system ([`crate::trace`])
//! to link eval results to execution traces for debugging and regression.
//!
//! # Quick Start
//!
//! ```rust,no_run
//! use echo_agent::eval::{EvalCase, EvalRunner, SuccessCriteria};
//!
//! let case = EvalCase {
//!     id: "test_001".into(),
//!     name: "Basic tool use".into(),
//!     description: "Agent should use read_file when asked to read".into(),
//!     domain: Some("coding".into()),
//!     task: "Read the file src/main.rs".into(),
//!     project_fixture: None,
//!     success_criteria: SuccessCriteria::ToolUsed {
//!         tool_name: "read_file".into(),
//!     },
//!     constraints: Default::default(),
//! };
//!
//! // let runner = EvalRunner::new(temp_dir);
//! // let result = runner.run(&case, &agent).await;
//! ```

pub mod comparator;
pub mod grader;
pub mod regression;
pub mod replay;
pub mod report;
pub mod runner;
pub mod server;
pub mod trigger;

pub use comparator::AbComparator;
pub use grader::LlmGrader;
pub use regression::RegressionSuite;
pub use replay::TrajectoryReplay;
pub use report::generate_html;
pub use runner::EvalRunner;
pub use server::generate_review_html;
pub use trigger::TriggerAccuracy;

use serde::{Deserialize, Serialize};
use std::path::PathBuf;

fn default_min_citations() -> usize {
    1
}

fn default_citation_format() -> String {
    "any".to_string()
}

fn default_tolerance() -> f64 {
    0.05
}

// ── EvalCase ─────────────────────────────────────────────────────────

/// A single eval test case — what to test and how to judge success.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EvalCase {
    /// Unique identifier for this case (e.g. "read_before_edit_001").
    pub id: String,
    /// Human-readable name.
    pub name: String,
    /// Description of what this case tests.
    #[serde(default)]
    pub description: String,
    /// Domain this case belongs to (coding, data, research, medical, general, skill-trigger).
    #[serde(default)]
    pub domain: Option<String>,
    /// The task/question to give the agent.
    pub task: String,
    /// Optional project fixture directory to set up before the test.
    /// Files are copied to the eval workspace before the agent runs.
    #[serde(default)]
    pub project_fixture: Option<PathBuf>,
    /// Criteria that determine pass/fail.
    pub success_criteria: SuccessCriteria,
    /// Constraints the agent must respect.
    #[serde(default)]
    pub constraints: EvalConstraints,
}

// ── SuccessCriteria ──────────────────────────────────────────────────

/// How to determine if an eval case passed.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum SuccessCriteria {
    /// A test command exits successfully (e.g., `cargo test`).
    TestPass { command: String },
    /// The agent's final output contains a specific substring.
    OutputContains { substring: String },
    /// The agent used a specific tool at least once.
    ToolUsed { tool_name: String },
    /// The agent did NOT use a specific tool.
    ToolNotUsed { tool_name: String },
    /// All of the given criteria must pass.
    AllOf(Vec<SuccessCriteria>),
    /// At least one of the given criteria must pass.
    AnyOf(Vec<SuccessCriteria>),
    /// LLM-as-Judge: assertions checked by an LLM grader agent.
    LlmGraded {
        /// Assertions for the grader to check.
        assertions: Vec<crate::eval::grader::Assertion>,
    },
    /// SWE-bench style: clone repo, check out commit, run agent, apply test patch, run tests.
    SweBench {
        /// Git repository URL to clone.
        repo_url: String,
        /// Base commit to check out before the agent runs.
        base_commit: String,
        /// Patch file to apply after the agent completes (adds tests).
        test_patch: String,
        /// Command to run after applying the test patch.
        test_command: String,
    },
    /// Safety check: forbidden patterns must NOT appear, required patterns MUST appear.
    /// Used for medical/red-line evaluation where certain outputs are unacceptable.
    SafetyCheck {
        /// Patterns that must NOT appear in the output (e.g. "建议你服用").
        forbidden_patterns: Vec<String>,
        /// Patterns that MUST appear in the output (e.g. "咨询医生").
        required_patterns: Vec<String>,
    },
    /// Citation validity: agent's citations must come from tool results, not fabricated.
    /// Checks that the output contains citation markers (PMID, DOI, URLs) and optionally
    /// that a minimum number of citations are present.
    CitationValid {
        /// Minimum number of citations required in the output.
        #[serde(default = "default_min_citations")]
        min_citations: usize,
        /// Citation format to check for: "pmid", "doi", "url", "any".
        #[serde(default = "default_citation_format")]
        format: String,
    },
    /// Value matching: agent's numeric outputs must match expected values within tolerance.
    /// Used for data analysis evaluation where statistical results must be accurate.
    ValueMatch {
        /// Expected key-value pairs (key = metric name, value = expected number).
        expected: std::collections::HashMap<String, f64>,
        /// Allowed tolerance for each value (e.g. 0.01 = 1%).
        #[serde(default = "default_tolerance")]
        tolerance: f64,
    },
}

// ── EvalConstraints ──────────────────────────────────────────────────

/// Guardrails the agent must respect during the eval.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct EvalConstraints {
    /// Maximum number of files the agent is allowed to change.
    #[serde(default)]
    pub max_files_changed: Option<usize>,
    /// Maximum number of tool calls allowed.
    #[serde(default)]
    pub max_tool_calls: Option<usize>,
    /// Paths the agent must not modify.
    #[serde(default)]
    pub forbidden_paths: Vec<String>,
    /// Whether the agent must read a file before editing it.
    #[serde(default)]
    pub required_read_before_edit: bool,
}

// ── EvalMetric ───────────────────────────────────────────────────────

/// A single scored dimension in an eval result.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EvalMetric {
    /// Metric name (e.g. "tool_accuracy", "test_pass", "constraint_compliance").
    pub name: String,
    /// Score from 0.0 (worst) to 1.0 (best).
    pub score: f64,
    /// Human-readable detail.
    pub detail: String,
}

// ── EvalResult ───────────────────────────────────────────────────────

/// Outcome of running a single eval case.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EvalResult {
    /// The case ID this result corresponds to.
    pub case_id: String,
    /// Whether the success criteria were met.
    pub success: bool,
    /// Aggregate score (average of all metrics).
    pub score: f64,
    /// Per-dimension scores.
    pub metrics: Vec<EvalMetric>,
    /// Constraint violations found.
    pub violations: Vec<String>,
    /// Link to the execution trace (run ID).
    pub run_id: Option<String>,
    /// Wall-clock duration in milliseconds.
    pub duration_ms: u64,
    /// Total tool calls made by the agent.
    #[serde(default)]
    pub tool_calls: usize,
    /// Estimated input tokens.
    #[serde(default)]
    pub tokens_in: u32,
    /// Estimated output tokens.
    #[serde(default)]
    pub tokens_out: u32,
    /// Provider-reported input tokens served from prompt cache.
    #[serde(default)]
    pub cached_tokens_in: u32,
    /// Provider-reported input tokens written into prompt cache.
    #[serde(default)]
    pub cache_creation_tokens_in: u32,
    /// Prompt cache read rate for this run.
    #[serde(default)]
    pub cache_hit_rate: Option<f64>,
    /// Tool errors observed in the execution trace.
    #[serde(default)]
    pub tool_errors: usize,
    /// Maximum protected-context token estimate observed before an LLM call.
    #[serde(default)]
    pub max_protected_context_tokens: usize,
    /// Number of files changed.
    #[serde(default)]
    pub file_changes: usize,
    /// Whether compilation succeeded (if applicable).
    #[serde(default)]
    pub compile_ok: Option<bool>,
    /// Whether tests passed (if applicable).
    #[serde(default)]
    pub tests_pass: Option<bool>,
}

impl EvalResult {
    pub fn new(case_id: &str, success: bool) -> Self {
        Self {
            case_id: case_id.to_string(),
            success,
            score: if success { 1.0 } else { 0.0 },
            metrics: Vec::new(),
            violations: Vec::new(),
            run_id: None,
            duration_ms: 0,
            tool_calls: 0,
            tokens_in: 0,
            tokens_out: 0,
            cached_tokens_in: 0,
            cache_creation_tokens_in: 0,
            cache_hit_rate: None,
            tool_errors: 0,
            max_protected_context_tokens: 0,
            file_changes: 0,
            compile_ok: None,
            tests_pass: None,
        }
    }

    pub fn with_metric(mut self, name: &str, score: f64, detail: &str) -> Self {
        self.metrics.push(EvalMetric {
            name: name.to_string(),
            score,
            detail: detail.to_string(),
        });
        self.recompute_score();
        self
    }

    pub fn with_violation(mut self, violation: &str) -> Self {
        self.violations.push(violation.to_string());
        self.success = false;
        self
    }

    pub fn with_run_id(mut self, run_id: &str) -> Self {
        self.run_id = Some(run_id.to_string());
        self
    }

    fn recompute_score(&mut self) {
        if self.metrics.is_empty() {
            self.score = if self.success { 1.0 } else { 0.0 };
        } else {
            self.score =
                self.metrics.iter().map(|m| m.score).sum::<f64>() / self.metrics.len() as f64;
        }
    }
}

// ── EvalReport ───────────────────────────────────────────────────────

/// Aggregate report across multiple eval cases.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EvalReport {
    /// Total number of cases.
    pub total: usize,
    /// Number that passed.
    pub passed: usize,
    /// Number that failed.
    pub failed: usize,
    /// Average score across all cases.
    pub avg_score: f64,
    /// Standard deviation of scores.
    #[serde(default)]
    pub std_dev: f64,
    /// Minimum score.
    #[serde(default)]
    pub min_score: f64,
    /// Maximum score.
    #[serde(default)]
    pub max_score: f64,
    /// Score delta from baseline (if comparing two runs).
    #[serde(default)]
    pub delta_vs_baseline: Option<f64>,
    /// Total tool calls across all cases.
    #[serde(default)]
    pub total_tool_calls: usize,
    /// Total tokens in across all cases.
    #[serde(default)]
    pub total_tokens_in: u32,
    /// Total tokens out across all cases.
    #[serde(default)]
    pub total_tokens_out: u32,
    /// Total input tokens served from prompt cache.
    #[serde(default)]
    pub total_cached_tokens_in: u32,
    /// Total input tokens written into prompt cache.
    #[serde(default)]
    pub total_cache_creation_tokens_in: u32,
    /// Aggregate prompt cache read rate.
    #[serde(default)]
    pub cache_hit_rate: Option<f64>,
    /// Total tool errors across all cases.
    #[serde(default)]
    pub total_tool_errors: usize,
    /// Largest protected-context estimate across all cases.
    #[serde(default)]
    pub max_protected_context_tokens: usize,
    /// Total files changed across all cases.
    #[serde(default)]
    pub total_file_changes: usize,
    /// Per-case results.
    pub results: Vec<EvalResult>,
}

impl EvalReport {
    pub fn new(results: Vec<EvalResult>) -> Self {
        let total = results.len();
        let passed = results.iter().filter(|r| r.success).count();
        let failed = total - passed;
        let avg_score = if total > 0 {
            results.iter().map(|r| r.score).sum::<f64>() / total as f64
        } else {
            0.0
        };
        let total_tool_calls = results.iter().fold(0usize, |total, result| {
            total.saturating_add(result.tool_calls)
        });
        let total_tokens_in = results
            .iter()
            .fold(0u32, |total, result| total.saturating_add(result.tokens_in));
        let total_tokens_out = results.iter().fold(0u32, |total, result| {
            total.saturating_add(result.tokens_out)
        });
        let total_cached_tokens_in = results.iter().fold(0u32, |total, result| {
            total.saturating_add(result.cached_tokens_in)
        });
        let total_cache_creation_tokens_in = results.iter().fold(0u32, |total, result| {
            total.saturating_add(result.cache_creation_tokens_in)
        });
        let cache_hit_rate = if total_tokens_in == 0 {
            None
        } else {
            Some(total_cached_tokens_in as f64 / total_tokens_in as f64)
        };
        let total_tool_errors = results.iter().fold(0usize, |total, result| {
            total.saturating_add(result.tool_errors)
        });
        let max_protected_context_tokens = results
            .iter()
            .map(|r| r.max_protected_context_tokens)
            .max()
            .unwrap_or(0);
        let total_file_changes = results.iter().fold(0usize, |total, result| {
            total.saturating_add(result.file_changes)
        });
        // Statistical aggregation
        let scores: Vec<f64> = results.iter().map(|r| r.score).collect();
        let variance = if total > 1 {
            scores.iter().map(|s| (s - avg_score).powi(2)).sum::<f64>() / (total - 1) as f64
        } else {
            0.0
        };
        let std_dev = variance.sqrt();
        let min_score = scores.iter().cloned().fold(f64::MAX, f64::min);
        let max_score = scores.iter().cloned().fold(f64::MIN, f64::max);
        Self {
            total,
            passed,
            failed,
            avg_score,
            std_dev,
            min_score: if total > 0 { min_score } else { 0.0 },
            max_score: if total > 0 { max_score } else { 0.0 },
            delta_vs_baseline: None,
            total_tool_calls,
            total_tokens_in,
            total_tokens_out,
            total_cached_tokens_in,
            total_cache_creation_tokens_in,
            cache_hit_rate,
            total_tool_errors,
            max_protected_context_tokens,
            total_file_changes,
            results,
        }
    }
}
