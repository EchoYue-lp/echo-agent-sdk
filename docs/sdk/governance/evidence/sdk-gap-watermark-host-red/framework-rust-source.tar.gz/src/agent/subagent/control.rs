//! Attempt-scoped, in-process control for active subagent dispatches.
//!
//! Durable command identity and recovery belong to framework consumers. This
//! registry only binds an exact execution attempt to its cancellation token and
//! the agent's existing live-steering safe point.

use echo_core::agent::{
    Agent, AgentSteerError, AgentSteerReceipt, AgentSteerState, CancellationToken,
};
use echo_core::llm::types::Message;
use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet, VecDeque};
use std::fmt;
use std::sync::{Arc, Mutex};
use tokio::sync::watch;

use super::types::SubagentStatus;

const SETTLED_RETENTION: usize = 256;
const PENDING_INTERRUPT_CAPACITY: usize = 256;

/// Stable identity for one attempt of a logical subagent task.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize)]
pub struct SubagentAttemptIdentity {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub run_id: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub control_scope_id: Option<String>,
    pub task_id: String,
    pub execution_id: String,
    pub attempt: u32,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct SubagentAttemptIdentityFields {
    #[serde(default)]
    run_id: Option<String>,
    #[serde(default)]
    control_scope_id: Option<String>,
    task_id: String,
    execution_id: String,
    attempt: u32,
}

impl<'de> Deserialize<'de> for SubagentAttemptIdentity {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        let fields = SubagentAttemptIdentityFields::deserialize(deserializer)?;
        let identity = Self {
            run_id: fields.run_id,
            control_scope_id: fields.control_scope_id,
            task_id: fields.task_id,
            execution_id: fields.execution_id,
            attempt: fields.attempt,
        };
        identity.validate().map_err(serde::de::Error::custom)?;
        Ok(identity)
    }
}

/// Durable identity for one idempotent command addressed to an exact
/// Subagent attempt.
///
/// The command id and task-graph revision are generic lifecycle facts, so
/// consumers can persist this value directly instead of defining a parallel
/// command identity around [`SubagentAttemptIdentity`].
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize)]
pub struct SubagentCommandIdentity {
    pub run_id: String,
    pub task_id: String,
    pub execution_id: String,
    pub plan_revision: u64,
    pub attempt: u32,
    pub command_id: String,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct SubagentCommandIdentityFields {
    run_id: String,
    task_id: String,
    execution_id: String,
    plan_revision: u64,
    attempt: u32,
    command_id: String,
}

impl<'de> Deserialize<'de> for SubagentCommandIdentity {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        let fields = SubagentCommandIdentityFields::deserialize(deserializer)?;
        let identity = Self {
            run_id: fields.run_id,
            task_id: fields.task_id,
            execution_id: fields.execution_id,
            plan_revision: fields.plan_revision,
            attempt: fields.attempt,
            command_id: fields.command_id,
        };
        identity.validate().map_err(serde::de::Error::custom)?;
        Ok(identity)
    }
}

impl SubagentCommandIdentity {
    pub fn new(
        run_id: impl Into<String>,
        task_id: impl Into<String>,
        execution_id: impl Into<String>,
        plan_revision: u64,
        attempt: u32,
        command_id: impl Into<String>,
    ) -> Result<Self, SubagentControlError> {
        let identity = Self {
            run_id: run_id.into(),
            task_id: task_id.into(),
            execution_id: execution_id.into(),
            plan_revision,
            attempt,
            command_id: command_id.into(),
        };
        identity.validate()?;
        Ok(identity)
    }

    pub fn validate(&self) -> Result<(), SubagentControlError> {
        if self.run_id.trim().is_empty() {
            return Err(SubagentControlError::InvalidIdentity { field: "run_id" });
        }
        if self.plan_revision == 0 {
            return Err(SubagentControlError::InvalidIdentity {
                field: "plan_revision",
            });
        }
        if self.command_id.trim().is_empty() {
            return Err(SubagentControlError::InvalidIdentity {
                field: "command_id",
            });
        }
        self.attempt_identity().map(|_| ())
    }

    /// Return the live-control identity for this command's exact attempt.
    pub fn attempt_identity(&self) -> Result<SubagentAttemptIdentity, SubagentControlError> {
        SubagentAttemptIdentity::for_run(
            self.run_id.clone(),
            self.task_id.clone(),
            self.execution_id.clone(),
            self.attempt,
        )
    }
}

impl SubagentAttemptIdentity {
    pub fn new(
        task_id: impl Into<String>,
        execution_id: impl Into<String>,
        attempt: u32,
    ) -> Result<Self, SubagentControlError> {
        let identity = Self {
            run_id: None,
            control_scope_id: None,
            task_id: task_id.into(),
            execution_id: execution_id.into(),
            attempt,
        };
        identity.validate()?;
        Ok(identity)
    }

    pub fn for_run(
        run_id: impl Into<String>,
        task_id: impl Into<String>,
        execution_id: impl Into<String>,
        attempt: u32,
    ) -> Result<Self, SubagentControlError> {
        let run_id = run_id.into();
        let identity = Self {
            control_scope_id: Some(run_id.clone()),
            run_id: Some(run_id),
            task_id: task_id.into(),
            execution_id: execution_id.into(),
            attempt,
        };
        identity.validate()?;
        Ok(identity)
    }

    pub fn for_runtime_scope(
        control_scope_id: impl Into<String>,
        run_id: impl Into<String>,
        task_id: impl Into<String>,
        execution_id: impl Into<String>,
        attempt: u32,
    ) -> Result<Self, SubagentControlError> {
        let identity = Self {
            run_id: Some(run_id.into()),
            control_scope_id: Some(control_scope_id.into()),
            task_id: task_id.into(),
            execution_id: execution_id.into(),
            attempt,
        };
        identity.validate()?;
        Ok(identity)
    }

    fn validate(&self) -> Result<(), SubagentControlError> {
        if self
            .run_id
            .as_ref()
            .is_some_and(|run_id| run_id.trim().is_empty())
        {
            return Err(SubagentControlError::InvalidIdentity { field: "run_id" });
        }
        if self
            .control_scope_id
            .as_ref()
            .is_some_and(|scope_id| scope_id.trim().is_empty())
        {
            return Err(SubagentControlError::InvalidIdentity {
                field: "control_scope_id",
            });
        }
        if self.task_id.trim().is_empty() {
            return Err(SubagentControlError::InvalidIdentity { field: "task_id" });
        }
        if self.execution_id.trim().is_empty() {
            return Err(SubagentControlError::InvalidIdentity {
                field: "execution_id",
            });
        }
        if self.attempt == 0 {
            return Err(SubagentControlError::InvalidIdentity { field: "attempt" });
        }
        Ok(())
    }

    fn task_attempt(&self) -> ScopedTaskAttemptKey {
        (
            self.control_scope_id.clone(),
            self.run_id.clone(),
            self.task_id.clone(),
            self.attempt,
        )
    }
}

/// Control phase observed before or while settling an interrupt request.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SubagentControlPhase {
    Starting,
    Running,
    InterruptRequested,
    Settled,
}

/// Durable lifecycle phase for one Subagent command.
///
/// This phase is distinct from [`SubagentControlPhase`], which describes the
/// in-process executor binding. It starts at durable command persistence and
/// ends when the owning turn settles, so a consumer can expose one complete
/// command receipt without inventing another lifecycle enum.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SubagentCommandPhase {
    Persisted,
    MailboxAccepted,
    Drained,
    TurnSettled,
}

impl SubagentCommandPhase {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Persisted => "persisted",
            Self::MailboxAccepted => "mailbox_accepted",
            Self::Drained => "drained",
            Self::TurnSettled => "turn_settled",
        }
    }

    pub fn parse(value: &str) -> Option<Self> {
        match value {
            "persisted" => Some(Self::Persisted),
            "mailbox_accepted" => Some(Self::MailboxAccepted),
            "drained" => Some(Self::Drained),
            "turn_settled" => Some(Self::TurnSettled),
            _ => None,
        }
    }
}

/// Exact-attempt envelope for one live message accepted by the active Agent
/// mailbox. The nested framework receipt is the sole lifecycle authority.
#[derive(Debug, Clone)]
pub struct SubagentMessageReceipt {
    pub execution_id: String,
    pub attempt: u32,
    receipt: AgentSteerReceipt,
}

impl SubagentMessageReceipt {
    /// The framework-owned tracked receipt for this exact message.
    pub fn receipt(&self) -> &AgentSteerReceipt {
        &self.receipt
    }

    /// Consume this delivery and return its framework-owned tracked receipt.
    pub fn into_receipt(self) -> AgentSteerReceipt {
        self.receipt
    }

    /// Wait until the message reaches model context or the owning turn settles.
    pub async fn wait_for_drained(&mut self) -> AgentSteerState {
        self.receipt.wait_for_drained().await
    }

    /// Wait until the owning turn reaches its typed terminal outcome.
    pub async fn wait_for_turn_settled(&mut self) -> AgentSteerState {
        self.receipt.wait_for_turn_settled().await
    }
}

/// Receipt for guidance queued for one exact future attempt.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SubagentGuidanceQueueReceipt {
    pub task_id: String,
    pub attempt: u32,
    pub queued_count: usize,
}

/// Result returned after an exact-attempt interrupt reaches settlement.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SubagentInterruptOutcome {
    pub execution_id: String,
    pub attempt: u32,
    pub requested: bool,
    pub settled: bool,
    pub previous_status: SubagentControlPhase,
    pub terminal_status: Option<SubagentStatus>,
}

/// Immediate acknowledgement for an exact interrupt request.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SubagentInterruptRequestReceipt {
    pub identity: SubagentAttemptIdentity,
    pub disposition: SubagentInterruptRequestDisposition,
}

/// Process-local disposition before an exact interrupt is fully settled.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SubagentInterruptRequestDisposition {
    QueuedBeforeAdmission,
    ReservedRequested,
    ActiveRequested,
    ActiveAlreadyRequested,
    AlreadySettled(SubagentStatus),
}

/// Typed rejection from the process-scoped Subagent control plane.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SubagentControlError {
    InvalidIdentity {
        field: &'static str,
    },
    EmptyInstruction,
    StateUnavailable,
    DuplicateExecution {
        execution_id: String,
    },
    ExecutionIdentityMismatch {
        expected: String,
        actual: String,
    },
    AttemptIdentityMismatch {
        execution_id: String,
        field: &'static str,
        expected: String,
        actual: String,
    },
    AttemptAlreadyStarted {
        task_id: String,
        attempt: u32,
    },
    UnknownExecution {
        execution_id: String,
    },
    AttemptMismatch {
        execution_id: String,
        expected: u32,
        actual: u32,
    },
    InterruptPending {
        execution_id: String,
        attempt: u32,
    },
    PendingCapacityExceeded {
        limit: usize,
    },
    IdentityConflict {
        task_id: String,
        attempt: u32,
        expected_execution_id: String,
        actual_execution_id: String,
    },
    AttemptSettled {
        execution_id: String,
        attempt: u32,
        status: SubagentStatus,
    },
    Steer(AgentSteerError),
}

impl fmt::Display for SubagentControlError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidIdentity { field } => {
                write!(f, "invalid Subagent identity field: {field}")
            }
            Self::EmptyInstruction => f.write_str("Subagent instruction must not be empty"),
            Self::StateUnavailable => f.write_str("Subagent control state is unavailable"),
            Self::DuplicateExecution { execution_id } => {
                write!(f, "Subagent execution already exists: {execution_id}")
            }
            Self::ExecutionIdentityMismatch { expected, actual } => write!(
                f,
                "Subagent execution identity mismatch: expected {expected}, actual {actual}"
            ),
            Self::AttemptIdentityMismatch {
                execution_id,
                field,
                expected,
                actual,
            } => write!(
                f,
                "Subagent execution {execution_id} identity field {field} mismatch: expected {expected}, actual {actual}"
            ),
            Self::AttemptAlreadyStarted { task_id, attempt } => {
                write!(
                    f,
                    "Subagent task {task_id} attempt {attempt} already started"
                )
            }
            Self::UnknownExecution { execution_id } => {
                write!(f, "unknown Subagent execution: {execution_id}")
            }
            Self::AttemptMismatch {
                execution_id,
                expected,
                actual,
            } => write!(
                f,
                "Subagent execution {execution_id} attempt mismatch: expected {expected}, actual {actual}"
            ),
            Self::InterruptPending {
                execution_id,
                attempt,
            } => write!(
                f,
                "Subagent execution {execution_id} attempt {attempt} is settling an interrupt"
            ),
            Self::PendingCapacityExceeded { limit } => {
                write!(
                    f,
                    "Subagent interrupt pending capacity exceeded (limit {limit})"
                )
            }
            Self::IdentityConflict {
                task_id,
                attempt,
                expected_execution_id,
                actual_execution_id,
            } => write!(
                f,
                "Subagent task {task_id} attempt {attempt} execution identity conflict: expected {expected_execution_id}, actual {actual_execution_id}"
            ),
            Self::AttemptSettled {
                execution_id,
                attempt,
                status,
            } => write!(
                f,
                "Subagent execution {execution_id} attempt {attempt} already settled as {}",
                status.as_str()
            ),
            Self::Steer(error) => write!(f, "Subagent steering rejected: {error}"),
        }
    }
}

impl std::error::Error for SubagentControlError {}

#[derive(Clone)]
pub(crate) struct SubagentAttemptBinding {
    registry: Arc<SubagentControlRegistry>,
    identity: SubagentAttemptIdentity,
}

impl SubagentAttemptBinding {
    pub(crate) fn identity(&self) -> &SubagentAttemptIdentity {
        &self.identity
    }

    pub(crate) fn attach(
        &self,
        agent: Arc<dyn Agent>,
        turn_id: String,
    ) -> Result<SubagentSteeringLease, SubagentControlError> {
        self.registry.attach(&self.identity, agent, turn_id)?;
        Ok(SubagentSteeringLease {
            binding: self.clone(),
        })
    }
}

pub(crate) struct SubagentAttemptAdmission {
    pub(crate) binding: SubagentAttemptBinding,
    pub(crate) guidance: Vec<String>,
    pub(crate) cancel: CancellationToken,
    settled: bool,
}

impl SubagentAttemptAdmission {
    pub(crate) fn settle(mut self, status: SubagentStatus) {
        self.binding.registry.settle(&self.binding.identity, status);
        self.settled = true;
    }
}

impl Drop for SubagentAttemptAdmission {
    fn drop(&mut self) {
        if !self.settled {
            let status = if self.binding.registry.is_cancelled(&self.binding.identity) {
                SubagentStatus::Cancelled
            } else {
                SubagentStatus::Failed
            };
            self.binding.registry.settle(&self.binding.identity, status);
        }
    }
}

pub(crate) struct SubagentSteeringLease {
    binding: SubagentAttemptBinding,
}

impl Drop for SubagentSteeringLease {
    fn drop(&mut self) {
        self.binding.registry.detach(&self.binding.identity);
    }
}

struct ActiveAttempt {
    identity: SubagentAttemptIdentity,
    cancel: CancellationToken,
    reserved: bool,
    phase: SubagentControlPhase,
    agent: Option<Arc<dyn Agent>>,
    turn_id: Option<String>,
    ready_tx: watch::Sender<bool>,
    settled_tx: watch::Sender<Option<SubagentStatus>>,
}

#[derive(Debug, Clone)]
struct SettledAttempt {
    identity: SubagentAttemptIdentity,
    status: SubagentStatus,
}

type ScopedTaskAttemptKey = (Option<String>, Option<String>, String, u32);

#[derive(Default)]
struct ControlState {
    active: HashMap<String, ActiveAttempt>,
    active_by_task_attempt: HashMap<ScopedTaskAttemptKey, String>,
    queued_guidance: HashMap<ScopedTaskAttemptKey, VecDeque<String>>,
    pending_interrupts: HashMap<String, SubagentAttemptIdentity>,
    settled: HashMap<String, SettledAttempt>,
    settled_by_task_attempt: HashMap<ScopedTaskAttemptKey, String>,
    settled_order: VecDeque<String>,
}

/// Bounded, read-only summary of one active attempt, for in-tree discovery
/// tools such as `subagent_list`.
#[derive(Clone, Debug)]
pub struct ActiveAttemptSummary {
    pub execution_id: String,
    pub task_id: String,
    pub attempt: u32,
    pub phase: SubagentControlPhase,
}

/// Process-scoped execution control. Durable state remains consumer-owned.
///
/// Shared per `SubagentRegistry` so an `execution_id` is addressable across
/// every executor built on that registry (see `SubagentRegistry::control_registry`).
#[derive(Default)]
pub struct SubagentControlRegistry {
    state: Mutex<ControlState>,
}

impl SubagentControlRegistry {
    /// Reserve an exact attempt before it waits for shared execution capacity.
    /// The later [`Self::admit`] call consumes this reservation and receives
    /// the same binding; no second identity or cancellation token is created.
    pub(crate) fn reserve(
        self: &Arc<Self>,
        identity: SubagentAttemptIdentity,
        cancel: CancellationToken,
    ) -> Result<(), SubagentControlError> {
        identity.validate()?;
        let mut state = self
            .state
            .lock()
            .map_err(|_| SubagentControlError::StateUnavailable)?;
        if let Some(active) = state.active.get(&identity.execution_id) {
            Self::validate_identity(&active.identity, &identity)?;
            return Err(SubagentControlError::DuplicateExecution {
                execution_id: identity.execution_id,
            });
        }
        if let Some(settled) = state.settled.get(&identity.execution_id) {
            Self::validate_identity(&settled.identity, &identity)?;
            return Err(SubagentControlError::DuplicateExecution {
                execution_id: identity.execution_id,
            });
        }
        let task_attempt = identity.task_attempt();
        if state.active_by_task_attempt.contains_key(&task_attempt)
            || state.settled_by_task_attempt.contains_key(&task_attempt)
        {
            return Err(SubagentControlError::AttemptAlreadyStarted {
                task_id: identity.task_id,
                attempt: identity.attempt,
            });
        }
        if let Some(pending) = state.pending_interrupts.get(&identity.execution_id) {
            Self::validate_identity(pending, &identity)?;
        }
        if let Some(conflict) = state.pending_interrupts.values().find(|pending| {
            pending.control_scope_id == identity.control_scope_id
                && pending.run_id == identity.run_id
                && pending.task_id == identity.task_id
                && pending.attempt == identity.attempt
                && pending.execution_id != identity.execution_id
        }) {
            return Err(SubagentControlError::IdentityConflict {
                task_id: identity.task_id,
                attempt: identity.attempt,
                expected_execution_id: identity.execution_id,
                actual_execution_id: conflict.execution_id.clone(),
            });
        }
        let pending_interrupt = state.pending_interrupts.remove(&identity.execution_id);
        let (ready_tx, _) = watch::channel(false);
        let (settled_tx, _) = watch::channel(None);
        state
            .active_by_task_attempt
            .insert(task_attempt, identity.execution_id.clone());
        state.active.insert(
            identity.execution_id.clone(),
            ActiveAttempt {
                identity: identity.clone(),
                cancel: cancel.clone(),
                reserved: true,
                phase: SubagentControlPhase::Starting,
                agent: None,
                turn_id: None,
                ready_tx,
                settled_tx,
            },
        );
        drop(state);
        if pending_interrupt.is_some() {
            cancel.cancel();
        }
        Ok(())
    }

    pub(crate) fn admit(
        self: &Arc<Self>,
        identity: SubagentAttemptIdentity,
        cancel: CancellationToken,
    ) -> Result<SubagentAttemptAdmission, SubagentControlError> {
        identity.validate()?;
        let mut state = self
            .state
            .lock()
            .map_err(|_| SubagentControlError::StateUnavailable)?;
        if let Some(active) = state.active.get_mut(&identity.execution_id) {
            Self::validate_identity(&active.identity, &identity)?;
            if !active.reserved {
                return Err(SubagentControlError::DuplicateExecution {
                    execution_id: identity.execution_id,
                });
            }
            // The reservation owns the child token. Use it for the dispatch
            // even if a caller supplied another token for this identity.
            let cancel = active.cancel.clone();
            active.reserved = false;
            let guidance = state
                .queued_guidance
                .remove(&identity.task_attempt())
                .map(VecDeque::into_iter)
                .into_iter()
                .flatten()
                .collect();
            return Ok(SubagentAttemptAdmission {
                binding: SubagentAttemptBinding {
                    registry: Arc::clone(self),
                    identity,
                },
                guidance,
                cancel,
                settled: false,
            });
        }
        if let Some(settled) = state.settled.get(&identity.execution_id) {
            Self::validate_identity(&settled.identity, &identity)?;
            return Err(SubagentControlError::DuplicateExecution {
                execution_id: identity.execution_id,
            });
        }
        let task_attempt = identity.task_attempt();
        if state.active_by_task_attempt.contains_key(&task_attempt)
            || state.settled_by_task_attempt.contains_key(&task_attempt)
        {
            return Err(SubagentControlError::AttemptAlreadyStarted {
                task_id: identity.task_id,
                attempt: identity.attempt,
            });
        }
        if let Some(pending) = state.pending_interrupts.get(&identity.execution_id) {
            Self::validate_identity(pending, &identity)?;
        }
        let pending_interrupt = state.pending_interrupts.remove(&identity.execution_id);
        let guidance = state
            .queued_guidance
            .remove(&task_attempt)
            .map(VecDeque::into_iter)
            .into_iter()
            .flatten()
            .collect();
        let (ready_tx, _) = watch::channel(false);
        let (settled_tx, _) = watch::channel(None);
        state
            .active_by_task_attempt
            .insert(task_attempt, identity.execution_id.clone());
        state.active.insert(
            identity.execution_id.clone(),
            ActiveAttempt {
                identity: identity.clone(),
                cancel: cancel.clone(),
                reserved: false,
                phase: SubagentControlPhase::Starting,
                agent: None,
                turn_id: None,
                ready_tx,
                settled_tx,
            },
        );
        drop(state);
        if pending_interrupt.is_some() {
            cancel.cancel();
        }
        Ok(SubagentAttemptAdmission {
            binding: SubagentAttemptBinding {
                registry: Arc::clone(self),
                identity,
            },
            guidance,
            cancel,
            settled: false,
        })
    }

    /// Request an exact interrupt without waiting for execution settlement.
    pub(crate) fn request_interrupt(
        &self,
        identity: SubagentAttemptIdentity,
    ) -> Result<SubagentInterruptRequestReceipt, SubagentControlError> {
        identity.validate()?;
        let cancel: Option<CancellationToken> = {
            let mut state = self
                .state
                .lock()
                .map_err(|_| SubagentControlError::StateUnavailable)?;
            if let Some(settled) = state.settled.get(&identity.execution_id) {
                Self::validate_identity(&settled.identity, &identity)?;
                return Ok(SubagentInterruptRequestReceipt {
                    identity,
                    disposition: SubagentInterruptRequestDisposition::AlreadySettled(
                        settled.status,
                    ),
                });
            }
            if let Some(active) = state.active.get_mut(&identity.execution_id) {
                Self::validate_identity(&active.identity, &identity)?;
                let already_requested = active.phase == SubagentControlPhase::InterruptRequested;
                active.phase = SubagentControlPhase::InterruptRequested;
                let cancel = active.cancel.clone();
                let disposition = if active.reserved {
                    SubagentInterruptRequestDisposition::ReservedRequested
                } else if already_requested {
                    SubagentInterruptRequestDisposition::ActiveAlreadyRequested
                } else {
                    SubagentInterruptRequestDisposition::ActiveRequested
                };
                drop(state);
                if !already_requested {
                    cancel.cancel();
                }
                return Ok(SubagentInterruptRequestReceipt {
                    identity,
                    disposition,
                });
            }
            if let Some(pending) = state.pending_interrupts.get(&identity.execution_id) {
                Self::validate_identity(pending, &identity)?;
                return Ok(SubagentInterruptRequestReceipt {
                    identity,
                    disposition: SubagentInterruptRequestDisposition::QueuedBeforeAdmission,
                });
            }
            if let Some(conflict) = state.pending_interrupts.values().find(|pending| {
                pending.control_scope_id == identity.control_scope_id
                    && pending.run_id == identity.run_id
                    && pending.task_id == identity.task_id
                    && pending.attempt == identity.attempt
            }) {
                return Err(SubagentControlError::IdentityConflict {
                    task_id: identity.task_id,
                    attempt: identity.attempt,
                    expected_execution_id: identity.execution_id,
                    actual_execution_id: conflict.execution_id.clone(),
                });
            }
            if state.pending_interrupts.len() >= PENDING_INTERRUPT_CAPACITY {
                return Err(SubagentControlError::PendingCapacityExceeded {
                    limit: PENDING_INTERRUPT_CAPACITY,
                });
            }
            state
                .pending_interrupts
                .insert(identity.execution_id.clone(), identity.clone());
            None
        };
        if let Some(cancel) = cancel {
            cancel.cancel();
            return Ok(SubagentInterruptRequestReceipt {
                identity,
                disposition: SubagentInterruptRequestDisposition::ActiveRequested,
            });
        }
        Ok(SubagentInterruptRequestReceipt {
            identity,
            disposition: SubagentInterruptRequestDisposition::QueuedBeforeAdmission,
        })
    }

    /// Retire an exact pending or settled projection after durable claim
    /// settlement. An active/reserved projection is cancelled and retained
    /// until canonical dispatch settlement.
    pub(crate) fn retire_exact(
        &self,
        identity: &SubagentAttemptIdentity,
    ) -> Result<bool, SubagentControlError> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| SubagentControlError::StateUnavailable)?;
        if let Some(current) = state.pending_interrupts.get(&identity.execution_id) {
            Self::validate_identity(current, identity)?;
            state.pending_interrupts.remove(&identity.execution_id);
            return Ok(true);
        }
        if let Some(active) = state.active.get_mut(&identity.execution_id) {
            Self::validate_identity(&active.identity, identity)?;
            active.phase = SubagentControlPhase::InterruptRequested;
            let cancel = active.cancel.clone();
            drop(state);
            cancel.cancel();
            return Err(SubagentControlError::InterruptPending {
                execution_id: identity.execution_id.clone(),
                attempt: identity.attempt,
            });
        }
        if let Some(settled) = state.settled.get(&identity.execution_id) {
            Self::validate_identity(&settled.identity, identity)?;
            let settled = state
                .settled
                .remove(&identity.execution_id)
                .ok_or(SubagentControlError::StateUnavailable)?;
            state
                .settled_by_task_attempt
                .remove(&settled.identity.task_attempt());
            state
                .settled_order
                .retain(|execution_id| execution_id != &identity.execution_id);
            return Ok(true);
        }
        Ok(false)
    }

    /// Reconcile process-local projections against the exact execution IDs
    /// still owned by durable TaskClaims. Stale active/reserved attempts are
    /// cancelled but retained until their canonical dispatch settles; stale
    /// pending and settled projections can be removed immediately.
    pub(crate) fn reconcile_scope(
        &self,
        control_scope_id: &str,
        run_id: &str,
        current_execution_ids: &HashSet<String>,
    ) -> Result<(), SubagentControlError> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| SubagentControlError::StateUnavailable)?;
        state.pending_interrupts.retain(|execution_id, identity| {
            identity.control_scope_id.as_deref() != Some(control_scope_id)
                || identity.run_id.as_deref() != Some(run_id)
                || current_execution_ids.contains(execution_id)
        });

        let stale_active = state
            .active
            .iter_mut()
            .filter_map(|(execution_id, active)| {
                if active.identity.control_scope_id.as_deref() != Some(control_scope_id)
                    || active.identity.run_id.as_deref() != Some(run_id)
                    || current_execution_ids.contains(execution_id)
                {
                    return None;
                }
                active.phase = SubagentControlPhase::InterruptRequested;
                Some(active.cancel.clone())
            })
            .collect::<Vec<_>>();

        let stale_settled = state
            .settled
            .keys()
            .filter(|execution_id| {
                state.settled.get(*execution_id).is_some_and(|settled| {
                    settled.identity.control_scope_id.as_deref() == Some(control_scope_id)
                        && settled.identity.run_id.as_deref() == Some(run_id)
                        && !current_execution_ids.contains(*execution_id)
                })
            })
            .cloned()
            .collect::<Vec<_>>();
        for execution_id in stale_settled {
            if let Some(settled) = state.settled.remove(&execution_id) {
                state
                    .settled_by_task_attempt
                    .remove(&settled.identity.task_attempt());
            }
            state
                .settled_order
                .retain(|retained| retained != &execution_id);
        }
        drop(state);
        for cancel in stale_active {
            cancel.cancel();
        }
        Ok(())
    }

    pub(crate) fn queue_guidance(
        &self,
        task_id: &str,
        expected_next_attempt: u32,
        instruction: impl Into<String>,
    ) -> Result<SubagentGuidanceQueueReceipt, SubagentControlError> {
        let task_id = task_id.trim();
        if task_id.is_empty() {
            return Err(SubagentControlError::InvalidIdentity { field: "task_id" });
        }
        if expected_next_attempt == 0 {
            return Err(SubagentControlError::InvalidIdentity { field: "attempt" });
        }
        let instruction = instruction.into();
        if instruction.trim().is_empty() {
            return Err(SubagentControlError::EmptyInstruction);
        }
        let key = (None, None, task_id.to_string(), expected_next_attempt);
        let mut state = self
            .state
            .lock()
            .map_err(|_| SubagentControlError::StateUnavailable)?;
        if state.active_by_task_attempt.contains_key(&key)
            || state.settled_by_task_attempt.contains_key(&key)
        {
            return Err(SubagentControlError::AttemptAlreadyStarted {
                task_id: task_id.to_string(),
                attempt: expected_next_attempt,
            });
        }
        let guidance = state.queued_guidance.entry(key).or_default();
        guidance.push_back(instruction);
        Ok(SubagentGuidanceQueueReceipt {
            task_id: task_id.to_string(),
            attempt: expected_next_attempt,
            queued_count: guidance.len(),
        })
    }

    pub(crate) async fn send_message_tracked(
        &self,
        execution_id: &str,
        expected_attempt: u32,
        instruction: impl Into<String>,
    ) -> Result<SubagentMessageReceipt, SubagentControlError> {
        let instruction = instruction.into();
        if instruction.trim().is_empty() {
            return Err(SubagentControlError::EmptyInstruction);
        }
        loop {
            let mut ready_rx = {
                let state = self
                    .state
                    .lock()
                    .map_err(|_| SubagentControlError::StateUnavailable)?;
                let Some(active) = state.active.get(execution_id) else {
                    return Err(self.missing_execution_error(
                        &state,
                        execution_id,
                        expected_attempt,
                    ));
                };
                Self::validate_attempt(&active.identity, expected_attempt)?;
                if active.phase == SubagentControlPhase::InterruptRequested {
                    return Err(SubagentControlError::InterruptPending {
                        execution_id: execution_id.to_string(),
                        attempt: expected_attempt,
                    });
                }
                if let (Some(agent), Some(turn_id)) = (&active.agent, active.turn_id.as_deref()) {
                    let tracked = agent
                        .steer_input_tracked(Some(turn_id), Message::user(instruction.clone()))
                        .map_err(SubagentControlError::Steer)?;
                    return Ok(SubagentMessageReceipt {
                        execution_id: execution_id.to_string(),
                        attempt: expected_attempt,
                        receipt: tracked,
                    });
                }
                active.ready_tx.subscribe()
            };
            if ready_rx.changed().await.is_err() {
                // Settlement drops the readiness sender. Re-read the bounded
                // terminal record and return its exact outcome.
                continue;
            }
        }
    }

    /// Deliver a queue-only message to whichever attempt is currently active
    /// under `execution_id`, resolving the attempt number internally.
    ///
    /// Used by the default uplink (parent steer) and `subagent_message`
    /// (sibling steer), where the caller knows the target execution id but
    /// not its attempt number. Attempts the same receipt contract as
    /// [`Self::send_message_tracked`].
    pub(crate) async fn send_message_to_active(
        &self,
        execution_id: &str,
        instruction: impl Into<String>,
    ) -> Result<SubagentMessageReceipt, SubagentControlError> {
        let attempt = {
            let state = self
                .state
                .lock()
                .map_err(|_| SubagentControlError::StateUnavailable)?;
            let active = state.active.get(execution_id).ok_or_else(|| {
                SubagentControlError::UnknownExecution {
                    execution_id: execution_id.to_string(),
                }
            })?;
            active.identity.attempt
        };
        self.send_message_tracked(execution_id, attempt, instruction)
            .await
    }

    /// Snapshot of currently active attempts, bounded by `limit` (clamped to
    /// at most 64 entries; sorted by execution id for stable output).
    pub fn active_snapshot(&self, limit: usize) -> Vec<ActiveAttemptSummary> {
        let limit = limit.min(64);
        let Ok(state) = self.state.lock() else {
            return Vec::new();
        };
        let mut summaries: Vec<ActiveAttemptSummary> = state
            .active
            .values()
            .map(|active| ActiveAttemptSummary {
                execution_id: active.identity.execution_id.clone(),
                task_id: active.identity.task_id.clone(),
                attempt: active.identity.attempt,
                phase: active.phase,
            })
            .collect();
        summaries.sort_by(|left, right| left.execution_id.cmp(&right.execution_id));
        summaries.truncate(limit);
        summaries
    }

    pub(crate) async fn interrupt(
        &self,
        execution_id: &str,
        expected_attempt: u32,
    ) -> Result<SubagentInterruptOutcome, SubagentControlError> {
        let (previous_status, requested, cancel, mut settled_rx) = {
            let mut state = self
                .state
                .lock()
                .map_err(|_| SubagentControlError::StateUnavailable)?;
            if let Some(settled) = state.settled.get(execution_id) {
                Self::validate_attempt(&settled.identity, expected_attempt)?;
                return Ok(SubagentInterruptOutcome {
                    execution_id: execution_id.to_string(),
                    attempt: expected_attempt,
                    requested: false,
                    settled: true,
                    previous_status: SubagentControlPhase::Settled,
                    terminal_status: Some(settled.status),
                });
            }
            let active = state.active.get_mut(execution_id).ok_or_else(|| {
                SubagentControlError::UnknownExecution {
                    execution_id: execution_id.to_string(),
                }
            })?;
            Self::validate_attempt(&active.identity, expected_attempt)?;
            let previous_status = active.phase;
            let requested = active.phase != SubagentControlPhase::InterruptRequested;
            active.phase = SubagentControlPhase::InterruptRequested;
            (
                previous_status,
                requested,
                active.cancel.clone(),
                active.settled_tx.subscribe(),
            )
        };
        cancel.cancel();

        let terminal_status = loop {
            if let Some(status) = *settled_rx.borrow_and_update() {
                break status;
            }
            settled_rx
                .changed()
                .await
                .map_err(|_| SubagentControlError::StateUnavailable)?;
        };
        Ok(SubagentInterruptOutcome {
            execution_id: execution_id.to_string(),
            attempt: expected_attempt,
            requested,
            settled: true,
            previous_status,
            terminal_status: Some(terminal_status),
        })
    }

    fn attach(
        &self,
        identity: &SubagentAttemptIdentity,
        agent: Arc<dyn Agent>,
        turn_id: String,
    ) -> Result<(), SubagentControlError> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| SubagentControlError::StateUnavailable)?;
        let active = state
            .active
            .get_mut(&identity.execution_id)
            .ok_or_else(|| SubagentControlError::UnknownExecution {
                execution_id: identity.execution_id.clone(),
            })?;
        Self::validate_identity(&active.identity, identity)?;
        active.agent = Some(agent);
        active.turn_id = Some(turn_id);
        active.ready_tx.send_replace(true);
        if active.phase == SubagentControlPhase::Starting {
            active.phase = SubagentControlPhase::Running;
        }
        Ok(())
    }

    fn detach(&self, identity: &SubagentAttemptIdentity) {
        let Ok(mut state) = self.state.lock() else {
            return;
        };
        let Some(active) = state.active.get_mut(&identity.execution_id) else {
            return;
        };
        if active.identity == *identity {
            active.agent = None;
            active.turn_id = None;
            active.ready_tx.send_replace(false);
            if active.phase == SubagentControlPhase::Running {
                active.phase = SubagentControlPhase::Starting;
            }
        }
    }

    fn settle(&self, identity: &SubagentAttemptIdentity, status: SubagentStatus) {
        let Ok(mut state) = self.state.lock() else {
            return;
        };
        let Some(active) = state.active.remove(&identity.execution_id) else {
            return;
        };
        if active.identity != *identity {
            state.active.insert(identity.execution_id.clone(), active);
            return;
        }
        state.pending_interrupts.remove(&identity.execution_id);
        state
            .active_by_task_attempt
            .remove(&identity.task_attempt());
        active.settled_tx.send_replace(Some(status));
        state
            .settled_by_task_attempt
            .insert(identity.task_attempt(), identity.execution_id.clone());
        state.settled.insert(
            identity.execution_id.clone(),
            SettledAttempt {
                identity: identity.clone(),
                status,
            },
        );
        state.settled_order.push_back(identity.execution_id.clone());
        while state.settled_order.len() > SETTLED_RETENTION {
            let Some(old_execution_id) = state.settled_order.pop_front() else {
                break;
            };
            if let Some(old) = state.settled.remove(&old_execution_id) {
                state
                    .settled_by_task_attempt
                    .remove(&old.identity.task_attempt());
            }
        }
    }

    fn is_cancelled(&self, identity: &SubagentAttemptIdentity) -> bool {
        self.state
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
            .active
            .get(&identity.execution_id)
            .is_some_and(|active| active.identity == *identity && active.cancel.is_cancelled())
    }

    fn validate_attempt(
        identity: &SubagentAttemptIdentity,
        expected_attempt: u32,
    ) -> Result<(), SubagentControlError> {
        if identity.attempt != expected_attempt {
            return Err(SubagentControlError::AttemptMismatch {
                execution_id: identity.execution_id.clone(),
                expected: expected_attempt,
                actual: identity.attempt,
            });
        }
        Ok(())
    }

    fn validate_identity(
        expected: &SubagentAttemptIdentity,
        actual: &SubagentAttemptIdentity,
    ) -> Result<(), SubagentControlError> {
        Self::validate_attempt(expected, actual.attempt)?;
        Self::validate_identity_field(
            &expected.execution_id,
            "control_scope_id",
            expected.control_scope_id.as_deref(),
            actual.control_scope_id.as_deref(),
        )?;
        Self::validate_identity_field(
            &expected.execution_id,
            "run_id",
            expected.run_id.as_deref(),
            actual.run_id.as_deref(),
        )?;
        Self::validate_identity_field(
            &expected.execution_id,
            "task_id",
            Some(expected.task_id.as_str()),
            Some(actual.task_id.as_str()),
        )?;
        Self::validate_identity_field(
            &expected.execution_id,
            "execution_id",
            Some(expected.execution_id.as_str()),
            Some(actual.execution_id.as_str()),
        )
    }

    fn validate_identity_field(
        execution_id: &str,
        field: &'static str,
        expected: Option<&str>,
        actual: Option<&str>,
    ) -> Result<(), SubagentControlError> {
        if expected != actual {
            return Err(SubagentControlError::AttemptIdentityMismatch {
                execution_id: execution_id.to_string(),
                field,
                expected: expected.unwrap_or("<none>").to_string(),
                actual: actual.unwrap_or("<none>").to_string(),
            });
        }
        Ok(())
    }

    fn missing_execution_error(
        &self,
        state: &ControlState,
        execution_id: &str,
        expected_attempt: u32,
    ) -> SubagentControlError {
        if let Some(settled) = state.settled.get(execution_id) {
            if settled.identity.attempt != expected_attempt {
                return SubagentControlError::AttemptMismatch {
                    execution_id: execution_id.to_string(),
                    expected: expected_attempt,
                    actual: settled.identity.attempt,
                };
            }
            return SubagentControlError::AttemptSettled {
                execution_id: execution_id.to_string(),
                attempt: expected_attempt,
                status: settled.status,
            };
        }
        SubagentControlError::UnknownExecution {
            execution_id: execution_id.to_string(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use echo_core::agent::AgentEvent;
    use echo_core::agent::AgentSteerTurnOutcome;
    use echo_core::error::Result as AgentResult;
    use futures::future::BoxFuture;
    use futures::stream::BoxStream;

    struct SteerTestAgent {
        active_turn: Mutex<Option<String>>,
        messages: Mutex<Vec<String>>,
        lifecycle: Mutex<Option<watch::Sender<AgentSteerState>>>,
    }

    impl SteerTestAgent {
        fn new(turn_id: &str) -> Self {
            Self {
                active_turn: Mutex::new(Some(turn_id.to_string())),
                messages: Mutex::new(Vec::new()),
                lifecycle: Mutex::new(None),
            }
        }

        fn mark_drained(&self) {
            if let Some(sender) = self
                .lifecycle
                .lock()
                .unwrap_or_else(|error| error.into_inner())
                .as_ref()
            {
                let _ = sender.send(AgentSteerState::Drained);
            }
        }

        fn settle(&self, outcome: AgentSteerTurnOutcome) {
            if let Some(sender) = self
                .lifecycle
                .lock()
                .unwrap_or_else(|error| error.into_inner())
                .as_ref()
            {
                let _ = sender.send(AgentSteerState::TurnSettled {
                    outcome,
                    drained: matches!(outcome, AgentSteerTurnOutcome::Completed),
                });
            }
        }
    }

    impl Agent for SteerTestAgent {
        fn name(&self) -> &str {
            "steer-test"
        }

        fn model_name(&self) -> &str {
            "test"
        }

        fn system_prompt(&self) -> &str {
            ""
        }

        fn execute<'a>(&'a self, _task: &'a str) -> BoxFuture<'a, AgentResult<String>> {
            Box::pin(async { Ok("done".to_string()) })
        }

        fn execute_stream<'a>(
            &'a self,
            _task: &'a str,
        ) -> BoxFuture<'a, AgentResult<BoxStream<'a, AgentResult<AgentEvent>>>> {
            Box::pin(async {
                Ok(Box::pin(futures::stream::once(async {
                    Ok(AgentEvent::FinalAnswer("done".to_string()))
                }))
                    as BoxStream<'a, AgentResult<AgentEvent>>)
            })
        }

        fn steer_input(
            &self,
            expected_turn_id: Option<&str>,
            message: Message,
        ) -> Result<String, AgentSteerError> {
            let active = self
                .active_turn
                .lock()
                .map_err(|_| AgentSteerError::StateUnavailable)?;
            let actual = active.as_deref().ok_or(AgentSteerError::NoActiveTurn)?;
            if let Some(expected) = expected_turn_id
                && expected != actual
            {
                return Err(AgentSteerError::TurnMismatch {
                    expected: expected.to_string(),
                    actual: actual.to_string(),
                });
            }
            let text = message
                .content
                .as_text()
                .filter(|text| !text.trim().is_empty())
                .ok_or(AgentSteerError::EmptyInput)?;
            self.messages
                .lock()
                .map_err(|_| AgentSteerError::StateUnavailable)?
                .push(text);
            Ok(actual.to_string())
        }

        fn steer_input_tracked(
            &self,
            expected_turn_id: Option<&str>,
            message: Message,
        ) -> Result<AgentSteerReceipt, AgentSteerError> {
            let turn_id = self.steer_input(expected_turn_id, message)?;
            let (sender, receiver) = watch::channel(AgentSteerState::Accepted);
            *self
                .lifecycle
                .lock()
                .map_err(|_| AgentSteerError::StateUnavailable)? = Some(sender);
            Ok(AgentSteerReceipt::new(
                uuid::Uuid::new_v4().to_string(),
                turn_id,
                receiver,
            ))
        }
    }

    #[test]
    fn queued_guidance_is_claimed_once_by_exact_attempt() -> Result<(), SubagentControlError> {
        let registry = Arc::new(SubagentControlRegistry::default());
        let first = registry.queue_guidance("task-1", 2, "inspect the current diff")?;
        let second = registry.queue_guidance("task-1", 2, "run the focused test")?;
        assert_eq!(first.queued_count, 1);
        assert_eq!(second.queued_count, 2);

        let identity = SubagentAttemptIdentity::new("task-1", "execution-2", 2)?;
        let admission = registry.admit(identity, CancellationToken::new())?;
        assert_eq!(
            admission.guidance,
            vec![
                "inspect the current diff".to_string(),
                "run the focused test".to_string()
            ]
        );
        assert!(matches!(
            registry.queue_guidance("task-1", 2, "late"),
            Err(SubagentControlError::AttemptAlreadyStarted { .. })
        ));
        admission.settle(SubagentStatus::Completed);
        Ok(())
    }

    #[test]
    fn invalid_and_empty_inputs_are_rejected() {
        assert!(matches!(
            SubagentAttemptIdentity::new("", "execution", 1),
            Err(SubagentControlError::InvalidIdentity { field: "task_id" })
        ));
        let registry = SubagentControlRegistry::default();
        assert_eq!(
            registry.queue_guidance("task", 1, "  "),
            Err(SubagentControlError::EmptyInstruction)
        );
    }

    #[test]
    fn attempt_identity_round_trips_as_a_framework_value() -> Result<(), String> {
        let identity = SubagentAttemptIdentity::new("task-1", "execution-1", 2)
            .map_err(|error| error.to_string())?;
        let encoded = serde_json::to_value(&identity).map_err(|error| error.to_string())?;
        let decoded: SubagentAttemptIdentity =
            serde_json::from_value(encoded).map_err(|error| error.to_string())?;
        assert_eq!(decoded, identity);
        Ok(())
    }

    #[test]
    fn attempt_identity_deserialization_rejects_invalid_values() {
        let invalid = serde_json::json!({
            "task_id": "",
            "execution_id": "execution-1",
            "attempt": 0,
        });
        assert!(serde_json::from_value::<SubagentAttemptIdentity>(invalid).is_err());
        let unknown = serde_json::json!({
            "task_id": "task-1",
            "execution_id": "execution-1",
            "attempt": 1,
            "extra": true,
        });
        assert!(serde_json::from_value::<SubagentAttemptIdentity>(unknown).is_err());
    }

    #[test]
    fn command_identity_round_trips_and_exposes_the_live_attempt() -> Result<(), String> {
        let identity =
            SubagentCommandIdentity::new("run-1", "task-1", "execution-1", 3, 2, "command-1")
                .map_err(|error| error.to_string())?;
        let encoded = serde_json::to_value(&identity).map_err(|error| error.to_string())?;
        let decoded: SubagentCommandIdentity =
            serde_json::from_value(encoded).map_err(|error| error.to_string())?;
        assert_eq!(decoded, identity);
        assert_eq!(
            decoded
                .attempt_identity()
                .map_err(|error| error.to_string())?,
            SubagentAttemptIdentity::for_run("run-1", "task-1", "execution-1", 2)
                .map_err(|error| error.to_string())?
        );
        assert!(SubagentCommandIdentity::new("run-1", "task-1", "execution-1", 1, 1, "").is_err());
        Ok(())
    }

    #[test]
    fn command_phase_wire_names_round_trip() {
        for phase in [
            SubagentCommandPhase::Persisted,
            SubagentCommandPhase::MailboxAccepted,
            SubagentCommandPhase::Drained,
            SubagentCommandPhase::TurnSettled,
        ] {
            assert_eq!(SubagentCommandPhase::parse(phase.as_str()), Some(phase));
        }
        assert_eq!(SubagentCommandPhase::parse("unknown"), None);
    }

    #[tokio::test]
    async fn live_message_is_exact_attempt_and_never_crosses_settlement() -> Result<(), String> {
        let registry = Arc::new(SubagentControlRegistry::default());
        let identity = SubagentAttemptIdentity::new("task", "execution-1", 1)
            .map_err(|error| error.to_string())?;
        let admission = registry
            .admit(identity.clone(), CancellationToken::new())
            .map_err(|error| error.to_string())?;
        let concrete = Arc::new(SteerTestAgent::new("turn-1"));
        let agent: Arc<dyn Agent> = concrete.clone();
        let steering = admission
            .binding
            .attach(agent, "turn-1".to_string())
            .map_err(|error| error.to_string())?;

        let mut delivered = registry
            .send_message_tracked("execution-1", 1, "first")
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(delivered.receipt().turn_id(), "turn-1");
        assert_eq!(delivered.receipt().state(), AgentSteerState::Accepted);
        concrete.mark_drained();
        assert_eq!(delivered.wait_for_drained().await, AgentSteerState::Drained);
        assert!(matches!(
            registry
                .send_message_tracked("execution-1", 2, "stale")
                .await,
            Err(SubagentControlError::AttemptMismatch { .. })
        ));
        let messages = concrete
            .messages
            .lock()
            .map_err(|_| "message state unavailable".to_string())?
            .clone();
        assert_eq!(messages, vec!["first".to_string()]);

        concrete.settle(AgentSteerTurnOutcome::Completed);
        assert_eq!(
            delivered.wait_for_turn_settled().await,
            AgentSteerState::TurnSettled {
                outcome: AgentSteerTurnOutcome::Completed,
                drained: true,
            }
        );
        drop(steering);
        admission.settle(SubagentStatus::Completed);
        assert!(matches!(
            registry
                .send_message_tracked("execution-1", 1, "late")
                .await,
            Err(SubagentControlError::AttemptSettled { .. })
        ));
        assert_eq!(
            concrete
                .messages
                .lock()
                .map_err(|_| "message state unavailable".to_string())?
                .as_slice(),
            ["first".to_string()]
        );
        Ok(())
    }

    #[tokio::test]
    async fn live_message_waits_for_existing_attempt_safe_point() -> Result<(), String> {
        let registry = Arc::new(SubagentControlRegistry::default());
        let identity = SubagentAttemptIdentity::new("task", "execution-starting", 1)
            .map_err(|error| error.to_string())?;
        let admission = registry
            .admit(identity, CancellationToken::new())
            .map_err(|error| error.to_string())?;

        let delivery = registry.send_message_tracked("execution-starting", 1, "wait for ready");
        futures::pin_mut!(delivery);
        assert!(matches!(
            futures::poll!(delivery.as_mut()),
            std::task::Poll::Pending
        ));

        let concrete = Arc::new(SteerTestAgent::new("turn-starting"));
        let agent: Arc<dyn Agent> = concrete.clone();
        let steering = admission
            .binding
            .attach(agent, "turn-starting".to_string())
            .map_err(|error| error.to_string())?;
        let mut delivered = delivery.await.map_err(|error| error.to_string())?;
        assert_eq!(delivered.receipt().turn_id(), "turn-starting");
        concrete.mark_drained();
        assert_eq!(delivered.wait_for_drained().await, AgentSteerState::Drained);
        assert_eq!(
            concrete
                .messages
                .lock()
                .map_err(|_| "message state unavailable".to_string())?
                .as_slice(),
            ["wait for ready".to_string()]
        );
        concrete.settle(AgentSteerTurnOutcome::Completed);
        drop(steering);
        admission.settle(SubagentStatus::Completed);
        Ok(())
    }

    #[tokio::test]
    async fn interrupt_waits_for_exact_attempt_settlement() -> Result<(), String> {
        let registry = Arc::new(SubagentControlRegistry::default());
        let cancel = CancellationToken::new();
        let identity = SubagentAttemptIdentity::new("task", "execution-1", 1)
            .map_err(|error| error.to_string())?;
        let admission = registry
            .admit(identity, cancel.clone())
            .map_err(|error| error.to_string())?;
        let interrupt_registry = registry.clone();
        let interrupt =
            tokio::spawn(async move { interrupt_registry.interrupt("execution-1", 1).await });

        cancel.cancelled().await;
        admission.settle(SubagentStatus::Cancelled);
        let outcome = interrupt
            .await
            .map_err(|error| error.to_string())?
            .map_err(|error| error.to_string())?;
        assert!(outcome.requested);
        assert!(outcome.settled);
        assert_eq!(outcome.previous_status, SubagentControlPhase::Starting);
        assert_eq!(outcome.terminal_status, Some(SubagentStatus::Cancelled));

        let replay = registry
            .interrupt("execution-1", 1)
            .await
            .map_err(|error| error.to_string())?;
        assert!(!replay.requested);
        assert!(replay.settled);
        assert_eq!(replay.previous_status, SubagentControlPhase::Settled);
        Ok(())
    }

    #[tokio::test]
    async fn pending_interrupt_is_consumed_by_exact_admission() -> Result<(), String> {
        let registry = Arc::new(SubagentControlRegistry::default());
        let identity = SubagentAttemptIdentity::new("task", "execution-pending", 2)
            .map_err(|error| error.to_string())?;
        let receipt = registry
            .request_interrupt(identity.clone())
            .map_err(|error| error.to_string())?;
        assert_eq!(
            receipt.disposition,
            SubagentInterruptRequestDisposition::QueuedBeforeAdmission
        );
        let cancel = CancellationToken::new();
        let admission = registry
            .admit(identity.clone(), cancel.clone())
            .map_err(|error| error.to_string())?;
        assert!(cancel.is_cancelled());
        admission.settle(SubagentStatus::Cancelled);
        assert!(
            registry
                .retire_exact(&identity)
                .is_ok_and(|retired| retired)
        );
        assert!(
            registry
                .retire_exact(&identity)
                .is_ok_and(|retired| !retired)
        );
        Ok(())
    }

    #[test]
    fn reserved_attempt_is_consumed_by_dispatch_admission() -> Result<(), String> {
        let registry = Arc::new(SubagentControlRegistry::default());
        let identity = SubagentAttemptIdentity::new("task-reserved", "execution-reserved", 1)
            .map_err(|error| error.to_string())?;
        let cancel = CancellationToken::new();
        registry
            .reserve(identity.clone(), cancel.clone())
            .map_err(|error| error.to_string())?;

        let admission = registry
            .admit(identity.clone(), CancellationToken::new())
            .map_err(|error| error.to_string())?;
        assert!(!admission.cancel.is_cancelled());
        admission.settle(SubagentStatus::Completed);
        assert!(matches!(
            registry
                .request_interrupt(identity)
                .map_err(|error| error.to_string())?
                .disposition,
            SubagentInterruptRequestDisposition::AlreadySettled(SubagentStatus::Completed)
        ));
        Ok(())
    }

    #[test]
    fn reserved_interrupt_drops_as_cancelled_not_failed() -> Result<(), String> {
        let registry = Arc::new(SubagentControlRegistry::default());
        let identity = SubagentAttemptIdentity::new("task-reserved", "execution-cancelled", 1)
            .map_err(|error| error.to_string())?;
        let cancel = CancellationToken::new();
        registry
            .reserve(identity.clone(), cancel.clone())
            .map_err(|error| error.to_string())?;

        let receipt = registry
            .request_interrupt(identity.clone())
            .map_err(|error| error.to_string())?;
        assert_eq!(
            receipt.disposition,
            SubagentInterruptRequestDisposition::ReservedRequested
        );
        assert!(cancel.is_cancelled());
        let admission = registry
            .admit(identity.clone(), CancellationToken::new())
            .map_err(|error| error.to_string())?;
        drop(admission);
        assert!(matches!(
            registry
                .request_interrupt(identity)
                .map_err(|error| error.to_string())?
                .disposition,
            SubagentInterruptRequestDisposition::AlreadySettled(SubagentStatus::Cancelled)
        ));
        Ok(())
    }

    #[test]
    fn exact_attempt_control_rejects_cross_scope_identity() -> Result<(), String> {
        let registry = Arc::new(SubagentControlRegistry::default());
        let expected =
            SubagentAttemptIdentity::for_runtime_scope("scope-a", "run", "task", "execution", 1)
                .map_err(|error| error.to_string())?;
        let wrong_scope =
            SubagentAttemptIdentity::for_runtime_scope("scope-b", "run", "task", "execution", 1)
                .map_err(|error| error.to_string())?;
        let cancel = CancellationToken::new();
        registry
            .reserve(expected.clone(), cancel.clone())
            .map_err(|error| error.to_string())?;

        for result in [
            registry.reserve(wrong_scope.clone(), CancellationToken::new()),
            registry
                .admit(wrong_scope.clone(), CancellationToken::new())
                .map(|_| ()),
            registry.request_interrupt(wrong_scope.clone()).map(|_| ()),
            registry.retire_exact(&wrong_scope).map(|_| ()),
        ] {
            assert!(matches!(
                result,
                Err(SubagentControlError::AttemptIdentityMismatch {
                    field: "control_scope_id",
                    ..
                })
            ));
        }
        assert!(!cancel.is_cancelled());
        let admission = registry
            .admit(expected.clone(), CancellationToken::new())
            .map_err(|error| error.to_string())?;
        admission.settle(SubagentStatus::Completed);
        assert!(matches!(
            registry.request_interrupt(wrong_scope),
            Err(SubagentControlError::AttemptIdentityMismatch {
                field: "control_scope_id",
                ..
            })
        ));
        assert!(matches!(
            registry
                .request_interrupt(expected)
                .map_err(|error| error.to_string())?
                .disposition,
            SubagentInterruptRequestDisposition::AlreadySettled(SubagentStatus::Completed)
        ));
        Ok(())
    }

    #[test]
    fn reconciliation_isolates_runs_within_one_control_scope() -> Result<(), String> {
        let registry = Arc::new(SubagentControlRegistry::default());
        let run_a = SubagentAttemptIdentity::for_runtime_scope(
            "shared-scope",
            "run-a",
            "task",
            "execution-a",
            1,
        )
        .map_err(|error| error.to_string())?;
        let run_b = SubagentAttemptIdentity::for_runtime_scope(
            "shared-scope",
            "run-b",
            "task",
            "execution-b",
            1,
        )
        .map_err(|error| error.to_string())?;
        let cancel_a = CancellationToken::new();
        let cancel_b = CancellationToken::new();
        registry
            .reserve(run_a, cancel_a.clone())
            .map_err(|error| error.to_string())?;
        registry
            .reserve(run_b, cancel_b.clone())
            .map_err(|error| error.to_string())?;

        registry
            .reconcile_scope("shared-scope", "run-a", &HashSet::new())
            .map_err(|error| error.to_string())?;
        assert!(cancel_a.is_cancelled());
        assert!(!cancel_b.is_cancelled());
        Ok(())
    }

    #[test]
    fn reconciliation_retires_stale_pending_and_settled_and_cancels_active() -> Result<(), String> {
        let registry = Arc::new(SubagentControlRegistry::default());
        let pending = SubagentAttemptIdentity::for_run("run-a", "pending", "execution-pending", 1)
            .map_err(|error| error.to_string())?;
        registry
            .request_interrupt(pending.clone())
            .map_err(|error| error.to_string())?;

        let active = SubagentAttemptIdentity::for_run("run-a", "active", "execution-active", 1)
            .map_err(|error| error.to_string())?;
        let active_cancel = CancellationToken::new();
        registry
            .reserve(active.clone(), active_cancel.clone())
            .map_err(|error| error.to_string())?;

        let settled = SubagentAttemptIdentity::for_run("run-a", "settled", "execution-settled", 1)
            .map_err(|error| error.to_string())?;
        registry
            .admit(settled.clone(), CancellationToken::new())
            .map_err(|error| error.to_string())?
            .settle(SubagentStatus::Completed);

        let other_run =
            SubagentAttemptIdentity::for_run("run-b", "active", "execution-other-run", 1)
                .map_err(|error| error.to_string())?;
        let other_cancel = CancellationToken::new();
        registry
            .reserve(other_run.clone(), other_cancel.clone())
            .map_err(|error| error.to_string())?;
        let direct = SubagentAttemptIdentity::new("active", "execution-direct", 1)
            .map_err(|error| error.to_string())?;
        let direct_cancel = CancellationToken::new();
        registry
            .reserve(direct.clone(), direct_cancel.clone())
            .map_err(|error| error.to_string())?;
        let parent_scope = SubagentAttemptIdentity::for_runtime_scope(
            "parent-scope",
            "run-a",
            "active",
            "execution-parent-scope",
            1,
        )
        .map_err(|error| error.to_string())?;
        let parent_cancel = CancellationToken::new();
        registry
            .reserve(parent_scope.clone(), parent_cancel.clone())
            .map_err(|error| error.to_string())?;

        registry
            .reconcile_scope("run-a", "run-a", &HashSet::new())
            .map_err(|error| error.to_string())?;
        assert!(active_cancel.is_cancelled());
        assert!(!other_cancel.is_cancelled());
        assert!(!direct_cancel.is_cancelled());
        assert!(!parent_cancel.is_cancelled());
        assert_eq!(
            registry
                .request_interrupt(pending)
                .map_err(|error| error.to_string())?
                .disposition,
            SubagentInterruptRequestDisposition::QueuedBeforeAdmission
        );
        assert_eq!(
            registry
                .request_interrupt(settled)
                .map_err(|error| error.to_string())?
                .disposition,
            SubagentInterruptRequestDisposition::QueuedBeforeAdmission
        );
        let admission = registry
            .admit(active.clone(), CancellationToken::new())
            .map_err(|error| error.to_string())?;
        assert!(admission.cancel.is_cancelled());
        drop(admission);
        assert!(matches!(
            registry
                .request_interrupt(active)
                .map_err(|error| error.to_string())?
                .disposition,
            SubagentInterruptRequestDisposition::AlreadySettled(SubagentStatus::Cancelled)
        ));
        Ok(())
    }
}
