//! Subagent registry — discovery, registration, and lifecycle management
//!
//! Owns declarative definitions, lazy factories, and lifecycle events for
//! registered Subagents.

use crate::error::Result;
use echo_core::agent::Agent;
use futures::future::BoxFuture;
use std::collections::HashMap;
use std::sync::Arc;
use std::sync::atomic::{AtomicU64, Ordering};
use tokio::sync::{OnceCell, RwLock};
use tracing::{debug, info, warn};

use super::events::SubagentEventBus;
use super::types::{RegisteredSubagent, SubagentDefinition};

struct RegistryEntry {
    definition: SubagentDefinition,
    agent: Arc<OnceCell<Arc<dyn Agent>>>,
    factory: Option<Arc<dyn AgentFactory>>,
    revision: u64,
}

#[derive(Default)]
struct RegistryState {
    entries: HashMap<String, RegistryEntry>,
    next_revision: u64,
}

#[cfg(test)]
#[derive(Clone)]
struct FactoryPublicationPause {
    reached: Arc<tokio::sync::Semaphore>,
    resume: Arc<tokio::sync::Semaphore>,
}

impl RegistryState {
    fn next_revision(&mut self) -> u64 {
        self.next_revision = self.next_revision.saturating_add(1);
        self.next_revision
    }
}

// ── Agent Factory ─────────────────────────────────────────────────────────────

/// Factory trait for lazy agent instantiation.
///
/// Used when you want to register an agent definition but defer
/// the actual agent construction until it's first dispatched.
pub trait AgentFactory: Send + Sync {
    /// Create an agent instance asynchronously.
    ///
    /// A factory must not recursively resolve its own registration through
    /// [`SubagentRegistry::get_agent`]; async single initialization cannot
    /// complete while waiting for itself. Callers own any required deadline.
    ///
    /// # Returns
    /// A boxed future that resolves to a `Result<Box<dyn Agent>>`.
    fn create(&self) -> BoxFuture<'static, Result<Box<dyn Agent>>>;
}

/// Type-erased closure wrapper for `AgentFactory`.
pub struct FnAgentFactory<F>
where
    F: Fn() -> BoxFuture<'static, Result<Box<dyn Agent>>> + Send + Sync,
{
    f: F,
}

impl<F> FnAgentFactory<F>
where
    F: Fn() -> BoxFuture<'static, Result<Box<dyn Agent>>> + Send + Sync,
{
    /// Create a new function-based agent factory.
    ///
    /// # Parameters
    /// * `f` - Async closure that creates an agent when invoked.
    pub fn new(f: F) -> Self {
        Self { f }
    }
}

impl<F> AgentFactory for FnAgentFactory<F>
where
    F: Fn() -> BoxFuture<'static, Result<Box<dyn Agent>>> + Send + Sync,
{
    fn create(&self) -> BoxFuture<'static, Result<Box<dyn Agent>>> {
        (self.f)()
    }
}

// ── Subagent Registry ─────────────────────────────────────────────────────────

/// Registry for subagent definitions and instances.
///
/// Owns the registered Subagent definitions and adds:
/// - Definition-based lookup
/// - Factory support for lazy instantiation
/// - Lifecycle events
pub struct SubagentRegistry {
    /// One atomic record per name keeps definition and executable generation aligned.
    state: Arc<RwLock<RegistryState>>,
    executable_catalog: Arc<std::sync::RwLock<Vec<SubagentDefinition>>>,
    catalog_revision: Arc<AtomicU64>,
    #[cfg(test)]
    factory_publication_pause: Arc<RwLock<Option<FactoryPublicationPause>>>,
    /// Event bus for lifecycle events.
    event_bus: SubagentEventBus,
    /// Shared process-level execution control for dispatched attempts.
    ///
    /// One registry owns exactly one control plane so an `execution_id` is
    /// addressable across every `SubagentExecutor` built on this registry —
    /// without this, each executor would keep a private control registry and
    /// sibling attempts dispatched by different executors could not see each
    /// other (Subagent↔Subagent messaging and the default uplink both rely
    /// on this unified lookup).
    control: Arc<super::control::SubagentControlRegistry>,
}

impl SubagentRegistry {
    /// Create an empty registry.
    pub fn new() -> Self {
        Self {
            state: Arc::new(RwLock::new(RegistryState::default())),
            executable_catalog: Arc::new(std::sync::RwLock::new(Vec::new())),
            catalog_revision: Arc::new(AtomicU64::new(0)),
            #[cfg(test)]
            factory_publication_pause: Arc::new(RwLock::new(None)),
            event_bus: SubagentEventBus::new(),
            control: Arc::new(super::control::SubagentControlRegistry::default()),
        }
    }

    /// Create with a specific event bus.
    pub fn with_event_bus(event_bus: SubagentEventBus) -> Self {
        Self {
            state: Arc::new(RwLock::new(RegistryState::default())),
            executable_catalog: Arc::new(std::sync::RwLock::new(Vec::new())),
            catalog_revision: Arc::new(AtomicU64::new(0)),
            #[cfg(test)]
            factory_publication_pause: Arc::new(RwLock::new(None)),
            event_bus,
            control: Arc::new(super::control::SubagentControlRegistry::default()),
        }
    }

    /// Shared execution-control plane for all executors on this registry.
    pub fn control_registry(&self) -> &Arc<super::control::SubagentControlRegistry> {
        &self.control
    }

    fn publish_catalog(&self, state: &RegistryState) {
        let mut definitions = state
            .entries
            .values()
            .filter(|entry| entry.agent.get().is_some() || entry.factory.is_some())
            .map(|entry| entry.definition.clone())
            .collect::<Vec<_>>();
        definitions.sort_by(|left, right| left.name.cmp(&right.name));
        *self
            .executable_catalog
            .write()
            .unwrap_or_else(|error| error.into_inner()) = definitions;
        self.catalog_revision.fetch_add(1, Ordering::Release);
    }

    pub(crate) fn executable_catalog_handle(
        &self,
    ) -> Arc<std::sync::RwLock<Vec<SubagentDefinition>>> {
        Arc::clone(&self.executable_catalog)
    }

    pub(crate) fn catalog_revision_handle(&self) -> Arc<AtomicU64> {
        Arc::clone(&self.catalog_revision)
    }

    #[cfg(test)]
    async fn pause_before_factory_publication(&self) {
        let pause = self.factory_publication_pause.read().await.clone();
        if let Some(pause) = pause {
            pause.reached.add_permits(1);
            if let Ok(permit) = pause.resume.acquire().await {
                permit.forget();
            }
        }
    }

    // ── Registration ──────────────────────────────────────────────────────

    /// Register a pre-built agent with its definition.
    pub async fn register(&self, def: SubagentDefinition, agent: Box<dyn Agent>) {
        self.register_shared(def, Arc::from(agent)).await;
    }

    /// Register a shared pre-built Agent without wrapping it in a second
    /// execution container. This is the programmatic composition path used by
    /// Team and agents-as-tools style integrations.
    pub async fn register_shared(&self, def: SubagentDefinition, agent: Arc<dyn Agent>) {
        let name = def.name.clone();
        info!(subagent = %name, mode = %def.execution_mode, "Registering subagent");

        let mut state = self.state.write().await;
        let revision = state.next_revision();
        state.entries.insert(
            name.clone(),
            RegistryEntry {
                definition: def,
                agent: Arc::new(OnceCell::new_with(Some(agent))),
                factory: None,
                revision,
            },
        );
        self.publish_catalog(&state);
        drop(state);

        self.event_bus
            .emit(super::events::SubagentEvent::Registered { name: name.clone() });
    }

    /// Sync registration — uses `try_write` to avoid `block_on` deadlock.
    ///
    /// Use this from synchronous contexts (e.g., builder pattern, `main()`).
    /// Falls back to logging a warning if locks are contended.
    pub fn register_sync(&self, def: SubagentDefinition, agent: Box<dyn Agent>) -> bool {
        self.register_shared_sync(def, Arc::from(agent))
    }

    /// Synchronous counterpart to [`register_shared`](Self::register_shared).
    /// Returns `false` rather than blocking when the registry is contended.
    pub fn register_shared_sync(&self, def: SubagentDefinition, agent: Arc<dyn Agent>) -> bool {
        let name = def.name.clone();

        let ok = match self.state.try_write() {
            Ok(mut state) => {
                let revision = state.next_revision();
                state.entries.insert(
                    name.clone(),
                    RegistryEntry {
                        definition: def,
                        agent: Arc::new(OnceCell::new_with(Some(agent))),
                        factory: None,
                        revision,
                    },
                );
                self.publish_catalog(&state);
                true
            }
            Err(_) => {
                warn!(subagent = %name, "Lock contention on subagent registry, registration deferred");
                false
            }
        };

        if ok {
            self.event_bus
                .emit(super::events::SubagentEvent::Registered { name });
        }

        ok
    }

    /// Register a definition with a factory for lazy instantiation.
    pub async fn register_factory(&self, def: SubagentDefinition, factory: Arc<dyn AgentFactory>) {
        let name = def.name.clone();
        debug!(subagent = %name, "Registering subagent factory");

        let mut state = self.state.write().await;
        let revision = state.next_revision();
        state.entries.insert(
            name,
            RegistryEntry {
                definition: def,
                agent: Arc::new(OnceCell::new()),
                factory: Some(factory),
                revision,
            },
        );
        self.publish_catalog(&state);
    }

    /// Register a **definition only** — no agent instance and no factory.
    ///
    /// This is a low-level late-binding path: `get` and `contains` can inspect
    /// the pending definition, but `list_available`, `list_by_tag`, `agent_names`,
    /// and the model-facing dispatch catalog include only definitions backed
    /// by an instance or factory. A later call to
    /// [`register`](Self::register) / [`register_sync`](Self::register_sync)
    /// / [`register_factory`](Self::register_factory) under the same name
    /// supplies (or lazily produces) the instance, overwriting the definition.
    ///
    /// Explicit programmatic dispatch before hydration fails because there is
    /// no agent to run. The model-facing catalog does not offer that target.
    ///
    /// Returns `true` if inserted (always, under uncontended locks).
    pub async fn register_definition(&self, def: SubagentDefinition) -> bool {
        let name = def.name.clone();
        debug!(subagent = %name, "Registering subagent definition (no instance)");
        let mut state = self.state.write().await;
        let revision = state.next_revision();
        state.entries.insert(
            name,
            RegistryEntry {
                definition: def,
                agent: Arc::new(OnceCell::new()),
                factory: None,
                revision,
            },
        );
        self.publish_catalog(&state);
        true
    }

    /// Sync variant of [`register_definition`](Self::register_definition).
    ///
    /// Uses `try_write` to avoid `block_on` deadlock from synchronous
    /// contexts that cannot await this registry.
    /// Logs a warning and returns `false` on lock contention.
    pub fn register_definition_sync(&self, def: SubagentDefinition) -> bool {
        let name = def.name.clone();
        match self.state.try_write() {
            Ok(mut state) => {
                let revision = state.next_revision();
                state.entries.insert(
                    name,
                    RegistryEntry {
                        definition: def,
                        agent: Arc::new(OnceCell::new()),
                        factory: None,
                        revision,
                    },
                );
                self.publish_catalog(&state);
                true
            }
            Err(error) => {
                warn!(subagent = %name, %error, "Cannot register subagent definition");
                false
            }
        }
    }

    /// Register a definition factory while constructing an agent synchronously.
    pub fn register_factory_sync(
        &self,
        def: SubagentDefinition,
        factory: Arc<dyn AgentFactory>,
    ) -> bool {
        let name = def.name.clone();
        let mut state = match self.state.try_write() {
            Ok(state) => state,
            Err(error) => {
                warn!(subagent = %name, %error, "Cannot register subagent definition");
                return false;
            }
        };

        let revision = state.next_revision();
        state.entries.insert(
            name,
            RegistryEntry {
                definition: def,
                agent: Arc::new(OnceCell::new()),
                factory: Some(factory),
                revision,
            },
        );
        self.publish_catalog(&state);
        true
    }

    /// Remove a subagent by name.
    pub async fn remove(&self, name: &str) {
        let mut state = self.state.write().await;
        state.entries.remove(name);
        self.publish_catalog(&state);
        drop(state);

        self.event_bus
            .emit(super::events::SubagentEvent::Unregistered {
                name: name.to_string(),
            });
    }

    // ── Lookup ────────────────────────────────────────────────────────────

    /// Look up a registered subagent. Returns None if not found.
    pub async fn get(&self, name: &str) -> Option<RegisteredSubagent> {
        let state = self.state.read().await;
        let entry = state.entries.get(name)?;

        Some(RegisteredSubagent {
            definition: entry.definition.clone(),
            has_instance: entry.agent.get().is_some(),
        })
    }

    /// Get the agent instance for immediate execution.
    ///
    /// If the agent was registered via factory and not yet instantiated,
    /// this will create it on demand.
    ///
    /// Concurrent callers share one cancellation-safe initialization attempt
    /// for the current registration revision. Callers own any deadline around
    /// this operation; the registry does not impose a construction timeout.
    pub async fn get_agent(&self, name: &str) -> Option<Arc<dyn Agent>> {
        let (agent_cell, factory, factory_revision) = {
            let state = self.state.read().await;
            let entry = state.entries.get(name)?;
            if let Some(agent) = entry.agent.get() {
                return Some(Arc::clone(agent));
            }
            (
                Arc::clone(&entry.agent),
                entry.factory.clone()?,
                entry.revision,
            )
        };

        let result = agent_cell
            .get_or_try_init(|| async {
                info!(subagent = %name, "Instantiating agent from factory");
                factory.create().await.map(Arc::<dyn Agent>::from)
            })
            .await;

        #[cfg(test)]
        self.pause_before_factory_publication().await;

        match result {
            Ok(agent) => {
                let agent = Arc::clone(agent);
                let state = self.state.read().await;
                let entry = state.entries.get(name)?;
                if entry.revision != factory_revision || !Arc::ptr_eq(&entry.agent, &agent_cell) {
                    warn!(subagent = %name, "Discarding stale subagent factory result");
                    return entry.agent.get().cloned();
                }
                Some(agent)
            }
            Err(error) => {
                warn!(subagent = %name, error = %error, "Factory instantiation failed");
                None
            }
        }
    }

    /// Create a fresh agent when a factory is registered for `name`.
    ///
    /// Unlike `get_agent`, this never updates or reuses the cached agent.
    pub async fn create_fresh_agent(&self, name: &str) -> Result<Option<Arc<dyn Agent>>> {
        let factory = {
            let state = self.state.read().await;
            state
                .entries
                .get(name)
                .and_then(|entry| entry.factory.clone())
        };

        match factory {
            Some(factory) => factory
                .create()
                .await
                .map(|agent| Some(Arc::new(agent) as Arc<dyn Agent>)),
            None => Ok(None),
        }
    }

    /// Check if a subagent is registered.
    pub async fn contains(&self, name: &str) -> bool {
        self.state.read().await.entries.contains_key(name)
    }

    /// List definitions backed by a pre-built instance or a factory.
    pub async fn list_available(&self) -> Vec<SubagentDefinition> {
        let state = self.state.read().await;
        state
            .entries
            .values()
            .filter(|entry| entry.agent.get().is_some() || entry.factory.is_some())
            .map(|entry| entry.definition.clone())
            .collect()
    }

    /// List executable definitions matching a tag.
    pub async fn list_by_tag(&self, tag: &str) -> Vec<SubagentDefinition> {
        let state = self.state.read().await;
        state
            .entries
            .values()
            .filter(|entry| entry.agent.get().is_some() || entry.factory.is_some())
            .map(|entry| &entry.definition)
            .filter(|definition| definition.tags.iter().any(|entry_tag| entry_tag == tag))
            .cloned()
            .collect()
    }

    /// Get executable agent names for tool descriptions (convenience).
    pub async fn agent_names(&self) -> Vec<String> {
        let state = self.state.read().await;
        state
            .entries
            .iter()
            .filter(|(_, entry)| entry.agent.get().is_some() || entry.factory.is_some())
            .map(|(name, _)| name.clone())
            .collect()
    }

    /// Get the event bus reference.
    pub fn event_bus(&self) -> &SubagentEventBus {
        &self.event_bus
    }
}

impl Default for SubagentRegistry {
    fn default() -> Self {
        Self::new()
    }
}

impl Clone for SubagentRegistry {
    fn clone(&self) -> Self {
        Self {
            state: self.state.clone(),
            executable_catalog: self.executable_catalog.clone(),
            catalog_revision: self.catalog_revision.clone(),
            #[cfg(test)]
            factory_publication_pause: self.factory_publication_pause.clone(),
            event_bus: self.event_bus.clone(),
            control: self.control.clone(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::testing::MockAgent;

    #[tokio::test]
    async fn test_register_and_get() {
        let registry = SubagentRegistry::new();
        let agent = MockAgent::new("researcher");
        let def = SubagentDefinition::new("researcher", "Researches topics");

        registry.register(def, Box::new(agent)).await;

        assert!(registry.contains("researcher").await);
        let registered = registry.get("researcher").await.unwrap();
        assert_eq!(registered.definition.name, "researcher");
        assert!(registered.has_instance);
    }

    #[tokio::test]
    async fn shared_registration_preserves_agent_identity() -> Result<()> {
        let registry = SubagentRegistry::new();
        let shared: Arc<dyn Agent> = Arc::new(MockAgent::new("shared"));
        registry
            .register_shared(
                SubagentDefinition::new("shared", "Shared programmatic Agent"),
                shared.clone(),
            )
            .await;

        let resolved = registry.get_agent("shared").await.ok_or_else(|| {
            crate::error::ReactError::Other("shared Agent was not registered".to_string())
        })?;
        assert!(Arc::ptr_eq(&shared, &resolved));
        Ok(())
    }

    #[tokio::test]
    async fn test_remove() {
        let registry = SubagentRegistry::new();
        let agent = MockAgent::new("subagent");
        let def = SubagentDefinition::new("subagent", "Subagent agent");

        registry.register(def, Box::new(agent)).await;
        assert!(registry.contains("subagent").await);

        registry.remove("subagent").await;
        assert!(!registry.contains("subagent").await);
    }

    #[tokio::test]
    async fn test_list_available() {
        let registry = SubagentRegistry::new();

        let a1 = MockAgent::new("a1");
        let a2 = MockAgent::new("a2");

        registry
            .register(SubagentDefinition::new("a1", "Agent 1"), Box::new(a1))
            .await;
        registry
            .register(SubagentDefinition::new("a2", "Agent 2"), Box::new(a2))
            .await;

        let available = registry.list_available().await;
        assert_eq!(available.len(), 2);
    }

    #[tokio::test]
    async fn test_list_by_tag() {
        let registry = SubagentRegistry::new();

        let mut def1 = SubagentDefinition::new("researcher", "Research");
        def1.tags.push("research".into());
        let mut def2 = SubagentDefinition::new("writer", "Write");
        def2.tags.push("writing".into());

        registry
            .register(def1, Box::new(MockAgent::new("researcher")))
            .await;
        registry
            .register(def2, Box::new(MockAgent::new("writer")))
            .await;

        let research = registry.list_by_tag("research").await;
        assert_eq!(research.len(), 1);
        assert_eq!(research[0].name, "researcher");
    }

    #[tokio::test]
    async fn test_get_agent() {
        let registry = SubagentRegistry::new();
        let agent = MockAgent::new("a");
        registry
            .register(SubagentDefinition::new("a", "A"), Box::new(agent))
            .await;

        let handle = registry.get_agent("a").await;
        assert!(handle.is_some());
    }

    #[tokio::test]
    async fn test_agent_names() {
        let registry = SubagentRegistry::new();
        assert!(registry.agent_names().await.is_empty());

        registry
            .register(
                SubagentDefinition::new("x", "X"),
                Box::new(MockAgent::new("x")),
            )
            .await;

        let names = registry.agent_names().await;
        assert_eq!(names, vec!["x"]);
    }

    #[tokio::test]
    async fn test_register_definition_only_is_not_advertised_as_executable() {
        let registry = SubagentRegistry::new();
        let mut def = SubagentDefinition::new("plugin_agent", "Plugin-defined agent");
        def.tags.push("plugin".to_string());

        let inserted = registry.register_definition(def).await;
        assert!(inserted);

        assert!(registry.contains("plugin_agent").await);
        let available = registry.list_available().await;
        assert!(!available.iter().any(|d| d.name == "plugin_agent"));
        assert!(registry.list_by_tag("plugin").await.is_empty());
        assert!(registry.agent_names().await.is_empty());
        assert!(
            registry
                .executable_catalog_handle()
                .read()
                .is_ok_and(|catalog| catalog.is_empty())
        );

        // No instance: get_agent must return None (no factory to invoke).
        let registered = registry.get("plugin_agent").await.unwrap();
        assert!(!registered.has_instance);
        assert!(registry.get_agent("plugin_agent").await.is_none());
    }

    #[tokio::test]
    async fn test_register_definition_then_promote_to_instance() {
        // A later register() under the same name supplies the instance,
        // overwriting the definition — this is how the application layer
        // hydrates a plugin-discovered definition with a real agent.
        let registry = SubagentRegistry::new();
        registry
            .register_definition(SubagentDefinition::new("hydrated", "H"))
            .await;
        assert!(!registry.get("hydrated").await.unwrap().has_instance);

        registry
            .register(
                SubagentDefinition::new("hydrated", "Hydrated"),
                Box::new(MockAgent::new("hydrated")),
            )
            .await;

        let registered = registry.get("hydrated").await.unwrap();
        assert!(registered.has_instance);
        assert_eq!(registered.definition.description, "Hydrated");
    }

    #[test]
    fn test_register_definition_sync_inserts_under_uncontended_locks() {
        let registry = SubagentRegistry::new();
        let inserted = registry.register_definition_sync(SubagentDefinition::new("sync", "S"));
        assert!(inserted);
        let state = registry.state.try_read().ok();
        assert!(
            state
                .as_ref()
                .is_some_and(|state| state.entries.contains_key("sync"))
        );
    }

    #[tokio::test]
    async fn cancelled_factory_attempt_allows_next_resolution() -> Result<()> {
        let registry = SubagentRegistry::new();
        let attempts = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let (started_tx, mut started_rx) = tokio::sync::mpsc::unbounded_channel();
        let factory_attempts = Arc::clone(&attempts);
        let factory = Arc::new(FnAgentFactory::new(move || {
            let attempt = factory_attempts.fetch_add(1, Ordering::SeqCst) + 1;
            let _ = started_tx.send(attempt);
            Box::pin(async move {
                if attempt == 1 {
                    std::future::pending::<()>().await;
                }
                Ok(Box::new(MockAgent::new("cancel-safe")) as Box<dyn Agent>)
            })
        }));
        registry
            .register_factory(
                SubagentDefinition::new("cancel-safe", "Cancellation-safe factory"),
                factory,
            )
            .await;

        let first_registry = registry.clone();
        let first = tokio::spawn(async move { first_registry.get_agent("cancel-safe").await });
        let first_attempt =
            tokio::time::timeout(std::time::Duration::from_secs(1), started_rx.recv())
                .await
                .map_err(|_| {
                    crate::error::ReactError::Other(
                        "first factory attempt did not start".to_string(),
                    )
                })?
                .ok_or_else(|| {
                    crate::error::ReactError::Other("factory start channel closed".to_string())
                })?;
        assert_eq!(first_attempt, 1);
        first.abort();
        let join_error = first.await.err().ok_or_else(|| {
            crate::error::ReactError::Other("cancelled factory task completed".to_string())
        })?;
        assert!(join_error.is_cancelled());

        let second = tokio::time::timeout(
            std::time::Duration::from_millis(250),
            registry.get_agent("cancel-safe"),
        )
        .await
        .map_err(|_| {
            crate::error::ReactError::Other(
                "cancelled factory attempt retained single-flight ownership".to_string(),
            )
        })?
        .ok_or_else(|| {
            crate::error::ReactError::Other("second factory attempt returned no agent".to_string())
        })?;
        assert_eq!(second.name(), "cancel-safe");
        assert_eq!(attempts.load(Ordering::SeqCst), 2);
        Ok(())
    }

    #[tokio::test]
    async fn factory_result_is_published_before_another_creation_can_start() -> Result<()> {
        let registry = SubagentRegistry::new();
        let attempts = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let (started_tx, mut started_rx) = tokio::sync::mpsc::unbounded_channel();
        let factory_attempts = Arc::clone(&attempts);
        let factory = Arc::new(FnAgentFactory::new(move || {
            let attempt = factory_attempts.fetch_add(1, Ordering::SeqCst) + 1;
            let _ = started_tx.send(attempt);
            Box::pin(async move { Ok(Box::new(MockAgent::new("single-flight")) as Box<dyn Agent>) })
        }));
        let publication_reached = Arc::new(tokio::sync::Semaphore::new(0));
        let publication_resume = Arc::new(tokio::sync::Semaphore::new(0));
        *registry.factory_publication_pause.write().await = Some(FactoryPublicationPause {
            reached: Arc::clone(&publication_reached),
            resume: Arc::clone(&publication_resume),
        });
        registry
            .register_factory(
                SubagentDefinition::new("single-flight", "Single-flight factory"),
                factory,
            )
            .await;

        let first_registry = registry.clone();
        let first = tokio::spawn(async move { first_registry.get_agent("single-flight").await });
        let first_attempt =
            tokio::time::timeout(std::time::Duration::from_secs(1), started_rx.recv())
                .await
                .map_err(|_| {
                    crate::error::ReactError::Other(
                        "first factory attempt did not start".to_string(),
                    )
                })?
                .ok_or_else(|| {
                    crate::error::ReactError::Other("factory start channel closed".to_string())
                })?;
        assert_eq!(first_attempt, 1);

        let reached_permit = tokio::time::timeout(
            std::time::Duration::from_secs(1),
            publication_reached.acquire(),
        )
        .await
        .map_err(|_| {
            crate::error::ReactError::Other(
                "first factory did not reach the publication boundary".to_string(),
            )
        })?
        .map_err(|error| {
            crate::error::ReactError::Other(format!(
                "publication boundary semaphore closed: {error}"
            ))
        })?;
        reached_permit.forget();

        let second_registry = registry.clone();
        let (entered_tx, entered_rx) = tokio::sync::oneshot::channel();
        let mut second = tokio::spawn(async move {
            let _ = entered_tx.send(());
            second_registry.get_agent("single-flight").await
        });
        tokio::time::timeout(std::time::Duration::from_secs(1), entered_rx)
            .await
            .map_err(|_| {
                crate::error::ReactError::Other(
                    "second resolver did not enter the publication interleaving".to_string(),
                )
            })?
            .map_err(|error| {
                crate::error::ReactError::Other(format!(
                    "second resolver entry channel closed: {error}"
                ))
            })?;
        let second_agent = tokio::select! {
            joined = &mut second => {
                joined
                    .map_err(|error| {
                        crate::error::ReactError::Other(format!(
                            "second resolver failed while first publication was paused: {error}"
                        ))
                    })?
                    .ok_or_else(|| {
                        crate::error::ReactError::Other(
                            "second resolver returned no published agent".to_string(),
                        )
                    })?
            }
            duplicate = started_rx.recv() => {
                publication_resume.add_permits(2);
                return match duplicate {
                    Some(attempt) => Err(crate::error::ReactError::Other(format!(
                        "factory started duplicate attempt {attempt} before publication"
                    ))),
                    None => Err(crate::error::ReactError::Other(
                        "factory start channel closed before publication".to_string(),
                    )),
                };
            }
            _ = tokio::time::sleep(std::time::Duration::from_secs(1)) => {
                publication_resume.add_permits(2);
                second.abort();
                return Err(crate::error::ReactError::Other(
                    "second resolver produced neither a cached agent nor a duplicate factory attempt"
                        .to_string(),
                ));
            }
        };
        publication_resume.add_permits(1);

        let first_agent = first
            .await
            .map_err(|error| {
                crate::error::ReactError::Other(format!("first resolver failed: {error}"))
            })?
            .ok_or_else(|| {
                crate::error::ReactError::Other("first resolver returned no agent".to_string())
            })?;
        assert!(Arc::ptr_eq(&first_agent, &second_agent));
        assert_eq!(attempts.load(Ordering::SeqCst), 1);
        Ok(())
    }

    #[tokio::test]
    async fn failed_factory_attempt_does_not_poison_registration() -> Result<()> {
        let registry = SubagentRegistry::new();
        let attempts = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let factory_attempts = Arc::clone(&attempts);
        let factory = Arc::new(FnAgentFactory::new(move || {
            let attempt = factory_attempts.fetch_add(1, Ordering::SeqCst) + 1;
            Box::pin(async move {
                if attempt == 1 {
                    return Err(crate::error::ReactError::Other(
                        "first factory attempt failed".to_string(),
                    ));
                }
                Ok(Box::new(MockAgent::new("retryable-factory")) as Box<dyn Agent>)
            })
        }));
        registry
            .register_factory(
                SubagentDefinition::new("retryable-factory", "Retryable factory"),
                factory,
            )
            .await;

        assert!(registry.get_agent("retryable-factory").await.is_none());
        let recovered = registry
            .get_agent("retryable-factory")
            .await
            .ok_or_else(|| {
                crate::error::ReactError::Other(
                    "factory registration remained poisoned after an error".to_string(),
                )
            })?;
        assert_eq!(recovered.name(), "retryable-factory");
        assert_eq!(attempts.load(Ordering::SeqCst), 2);
        Ok(())
    }

    #[tokio::test]
    async fn stale_factory_result_does_not_replace_new_registration() -> Result<()> {
        let registry = SubagentRegistry::new();
        let release_old = Arc::new(tokio::sync::Semaphore::new(0));
        let (started_tx, mut started_rx) = tokio::sync::mpsc::unbounded_channel();
        let factory_release = Arc::clone(&release_old);
        let factory = Arc::new(FnAgentFactory::new(move || {
            let release = Arc::clone(&factory_release);
            let _ = started_tx.send(());
            Box::pin(async move {
                let permit = release.acquire().await.map_err(|error| {
                    crate::error::ReactError::Other(format!(
                        "stale factory release semaphore closed: {error}"
                    ))
                })?;
                permit.forget();
                Ok(Box::new(MockAgent::new("stale-factory")) as Box<dyn Agent>)
            })
        }));
        registry
            .register_factory(
                SubagentDefinition::new("replaceable", "Old factory registration"),
                factory,
            )
            .await;

        let old_registry = registry.clone();
        let old_resolution =
            tokio::spawn(async move { old_registry.get_agent("replaceable").await });
        tokio::time::timeout(std::time::Duration::from_secs(1), started_rx.recv())
            .await
            .map_err(|_| crate::error::ReactError::Other("old factory did not start".to_string()))?
            .ok_or_else(|| {
                crate::error::ReactError::Other("old factory start channel closed".to_string())
            })?;

        let current: Arc<dyn Agent> = Arc::new(MockAgent::new("current-registration"));
        registry
            .register_shared(
                SubagentDefinition::new("replaceable", "Current registration"),
                Arc::clone(&current),
            )
            .await;
        release_old.add_permits(1);

        let old_result = old_resolution
            .await
            .map_err(|error| {
                crate::error::ReactError::Other(format!(
                    "old factory resolver task failed: {error}"
                ))
            })?
            .ok_or_else(|| {
                crate::error::ReactError::Other(
                    "old factory resolver did not return the current registration".to_string(),
                )
            })?;
        assert!(Arc::ptr_eq(&old_result, &current));
        let resolved = registry.get_agent("replaceable").await.ok_or_else(|| {
            crate::error::ReactError::Other("current registration disappeared".to_string())
        })?;
        assert!(Arc::ptr_eq(&resolved, &current));
        Ok(())
    }

    #[tokio::test]
    async fn test_factory_instantiation() {
        let registry = SubagentRegistry::new();

        let factory = Arc::new(FnAgentFactory::new(|| {
            Box::pin(async {
                Ok(
                    Box::new(MockAgent::new("lazy_agent").with_response("lazy result"))
                        as Box<dyn Agent>,
                )
            })
        }));

        let def = SubagentDefinition::new("lazy_agent", "Lazy agent");
        registry.register_factory(def, factory).await;

        // Should be registered but not yet instantiated
        let registered = registry.get("lazy_agent").await.unwrap();
        assert_eq!(registered.definition.name, "lazy_agent");
        assert!(!registered.has_instance);

        // get_agent should trigger factory instantiation
        let handle = registry.get_agent("lazy_agent").await;
        assert!(handle.is_some());

        // Now it should show as having an instance
        let registered = registry.get("lazy_agent").await.unwrap();
        assert!(registered.has_instance);

        // Verify the agent actually works
        let agent = handle.unwrap();
        let agent = agent.as_ref();
        let result = agent.execute("test").await.unwrap();
        assert_eq!(result, "lazy result");
    }
}
