//! Subagent executor — unified dispatch engine for Sync / Fork / Teammate modes
//!
//! The executor receives a [`DispatchRequest`] and routes it to the appropriate
//! execution strategy based on the definition's [`ExecutionMode`].

use crate::error::{AgentError, ReactError, Result};
use echo_core::agent::{
    Agent, AgentEvent, AgentInvocationContext, CancellationToken, EventIdentity,
    ExecutionAdmission, KeyedExecutionLease,
};
use echo_core::error::AgentTerminalKind;
use echo_core::llm::types::Message;
use futures::StreamExt;
use std::collections::{HashMap, HashSet, VecDeque};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};
use tokio::sync::Semaphore;
use tracing::{info, warn};

use super::context::SubagentContext;
use super::control::{
    SubagentAttemptBinding, SubagentAttemptIdentity, SubagentControlError, SubagentControlRegistry,
    SubagentGuidanceQueueReceipt, SubagentInterruptOutcome, SubagentInterruptRequestDisposition,
    SubagentMessageReceipt,
};
use super::events::{SubagentEvent, SubagentEventPublisher, SubagentInvocationIdentity};
use super::hooks::{SubagentHookContext, SubagentHookRegistry};
use super::prompt::{
    CompiledSubagentInvocation, ContextTransferPolicy, SubagentInvocation, SubagentPromptCompiler,
    SubagentTaskContext, ToolCapabilitySnapshot,
};
use super::registry::SubagentRegistry;
use super::types::{
    ExecutionMode, ObservedIsolation, SubagentArtifact, SubagentEvidence, SubagentEvidenceSource,
    SubagentOutcome, SubagentResult, SubagentStatus,
};
use crate::tasks::{
    NestedDelegationPolicy, RuntimeAttemptControlCleanupReceipt,
    RuntimeTaskAttemptInterruptDisposition, RuntimeTaskAttemptInterruptProjectionError, Task,
    TaskClaim, TaskSubagentContext,
};

// ── Dispatch Request ──────────────────────────────────────────────────────────

/// A request to dispatch a task to a subagent.
#[derive(Clone)]
pub struct DispatchRequest {
    /// Target subagent name.
    pub agent_name: String,
    /// Task description.
    pub task: String,
    /// Override the definition's default execution mode.
    pub mode_override: Option<ExecutionMode>,
    /// Cancellation token (propagated from parent).
    pub cancel: CancellationToken,
    /// Parent agent name (for logging and topology).
    pub parent_agent: String,
    /// Parent context for inheritance (Fork mode).
    pub parent_context: Option<SubagentContext>,
    /// Nested delegation policy (prevents unbounded delegation chains).
    pub delegation_policy: NestedDelegationPolicy,
    /// 应用层 run 级上下文（跨 spawn 安全，值传递）。
    ///
    /// dispatch_fork 将它放入本次 `AgentInvocationContext`，使 subagent 内的工具
    /// 能经 ToolContext 读到 run_id/cancel/trace_sink——不修改共享 agent。
    pub runtime_context: Option<echo_core::tools::ExternalRunContext>,
    /// Optional multimodal message (images/files). When `Some`, the subagent is
    /// dispatched via `execute_stream_message_with_invocation_context` instead of the text
    /// `task` path, so it sees user-uploaded attachments. `None` = plain text
    /// dispatch (the default for all existing callers).
    pub message: Option<Message>,
    /// Opaque structured payload consumed only by an injected product compiler.
    pub prompt_payload: Option<serde_json::Value>,
    /// Typed task facts consumed by every prompt compiler.
    pub prompt_context: Option<SubagentTaskContext>,
    /// Explicit task constraints / boundaries from the dispatch caller (e.g.
    /// the `agent_tool` `constraints` parameter). Rendered by the invocation
    /// compiler independently of `parent_context`, so fresh-context dispatches
    /// can still carry boundaries.
    pub constraints: Vec<String>,
    /// When true, this dispatch was (or will be) started via
    /// [`SubagentExecutor::dispatch_background`]. Propagated onto
    /// [`SubagentEvent::DispatchStarted`] so UI can mark background cards.
    pub background: bool,
}

impl std::fmt::Debug for DispatchRequest {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("DispatchRequest")
            .field("agent_name", &self.agent_name)
            .field("task", &self.task)
            .field("mode_override", &self.mode_override)
            .field("parent_agent", &self.parent_agent)
            .field("delegation_policy", &self.delegation_policy)
            .field(
                "runtime_context",
                &self.runtime_context.as_ref().map(|c| &c.run_id),
            )
            .field("has_prompt_payload", &self.prompt_payload.is_some())
            .field("has_prompt_context", &self.prompt_context.is_some())
            .finish()
    }
}

impl DispatchRequest {
    /// Build a request delegation policy from the legacy depth parameter used
    /// by older public helper methods.
    pub fn policy_from_depth(depth: u32) -> NestedDelegationPolicy {
        NestedDelegationPolicy {
            can_spawn_subagents: true,
            delegate_depth: depth.min(u8::MAX as u32) as u8,
            max_delegate_depth: 3,
        }
    }
}

fn invocation_disabled_tools(
    tool_names: Vec<String>,
    allowed_tools: Option<&[String]>,
) -> Option<HashSet<String>> {
    let allowed_tools = allowed_tools.filter(|tools| !tools.is_empty())?;
    let allowed = allowed_tools
        .iter()
        .map(String::as_str)
        .collect::<HashSet<_>>();
    Some(
        tool_names
            .into_iter()
            .filter(|tool| !allowed.contains(tool.as_str()))
            .collect(),
    )
}

fn effective_capabilities(
    agent: &dyn Agent,
    allowed_tools: Option<&[String]>,
) -> ToolCapabilitySnapshot {
    let definitions = agent.tool_definitions();
    let mut disabled = agent.disabled_tool_names();
    if let Some(allowed) = allowed_tools.filter(|tools| !tools.is_empty()) {
        let allowed = allowed.iter().map(String::as_str).collect::<HashSet<_>>();
        disabled.extend(
            definitions
                .iter()
                .map(|definition| definition.function.name.clone())
                .filter(|name| !allowed.contains(name.as_str())),
        );
    }
    ToolCapabilitySnapshot::from_definitions(&definitions, &disabled)
}

/// Map framework errors to the runtime-owned subagent terminal status.
pub fn subagent_status_from_error(error: &ReactError) -> SubagentStatus {
    match error {
        ReactError::Agent(agent_error) => match agent_error.as_ref() {
            AgentError::Timeout(_) => SubagentStatus::TimedOut,
            AgentError::Interrupted | AgentError::Cancelled(_) => SubagentStatus::Cancelled,
            _ => SubagentStatus::Failed,
        },
        _ => SubagentStatus::Failed,
    }
}

#[cfg(test)]
mod typed_error_mapping_tests {
    use super::*;

    #[test]
    fn terminal_status_ignores_misleading_error_text() {
        let error = ReactError::Other("cancelled timeout are ordinary words here".to_string());
        assert_eq!(subagent_status_from_error(&error), SubagentStatus::Failed);
    }

    #[test]
    fn attempt_control_projection_preserves_capacity_and_identity_conflict() {
        assert_eq!(
            runtime_interrupt_projection_error(SubagentControlError::PendingCapacityExceeded {
                limit: 17
            }),
            RuntimeTaskAttemptInterruptProjectionError::PendingCapacityExceeded { limit: 17 }
        );
        assert_eq!(
            runtime_interrupt_projection_error(SubagentControlError::IdentityConflict {
                task_id: "task".to_string(),
                attempt: 2,
                expected_execution_id: "expected".to_string(),
                actual_execution_id: "actual".to_string(),
            }),
            RuntimeTaskAttemptInterruptProjectionError::IdentityConflict {
                task_id: "task".to_string(),
                attempt: 2,
                expected_execution_id: "expected".to_string(),
                actual_execution_id: "actual".to_string(),
            }
        );
    }

    #[test]
    fn exact_dispatch_context_preserves_resources_and_rejects_identity_conflicts()
    -> std::result::Result<(), String> {
        let trace_sink: echo_core::tools::TraceSinkFn = Arc::new(|_| {});
        let uplink: echo_core::tools::SubagentUplinkFn = Arc::new(|_| {
            Box::pin(async {
                echo_core::tools::SubagentUplinkReceipt {
                    accepted: true,
                    status: "test".to_string(),
                    detail: String::new(),
                }
            })
        });
        let initial_cancel = CancellationToken::new();
        let exact_cancel = CancellationToken::new();
        let exact = ExactTaskDispatchContext {
            run_id: "run".to_string(),
            execution_id: "execution".to_string(),
            task_id: "task".to_string(),
            attempt: 3,
            plan_revision: 9,
            cancel: exact_cancel.clone(),
            delegation_policy: NestedDelegationPolicy {
                can_spawn_subagents: true,
                delegate_depth: 1,
                max_delegate_depth: 4,
            },
        };
        let mut request = DispatchRequest {
            agent_name: "reviewer".to_string(),
            task: "review".to_string(),
            mode_override: None,
            cancel: initial_cancel,
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: NestedDelegationPolicy::default(),
            runtime_context: Some(echo_core::tools::ExternalRunContext {
                conversation_id: Some("conversation".to_string()),
                turn_id: Some("turn".to_string()),
                isolation_id: Some("isolation".to_string()),
                message_id: Some("message".to_string()),
                trace_sink: Some(trace_sink.clone()),
                resource_guards: vec![echo_core::tools::InvocationResourceGuard::new_identified(
                    "guard".to_string(),
                    7_u64,
                )],
                subagent_lineage: Some(echo_core::tools::SubagentLineage {
                    agent_name: Some("reviewer".to_string()),
                    parent_agent: Some("parent".to_string()),
                    ..Default::default()
                }),
                uplink: Some(uplink.clone()),
                ..Default::default()
            }),
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        bind_exact_dispatch_context(&mut request, &exact).map_err(|error| error.to_string())?;
        let runtime = request
            .runtime_context
            .as_ref()
            .ok_or_else(|| "runtime context missing".to_string())?;
        assert_eq!(runtime.conversation_id.as_deref(), Some("conversation"));
        assert_eq!(runtime.turn_id.as_deref(), Some("turn"));
        assert_eq!(runtime.isolation_id.as_deref(), Some("isolation"));
        assert_eq!(runtime.message_id.as_deref(), Some("message"));
        assert_eq!(runtime.resource_guards.len(), 1);
        assert!(
            runtime
                .trace_sink
                .as_ref()
                .is_some_and(|value| { Arc::ptr_eq(value, &trace_sink) })
        );
        assert!(
            runtime
                .uplink
                .as_ref()
                .is_some_and(|value| { Arc::ptr_eq(value, &uplink) })
        );
        let lineage = runtime
            .subagent_lineage
            .as_ref()
            .ok_or_else(|| "subagent lineage missing".to_string())?;
        assert_eq!(lineage.agent_name.as_deref(), Some("reviewer"));
        assert_eq!(lineage.run_id.as_deref(), Some("run"));
        assert_eq!(lineage.task_id.as_deref(), Some("task"));
        assert_eq!(lineage.execution_id.as_deref(), Some("execution"));
        assert_eq!(lineage.attempt, Some(3));
        assert_eq!(lineage.plan_revision, Some(9));
        exact_cancel.cancel();
        assert!(request.cancel.is_cancelled());
        assert!(
            runtime
                .cancel
                .as_ref()
                .is_some_and(|cancel| cancel.is_cancelled())
        );
        assert_eq!(request.delegation_policy, exact.delegation_policy);

        let mut conflicting = request.clone();
        if let Some(runtime) = conflicting.runtime_context.as_mut() {
            runtime.run_id = Some("other-run".to_string());
        }
        assert!(
            bind_exact_dispatch_context(&mut conflicting, &exact)
                .is_err_and(|error| error.to_string().contains("run_id mismatch"))
        );
        Ok(())
    }
}

fn hook_stop_status(status: SubagentStatus) -> echo_core::hooks::SubagentStopStatus {
    match status {
        SubagentStatus::Running => echo_core::hooks::SubagentStopStatus::Failed,
        SubagentStatus::Completed => echo_core::hooks::SubagentStopStatus::Completed,
        SubagentStatus::Failed => echo_core::hooks::SubagentStopStatus::Failed,
        SubagentStatus::Cancelled => echo_core::hooks::SubagentStopStatus::Cancelled,
        SubagentStatus::TimedOut => echo_core::hooks::SubagentStopStatus::TimedOut,
    }
}

fn correlate_subagent_hook(
    ctx: crate::skills::hooks::HookContext,
    run_id: Option<&str>,
    execution_id: Option<&str>,
    attempt: u32,
) -> crate::skills::hooks::HookContext {
    ctx.with_run_correlation(run_id, None, execution_id, Some(attempt))
}

fn bounded_detail(text: &str) -> String {
    text.chars().take(500).collect()
}

/// Merge runtime-observed evidence into a parsed result.
///
/// Observed facts replace older evidence with the same kind, subject, and
/// attributes, while distinct invocations and artifacts are preserved.
pub fn merge_observed_evidence(
    outcome: &mut SubagentOutcome,
    evidence: Vec<SubagentEvidence>,
    artifacts: Vec<SubagentArtifact>,
) {
    for observed in evidence {
        outcome.evidence.retain(|existing| {
            existing.kind != observed.kind
                || existing.subject != observed.subject
                || existing.attributes != observed.attributes
        });
        outcome.evidence.push(observed);
    }
    for artifact in artifacts {
        outcome
            .artifacts
            .retain(|existing| existing.path != artifact.path);
        outcome.artifacts.push(artifact);
    }
    super::types::normalize_outcome(outcome);
    outcome.refresh_derived_views();
}

// ── Teammate Handle ───────────────────────────────────────────────────────────

/// Handle to a running teammate agent.
///
/// Used to poll for results or cancel execution.
#[derive(Debug)]
pub struct TeammateHandle {
    /// Unique handle ID.
    pub id: String,
    /// The teammate agent name.
    pub agent_name: String,
    /// Cancellation token for this teammate.
    pub cancel: CancellationToken,
    /// Join handle for the spawned task.
    join_handle: tokio::task::JoinHandle<Result<SubagentResult>>,
}

/// Handle returned immediately by [`SubagentExecutor::dispatch_background`].
///
/// The subagent continues on a spawned task; lifecycle events
/// (`DispatchStarted` / `DispatchCompleted` / `DispatchFailed`) still fire on
/// the registry event bus. The handle also owns cancellation and the eventual
/// result so direct API callers do not have to depend on a lossy event stream.
#[derive(Debug, Clone)]
pub struct BackgroundSubagentHandle {
    /// Stable execution id (also on `DispatchStarted.execution_id`).
    pub execution_id: String,
    /// Target subagent name.
    pub agent_name: String,
    cancel: CancellationToken,
    join_handle: Arc<Mutex<Option<tokio::task::JoinHandle<Result<SubagentResult>>>>>,
}

/// Scope-bound live control for TaskClaim-derived Subagent attempts.
///
/// Durable claim validation and Task terminal settlement remain owned by
/// [`crate::tasks::RuntimeTaskService`]. This handle only projects a controller's
/// already-validated claim into the same process-local registry used by dispatch.
pub struct SubagentAttemptControlHandle {
    executor: SubagentExecutor,
    control_scope_id: String,
}

impl Clone for SubagentAttemptControlHandle {
    fn clone(&self) -> Self {
        Self {
            executor: self.executor.clone_for_spawn(),
            control_scope_id: self.control_scope_id.clone(),
        }
    }
}

impl std::fmt::Debug for SubagentAttemptControlHandle {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("SubagentAttemptControlHandle")
            .field("control_scope_id", &self.control_scope_id)
            .finish_non_exhaustive()
    }
}

impl BackgroundSubagentHandle {
    /// Request cancellation of the background dispatch.
    pub fn cancel(&self) {
        self.cancel.cancel();
    }

    /// Check whether the spawned dispatch has reached a terminal state.
    pub fn is_finished(&self) -> bool {
        self.join_handle
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
            .as_ref()
            .is_none_or(tokio::task::JoinHandle::is_finished)
    }

    /// Await and consume the background result.
    ///
    /// Cloned handles share one result slot; only the first `join` call
    /// consumes it. Later calls return an explicit error.
    pub async fn join(&self) -> Result<SubagentResult> {
        let handle = self
            .join_handle
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
            .take()
            .ok_or_else(|| ReactError::Other("Background result already consumed".to_string()))?;
        handle
            .await
            .map_err(|error| ReactError::Other(format!("Background join error: {error}")))?
    }
}

impl TeammateHandle {
    /// Check if the teammate has completed.
    pub fn is_finished(&self) -> bool {
        self.join_handle.is_finished()
    }

    /// Await the teammate's result.
    pub async fn join(self) -> Result<SubagentResult> {
        self.join_handle
            .await
            .map_err(|e| ReactError::Other(format!("Teammate join error: {}", e)))?
    }
}

// ── Executor Config ───────────────────────────────────────────────────────────

/// Configuration for the subagent executor.
pub struct SubagentExecutorConfig {
    /// Maximum concurrent Fork dispatches.
    pub max_concurrent_forks: usize,
    /// Default timeout (seconds) for ALL dispatch modes (Sync/Fork/Teammate).
    /// 0 = no timeout. Sourced from `AgentConfig.subagent_timeout_secs` (default
    /// 600 = 10 min). Per-subagent `SubagentDefinition.timeout_secs` (>0) overrides.
    pub default_timeout_secs: u64,
    /// Enable hooks.
    pub enable_hooks: bool,
    /// Optional bridge to the unified lifecycle hook system (echo-core).
    /// When set, SubagentStart/SubagentStop events are fired into the
    /// unified HookRegistry alongside the trait-based SubagentHooks.
    pub unified_hook_executor: Option<crate::skills::hooks::UnifiedHookExecutorFn>,
    /// Optional application-owned provider for product-defined isolation kinds.
    pub isolation_provider: Option<super::isolation::SharedIsolationProvider>,
    /// Compiler shared by direct `agent_tool` and programmatic delegation.
    pub prompt_compiler: Arc<dyn SubagentPromptCompiler>,
    /// Optional shared process admission. When absent, Fork uses its local
    /// `max_concurrent_forks` semaphore for standalone compatibility.
    pub shared_admission: Option<Arc<ExecutionAdmission>>,
}

impl Default for SubagentExecutorConfig {
    fn default() -> Self {
        Self {
            max_concurrent_forks: 5,
            default_timeout_secs: 600,
            enable_hooks: true,
            unified_hook_executor: None,
            isolation_provider: None,
            prompt_compiler: Arc::new(super::prompt::DefaultSubagentPromptCompiler),
            shared_admission: None,
        }
    }
}

// ── Subagent Executor ─────────────────────────────────────────────────────────

/// Unified dispatch engine for all subagent execution modes.
pub struct SubagentExecutor {
    registry: Arc<SubagentRegistry>,
    hooks: Arc<SubagentHookRegistry>,
    config: SubagentExecutorConfig,
    semaphore: Arc<Semaphore>,
    control_registry: Arc<SubagentControlRegistry>,
    shared_admission: Arc<tokio::sync::RwLock<Option<Arc<ExecutionAdmission>>>>,
    team_runtimes: Arc<Mutex<TeamRuntimeIndex>>,
}

const TEAM_RUNTIME_RETENTION: usize = 64;

#[derive(Default)]
struct TeamRuntimeIndex {
    handles: HashMap<String, Arc<super::team::TeamRuntimeHandle>>,
    order: VecDeque<String>,
}

fn prune_team_runtime_index(index: &Arc<Mutex<TeamRuntimeIndex>>) {
    let mut runtimes = index
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner());
    let mut excess = runtimes
        .handles
        .values()
        .filter(|handle| !handle.is_active())
        .count()
        .saturating_sub(TEAM_RUNTIME_RETENTION);
    let scan_count = runtimes.order.len();
    for _ in 0..scan_count {
        let Some(handle_id) = runtimes.order.pop_front() else {
            break;
        };
        let remove = excess > 0
            && runtimes
                .handles
                .get(&handle_id)
                .is_some_and(|handle| !handle.is_active());
        if remove {
            runtimes.handles.remove(&handle_id);
            excess = excess.saturating_sub(1);
        } else if runtimes.handles.contains_key(&handle_id) {
            runtimes.order.push_back(handle_id);
        }
    }
}

struct TeamRuntimeRetentionGuard {
    index: Arc<Mutex<TeamRuntimeIndex>>,
}

impl Drop for TeamRuntimeRetentionGuard {
    fn drop(&mut self) {
        prune_team_runtime_index(&self.index);
    }
}

/// Framework-default uplink sink.
///
/// Behavior per target:
/// - `Parent`: when the sender's lineage carries `parent_execution_id` and
///   that attempt is live in the shared control registry, the message steers
///   the parent's active turn (queue-only; the parent drains it at its next
///   model boundary). Otherwise the message is still accepted and surfaced as
///   [`SubagentEvent::UplinkReceived`] for host-side listeners.
/// - `Sibling`: delivered queue-only via the shared control registry; a
///   non-active sibling reports `sibling_not_active` so the model can retry
///   or escalate instead of assuming delivery.
pub fn default_uplink_sink(registry: Arc<SubagentRegistry>) -> echo_core::tools::SubagentUplinkFn {
    use echo_core::tools::{SubagentUplinkMessage, SubagentUplinkReceipt, SubagentUplinkTarget};
    Arc::new(move |message: SubagentUplinkMessage| {
        let registry = Arc::clone(&registry);
        Box::pin(async move {
            let from = &message.from;
            let agent = from
                .agent_name
                .clone()
                .unwrap_or_else(|| "<unknown>".to_string());
            let parent = from
                .parent_agent
                .clone()
                .unwrap_or_else(|| "<unknown>".to_string());
            let (direction, intent_prefix, mut receipt) = match &message.target {
                SubagentUplinkTarget::Parent { kind, text } => {
                    let intent = if *kind == echo_core::tools::SubagentUplinkKind::Escalate {
                        "[escalate] "
                    } else {
                        ""
                    };
                    let delivery = match from.parent_execution_id.as_deref() {
                        Some(execution_id) => {
                            registry
                                .control_registry()
                                .send_message_to_active(execution_id, text.clone())
                                .await
                        }
                        None => Err(SubagentControlError::UnknownExecution {
                            execution_id: String::new(),
                        }),
                    };
                    let receipt = match delivery {
                        Ok(receipt) => SubagentUplinkReceipt {
                            accepted: true,
                            status: "parent_steered".to_string(),
                            detail: format!("queued into parent attempt {}", receipt.attempt),
                        },
                        Err(error) => SubagentUplinkReceipt {
                            accepted: true,
                            status: "event_emitted".to_string(),
                            detail: format!(
                                "parent not steerable ({error}); surfaced for host listeners"
                            ),
                        },
                    };
                    ("parent", intent, receipt)
                }
                SubagentUplinkTarget::Sibling { to, text } => {
                    let receipt = match to {
                        echo_core::tools::SubagentPeerAddress::ByExecutionId(execution_id) => {
                            match registry
                                .control_registry()
                                .send_message_to_active(execution_id, text.clone())
                                .await
                            {
                                Ok(receipt) => SubagentUplinkReceipt {
                                    accepted: true,
                                    status: "delivered_to_sibling".to_string(),
                                    detail: format!(
                                        "queued into sibling attempt {}",
                                        receipt.attempt
                                    ),
                                },
                                Err(error) => SubagentUplinkReceipt {
                                    accepted: false,
                                    status: "sibling_not_active".to_string(),
                                    detail: error.to_string(),
                                },
                            }
                        }
                        echo_core::tools::SubagentPeerAddress::ByTaskId(task_id) => {
                            SubagentUplinkReceipt {
                                accepted: false,
                                status: "task_addressing_requires_application_sink".to_string(),
                                detail: format!(
                                    "task '{task_id}' has no live attempt; an application                                      sink owning attempt scheduling must deliver it"
                                ),
                            }
                        }
                    };
                    ("sibling", "", receipt)
                }
            };
            let summary: String = {
                let text = match &message.target {
                    SubagentUplinkTarget::Parent { text, .. }
                    | SubagentUplinkTarget::Sibling { text, .. } => text,
                };
                format!(
                    "{intent_prefix}{}",
                    text.chars().take(200).collect::<String>()
                )
            };
            let uplink_event = SubagentEvent::UplinkReceived {
                parent,
                agent,
                direction: direction.to_string(),
                status: receipt.status.clone(),
                summary,
                execution_id: from.execution_id.clone(),
                run_id: from.run_id.clone(),
            };
            let published = from
                .execution_id
                .as_deref()
                .and_then(|execution_id| registry.event_bus().publisher_for_execution(execution_id))
                .is_some_and(|publisher| match publisher.emit(uplink_event) {
                    Ok(_) => true,
                    Err(error) => {
                        warn!(%error, "failed to publish Subagent uplink envelope");
                        false
                    }
                });
            if !published {
                warn!(
                    execution_id = from.execution_id.as_deref().unwrap_or("<none>"),
                    "Subagent uplink has no active event publisher"
                );
                if receipt.status == "event_emitted" {
                    receipt.accepted = false;
                    receipt.status = "event_unavailable".to_string();
                    receipt.detail =
                        "parent not steerable and no active event publisher exists".to_string();
                }
            }
            receipt
        })
    })
}

impl SubagentAttemptControlHandle {
    pub fn control_scope_id(&self) -> &str {
        &self.control_scope_id
    }

    fn identity_from_context(
        &self,
        context: &TaskSubagentContext,
    ) -> std::result::Result<SubagentAttemptIdentity, SubagentControlError> {
        let claim = context
            .claim()
            .ok_or(SubagentControlError::InvalidIdentity { field: "claim" })?;
        let task_id = context
            .task_id()
            .ok_or(SubagentControlError::InvalidIdentity { field: "task_id" })?;
        SubagentAttemptIdentity::for_runtime_scope(
            self.control_scope_id.clone(),
            context.run_id().to_string(),
            task_id.to_string(),
            claim.execution_id(context.run_id(), task_id),
            claim.attempt,
        )
    }

    fn identity_from_claim(
        &self,
        run_id: &str,
        task_id: &str,
        claim: &TaskClaim,
    ) -> std::result::Result<SubagentAttemptIdentity, SubagentControlError> {
        SubagentAttemptIdentity::for_runtime_scope(
            self.control_scope_id.clone(),
            run_id.to_string(),
            task_id.to_string(),
            claim.execution_id(run_id, task_id),
            claim.attempt,
        )
    }

    /// Reserve one exact TaskClaim attempt before it waits for admission.
    pub fn reserve(
        &self,
        context: &TaskSubagentContext,
    ) -> std::result::Result<(), SubagentControlError> {
        let identity = self.identity_from_context(context)?;
        self.executor
            .reserve_attempt(identity, context.cancellation_token().clone())
    }

    /// Dispatch one exact TaskClaim attempt through this handle's registry.
    pub async fn dispatch(
        &self,
        mut request: DispatchRequest,
        context: TaskSubagentContext,
    ) -> Result<SubagentResult> {
        let identity = self
            .identity_from_context(&context)
            .map_err(SubagentExecutor::control_react_error)?;
        bind_task_dispatch_context(&mut request, &context)?;
        self.executor.dispatch_attempt(request, identity).await
    }

    /// Project an interrupt that has already passed durable TaskClaim checks.
    ///
    /// Durable callers must invoke this only from
    /// [`crate::tasks::RuntimeDagController::request_live_interrupt`].
    pub fn project_interrupt(
        &self,
        run_id: &str,
        task_id: &str,
        claim: &TaskClaim,
    ) -> std::result::Result<
        RuntimeTaskAttemptInterruptDisposition,
        RuntimeTaskAttemptInterruptProjectionError,
    > {
        let identity = self
            .identity_from_claim(run_id, task_id, claim)
            .map_err(runtime_interrupt_projection_error)?;
        self.executor
            .request_interrupt(identity)
            .map(|receipt| runtime_interrupt_disposition(receipt.disposition))
            .map_err(runtime_interrupt_projection_error)
    }

    /// Retire one live projection after its durable claim has advanced.
    pub fn retire(
        &self,
        run_id: &str,
        task: &Task,
        claim: &TaskClaim,
    ) -> RuntimeAttemptControlCleanupReceipt {
        let identity = match self.identity_from_claim(run_id, &task.spec.id, claim) {
            Ok(identity) => identity,
            Err(error) => {
                return RuntimeAttemptControlCleanupReceipt::RetryableFailure {
                    error: error.to_string(),
                };
            }
        };
        match self.executor.retire_attempt_control(&identity) {
            Ok(true) => RuntimeAttemptControlCleanupReceipt::Retired,
            Ok(false) => RuntimeAttemptControlCleanupReceipt::AlreadyConsumed,
            Err(error) => RuntimeAttemptControlCleanupReceipt::RetryableFailure {
                error: error.to_string(),
            },
        }
    }

    /// Reconcile only this handle's fixed control scope.
    pub fn reconcile(
        &self,
        run_id: &str,
        current_execution_ids: &HashSet<String>,
    ) -> std::result::Result<(), SubagentControlError> {
        self.executor.reconcile_attempt_control(
            &self.control_scope_id,
            run_id,
            current_execution_ids,
        )
    }
}

fn bind_task_dispatch_context(
    request: &mut DispatchRequest,
    context: &TaskSubagentContext,
) -> Result<()> {
    let exact = ExactTaskDispatchContext::from_task_context(context)?;
    bind_exact_dispatch_context(request, &exact)
}

struct ExactTaskDispatchContext {
    run_id: String,
    execution_id: String,
    task_id: String,
    attempt: u32,
    plan_revision: u64,
    cancel: CancellationToken,
    delegation_policy: NestedDelegationPolicy,
}

impl ExactTaskDispatchContext {
    fn from_task_context(context: &TaskSubagentContext) -> Result<Self> {
        let execution_id = context.execution_id().ok_or_else(|| {
            ReactError::Other("exact task dispatch requires an execution identity".to_string())
        })?;
        let task_id = context.task_id().ok_or_else(|| {
            ReactError::Other("exact task dispatch requires a task identity".to_string())
        })?;
        let claim = context.claim().ok_or_else(|| {
            ReactError::Other("exact task dispatch requires a TaskClaim".to_string())
        })?;
        Ok(Self {
            run_id: context.run_id().to_string(),
            execution_id,
            task_id: task_id.to_string(),
            attempt: claim.attempt,
            plan_revision: claim.revision,
            cancel: context.cancellation_token().clone(),
            delegation_policy: context.delegation_policy(),
        })
    }
}

fn bind_exact_dispatch_context(
    request: &mut DispatchRequest,
    exact: &ExactTaskDispatchContext,
) -> Result<()> {
    let runtime = request
        .runtime_context
        .get_or_insert_with(echo_core::tools::ExternalRunContext::default);
    ensure_string_identity("run_id", runtime.run_id.as_deref(), &exact.run_id)?;
    ensure_string_identity(
        "execution_id",
        runtime.execution_id.as_deref(),
        &exact.execution_id,
    )?;
    runtime.run_id = Some(exact.run_id.clone());
    runtime.execution_id = Some(exact.execution_id.clone());
    if runtime.turn_id.is_none() {
        runtime.turn_id = Some(exact.execution_id.clone());
    }
    runtime.cancel = Some(Arc::new(exact.cancel.clone()));
    runtime.delegation_policy = Some(exact.delegation_policy);
    let lineage = runtime
        .subagent_lineage
        .get_or_insert_with(Default::default);
    ensure_string_identity("lineage.run_id", lineage.run_id.as_deref(), &exact.run_id)?;
    ensure_string_identity(
        "lineage.task_id",
        lineage.task_id.as_deref(),
        &exact.task_id,
    )?;
    ensure_string_identity(
        "lineage.execution_id",
        lineage.execution_id.as_deref(),
        &exact.execution_id,
    )?;
    ensure_numeric_identity("lineage.attempt", lineage.attempt, exact.attempt)?;
    ensure_numeric_identity(
        "lineage.plan_revision",
        lineage.plan_revision,
        exact.plan_revision,
    )?;
    lineage.run_id = Some(exact.run_id.clone());
    lineage.task_id = Some(exact.task_id.clone());
    lineage.execution_id = Some(exact.execution_id.clone());
    lineage.attempt = Some(exact.attempt);
    lineage.plan_revision = Some(exact.plan_revision);
    request.cancel = exact.cancel.clone();
    request.delegation_policy = exact.delegation_policy;
    Ok(())
}

fn ensure_string_identity(field: &str, actual: Option<&str>, expected: &str) -> Result<()> {
    if let Some(actual) = actual
        && actual != expected
    {
        return Err(ReactError::Other(format!(
            "Subagent {field} mismatch: expected {expected}, actual {actual}"
        )));
    }
    Ok(())
}

fn ensure_numeric_identity<T>(field: &str, actual: Option<T>, expected: T) -> Result<()>
where
    T: Copy + PartialEq + std::fmt::Display,
{
    if let Some(actual) = actual
        && actual != expected
    {
        return Err(ReactError::Other(format!(
            "Subagent {field} mismatch: expected {expected}, actual {actual}"
        )));
    }
    Ok(())
}

fn runtime_interrupt_disposition(
    disposition: SubagentInterruptRequestDisposition,
) -> RuntimeTaskAttemptInterruptDisposition {
    match disposition {
        SubagentInterruptRequestDisposition::QueuedBeforeAdmission => {
            RuntimeTaskAttemptInterruptDisposition::QueuedBeforeReservation
        }
        SubagentInterruptRequestDisposition::ReservedRequested => {
            RuntimeTaskAttemptInterruptDisposition::ReservedRequested
        }
        SubagentInterruptRequestDisposition::ActiveRequested => {
            RuntimeTaskAttemptInterruptDisposition::ActiveRequested
        }
        SubagentInterruptRequestDisposition::ActiveAlreadyRequested => {
            RuntimeTaskAttemptInterruptDisposition::ActiveAlreadyRequested
        }
        SubagentInterruptRequestDisposition::AlreadySettled(status) => {
            RuntimeTaskAttemptInterruptDisposition::AlreadySettled {
                status: status.as_str().to_string(),
            }
        }
    }
}

fn runtime_interrupt_projection_error(
    error: SubagentControlError,
) -> RuntimeTaskAttemptInterruptProjectionError {
    match error {
        SubagentControlError::PendingCapacityExceeded { limit } => {
            RuntimeTaskAttemptInterruptProjectionError::PendingCapacityExceeded { limit }
        }
        SubagentControlError::IdentityConflict {
            task_id,
            attempt,
            expected_execution_id,
            actual_execution_id,
        } => RuntimeTaskAttemptInterruptProjectionError::IdentityConflict {
            task_id,
            attempt,
            expected_execution_id,
            actual_execution_id,
        },
        error => RuntimeTaskAttemptInterruptProjectionError::Unavailable {
            message: error.to_string(),
        },
    }
}

impl SubagentExecutor {
    /// Create a new executor backed by the given registry.
    pub fn new(registry: Arc<SubagentRegistry>, config: SubagentExecutorConfig) -> Self {
        let semaphore = Arc::new(Semaphore::new(config.max_concurrent_forks));
        let shared_admission = config.shared_admission.clone();
        Self {
            control_registry: Arc::clone(registry.control_registry()),
            registry,
            hooks: Arc::new(SubagentHookRegistry::new()),
            config,
            semaphore,
            shared_admission: Arc::new(tokio::sync::RwLock::new(shared_admission)),
            team_runtimes: Arc::new(Mutex::new(TeamRuntimeIndex::default())),
        }
    }

    /// Create with a specific hook registry.
    pub fn with_hooks(
        registry: Arc<SubagentRegistry>,
        config: SubagentExecutorConfig,
        hooks: SubagentHookRegistry,
    ) -> Self {
        let semaphore = Arc::new(Semaphore::new(config.max_concurrent_forks));
        let shared_admission = config.shared_admission.clone();
        Self {
            control_registry: Arc::clone(registry.control_registry()),
            registry,
            hooks: Arc::new(hooks),
            config,
            semaphore,
            shared_admission: Arc::new(tokio::sync::RwLock::new(shared_admission)),
            team_runtimes: Arc::new(Mutex::new(TeamRuntimeIndex::default())),
        }
    }

    /// Get the hook registry (for external registration).
    pub fn hooks(&self) -> &SubagentHookRegistry {
        &self.hooks
    }

    /// Shared registry handle (for callers that need definition lookups).
    pub fn registry(&self) -> &Arc<SubagentRegistry> {
        &self.registry
    }

    /// Create one complete live-control capability for an external task adapter.
    pub fn attempt_control_handle(
        &self,
        control_scope_id: impl Into<String>,
    ) -> std::result::Result<SubagentAttemptControlHandle, SubagentControlError> {
        let control_scope_id = control_scope_id.into();
        if control_scope_id.trim().is_empty() {
            return Err(SubagentControlError::InvalidIdentity {
                field: "control_scope_id",
            });
        }
        Ok(SubagentAttemptControlHandle {
            executor: self.clone_for_spawn(),
            control_scope_id,
        })
    }

    /// Return one retained Team runtime by its unique handle identity.
    pub fn team_runtime_handle(
        &self,
        handle_id: &str,
    ) -> Option<Arc<super::team::TeamRuntimeHandle>> {
        self.team_runtimes
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
            .handles
            .get(handle_id)
            .cloned()
    }

    /// Return every retained Team runtime for a business run. Multiple nested
    /// or concurrent Team executions can legitimately share the same run ID.
    pub fn team_runtime_handles(&self, run_id: &str) -> Vec<Arc<super::team::TeamRuntimeHandle>> {
        let runtimes = self
            .team_runtimes
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        runtimes
            .order
            .iter()
            .filter_map(|handle_id| runtimes.handles.get(handle_id))
            .filter(|handle| handle.run_id() == run_id)
            .cloned()
            .collect()
    }

    fn retain_team_runtime(&self, handle: Arc<super::team::TeamRuntimeHandle>) {
        let mut runtimes = self
            .team_runtimes
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        let handle_id = handle.handle_id().to_string();
        if !runtimes.handles.contains_key(&handle_id) {
            runtimes.order.push_back(handle_id.clone());
        }
        runtimes.handles.insert(handle_id, handle);
        drop(runtimes);
        prune_team_runtime_index(&self.team_runtimes);
    }

    /// Inject an application-owned process admission for direct dispatches.
    pub async fn set_shared_admission(&self, admission: Arc<ExecutionAdmission>) {
        *self.shared_admission.write().await = Some(admission);
    }

    /// Main dispatch entry point.
    ///
    /// Routes to the appropriate mode based on the definition or override.
    /// Uses a loop for retry/delegation instead of recursion to prevent stack overflow.
    pub async fn dispatch(&self, req: DispatchRequest) -> Result<SubagentResult> {
        self.dispatch_inner(req, None).await
    }

    /// Dispatch one explicitly identified task attempt under live control.
    ///
    /// The identity is process-scoped. Durable run/revision/command validation
    /// remains the responsibility of the framework consumer.
    pub async fn dispatch_attempt(
        &self,
        req: DispatchRequest,
        identity: SubagentAttemptIdentity,
    ) -> Result<SubagentResult> {
        let (req, admission) = self.admit_attempt(req, identity)?;
        self.dispatch_admitted_attempt(req, admission).await
    }

    fn admit_attempt(
        &self,
        mut req: DispatchRequest,
        identity: SubagentAttemptIdentity,
    ) -> Result<(DispatchRequest, super::control::SubagentAttemptAdmission)> {
        Self::bind_attempt_runtime_identity(&mut req, &identity)?;
        let admission = self
            .control_registry
            .admit(identity, req.cancel.clone())
            .map_err(Self::control_react_error)?;
        req.cancel = admission.cancel.clone();
        if let Some(context) = req.runtime_context.as_mut() {
            context.cancel = Some(Arc::new(req.cancel.clone()));
        }
        Self::append_queued_guidance(&mut req.task, &admission.guidance);
        Ok((req, admission))
    }

    async fn dispatch_admitted_attempt(
        &self,
        req: DispatchRequest,
        admission: super::control::SubagentAttemptAdmission,
    ) -> Result<SubagentResult> {
        let binding = admission.binding.clone();
        let result = self.dispatch_inner(req, Some(binding)).await;
        let status = match &result {
            Ok(result) => result.outcome.status,
            Err(error) => subagent_status_from_error(error),
        };
        admission.settle(status);
        result
    }

    /// Deliver a live instruction to one exact active attempt.
    pub async fn send_message_tracked(
        &self,
        execution_id: &str,
        expected_attempt: u32,
        instruction: impl Into<String>,
    ) -> std::result::Result<SubagentMessageReceipt, SubagentControlError> {
        self.control_registry
            .send_message_tracked(execution_id, expected_attempt, instruction)
            .await
    }

    /// Queue guidance for one exact future attempt. Admission claims it once.
    pub fn queue_guidance(
        &self,
        task_id: &str,
        expected_next_attempt: u32,
        instruction: impl Into<String>,
    ) -> std::result::Result<SubagentGuidanceQueueReceipt, SubagentControlError> {
        self.control_registry
            .queue_guidance(task_id, expected_next_attempt, instruction)
    }

    /// Cancel one exact attempt and wait until its dispatch has settled.
    pub async fn interrupt_subagent(
        &self,
        execution_id: &str,
        expected_attempt: u32,
    ) -> std::result::Result<SubagentInterruptOutcome, SubagentControlError> {
        self.control_registry
            .interrupt(execution_id, expected_attempt)
            .await
    }

    /// Request an exact attempt interruption without waiting for settlement.
    ///
    /// This process-local acknowledgement may be queued before dispatch
    /// admission. Durable callers must validate the corresponding TaskClaim
    /// before invoking this registry-level projection.
    pub fn request_interrupt(
        &self,
        identity: SubagentAttemptIdentity,
    ) -> std::result::Result<super::control::SubagentInterruptRequestReceipt, SubagentControlError>
    {
        self.control_registry.request_interrupt(identity)
    }

    /// Bind a claimed Team task to its exact live-control identity before it
    /// waits for execution capacity. The later dispatch consumes this binding.
    pub(crate) fn reserve_attempt(
        &self,
        identity: SubagentAttemptIdentity,
        cancel: CancellationToken,
    ) -> std::result::Result<(), SubagentControlError> {
        self.control_registry.reserve(identity, cancel)
    }

    pub(crate) fn retire_attempt_control(
        &self,
        identity: &SubagentAttemptIdentity,
    ) -> std::result::Result<bool, SubagentControlError> {
        self.control_registry.retire_exact(identity)
    }

    pub(crate) fn reconcile_attempt_control(
        &self,
        control_scope_id: &str,
        run_id: &str,
        current_execution_ids: &HashSet<String>,
    ) -> std::result::Result<(), SubagentControlError> {
        self.control_registry
            .reconcile_scope(control_scope_id, run_id, current_execution_ids)
    }

    /// Stamp identity/lineage basics and install the default uplink sink on a
    /// dispatch request.
    ///
    /// Precedence: caller-stamped lineage fields always win (the `agent_tool`
    /// path fills the parent path/execution id; application task runtimes fill
    /// task/attempt/revision); only missing basics are derived here. An
    /// application-provided uplink sink is never replaced — the framework
    /// default (event bus + shared control-registry delivery) is a fallback,
    /// not an override.
    fn enrich_dispatch_context(&self, req: &mut DispatchRequest) {
        let Some(context) = req.runtime_context.as_mut() else {
            return;
        };
        let lineage = context
            .subagent_lineage
            .get_or_insert_with(Default::default);
        if lineage.agent_name.is_none() {
            lineage.agent_name = Some(req.agent_name.clone());
        }
        if lineage.parent_agent.is_none() {
            lineage.parent_agent = Some(req.parent_agent.clone());
        }
        if lineage.agent_path.is_none() {
            lineage.agent_path = Some(format!("root/{}", req.agent_name));
        }
        if lineage.execution_id.is_none() {
            lineage.execution_id = context.execution_id.clone();
        }
        if lineage.run_id.is_none() {
            lineage.run_id = context.run_id.clone();
        }
        if context.uplink.is_none() {
            context.uplink = Some(default_uplink_sink(Arc::clone(&self.registry)));
        }
    }

    fn event_publisher(&self, req: &DispatchRequest) -> Result<SubagentEventPublisher> {
        let runtime = req.runtime_context.as_ref();
        let transport_identity = EventIdentity::from_runtime_context(runtime)?;
        let invocation_identity = Self::event_invocation_identity(req, &transport_identity)?;
        self.registry
            .event_bus()
            .publisher(transport_identity, invocation_identity)
    }

    fn event_invocation_identity(
        req: &DispatchRequest,
        transport_identity: &EventIdentity,
    ) -> Result<SubagentInvocationIdentity> {
        let runtime = req.runtime_context.as_ref();
        SubagentInvocationIdentity::from_lineage(
            req.parent_agent.clone(),
            req.agent_name.clone(),
            transport_identity,
            runtime.and_then(|context| context.subagent_lineage.as_ref()),
        )
    }

    fn retarget_dispatch_context(req: &mut DispatchRequest) {
        let Some(context) = req.runtime_context.as_mut() else {
            return;
        };
        let lineage = context
            .subagent_lineage
            .get_or_insert_with(Default::default);
        lineage.agent_name = Some(req.agent_name.clone());
        lineage.parent_agent = Some(req.parent_agent.clone());
        lineage.agent_path = Some(
            lineage
                .agent_path
                .as_deref()
                .and_then(|path| path.rsplit_once('/').map(|(parent, _)| parent))
                .map(|parent| format!("{parent}/{}", req.agent_name))
                .unwrap_or_else(|| format!("root/{}", req.agent_name)),
        );
    }

    fn emit_pre_execution_failure(
        publisher: &SubagentEventPublisher,
        req: &DispatchRequest,
        error: &ReactError,
    ) -> Result<()> {
        let status = subagent_status_from_error(error);
        let detail = error.to_string();
        let outcome = SubagentOutcome::terminal(status, detail.clone(), vec![detail.clone()]);
        let runtime = req.runtime_context.as_ref();
        if status == SubagentStatus::Cancelled {
            publisher.emit(SubagentEvent::DispatchCancelled {
                parent: req.parent_agent.clone(),
                agent: req.agent_name.clone(),
                outcome,
                execution_id: runtime.and_then(|context| context.execution_id.clone()),
                run_id: runtime.and_then(|context| context.run_id.clone()),
            })?;
        } else {
            publisher.emit(SubagentEvent::DispatchFailed {
                parent: req.parent_agent.clone(),
                agent: req.agent_name.clone(),
                error: detail,
                status,
                outcome,
                execution_id: runtime.and_then(|context| context.execution_id.clone()),
                run_id: runtime.and_then(|context| context.run_id.clone()),
            })?;
        }
        Ok(())
    }

    fn terminal_event_for_result(
        parent: &str,
        agent: &str,
        result: &mut SubagentResult,
        execution_id: Option<String>,
        run_id: Option<String>,
    ) -> SubagentEvent {
        match result.outcome.status {
            SubagentStatus::Cancelled => SubagentEvent::DispatchCancelled {
                parent: parent.to_string(),
                agent: agent.to_string(),
                outcome: result.outcome.clone(),
                execution_id,
                run_id,
            },
            SubagentStatus::Completed => SubagentEvent::DispatchCompleted {
                parent: parent.to_string(),
                agent: agent.to_string(),
                duration_ms: u64::try_from(result.duration.as_millis()).unwrap_or(u64::MAX),
                tokens_used: result
                    .tokens_used
                    .map(|tokens| u64::try_from(tokens).unwrap_or(u64::MAX)),
                iterations: Some(u64::try_from(result.iterations).unwrap_or(u64::MAX)),
                output: result.output.clone(),
                outcome: result.outcome.clone(),
                execution_id,
                run_id,
            },
            status => {
                let status = if status == SubagentStatus::Running {
                    result.outcome.status = SubagentStatus::Failed;
                    result.outcome.summary =
                        "Subagent returned without a terminal outcome".to_string();
                    SubagentStatus::Failed
                } else {
                    status
                };
                let error = if result.outcome.summary.is_empty() {
                    format!("Subagent '{agent}' reported {}", status.as_str())
                } else {
                    result.outcome.summary.clone()
                };
                SubagentEvent::DispatchFailed {
                    parent: parent.to_string(),
                    agent: agent.to_string(),
                    error,
                    status,
                    outcome: result.outcome.clone(),
                    execution_id,
                    run_id,
                }
            }
        }
    }

    // Keep dispatch lazy and boxed: strategies can dispatch further Subagents,
    // while the future itself already carries Rust's must-use contract.
    fn dispatch_inner(
        &self,
        mut req: DispatchRequest,
        control: Option<SubagentAttemptBinding>,
    ) -> futures::future::BoxFuture<'_, Result<SubagentResult>> {
        Box::pin(async move {
            let mut retry_count: u32 = 0;
            let max_retries: u32 = 3; // Prevent infinite retry loops
            // Save parent cancel token so retry/delegate paths propagate cancellation
            // instead of creating independent tokens (P1 — CancellationToken propagation).
            let parent_cancel = req.cancel.clone();

            // Stamp identity and create the single attempt-scoped ordering
            // authority before any accepted dispatch can settle or fail setup.
            self.enrich_dispatch_context(&mut req);
            let event_publisher = self.event_publisher(&req)?;
            let initial_registration = self.registry.get(&req.agent_name).await;
            let initial_mode = req
                .mode_override
                .clone()
                .or_else(|| {
                    initial_registration
                        .as_ref()
                        .map(|registered| registered.definition.execution_mode.clone())
                })
                .unwrap_or(ExecutionMode::Sync);
            let runtime = req.runtime_context.as_ref();
            event_publisher.emit(SubagentEvent::DispatchStarted {
                parent: req.parent_agent.clone(),
                agent: req.agent_name.clone(),
                mode: initial_mode.clone(),
                task: req.task.clone(),
                execution_id: runtime.and_then(|context| context.execution_id.clone()),
                run_id: runtime.and_then(|context| context.run_id.clone()),
                conversation_id: runtime.and_then(|context| context.conversation_id.clone()),
                message_id: runtime.and_then(|context| context.message_id.clone()),
                background: req.background,
            })?;

            if parent_cancel.is_cancelled() {
                let result = SubagentResult::cancelled(
                    req.agent_name.clone(),
                    "Cancelled before execution",
                    initial_mode,
                );
                event_publisher.emit(SubagentEvent::DispatchCancelled {
                    parent: req.parent_agent.clone(),
                    agent: req.agent_name.clone(),
                    outcome: result.outcome.clone(),
                    execution_id: runtime.and_then(|context| context.execution_id.clone()),
                    run_id: runtime.and_then(|context| context.run_id.clone()),
                })?;
                return Ok(result);
            }

            if req.delegation_policy.delegate_depth > req.delegation_policy.max_delegate_depth {
                let error = ReactError::Other(format!(
                    "Delegation depth exceeded (max {}): agent '{}'",
                    req.delegation_policy.max_delegate_depth, req.agent_name
                ));
                Self::emit_pre_execution_failure(&event_publisher, &req, &error)?;
                return Err(error);
            }
            if initial_registration.is_none() {
                let error = ReactError::Other(format!("Subagent '{}' not found", req.agent_name));
                Self::emit_pre_execution_failure(&event_publisher, &req, &error)?;
                return Err(error);
            }

            loop {
                // Guard against excessive retries
                if retry_count > max_retries {
                    let error =
                        ReactError::Agent(Box::new(AgentError::ContextLimitExceeded(format!(
                            "Max retry count exceeded ({}): agent '{}'",
                            max_retries, req.agent_name
                        ))));
                    Self::emit_pre_execution_failure(&event_publisher, &req, &error)?;
                    return Err(error);
                }

                // Look up definition
                let registered = match self.registry.get(&req.agent_name).await {
                    Some(registered) => registered,
                    None => {
                        let error =
                            ReactError::Other(format!("Subagent '{}' not found", req.agent_name));
                        Self::emit_pre_execution_failure(&event_publisher, &req, &error)?;
                        return Err(error);
                    }
                };

                let mode = req
                    .mode_override
                    .as_ref()
                    .unwrap_or(&registered.definition.execution_mode)
                    .clone();
                let runtime_run_id = req
                    .runtime_context
                    .as_ref()
                    .and_then(|ctx| ctx.run_id.as_deref())
                    .unwrap_or("<none>");
                // Extract stable identity for event payload (Option<String>).
                // Used by all Dispatch* events so the bridge/frontend can route
                // thinking/tool/token streams without temp id allocation.
                let event_execution_id = req
                    .runtime_context
                    .as_ref()
                    .and_then(|ctx| ctx.execution_id.clone());
                let event_run_id = req
                    .runtime_context
                    .as_ref()
                    .and_then(|ctx| ctx.run_id.clone());
                let has_trace_sink = req
                    .runtime_context
                    .as_ref()
                    .is_some_and(|ctx| ctx.trace_sink.is_some());
                let has_cancel = req
                    .runtime_context
                    .as_ref()
                    .is_some_and(|ctx| ctx.cancel.is_some());
                info!(
                    parent = %req.parent_agent,
                    subagent = %req.agent_name,
                    mode = ?mode,
                    attempt = retry_count + 1,
                    delegate_depth = req.delegation_policy.delegate_depth,
                    runtime_run_id = %runtime_run_id,
                    has_runtime_context = req.runtime_context.is_some(),
                    has_trace_sink,
                    has_cancel,
                    task_chars = req.task.chars().count(),
                    "subagent_dispatch_start"
                );

                // Build hook context
                let hook_ctx = SubagentHookContext {
                    parent_agent: req.parent_agent.clone(),
                    subagent_name: req.agent_name.clone(),
                    execution_mode: mode.clone(),
                    task: req.task.clone(),
                    attempt: 1 + retry_count,
                };

                if self.config.enable_hooks {
                    self.hooks.before_dispatch(&hook_ctx).await;
                }

                // Snapshot fields needed in error path before `req` is moved
                let req_agent_name = req.agent_name.clone();
                let req_parent_agent = req.parent_agent.clone();
                let delegation_policy = req.delegation_policy;

                // Fire unified SubagentStart for this concrete dispatch attempt.
                if let Some(ref executor) = self.config.unified_hook_executor {
                    let ctx = correlate_subagent_hook(
                        crate::skills::hooks::HookContext::for_subagent_start(
                            &req_agent_name,
                            &mode.to_string(),
                            &req.task,
                            "", // session_id not available at this layer
                            &req_parent_agent,
                        ),
                        event_run_id.as_deref(),
                        event_execution_id.as_deref(),
                        hook_ctx.attempt,
                    );
                    executor(ctx).await;
                }

                // Dispatch based on mode
                let start = Instant::now();
                let result = match mode {
                    ExecutionMode::Sync => {
                        self.dispatch_sync(&req, control.clone(), event_publisher.clone())
                            .await
                    }
                    ExecutionMode::Fork => {
                        self.dispatch_fork(&req, control.clone(), event_publisher.clone())
                            .await
                    }
                    ExecutionMode::Teammate => {
                        // Teammate mode: spawn independently, then await result
                        match self
                            .dispatch_teammate_with_control(
                                req.clone(),
                                control.clone(),
                                event_publisher.clone(),
                                false,
                            )
                            .await
                        {
                            Ok(handle) => handle.join().await,
                            Err(e) => Err(e),
                        }
                    }
                    ExecutionMode::Team => self.dispatch_team(&req, event_publisher.clone()).await,
                };

                let duration = start.elapsed();

                match result {
                    Ok(mut sub_result) => {
                        sub_result.duration = duration;
                        sub_result.mode = mode.clone();
                        info!(
                            parent = %req_parent_agent,
                            subagent = %req_agent_name,
                            mode = ?mode,
                            duration_ms = duration.as_millis() as u64,
                            output_chars = sub_result.output.chars().count(),
                            tokens_used = ?sub_result.tokens_used,
                            iterations = sub_result.iterations,
                            "subagent_dispatch_complete"
                        );

                        event_publisher.emit(Self::terminal_event_for_result(
                            &req_parent_agent,
                            &req_agent_name,
                            &mut sub_result,
                            event_execution_id.clone(),
                            event_run_id.clone(),
                        ))?;

                        if self.config.enable_hooks {
                            self.hooks.after_dispatch(&hook_ctx, &sub_result).await;
                        }

                        // Every Start has exactly one Stop. An executor may return a
                        // structured cancelled/failed outcome inside Ok, so map the
                        // outcome instead of assuming Completed from the Result arm.
                        if let Some(ref executor) = self.config.unified_hook_executor {
                            let ctx = correlate_subagent_hook(
                                crate::skills::hooks::HookContext::for_subagent_stop(
                                    &req_agent_name,
                                    &mode.to_string(),
                                    &sub_result.output,
                                    hook_stop_status(sub_result.outcome.status),
                                    "",
                                    &req_parent_agent,
                                ),
                                event_run_id.as_deref(),
                                event_execution_id.as_deref(),
                                hook_ctx.attempt,
                            );
                            executor(ctx).await;
                        }

                        return Ok(sub_result);
                    }
                    Err(e) => {
                        let error_str = e.to_string();
                        let status = subagent_status_from_error(&e);
                        let terminal_result = SubagentOutcome::terminal(
                            status,
                            error_str.clone(),
                            vec![error_str.clone()],
                        );
                        warn!(
                            parent = %req_parent_agent,
                            subagent = %req_agent_name,
                            mode = ?mode,
                            error = %error_str,
                            "subagent_dispatch_failed"
                        );

                        // Close this attempt before cancellation returns or a hook
                        // policy starts another attempt. Previously cancellation
                        // returned above the only Stop call, while retries emitted
                        // multiple Starts followed by one terminal Stop.
                        if let Some(ref executor) = self.config.unified_hook_executor {
                            let ctx = correlate_subagent_hook(
                                crate::skills::hooks::HookContext::for_subagent_stop(
                                    &req_agent_name,
                                    &mode.to_string(),
                                    &format!("error: {error_str}"),
                                    hook_stop_status(status),
                                    "",
                                    &req_parent_agent,
                                ),
                                event_run_id.as_deref(),
                                event_execution_id.as_deref(),
                                hook_ctx.attempt,
                            );
                            executor(ctx).await;
                        }

                        if status == SubagentStatus::Cancelled {
                            event_publisher.emit(SubagentEvent::DispatchCancelled {
                                parent: req_parent_agent.clone(),
                                agent: req_agent_name.clone(),
                                outcome: terminal_result,
                                execution_id: event_execution_id.clone(),
                                run_id: event_run_id.clone(),
                            })?;
                            return Err(e);
                        }

                        if self.config.enable_hooks {
                            let decision = self.hooks.on_failure(&hook_ctx, &error_str).await;
                            match decision {
                                super::hooks::SubagentRetryDecision::Delegate {
                                    alternative_agent,
                                } => {
                                    if let Some(child_policy) = delegation_policy.child_policy() {
                                        info!(
                                            from = %hook_ctx.subagent_name,
                                            to = %alternative_agent,
                                            depth = child_policy.delegate_depth,
                                            "Delegating to alternative subagent"
                                        );
                                        retry_count = retry_count.saturating_add(1);
                                        let rt_ctx = req.runtime_context.clone();
                                        let retry_msg = req.message.clone();
                                        let prompt_payload = req.prompt_payload.clone();
                                        let prompt_context = req.prompt_context.clone();
                                        let parent_context = req.parent_context.clone();
                                        let constraints = req.constraints.clone();
                                        req = DispatchRequest {
                                            agent_name: alternative_agent,
                                            task: hook_ctx.task.clone(),
                                            mode_override: Some(hook_ctx.execution_mode.clone()),
                                            cancel: parent_cancel.child_token(),
                                            parent_agent: hook_ctx.parent_agent.clone(),
                                            parent_context,
                                            delegation_policy: child_policy,
                                            runtime_context: rt_ctx,
                                            message: retry_msg,
                                            prompt_payload,
                                            prompt_context,
                                            constraints,
                                            background: false,
                                        };
                                        Self::retarget_dispatch_context(&mut req);
                                        event_publisher.retarget_from_lineage(
                                            req.parent_agent.clone(),
                                            req.agent_name.clone(),
                                            req.runtime_context.as_ref().and_then(|context| {
                                                context.subagent_lineage.as_ref()
                                            }),
                                        )?;
                                        // This attempt is recoverable, so it is not a terminal event.
                                        continue;
                                    }
                                    warn!(
                                        agent = %hook_ctx.subagent_name,
                                        max_depth = delegation_policy.max_delegate_depth,
                                        "subagent delegation rejected at depth limit"
                                    );
                                }
                                super::hooks::SubagentRetryDecision::Retry { delay_secs } => {
                                    if retry_count < max_retries {
                                        info!(
                                            delay_secs,
                                            attempt = retry_count.saturating_add(2),
                                            "Retrying subagent dispatch"
                                        );
                                        tokio::time::sleep(Duration::from_secs(delay_secs)).await;
                                        retry_count = retry_count.saturating_add(1);
                                        let rt_ctx = req.runtime_context.clone();
                                        let retry_msg = req.message.clone();
                                        let prompt_payload = req.prompt_payload.clone();
                                        let prompt_context = req.prompt_context.clone();
                                        let parent_context = req.parent_context.clone();
                                        let constraints = req.constraints.clone();
                                        req = DispatchRequest {
                                            agent_name: hook_ctx.subagent_name.clone(),
                                            task: hook_ctx.task.clone(),
                                            mode_override: Some(hook_ctx.execution_mode.clone()),
                                            cancel: parent_cancel.child_token(),
                                            parent_agent: hook_ctx.parent_agent.clone(),
                                            parent_context,
                                            delegation_policy,
                                            runtime_context: rt_ctx,
                                            message: retry_msg,
                                            prompt_payload,
                                            prompt_context,
                                            constraints,
                                            background: false,
                                        };
                                        // This attempt is recoverable, so it is not a terminal event.
                                        continue;
                                    }
                                    warn!(
                                        agent = %hook_ctx.subagent_name,
                                        max_retries,
                                        "subagent retry limit reached"
                                    );
                                }
                                super::hooks::SubagentRetryDecision::Fail => {}
                            }
                        }

                        event_publisher.emit(SubagentEvent::DispatchFailed {
                            parent: req_parent_agent.clone(),
                            agent: req_agent_name.clone(),
                            error: error_str.clone(),
                            status,
                            outcome: terminal_result,
                            execution_id: event_execution_id.clone(),
                            run_id: event_run_id.clone(),
                        })?;

                        return Err(e);
                    }
                }
            }
        })
    }

    /// Clone internals so a background subagent can own an executor on a spawned task.
    fn clone_for_spawn(&self) -> Self {
        Self {
            registry: self.registry.clone(),
            hooks: self.hooks.clone(),
            config: SubagentExecutorConfig {
                max_concurrent_forks: self.config.max_concurrent_forks,
                default_timeout_secs: self.config.default_timeout_secs,
                enable_hooks: self.config.enable_hooks,
                unified_hook_executor: self.config.unified_hook_executor.clone(),
                isolation_provider: self.config.isolation_provider.clone(),
                prompt_compiler: self.config.prompt_compiler.clone(),
                shared_admission: self.config.shared_admission.clone(),
            },
            semaphore: self.semaphore.clone(),
            control_registry: self.control_registry.clone(),
            shared_admission: self.shared_admission.clone(),
            team_runtimes: self.team_runtimes.clone(),
        }
    }

    fn bind_attempt_runtime_identity(
        req: &mut DispatchRequest,
        identity: &SubagentAttemptIdentity,
    ) -> Result<()> {
        let context =
            req.runtime_context
                .get_or_insert_with(|| echo_core::tools::ExternalRunContext {
                    conversation_id: None,
                    run_id: None,
                    turn_id: Some(identity.execution_id.clone()),
                    execution_id: Some(identity.execution_id.clone()),
                    isolation_id: None,
                    message_id: None,
                    cancel: None,
                    trace_sink: None,
                    delegation_policy: None,
                    resource_guards: Vec::new(),
                    subagent_lineage: None,
                    uplink: None,
                });
        if let Some(existing) = context.execution_id.as_deref()
            && existing != identity.execution_id.as_str()
        {
            return Err(Self::control_react_error(
                SubagentControlError::ExecutionIdentityMismatch {
                    expected: identity.execution_id.clone(),
                    actual: existing.to_string(),
                },
            ));
        }
        context.execution_id = Some(identity.execution_id.clone());
        if context.turn_id.is_none() && context.run_id.is_none() {
            context.turn_id = Some(identity.execution_id.clone());
        }
        let lineage = context
            .subagent_lineage
            .get_or_insert_with(Default::default);
        lineage.execution_id = Some(identity.execution_id.clone());
        lineage.task_id = Some(identity.task_id.clone());
        lineage.attempt = Some(identity.attempt);
        if lineage.run_id.is_none() {
            lineage.run_id = context.run_id.clone();
        }
        Ok(())
    }

    fn append_queued_guidance(task: &mut String, guidance: &[String]) {
        if guidance.is_empty() {
            return;
        }
        task.push_str("\n\n[queued_guidance]");
        for instruction in guidance {
            task.push_str("\n- ");
            task.push_str(instruction);
        }
        task.push_str("\n[/queued_guidance]");
    }

    fn control_react_error(error: SubagentControlError) -> ReactError {
        ReactError::Other(format!("Subagent control rejected: {error}"))
    }

    /// Ensure `runtime_context.execution_id` is set (generate `agent_tool-{uuid}` if missing).
    fn ensure_background_execution_id(req: &mut DispatchRequest) -> String {
        let ctx = req
            .runtime_context
            .get_or_insert_with(|| echo_core::tools::ExternalRunContext {
                conversation_id: None,
                run_id: Some(format!("bg-{}", uuid::Uuid::new_v4().as_simple())),
                turn_id: None,
                execution_id: None,
                isolation_id: None,
                message_id: None,
                cancel: None,
                trace_sink: None,
                delegation_policy: None,
                resource_guards: Vec::new(),
                subagent_lineage: None,
                uplink: None,
            });
        if ctx
            .execution_id
            .as_ref()
            .map(|id| id.is_empty())
            .unwrap_or(true)
        {
            ctx.execution_id = Some(format!("agent_tool-{}", uuid::Uuid::new_v4()));
        }
        ctx.execution_id
            .clone()
            .unwrap_or_else(|| format!("agent_tool-{}", uuid::Uuid::new_v4()))
    }

    /// Non-blocking dispatch: spawn the normal `dispatch` path and return a handle
    /// immediately. Lifecycle events still fire on the registry event bus.
    ///
    /// Mirrors the `tokio::spawn` pattern of [`Self::dispatch_teammate`], but
    /// reuses Sync/Fork/Team routing via [`Self::dispatch`] rather than the
    /// teammate-only streaming path.
    pub async fn dispatch_background(
        &self,
        mut req: DispatchRequest,
    ) -> Result<BackgroundSubagentHandle> {
        // Fail fast if the target role is missing (same as sync dispatch).
        if self.registry.get(&req.agent_name).await.is_none() {
            return Err(ReactError::Other(format!(
                "Subagent '{}' not found",
                req.agent_name
            )));
        }

        let execution_id = Self::ensure_background_execution_id(&mut req);
        req.background = true;
        let agent_name = req.agent_name.clone();
        let agent_name_for_handle = agent_name.clone();
        let cancel = req.cancel.clone();
        let spawned = self.clone_for_spawn();

        let join_handle = tokio::spawn(async move {
            let result = spawned.dispatch(req).await;
            if let Err(error) = &result {
                warn!(agent = %agent_name, error = %error, "background subagent dispatch failed");
            }
            result
        });

        Ok(BackgroundSubagentHandle {
            execution_id,
            agent_name: agent_name_for_handle,
            cancel,
            join_handle: Arc::new(Mutex::new(Some(join_handle))),
        })
    }

    /// Non-blocking variant of [`Self::dispatch_attempt`].
    pub async fn dispatch_background_attempt(
        &self,
        req: DispatchRequest,
        identity: SubagentAttemptIdentity,
    ) -> Result<BackgroundSubagentHandle> {
        if self.registry.get(&req.agent_name).await.is_none() {
            return Err(ReactError::Other(format!(
                "Subagent '{}' not found",
                req.agent_name
            )));
        }
        let (mut req, admission) = self.admit_attempt(req, identity)?;
        req.background = true;
        let execution_id = admission.binding.identity().execution_id.clone();
        let agent_name = req.agent_name.clone();
        let agent_name_for_handle = agent_name.clone();
        let cancel = req.cancel.clone();
        let spawned = self.clone_for_spawn();

        let join_handle = tokio::spawn(async move {
            let result = spawned.dispatch_admitted_attempt(req, admission).await;
            if let Err(error) = &result {
                warn!(agent = %agent_name, error = %error, "controlled background subagent dispatch failed");
            }
            result
        });

        Ok(BackgroundSubagentHandle {
            execution_id,
            agent_name: agent_name_for_handle,
            cancel,
            join_handle: Arc::new(Mutex::new(Some(join_handle))),
        })
    }

    /// Dispatch a teammate, returning a handle for async polling.
    pub async fn dispatch_teammate(&self, mut req: DispatchRequest) -> Result<TeammateHandle> {
        self.enrich_dispatch_context(&mut req);
        let event_publisher = self.event_publisher(&req)?;
        let runtime = req.runtime_context.as_ref();
        event_publisher.emit(SubagentEvent::DispatchStarted {
            parent: req.parent_agent.clone(),
            agent: req.agent_name.clone(),
            mode: ExecutionMode::Teammate,
            task: req.task.clone(),
            execution_id: runtime.and_then(|context| context.execution_id.clone()),
            run_id: runtime.and_then(|context| context.run_id.clone()),
            conversation_id: runtime.and_then(|context| context.conversation_id.clone()),
            message_id: runtime.and_then(|context| context.message_id.clone()),
            background: req.background,
        })?;
        match self
            .dispatch_teammate_with_control(req.clone(), None, event_publisher.clone(), true)
            .await
        {
            Ok(handle) => Ok(handle),
            Err(error) => {
                Self::emit_pre_execution_failure(&event_publisher, &req, &error)?;
                Err(error)
            }
        }
    }

    async fn dispatch_teammate_with_control(
        &self,
        req: DispatchRequest,
        control: Option<SubagentAttemptBinding>,
        event_publisher: SubagentEventPublisher,
        settle_in_handle: bool,
    ) -> Result<TeammateHandle> {
        let registered =
            self.registry.get(&req.agent_name).await.ok_or_else(|| {
                ReactError::Other(format!("Subagent '{}' not found", req.agent_name))
            })?;

        let agent_arc = self.isolated_dispatch_agent(&req.agent_name).await?;

        let child_token = req.cancel.child_token();
        let handle_cancel = child_token.clone();
        let compiled = self.compile_invocation(
            &req,
            ExecutionMode::Teammate,
            registered.definition.inherit_history,
            agent_arc.as_ref(),
        );
        let agent_name = req.agent_name.clone();
        let parent_agent = req.parent_agent.clone();
        let timeout_secs = if registered.definition.timeout_secs > 0 {
            registered.definition.timeout_secs
        } else {
            self.config.default_timeout_secs
        };

        let handle_id = format!("tm_{}", uuid::Uuid::new_v4().as_simple());

        // Extract stable identity for event payload (moved into the spawn).
        let event_execution_id = req
            .runtime_context
            .as_ref()
            .and_then(|ctx| ctx.execution_id.clone());
        let event_run_id = req
            .runtime_context
            .as_ref()
            .and_then(|ctx| ctx.run_id.clone());
        let invocation = AgentInvocationContext {
            runtime: req.runtime_context.clone(),
            working_dir: agent_arc.working_dir(),
            ..AgentInvocationContext::default()
        };

        let join_handle = tokio::spawn(async move {
            let _permit = child_token.clone();
            let start = Instant::now();

            let mut result = if timeout_secs > 0 {
                // Race between timeout, cancellation, and execution
                tokio::select! {
                    biased; // Check cancellation first
                    _ = child_token.cancelled() => {
                        Err(ReactError::Agent(Box::new(AgentError::Interrupted)))
                    }
                    _ = tokio::time::sleep(Duration::from_secs(timeout_secs)) => {
                        child_token.cancel();
                        Err(ReactError::Agent(Box::new(AgentError::Timeout(format!(
                            "Teammate '{}' timed out after {}s",
                            agent_name, timeout_secs
                        )))))
                    }
                    r = Self::execute_agent_streaming(
                        agent_arc.clone(),
                        compiled.clone(),
                        child_token.clone(),
                        invocation.clone(),
                        &parent_agent,
                        &agent_name,
                        ExecutionMode::Teammate,
                        start,
                        event_execution_id.clone(),
                        event_run_id.clone(),
                        control.clone(),
                        event_publisher.clone(),
                    ) => r,
                }
            } else {
                // Race between cancellation and execution
                tokio::select! {
                    biased;
                    _ = child_token.cancelled() => {
                        Err(ReactError::Agent(Box::new(AgentError::Interrupted)))
                    }
                    r = Self::execute_agent_streaming(
                        agent_arc.clone(),
                        compiled.clone(),
                        child_token.clone(),
                        invocation.clone(),
                        &parent_agent,
                        &agent_name,
                        ExecutionMode::Teammate,
                        start,
                        event_execution_id.clone(),
                        event_run_id.clone(),
                        control.clone(),
                        event_publisher.clone(),
                    ) => r,
                }
            };
            if settle_in_handle {
                match &mut result {
                    Ok(value) => {
                        event_publisher.emit(Self::terminal_event_for_result(
                            &parent_agent,
                            &agent_name,
                            value,
                            event_execution_id.clone(),
                            event_run_id.clone(),
                        ))?;
                    }
                    Err(error) => {
                        let status = subagent_status_from_error(error);
                        let outcome = SubagentOutcome::terminal(
                            status,
                            error.to_string(),
                            vec![error.to_string()],
                        );
                        if status == SubagentStatus::Cancelled {
                            event_publisher.emit(SubagentEvent::DispatchCancelled {
                                parent: parent_agent.clone(),
                                agent: agent_name.clone(),
                                outcome,
                                execution_id: event_execution_id.clone(),
                                run_id: event_run_id.clone(),
                            })?;
                        } else {
                            event_publisher.emit(SubagentEvent::DispatchFailed {
                                parent: parent_agent.clone(),
                                agent: agent_name.clone(),
                                error: error.to_string(),
                                status,
                                outcome,
                                execution_id: event_execution_id.clone(),
                                run_id: event_run_id.clone(),
                            })?;
                        }
                    }
                }
            }
            result
        });

        Ok(TeammateHandle {
            id: handle_id,
            agent_name: req.agent_name.clone(),
            cancel: handle_cancel,
            join_handle,
        })
    }

    /// Compile Team intent to one revisioned graph and execute it through the
    /// canonical `RuntimeTaskService`.
    async fn dispatch_team(
        &self,
        req: &DispatchRequest,
        event_publisher: SubagentEventPublisher,
    ) -> Result<SubagentResult> {
        let registered =
            self.registry.get(&req.agent_name).await.ok_or_else(|| {
                ReactError::Other(format!("Subagent '{}' not found", req.agent_name))
            })?;
        let spec = registered.definition.team.clone().ok_or_else(|| {
            ReactError::Other("Team mode requested but definition has no TeamSpec".to_string())
        })?;
        let delegation_policy = req.delegation_policy.child_policy().ok_or_else(|| {
            ReactError::Other(format!(
                "Delegation depth exceeded before Team '{}' (max {})",
                req.agent_name, req.delegation_policy.max_delegate_depth
            ))
        })?;
        // Team is a graph coordinator rather than a model invocation. Keep its
        // objective raw; every concrete member dispatch below compiles exactly
        // once with the member's actual tools, workspace, and inherited context.
        let team_objective = req.task.clone();
        let run_id = req
            .runtime_context
            .as_ref()
            .and_then(|context| context.run_id.clone())
            .unwrap_or_else(|| format!("team-{}", uuid::Uuid::new_v4().as_simple()));
        let parent_agent = req.agent_name.clone();
        let team_prompt_payload = req.prompt_payload.clone();
        let team_prompt_context = req.prompt_context.clone();
        let team_constraints = req.constraints.clone();
        let team_message = req.message.clone();
        let team_parent_event_id = event_publisher
            .dispatch_started_event_id()
            .map(|event_id| event_id.as_str().to_string());
        let inherited_history = req
            .parent_context
            .clone()
            .filter(|context| !context.messages.is_empty() || context.parent_goal.is_some());
        let control_scope_id = format!(
            "team-control:{}:{}",
            run_id,
            req.runtime_context
                .as_ref()
                .and_then(|context| context.execution_id.as_deref())
                .map(str::to_string)
                .unwrap_or_else(|| uuid::Uuid::new_v4().to_string())
        );
        let attempt_control = Arc::new(
            self.attempt_control_handle(control_scope_id)
                .map_err(Self::control_react_error)?,
        );
        let reserve_control = Arc::clone(&attempt_control);
        let reserve_attempt: super::team::TeamReserveAttemptFn = Arc::new(move |context| {
            reserve_control
                .reserve(&context)
                .map_err(|error| error.to_string())
        });
        let interrupt_control = Arc::clone(&attempt_control);
        let request_interrupt: super::team::TeamRequestInterruptFn =
            Arc::new(move |run_id, task_id, claim| {
                interrupt_control
                    .project_interrupt(&run_id, &task_id, &claim)
                    .map(Some)
            });
        let cleanup_control = Arc::clone(&attempt_control);
        let retire_attempt: super::team::TeamRetireAttemptFn =
            Arc::new(move |run_id, task, claim| {
                let cleanup_control = Arc::clone(&cleanup_control);
                Box::pin(async move { cleanup_control.retire(&run_id, &task, &claim) })
            });
        let reconcile_control = Arc::clone(&attempt_control);
        let reconcile_attempts: super::team::TeamReconcileAttemptFn =
            Arc::new(move |run_id, current_execution_ids| {
                reconcile_control
                    .reconcile(&run_id, &current_execution_ids)
                    .map_err(|error| error.to_string())
            });
        let spawned = self.clone_for_spawn();
        let dispatch_control = attempt_control;
        let dispatch: super::team::TeamDispatchFn = Arc::new(move |request| {
            let super::team::TeamDispatchRequest {
                member: agent_name,
                task,
                context,
            } = request;
            let executor = spawned.clone_for_spawn();
            let attempt_control = Arc::clone(&dispatch_control);
            let parent_agent = parent_agent.clone();
            let parent_context = inherited_history.clone();
            let prompt_payload = team_prompt_payload.clone();
            let message = team_message.clone();
            let mut prompt_context = team_prompt_context.clone();
            if let Some(context) = prompt_context.as_mut() {
                context.task_title = Some(task.clone());
            }
            let constraints = team_constraints.clone();
            let parent_event_id = team_parent_event_id.clone();
            Box::pin(async move {
                let member = executor.registry.get(&agent_name).await.ok_or_else(|| {
                    ReactError::Other(format!("Team Subagent '{agent_name}' not registered"))
                })?;
                if member.definition.execution_mode == ExecutionMode::Team {
                    return Err(ReactError::Other(format!(
                        "nested Team mode is not supported for '{agent_name}'"
                    )));
                }
                let mut runtime_context = context.runtime_context();
                runtime_context.subagent_lineage =
                    runtime_context.subagent_lineage.map(|mut lineage| {
                        lineage.agent_name = Some(agent_name.clone());
                        lineage.parent_agent = Some(parent_agent.clone());
                        lineage.parent_event_id = parent_event_id.clone();
                        lineage
                    });
                attempt_control
                    .dispatch(
                        DispatchRequest {
                            agent_name,
                            task,
                            mode_override: None,
                            cancel: context.cancellation_token().clone(),
                            parent_agent,
                            parent_context,
                            delegation_policy: NestedDelegationPolicy::default(),
                            runtime_context: Some(runtime_context),
                            message,
                            prompt_payload,
                            prompt_context,
                            constraints,
                            background: false,
                        },
                        context,
                    )
                    .await
            })
        });
        let start = Instant::now();
        let control = super::team::TeamDispatchControl {
            reserve_attempt,
            request_interrupt,
            retire_attempt,
            reconcile_attempts,
        };
        let dispatch_controller = super::team::closure_dispatch_controller(dispatch, control);
        let runtime_handle = super::team::runtime_handle_for_controller(
            run_id.clone(),
            dispatch_controller,
            echo_orchestration::tasks::RuntimeTaskServiceConfig {
                max_concurrent_subagents: spec.config.max_concurrent.max(1),
                delegation_policy,
                ..echo_orchestration::tasks::RuntimeTaskServiceConfig::default()
            },
        );
        let active = runtime_handle.start_execution();
        self.retain_team_runtime(runtime_handle.clone());
        let _retention = TeamRuntimeRetentionGuard {
            index: Arc::clone(&self.team_runtimes),
        };
        let result = runtime_handle
            .execute_started(&spec, &team_objective, req.cancel.child_token(), active)
            .await?;
        let tokens_used = result
            .usage
            .as_ref()
            .map(|usage| usize::try_from(usage.total_tokens).unwrap_or(usize::MAX));
        Ok(SubagentResult {
            agent_name: req.agent_name.clone(),
            output: result.output,
            outcome: SubagentOutcome {
                status: SubagentStatus::Completed,
                ..SubagentOutcome::default()
            },
            duration: start.elapsed(),
            iterations: 1,
            tokens_used,
            was_truncated: false,
            mode: ExecutionMode::Team,
            isolation_observed: ObservedIsolation::new("subagent"),
            llm_usage: result.usage,
        }
        .with_structured(
            req.runtime_context
                .as_ref()
                .and_then(|context| context.execution_id.as_deref()),
            std::env::current_dir().ok().as_deref(),
        ))
    }

    // ── Internal dispatch methods ──────────────────────────────────────────

    fn compile_invocation(
        &self,
        req: &DispatchRequest,
        mode: ExecutionMode,
        inherit_history: Option<usize>,
        agent: &dyn Agent,
    ) -> CompiledSubagentInvocation {
        let transfer_policy = if matches!(
            mode,
            ExecutionMode::Fork | ExecutionMode::Teammate | ExecutionMode::Team
        ) && req
            .parent_context
            .as_ref()
            .is_some_and(|context| !context.messages.is_empty())
        {
            ContextTransferPolicy::InheritStructured
        } else {
            ContextTransferPolicy::Fresh
        };
        let mut context = req.prompt_context.clone().unwrap_or_default();
        if context.user_goal.is_none() {
            context.user_goal = req
                .parent_context
                .as_ref()
                .and_then(|parent| parent.parent_goal.clone());
        }
        if context.workspace.is_none() {
            context.workspace = agent.working_dir();
        }
        if context.constraints.is_empty() {
            context.constraints = req.constraints.clone();
        }
        let allowed_tools = req
            .parent_context
            .as_ref()
            .and_then(|parent| parent.allowed_tools.as_deref())
            .filter(|allowed| !allowed.is_empty());
        let capability_override =
            allowed_tools.map(|allowed| effective_capabilities(agent, Some(allowed)));
        self.config
            .prompt_compiler
            .compile_invocation(&SubagentInvocation {
                agent_name: &req.agent_name,
                task: &req.task,
                mode,
                transfer_policy,
                history: req
                    .parent_context
                    .as_ref()
                    .map(|context| context.messages.as_slice())
                    .unwrap_or_default(),
                history_limit: inherit_history,
                current_message: req.message.as_ref(),
                context: &context,
                capability_override: capability_override.as_ref(),
                payload: req.prompt_payload.as_ref(),
            })
    }

    #[allow(clippy::too_many_arguments)]
    async fn execute_agent_streaming(
        agent: Arc<dyn Agent>,
        compiled: CompiledSubagentInvocation,
        cancel: CancellationToken,
        mut invocation: AgentInvocationContext,
        parent: &str,
        subagent: &str,
        mode: ExecutionMode,
        start: Instant,
        execution_id: Option<String>,
        run_id: Option<String>,
        control: Option<SubagentAttemptBinding>,
        event_publisher: SubagentEventPublisher,
    ) -> Result<SubagentResult> {
        let artifact_base_dir = invocation
            .working_dir
            .clone()
            .or_else(|| std::env::current_dir().ok());
        let control_turn_id = control.as_ref().map(|binding| {
            invocation
                .runtime
                .as_ref()
                .and_then(|runtime| runtime.turn_id.clone().or_else(|| runtime.run_id.clone()))
                .unwrap_or_else(|| binding.identity().execution_id.clone())
        });
        let mut messages = compiled.messages;
        let current_message = messages.pop().ok_or_else(|| {
            ReactError::Other("Subagent prompt compiler returned no invocation message".to_string())
        })?;
        invocation.history = (!messages.is_empty()).then_some(messages);
        let event_identity = echo_core::agent::EventIdentity::from_invocation(&invocation)?;
        // Route by content: text-only invocations use the text streaming path
        // (agents that implement only `execute_stream` stay dispatch-
        // compatible); genuinely multimodal input requires the message
        // override. This mirrors the documented `DispatchRequest.message`
        // contract instead of assuming every agent implements both paths.
        let raw_stream = match current_message.content.as_text_ref() {
            Some(task) => {
                agent
                    .execute_stream_with_invocation_context(task, cancel, invocation)
                    .await?
            }
            None => {
                agent
                    .execute_stream_message_with_invocation_context(
                        current_message,
                        cancel,
                        invocation,
                    )
                    .await?
            }
        };
        let _steering_lease = if let Some(binding) = control {
            let turn_id = control_turn_id
                .ok_or_else(|| ReactError::Other("Subagent control turn id missing".to_string()))?;
            Some(
                binding
                    .attach(agent.clone(), turn_id)
                    .map_err(Self::control_react_error)?,
            )
        } else {
            None
        };
        let mut stream = echo_core::agent::envelope_event_stream(raw_stream, event_identity);
        let mut output = String::new();
        let mut in_thinking = false;
        let mut prompt_tokens: usize = 0;
        let mut completion_tokens: usize = 0;
        let mut usage_stats = super::usage::LlmUsageStats::default();
        let mut pending_tool_evidence = HashMap::<String, (String, serde_json::Value)>::new();
        let mut observed_evidence = Vec::new();
        let mut observed_artifacts = Vec::new();

        while let Some(event_result) = stream.next().await {
            let event = event_result?.payload;
            match event {
                AgentEvent::Token(content) => {
                    if in_thinking {
                        event_publisher.emit(SubagentEvent::DispatchThinkingDelta {
                            parent: parent.to_string(),
                            agent: subagent.to_string(),
                            content,
                            execution_id: execution_id.clone(),
                            run_id: run_id.clone(),
                        })?;
                    } else {
                        output.push_str(&content);
                        event_publisher.emit(SubagentEvent::DispatchTokenDelta {
                            parent: parent.to_string(),
                            agent: subagent.to_string(),
                            content,
                            execution_id: execution_id.clone(),
                            run_id: run_id.clone(),
                        })?;
                    }
                }
                AgentEvent::ThinkStart => {
                    in_thinking = true;
                    event_publisher.emit(SubagentEvent::DispatchThinkingStarted {
                        parent: parent.to_string(),
                        agent: subagent.to_string(),
                        execution_id: execution_id.clone(),
                        run_id: run_id.clone(),
                    })?;
                }
                AgentEvent::ThinkEnd {
                    prompt_tokens: pt,
                    completion_tokens: ct,
                } => {
                    in_thinking = false;
                    prompt_tokens = prompt_tokens.saturating_add(pt);
                    completion_tokens = completion_tokens.saturating_add(ct);
                    event_publisher.emit(SubagentEvent::DispatchThinkingEnded {
                        parent: parent.to_string(),
                        agent: subagent.to_string(),
                        prompt_tokens: pt,
                        completion_tokens: ct,
                        execution_id: execution_id.clone(),
                        run_id: run_id.clone(),
                    })?;
                }
                AgentEvent::LlmUsage {
                    model,
                    prompt_tokens: pt,
                    completion_tokens: ct,
                    total_tokens: tt,
                    cached_prompt_tokens: cpt,
                    cache_creation_prompt_tokens: ccpt,
                    usage_reported,
                } => {
                    usage_stats.record(&model, pt, ct, tt, cpt, ccpt, usage_reported);
                    event_publisher.emit(SubagentEvent::DispatchLlmUsage {
                        parent: parent.to_string(),
                        agent: subagent.to_string(),
                        model: model.clone(),
                        prompt_tokens: pt,
                        completion_tokens: ct,
                        total_tokens: tt,
                        cached_prompt_tokens: cpt,
                        cache_creation_prompt_tokens: ccpt,
                        usage_reported,
                        execution_id: execution_id.clone(),
                        run_id: run_id.clone(),
                    })?;
                }
                AgentEvent::ToolCall {
                    call_id,
                    invocation,
                } => {
                    pending_tool_evidence.insert(
                        call_id.clone(),
                        (invocation.name.clone(), invocation.args.clone()),
                    );
                    event_publisher.emit(SubagentEvent::DispatchToolStarted {
                        parent: parent.to_string(),
                        agent: subagent.to_string(),
                        call_id,
                        invocation,
                        execution_id: execution_id.clone(),
                        run_id: run_id.clone(),
                    })?;
                }
                AgentEvent::ToolResult {
                    call_id,
                    name,
                    result,
                } => {
                    let detail = result
                        .error
                        .as_deref()
                        .filter(|value| !value.is_empty())
                        .unwrap_or(&result.output);
                    let (subject, args) = pending_tool_evidence
                        .remove(&call_id)
                        .unwrap_or_else(|| (name.clone(), serde_json::Value::Null));
                    observed_evidence.push(SubagentEvidence {
                        kind: "tool_result".to_string(),
                        subject,
                        outcome: Some(if result.success {
                            "succeeded".to_string()
                        } else {
                            "failed".to_string()
                        }),
                        details: bounded_detail(detail),
                        source: SubagentEvidenceSource::Observed,
                        attributes: serde_json::json!({ "args": args }),
                    });
                    if let Some(artifact) = result.artifact.as_ref() {
                        observed_artifacts.push(SubagentArtifact {
                            path: artifact.path.to_string_lossy().to_string(),
                            kind: "tool_log".to_string(),
                            bytes: Some(artifact.artifact_bytes),
                            sha256: Some(artifact.sha256.clone()),
                            producer_execution_id: execution_id.clone(),
                            available: true,
                        });
                    }
                    event_publisher.emit(SubagentEvent::DispatchToolCompleted {
                        parent: parent.to_string(),
                        agent: subagent.to_string(),
                        call_id,
                        name,
                        result,
                        execution_id: execution_id.clone(),
                        run_id: run_id.clone(),
                    })?;
                }
                AgentEvent::FinalAnswer(answer) if !answer.is_empty() => {
                    output = answer;
                }
                AgentEvent::FinalAnswer(_) => {}
                AgentEvent::Cancelled => {
                    return Err(ReactError::Agent(Box::new(AgentError::Cancelled(format!(
                        "Subagent '{subagent}' cancelled"
                    )))));
                }
                AgentEvent::Error {
                    source,
                    message,
                    failure,
                } => {
                    return match failure.terminal_kind {
                        AgentTerminalKind::Cancelled => {
                            Err(ReactError::Agent(Box::new(AgentError::Cancelled(message))))
                        }
                        AgentTerminalKind::TimedOut => {
                            Err(ReactError::Agent(Box::new(AgentError::Timeout(message))))
                        }
                        AgentTerminalKind::PermissionDenied => Err(ReactError::Agent(Box::new(
                            AgentError::PermissionDenied(message),
                        ))),
                        AgentTerminalKind::Failed => {
                            Err(ReactError::Other(format!("{source}: {message}")))
                        }
                    };
                }
                _ => {}
            }
        }

        let tokens_used = Some(prompt_tokens.saturating_add(completion_tokens));
        let usage = if usage_stats.call_count > 0 {
            // Also update tokens_used from real usage stats for consistency.
            Some(usage_stats)
        } else {
            None
        };

        let status = SubagentStatus::Completed;
        let mut result = SubagentResult {
            agent_name: subagent.to_string(),
            output,
            outcome: SubagentOutcome {
                status,
                ..SubagentOutcome::default()
            },
            duration: start.elapsed(),
            iterations: 1,
            tokens_used,
            was_truncated: false,
            mode,
            isolation_observed: ObservedIsolation::default(),
            llm_usage: usage,
        }
        .with_structured(execution_id.as_deref(), artifact_base_dir.as_deref());
        merge_observed_evidence(&mut result.outcome, observed_evidence, observed_artifacts);
        Ok(result)
    }

    async fn isolated_dispatch_agent(&self, agent_name: &str) -> Result<Arc<dyn Agent>> {
        let agent = match self.registry.create_fresh_agent(agent_name).await? {
            Some(agent) => agent,
            None => self.registry.get_agent(agent_name).await.ok_or_else(|| {
                ReactError::Other(format!(
                    "Subagent '{}' not found or not instantiated",
                    agent_name
                ))
            })?,
        };
        Ok(agent)
    }

    /// Sync mode: execute one isolated invocation and return its result.
    async fn dispatch_sync(
        &self,
        req: &DispatchRequest,
        control: Option<SubagentAttemptBinding>,
        event_publisher: SubagentEventPublisher,
    ) -> Result<SubagentResult> {
        let agent_arc = self.isolated_dispatch_agent(&req.agent_name).await?;

        // Per-subagent override (0 = executor default). Sync now enforces a
        // timeout too (previously it blocked the parent indefinitely) — one
        // config (AgentConfig.subagent_timeout_secs) governs all three modes.
        let timeout_secs = match self.registry.get(&req.agent_name).await {
            Some(r) if r.definition.timeout_secs > 0 => r.definition.timeout_secs,
            _ => self.config.default_timeout_secs,
        };

        let start = Instant::now();
        let inherit_history = match self.registry.get(&req.agent_name).await {
            Some(r) => r.definition.inherit_history,
            None => None,
        };
        let compiled = self.compile_invocation(
            req,
            ExecutionMode::Sync,
            inherit_history,
            agent_arc.as_ref(),
        );
        let execution_cancel = req.cancel.child_token();
        let event_execution_id = req
            .runtime_context
            .as_ref()
            .and_then(|ctx| ctx.execution_id.clone());
        let event_run_id = req
            .runtime_context
            .as_ref()
            .and_then(|ctx| ctx.run_id.clone());
        let invocation = AgentInvocationContext {
            runtime: req.runtime_context.clone(),
            working_dir: agent_arc.working_dir(),
            ..AgentInvocationContext::default()
        };

        if timeout_secs > 0 {
            tokio::select! {
                biased;
                _ = execution_cancel.cancelled() => Err(ReactError::Agent(Box::new(
                    AgentError::Cancelled(format!("Sync subagent '{}' cancelled", req.agent_name))
                ))),
                r = tokio::time::timeout(
                    Duration::from_secs(timeout_secs),
                    Self::execute_agent_streaming(
                        agent_arc.clone(),
                        compiled.clone(),
                        execution_cancel.clone(),
                        invocation.clone(),
                        &req.parent_agent,
                        &req.agent_name,
                        ExecutionMode::Sync,
                        start,
                        event_execution_id.clone(),
                        event_run_id.clone(),
                        control.clone(),
                        event_publisher.clone(),
                    )
                ) => match r {
                    Ok(r) => r,
                    Err(_) => {
                        execution_cancel.cancel();
                        Err(ReactError::Agent(Box::new(AgentError::Timeout(format!(
                            "Sync subagent '{}' timed out after {}s",
                            req.agent_name, timeout_secs
                        )))))
                    }
                },
            }
        } else {
            Self::execute_agent_streaming(
                agent_arc,
                compiled,
                execution_cancel,
                invocation,
                &req.parent_agent,
                &req.agent_name,
                ExecutionMode::Sync,
                start,
                event_execution_id,
                event_run_id,
                control,
                event_publisher,
            )
            .await
        }
    }

    /// Fork mode: acquire semaphore, spawn task, await with timeout.
    async fn dispatch_fork(
        &self,
        req: &DispatchRequest,
        control: Option<SubagentAttemptBinding>,
        event_publisher: SubagentEventPublisher,
    ) -> Result<SubagentResult> {
        let registered =
            self.registry.get(&req.agent_name).await.ok_or_else(|| {
                ReactError::Other(format!("Subagent '{}' not found", req.agent_name))
            })?;
        let timeout_secs = if registered.definition.timeout_secs > 0 {
            registered.definition.timeout_secs
        } else {
            self.config.default_timeout_secs
        };
        let deadline = (timeout_secs > 0)
            .then(|| tokio::time::Instant::now() + Duration::from_secs(timeout_secs));
        enum ForkAdmission {
            Local(tokio::sync::OwnedSemaphorePermit),
            Shared(KeyedExecutionLease),
        }
        let shared_admission = self.shared_admission.read().await.clone();
        let permit = if let Some(admission) = shared_admission {
            let admission_key = req
                .runtime_context
                .as_ref()
                .and_then(|context| context.execution_id.as_deref())
                .map(str::to_string)
                .unwrap_or_else(|| uuid::Uuid::new_v4().as_simple().to_string());
            tokio::select! {
                biased;
                _ = req.cancel.cancelled() => {
                    return Err(ReactError::Agent(Box::new(AgentError::Cancelled(format!(
                        "Fork subagent '{}' cancelled while waiting for shared capacity",
                        req.agent_name
                    )))));
                }
                _ = async {
                    match deadline {
                        Some(deadline) => tokio::time::sleep_until(deadline).await,
                        None => std::future::pending().await,
                    }
                } => {
                    return Err(ReactError::Agent(Box::new(AgentError::Timeout(format!(
                        "Fork subagent '{}' timed out after {}s while waiting for shared capacity",
                        req.agent_name, timeout_secs
                    )))));
                }
                permit = admission.issue_wait(format!("subagent:{admission_key}")) => permit
                    .map(ForkAdmission::Shared)
                    .map_err(|error| ReactError::Other(format!("shared execution admission rejected Fork: {error}")))?,
            }
        } else {
            tokio::select! {
            biased;
            _ = req.cancel.cancelled() => {
                return Err(ReactError::Agent(Box::new(AgentError::Cancelled(format!(
                    "Fork subagent '{}' cancelled while waiting for capacity",
                    req.agent_name
                )))));
            }
            _ = async {
                match deadline {
                    Some(deadline) => tokio::time::sleep_until(deadline).await,
                    None => std::future::pending().await,
                }
            } => {
                return Err(ReactError::Agent(Box::new(AgentError::Timeout(format!(
                    "Fork subagent '{}' timed out after {}s while waiting for capacity",
                    req.agent_name, timeout_secs
                )))));
            }
            permit = self.semaphore.clone().acquire_owned() => permit
                .map(ForkAdmission::Local)
                .map_err(|error| ReactError::Other(format!("Semaphore error: {error}")))?,
            }
        };

        let agent_arc = tokio::select! {
            biased;
            _ = req.cancel.cancelled() => {
                return Err(ReactError::Agent(Box::new(AgentError::Cancelled(format!(
                    "Fork subagent '{}' cancelled during initialization",
                    req.agent_name
                )))));
            }
            _ = async {
                match deadline {
                    Some(deadline) => tokio::time::sleep_until(deadline).await,
                    None => std::future::pending().await,
                }
            } => {
                return Err(ReactError::Agent(Box::new(AgentError::Timeout(format!(
                    "Fork subagent '{}' timed out after {}s during initialization",
                    req.agent_name, timeout_secs
                )))));
            }
            agent = self.isolated_dispatch_agent(&req.agent_name) => agent?,
        };

        let agent_name = req.agent_name.clone();
        let parent_agent = req.parent_agent.clone();
        let cancel = req.cancel.clone();
        let message = req.message.clone();
        let prompt_compiler = self.config.prompt_compiler.clone();
        let prompt_task = req.task.clone();
        let prompt_parent_context = req.parent_context.clone();
        let prompt_payload = req.prompt_payload.clone();
        let prompt_context = req.prompt_context.clone();
        let prompt_constraints = req.constraints.clone();
        let prompt_inherit_history = registered.definition.inherit_history;
        // 跨 spawn 安全的值传递: 把外部 run context 带进 spawn 块。
        // Carry run context as an invocation value. Factory-backed Fork roles
        // receive a fresh agent instance; legacy pre-built roles still use the
        // cached instance without mutating shared runtime/working_dir fields.
        let mut runtime_context = req.runtime_context.clone();
        if let Some(ctx) = runtime_context.as_mut() {
            ctx.delegation_policy = Some(req.delegation_policy);
        }
        // Extract stable identity for event payload (moved into the spawn below).
        let event_execution_id = runtime_context
            .as_ref()
            .and_then(|ctx| ctx.execution_id.clone());
        let event_run_id = runtime_context.as_ref().and_then(|ctx| ctx.run_id.clone());

        let isolation_kind = registered.definition.isolation.clone();
        let isolation_provider = isolation_kind
            .as_ref()
            .and_then(|_| self.config.isolation_provider.clone());
        if isolation_kind.is_some() && isolation_provider.is_none() {
            // Local execution still requires this guard: silently dropping a
            // requested isolation boundary can corrupt user data.
            return Err(ReactError::Other(format!(
                "Subagent '{}' requests isolation but no IsolationProvider is configured; refusing to run without isolation",
                agent_name
            )));
        }
        let runtime_run_id = runtime_context
            .as_ref()
            .and_then(|ctx| ctx.run_id.as_deref())
            .unwrap_or("<none>");
        let has_trace_sink = runtime_context
            .as_ref()
            .is_some_and(|ctx| ctx.trace_sink.is_some());
        info!(
            parent = %parent_agent,
            subagent = %agent_name,
            runtime_run_id = %runtime_run_id,
            has_runtime_context = runtime_context.is_some(),
            has_trace_sink,
            timeout_secs,
            isolation = isolation_kind.as_deref().unwrap_or("context"),
            "subagent_fork_start"
        );
        // Prefer a caller-supplied stable isolation identity so retries of one
        // logical task can reuse the same worktree/workspace while preserving
        // their distinct execution ids for events and audit records.
        let isolation_identity = runtime_context
            .as_ref()
            .and_then(|context| {
                context
                    .isolation_id
                    .as_deref()
                    .or(context.execution_id.as_deref())
                    .or(context.run_id.as_deref())
                    .or(context.turn_id.as_deref())
            })
            .map(str::to_string)
            .unwrap_or_else(|| uuid::Uuid::new_v4().as_simple().to_string());
        let isolation_label = format!("{agent_name}-{isolation_identity}");
        let execution_cancel = cancel.child_token();
        let invocation_allowed_tools = req
            .parent_context
            .as_ref()
            .and_then(|context| context.allowed_tools.clone())
            .filter(|allowed| !allowed.is_empty());

        let result = tokio::spawn(async move {
            let _permit = permit;
            match &_permit {
                ForkAdmission::Local(permit) => {
                    let _ = permit;
                }
                ForkAdmission::Shared(lease) => {
                    let _ = lease;
                }
            }
            let start = Instant::now();

            // Check cancellation
            if execution_cancel.is_cancelled() {
                let mut result = SubagentResult::cancelled(
                    agent_name.clone(),
                    "Cancelled before execution",
                    ExecutionMode::Fork,
                );
                result.duration = start.elapsed();
                return Ok(result);
            }

            let mut isolation_handle: Option<super::isolation::IsolationHandle> = None;
            if let (Some(provider), Some(kind)) = (&isolation_provider, &isolation_kind) {
                let request = super::isolation::IsolationRequest {
                    kind: kind.clone(),
                    label: isolation_label,
                };
                match provider.isolate(&request) {
                    Ok(handle) => {
                        isolation_handle = Some(handle);
                    }
                    Err(error) => {
                        return Err(ReactError::Other(format!(
                            "Isolation '{}' for Fork subagent '{agent_name}' failed: {error}",
                            request.kind
                        )));
                    }
                }
            }
            let isolation_observed = isolation_handle
                .as_ref()
                .map(|handle| handle.observed.clone())
                .unwrap_or_else(|| ObservedIsolation::new("context"));
            let mut context = prompt_context.unwrap_or_default();
            if context.user_goal.is_none() {
                context.user_goal = prompt_parent_context
                    .as_ref()
                    .and_then(|parent| parent.parent_goal.clone());
            }
            if context.workspace.is_none() {
                context.workspace = isolation_handle
                    .as_ref()
                    .map(|handle| handle.path.clone())
                    .or_else(|| agent_arc.working_dir());
            }
            if context.constraints.is_empty() {
                context.constraints = prompt_constraints;
            }
            let capability_override = invocation_allowed_tools
                .as_deref()
                .map(|allowed| effective_capabilities(agent_arc.as_ref(), Some(allowed)));
            let compiled = prompt_compiler.compile_invocation(&SubagentInvocation {
                agent_name: &agent_name,
                task: &prompt_task,
                mode: ExecutionMode::Fork,
                transfer_policy: if prompt_parent_context
                    .as_ref()
                    .is_some_and(|context| !context.messages.is_empty())
                {
                    ContextTransferPolicy::InheritStructured
                } else {
                    ContextTransferPolicy::Fresh
                },
                history: prompt_parent_context
                    .as_ref()
                    .map(|context| context.messages.as_slice())
                    .unwrap_or_default(),
                history_limit: prompt_inherit_history,
                current_message: message.as_ref(),
                context: &context,
                capability_override: capability_override.as_ref(),
                payload: prompt_payload.as_ref(),
            });
            let disabled_tools = invocation_disabled_tools(
                agent_arc.tool_names(),
                invocation_allowed_tools.as_deref(),
            );
            let effective_working_dir = isolation_handle
                .as_ref()
                .map(|handle| handle.path.clone())
                .or_else(|| agent_arc.working_dir());
            let invocation = AgentInvocationContext {
                runtime: runtime_context.clone(),
                runtime_state_id: None,
                transcript_generation_id: None,
                working_dir: effective_working_dir,
                cancel: None,
                disabled_tools,
                visible_tools: None,
                run_budget: None,
                history: None,
                resource_guards: Vec::new(),
                input_lifecycle: None,
            };
            event_publisher.emit(SubagentEvent::DispatchIsolationObserved {
                parent: parent_agent.clone(),
                agent: agent_name.clone(),
                isolation: isolation_observed.clone(),
                execution_id: event_execution_id.clone(),
                run_id: event_run_id.clone(),
            })?;
            let mut result = if let Some(deadline) = deadline {
                tokio::select! {
                    biased;
                    _ = execution_cancel.cancelled() => Err(ReactError::Agent(Box::new(
                        AgentError::Cancelled(format!("Fork subagent '{}' cancelled", agent_name))
                    ))),
                    r = tokio::time::timeout_at(
                        deadline,
                        Self::execute_agent_streaming(
                            agent_arc.clone(),
                            compiled.clone(),
                            execution_cancel.clone(),
                            invocation.clone(),
                            &parent_agent,
                            &agent_name,
                            ExecutionMode::Fork,
                            start,
                            event_execution_id.clone(),
                            event_run_id.clone(),
                            control.clone(),
                            event_publisher.clone(),
                        )
                    ) => {
                        match r {
                            Ok(r) => r,
                            Err(_) => {
                                execution_cancel.cancel();
                                Err(ReactError::Agent(Box::new(AgentError::Timeout(format!(
                                    "Fork subagent '{}' timed out after {}s",
                                    agent_name, timeout_secs
                                )))))
                            }
                        }
                    }
                }
            } else {
                tokio::select! {
                    biased;
                    _ = execution_cancel.cancelled() => Err(ReactError::Agent(Box::new(
                        AgentError::Cancelled(format!("Fork subagent '{}' cancelled", agent_name))
                    ))),
                    r = Self::execute_agent_streaming(
                        agent_arc.clone(),
                        compiled.clone(),
                        execution_cancel.clone(),
                        invocation.clone(),
                        &parent_agent,
                        &agent_name,
                        ExecutionMode::Fork,
                        start,
                        event_execution_id.clone(),
                        event_run_id.clone(),
                        control.clone(),
                        event_publisher.clone(),
                    ) => r,
                }
            };
            if let Ok(subagent_result) = &mut result {
                subagent_result.isolation_observed = isolation_observed;
            }

            if let Some(handle) = isolation_handle {
                match (handle.finalize)() {
                    Ok(finalized) => {
                        if let Ok(mut r) = result {
                            if !finalized.summary.trim().is_empty() {
                                r.output = format!(
                                    "{}\n\n--- isolation outcome ---\n{}",
                                    r.output, finalized.summary
                                );
                            }
                            merge_observed_evidence(
                                &mut r.outcome,
                                finalized.evidence,
                                finalized.artifacts,
                            );
                            return Ok(r);
                        }
                    }
                    Err(error) => {
                        tracing::warn!(
                            subagent = %agent_name,
                            error = %error,
                            "Subagent isolation finalization failed; result preserved"
                        );
                    }
                }
            }

            result
        })
        .await
        .map_err(|e| ReactError::Other(format!("Fork task join error: {}", e)))??;

        Ok(result)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::agent::subagent::SubagentDefinition;
    use crate::agent::subagent::prompt::{
        CompiledSubagentSystemPrompt, PromptDiagnostics, SubagentSystemPromptInput,
    };
    use crate::agent::subagent::registry::FnAgentFactory;
    use crate::testing::{FailingMockAgent, MockAgent};
    use echo_core::agent::{ToolInvocation, ToolInvocationRewrite};
    use echo_core::tools::{InvocationResourceGuard, ToolResult, ToolResultKind};
    use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};

    /// Agent that blocks its stream until released and records steer input —
    /// used to exercise the default uplink sink against a live attempt.
    struct SteerableBlockingAgent {
        release: Arc<tokio::sync::Notify>,
        steered: Arc<Mutex<Vec<String>>>,
    }

    impl SteerableBlockingAgent {
        fn blocking_stream<'a>(
            release: Arc<tokio::sync::Notify>,
        ) -> futures::future::BoxFuture<
            'a,
            Result<futures::stream::BoxStream<'a, Result<AgentEvent>>>,
        > {
            // Resolve the stream-creation future immediately: the control
            // plane attaches (and live steer becomes possible) only after the
            // stream exists, so the release wait must live inside the first
            // stream poll rather than in this future.
            Box::pin(async move {
                Ok(Box::pin(futures::stream::once(async move {
                    release.notified().await;
                    Ok(AgentEvent::FinalAnswer("released".to_string()))
                }))
                    as futures::stream::BoxStream<'a, Result<AgentEvent>>)
            })
        }
    }

    impl Agent for SteerableBlockingAgent {
        fn name(&self) -> &str {
            "steerable-blocking"
        }

        fn model_name(&self) -> &str {
            "test"
        }

        fn system_prompt(&self) -> &str {
            ""
        }

        fn execute<'a>(&'a self, _task: &'a str) -> futures::future::BoxFuture<'a, Result<String>> {
            Box::pin(async { Ok("done".to_string()) })
        }

        fn execute_stream<'a>(
            &'a self,
            _task: &'a str,
        ) -> futures::future::BoxFuture<
            'a,
            Result<futures::stream::BoxStream<'a, Result<AgentEvent>>>,
        > {
            Self::blocking_stream(self.release.clone())
        }

        fn execute_stream_message_with_cancel<'a>(
            &'a self,
            _message: Message,
            _cancel: CancellationToken,
        ) -> futures::future::BoxFuture<
            'a,
            Result<futures::stream::BoxStream<'a, Result<AgentEvent>>>,
        > {
            Self::blocking_stream(self.release.clone())
        }

        fn steer_input(
            &self,
            _expected_turn_id: Option<&str>,
            message: Message,
        ) -> std::result::Result<String, echo_core::agent::AgentSteerError> {
            let text = message
                .content
                .as_text()
                .filter(|text| !text.trim().is_empty())
                .ok_or(echo_core::agent::AgentSteerError::EmptyInput)?
                .to_string();
            self.steered
                .lock()
                .map_err(|_| echo_core::agent::AgentSteerError::StateUnavailable)?
                .push(text.clone());
            Ok("turn".to_string())
        }

        fn steer_input_tracked(
            &self,
            expected_turn_id: Option<&str>,
            message: Message,
        ) -> std::result::Result<
            echo_core::agent::AgentSteerReceipt,
            echo_core::agent::AgentSteerError,
        > {
            let turn_id = self.steer_input(expected_turn_id, message)?;
            let (_tx, rx) = tokio::sync::watch::channel(echo_core::agent::AgentSteerState::Drained);
            Ok(echo_core::agent::AgentSteerReceipt::new(
                uuid::Uuid::new_v4().to_string(),
                turn_id,
                rx,
            ))
        }
    }

    #[test]
    fn enrich_dispatch_context_fills_missing_lineage_and_keeps_caller_values() {
        let registry = Arc::new(SubagentRegistry::new());
        let executor = SubagentExecutor::new(registry, SubagentExecutorConfig::default());

        // Missing lineage → basics derived from the request.
        let mut req = DispatchRequest {
            agent_name: "explorer".to_string(),
            task: "probe".to_string(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "primary".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: Some(echo_core::tools::ExternalRunContext {
                run_id: Some("run-1".to_string()),
                execution_id: Some("exec-1".to_string()),
                ..Default::default()
            }),
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };
        executor.enrich_dispatch_context(&mut req);
        let lineage = req
            .runtime_context
            .as_ref()
            .and_then(|context| context.subagent_lineage.clone())
            .unwrap_or_default();
        assert_eq!(lineage.agent_name.as_deref(), Some("explorer"));
        assert_eq!(lineage.parent_agent.as_deref(), Some("primary"));
        assert_eq!(lineage.agent_path.as_deref(), Some("root/explorer"));
        assert_eq!(lineage.execution_id.as_deref(), Some("exec-1"));
        assert_eq!(lineage.run_id.as_deref(), Some("run-1"));
        assert!(
            req.runtime_context
                .as_ref()
                .is_some_and(|c| c.uplink.is_some())
        );

        // Caller-stamped lineage and application uplink are preserved.
        let mut stamped = req.clone();
        let app_sink: echo_core::tools::SubagentUplinkFn = Arc::new(|_message| {
            Box::pin(async {
                echo_core::tools::SubagentUplinkReceipt {
                    accepted: true,
                    status: "app".to_string(),
                    detail: String::new(),
                }
            })
        });
        if let Some(context) = stamped.runtime_context.as_mut() {
            context.subagent_lineage = Some(echo_core::tools::SubagentLineage {
                agent_path: Some("root/implementer/sub-probe".to_string()),
                parent_execution_id: Some("parent-exec".to_string()),
                ..Default::default()
            });
            context.uplink = Some(app_sink.clone());
        }
        executor.enrich_dispatch_context(&mut stamped);
        let (preserved, kept_sink) = stamped
            .runtime_context
            .as_ref()
            .and_then(|context| {
                context
                    .subagent_lineage
                    .clone()
                    .map(|lineage| (lineage, context.uplink.clone()))
            })
            .unwrap_or_default();
        assert_eq!(
            preserved.agent_path.as_deref(),
            Some("root/implementer/sub-probe")
        );
        assert_eq!(
            preserved.parent_execution_id.as_deref(),
            Some("parent-exec")
        );
        assert!(kept_sink.is_some_and(|sink| Arc::ptr_eq(&sink, &app_sink)));
    }

    #[tokio::test]
    async fn default_uplink_sink_delivers_to_active_attempt_and_reports_missing() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let mut envelopes = registry.event_bus().subscribe_envelopes();
        let release = Arc::new(tokio::sync::Notify::new());
        let steered = Arc::new(Mutex::new(Vec::new()));
        registry
            .register(
                SubagentDefinition::new("target", "Uplink target"),
                Box::new(SteerableBlockingAgent {
                    release: release.clone(),
                    steered: steered.clone(),
                }),
            )
            .await;

        let identity = SubagentAttemptIdentity::new("task-9", "exec-9", 1)
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let dispatch = tokio::spawn(async move {
            executor
                .dispatch_attempt(
                    DispatchRequest {
                        agent_name: "target".to_string(),
                        task: "block until released".to_string(),
                        mode_override: Some(ExecutionMode::Sync),
                        cancel: CancellationToken::new(),
                        parent_agent: "primary".to_string(),
                        parent_context: None,
                        delegation_policy: DispatchRequest::policy_from_depth(0),
                        runtime_context: None,
                        message: None,
                        prompt_payload: None,
                        prompt_context: None,
                        constraints: Vec::new(),
                        background: false,
                    },
                    identity,
                )
                .await
        });

        // Wait for the attempt to become addressable in the shared plane.
        let mut became_active = false;
        for _ in 0..100 {
            if registry
                .control_registry()
                .active_snapshot(16)
                .iter()
                .any(|summary| summary.execution_id == "exec-9")
            {
                became_active = true;
                break;
            }
            tokio::time::sleep(std::time::Duration::from_millis(20)).await;
        }
        assert!(became_active, "attempt never became active");

        let sink = default_uplink_sink(Arc::clone(&registry));
        let sender_lineage = echo_core::tools::SubagentLineage {
            agent_name: Some("target".to_string()),
            execution_id: Some("exec-9".to_string()),
            parent_agent: Some("primary".to_string()),
            parent_execution_id: Some("exec-9".to_string()),
            ..Default::default()
        };

        // Parent direction: the parent attempt is live → steered queue-only.
        let parent_receipt = sink(echo_core::tools::SubagentUplinkMessage {
            from: sender_lineage.clone(),
            target: echo_core::tools::SubagentUplinkTarget::Parent {
                kind: echo_core::tools::SubagentUplinkKind::Escalate,
                text: "plan assumption is wrong?".to_string(),
            },
        })
        .await;
        assert!(parent_receipt.accepted);
        assert_eq!(parent_receipt.status, "parent_steered");

        // Sibling direction: live attempt → delivered; unknown → reported.
        let sibling_receipt = sink(echo_core::tools::SubagentUplinkMessage {
            from: sender_lineage,
            target: echo_core::tools::SubagentUplinkTarget::Sibling {
                to: echo_core::tools::SubagentPeerAddress::ByExecutionId("exec-9".to_string()),
                text: "dependency output is ready".to_string(),
            },
        })
        .await;
        assert!(sibling_receipt.accepted);
        assert_eq!(sibling_receipt.status, "delivered_to_sibling");

        let missing_receipt =
            default_uplink_sink(Arc::clone(&registry))(echo_core::tools::SubagentUplinkMessage {
                from: echo_core::tools::SubagentLineage::default(),
                target: echo_core::tools::SubagentUplinkTarget::Sibling {
                    to: echo_core::tools::SubagentPeerAddress::ByExecutionId(
                        "exec-missing".to_string(),
                    ),
                    text: "anyone?".to_string(),
                },
            })
            .await;
        assert!(!missing_receipt.accepted);
        assert_eq!(missing_receipt.status, "sibling_not_active");

        release.notify_one();
        let settled = dispatch
            .await
            .map_err(|error| ReactError::Other(error.to_string()))??;
        assert_eq!(settled.outcome.status, SubagentStatus::Completed);
        let steered_now = steered
            .lock()
            .map(|messages| messages.clone())
            .unwrap_or_default();
        assert_eq!(steered_now.len(), 2);
        let mut observed = Vec::new();
        for _ in 0..4 {
            observed.push(
                envelopes
                    .recv()
                    .await
                    .map_err(|error| ReactError::Other(error.to_string()))?,
            );
        }
        assert_eq!(
            observed
                .iter()
                .map(|envelope| envelope.sequence)
                .collect::<Vec<_>>(),
            vec![1, 2, 3, 4]
        );
        assert!(matches!(
            observed.get(1).map(|envelope| &envelope.payload.event),
            Some(SubagentEvent::UplinkReceived { .. })
        ));
        assert!(matches!(
            observed.get(2).map(|envelope| &envelope.payload.event),
            Some(SubagentEvent::UplinkReceived { .. })
        ));
        Ok(())
    }

    struct PrefixPromptCompiler;

    impl SubagentPromptCompiler for PrefixPromptCompiler {
        fn compile_system(
            &self,
            input: &SubagentSystemPromptInput<'_>,
        ) -> CompiledSubagentSystemPrompt {
            CompiledSubagentSystemPrompt {
                system_prompt: input.role_prompt.to_string(),
                diagnostics: PromptDiagnostics::default(),
            }
        }

        fn compile_invocation(&self, input: &SubagentInvocation<'_>) -> CompiledSubagentInvocation {
            CompiledSubagentInvocation {
                messages: vec![Message::user(format!("compiled:{}", input.task))],
                diagnostics: PromptDiagnostics::default(),
            }
        }
    }

    #[test]
    fn invocation_allowlist_hides_every_unlisted_tool() {
        let tools = vec![
            "read_file".to_string(),
            "write_file".to_string(),
            "shell".to_string(),
        ];
        let allowed = vec!["read_file".to_string()];
        let disabled = invocation_disabled_tools(tools.clone(), Some(&allowed)).unwrap_or_default();
        assert_eq!(
            disabled,
            HashSet::from(["write_file".to_string(), "shell".to_string()])
        );
        assert!(invocation_disabled_tools(tools.clone(), None).is_none());
        assert!(invocation_disabled_tools(tools, Some(&[])).is_none());
    }

    struct DelegateFailedDispatch;

    struct CancellationAwareStreamAgent {
        cancellation_seen: Arc<tokio::sync::Notify>,
    }

    struct RichToolEventAgent;

    impl Agent for RichToolEventAgent {
        fn name(&self) -> &str {
            "rich-tool-events"
        }

        fn model_name(&self) -> &str {
            "test-model"
        }

        fn system_prompt(&self) -> &str {
            ""
        }

        fn execute<'a>(&'a self, _task: &'a str) -> futures::future::BoxFuture<'a, Result<String>> {
            Box::pin(async { Ok("done".to_string()) })
        }

        fn execute_stream<'a>(
            &'a self,
            _task: &'a str,
        ) -> futures::future::BoxFuture<
            'a,
            Result<futures::stream::BoxStream<'a, Result<AgentEvent>>>,
        > {
            Box::pin(async {
                let invocation = ToolInvocation {
                    requested_name: "requested_tool".to_string(),
                    requested_args: serde_json::json!({"value": "requested"}),
                    name: "effective_tool".to_string(),
                    args: serde_json::json!({"value": "effective"}),
                    rewrites: vec![ToolInvocationRewrite::Approval],
                };
                let result = ToolResult {
                    kind: ToolResultKind::Json,
                    success: true,
                    output: "{\"ok\":true}".to_string(),
                    error: None,
                    failure: None,
                    data: Some(serde_json::json!({"ok": true})),
                    truncated: true,
                    mime_type: Some("application/json".to_string()),
                    metadata: HashMap::from([("source".to_string(), "fixture".to_string())]),
                    artifact: None,
                    effects: Vec::new(),
                    model_content: Vec::new(),
                };
                let events = vec![
                    Ok(AgentEvent::ToolCall {
                        call_id: "call-rich".to_string(),
                        invocation,
                    }),
                    Ok(AgentEvent::ToolResult {
                        call_id: "call-rich".to_string(),
                        name: "effective_tool".to_string(),
                        result,
                    }),
                    Ok(AgentEvent::FinalAnswer("done".to_string())),
                ];
                Ok(Box::pin(futures::stream::iter(events))
                    as futures::stream::BoxStream<'a, Result<AgentEvent>>)
            })
        }
    }

    impl Agent for CancellationAwareStreamAgent {
        fn name(&self) -> &str {
            "cancellation-aware"
        }

        fn model_name(&self) -> &str {
            "test-model"
        }

        fn system_prompt(&self) -> &str {
            ""
        }

        fn execute<'a>(&'a self, _task: &'a str) -> futures::future::BoxFuture<'a, Result<String>> {
            Box::pin(async move { std::future::pending::<Result<String>>().await })
        }

        fn execute_stream<'a>(
            &'a self,
            _task: &'a str,
        ) -> futures::future::BoxFuture<
            'a,
            Result<futures::stream::BoxStream<'a, Result<AgentEvent>>>,
        > {
            Box::pin(async move {
                let (_sender, receiver) = tokio::sync::mpsc::channel(1);
                Ok(
                    Box::pin(tokio_stream::wrappers::ReceiverStream::new(receiver))
                        as futures::stream::BoxStream<'a, Result<AgentEvent>>,
                )
            })
        }

        fn execute_stream_with_invocation_context<'a>(
            &'a self,
            _task: &'a str,
            cancel: CancellationToken,
            _invocation: AgentInvocationContext,
        ) -> futures::future::BoxFuture<
            'a,
            Result<futures::stream::BoxStream<'a, Result<AgentEvent>>>,
        > {
            let cancellation_seen = Arc::clone(&self.cancellation_seen);
            Box::pin(async move {
                let (sender, receiver) = tokio::sync::mpsc::channel(1);
                tokio::spawn(async move {
                    cancel.cancelled().await;
                    cancellation_seen.notify_one();
                    let _ = sender.send(Ok(AgentEvent::Cancelled)).await;
                });
                Ok(
                    Box::pin(tokio_stream::wrappers::ReceiverStream::new(receiver))
                        as futures::stream::BoxStream<'a, Result<AgentEvent>>,
                )
            })
        }
    }

    #[async_trait::async_trait]
    impl super::super::hooks::SubagentHooks for DelegateFailedDispatch {
        async fn on_failure(
            &self,
            _ctx: &super::super::hooks::SubagentHookContext,
            _error: &str,
        ) -> super::super::hooks::SubagentRetryDecision {
            super::super::hooks::SubagentRetryDecision::Delegate {
                alternative_agent: "recovery".to_string(),
            }
        }
    }

    async fn make_executor() -> (Arc<SubagentRegistry>, SubagentExecutor) {
        let registry = Arc::new(SubagentRegistry::new());
        let executor = SubagentExecutor::new(registry.clone(), SubagentExecutorConfig::default());
        (registry, executor)
    }

    struct DispatchGuardDrop(Arc<AtomicUsize>);

    impl Drop for DispatchGuardDrop {
        fn drop(&mut self) {
            self.0.fetch_add(1, Ordering::SeqCst);
        }
    }

    struct PendingDropStream {
        dropped: Arc<AtomicBool>,
    }

    impl futures::Stream for PendingDropStream {
        type Item = Result<AgentEvent>;

        fn poll_next(
            self: std::pin::Pin<&mut Self>,
            _context: &mut std::task::Context<'_>,
        ) -> std::task::Poll<Option<Self::Item>> {
            std::task::Poll::Pending
        }
    }

    impl Drop for PendingDropStream {
        fn drop(&mut self) {
            self.dropped.store(true, Ordering::SeqCst);
        }
    }

    struct NonCooperativeTeamAgent {
        dropped: Arc<AtomicBool>,
    }

    impl Agent for NonCooperativeTeamAgent {
        fn name(&self) -> &str {
            "non-cooperative-team-member"
        }

        fn model_name(&self) -> &str {
            "test"
        }

        fn system_prompt(&self) -> &str {
            ""
        }

        fn execute<'a>(&'a self, _task: &'a str) -> futures::future::BoxFuture<'a, Result<String>> {
            Box::pin(std::future::pending())
        }

        fn execute_stream<'a>(
            &'a self,
            _task: &'a str,
        ) -> futures::future::BoxFuture<
            'a,
            Result<futures::stream::BoxStream<'a, Result<AgentEvent>>>,
        > {
            let dropped = Arc::clone(&self.dropped);
            Box::pin(async move {
                Ok(Box::pin(PendingDropStream { dropped })
                    as futures::stream::BoxStream<'a, Result<AgentEvent>>)
            })
        }

        fn execute_stream_with_invocation_context<'a>(
            &'a self,
            task: &'a str,
            _cancel: CancellationToken,
            _invocation: AgentInvocationContext,
        ) -> futures::future::BoxFuture<
            'a,
            Result<futures::stream::BoxStream<'a, Result<AgentEvent>>>,
        > {
            self.execute_stream(task)
        }
    }

    async fn assert_mode_retains_runtime_guards(
        mode: ExecutionMode,
    ) -> std::result::Result<(), String> {
        let (registry, executor) = make_executor().await;
        let agent = MockAgent::new("guarded").with_response("done");
        registry
            .register(
                SubagentDefinition {
                    execution_mode: mode.clone(),
                    ..SubagentDefinition::new("guarded", "Guarded subagent")
                },
                Box::new(agent.clone()),
            )
            .await;
        let drops = Arc::new(AtomicUsize::new(0));
        let result = executor
            .dispatch(DispatchRequest {
                agent_name: "guarded".to_string(),
                task: "retain guard".to_string(),
                mode_override: Some(mode),
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: Some(echo_core::tools::ExternalRunContext {
                    conversation_id: None,
                    run_id: None,
                    turn_id: None,
                    execution_id: None,
                    isolation_id: None,
                    message_id: None,
                    cancel: None,
                    trace_sink: None,
                    delegation_policy: None,
                    resource_guards: vec![InvocationResourceGuard::new(DispatchGuardDrop(
                        Arc::clone(&drops),
                    ))],
                    subagent_lineage: None,
                    uplink: None,
                }),
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .map_err(|error| error.to_string())?;
        if result.outcome.status != SubagentStatus::Completed {
            return Err(format!(
                "guarded dispatch did not complete: {:?}",
                result.outcome.status
            ));
        }

        let contexts = agent.take_invocation_contexts();
        let guard_count = contexts
            .first()
            .and_then(|context| context.runtime.as_ref())
            .map(|runtime| runtime.resource_guards.len());
        if guard_count != Some(1) {
            return Err(format!(
                "subagent invocation lost runtime guards: {guard_count:?}"
            ));
        }
        assert_eq!(drops.load(Ordering::SeqCst), 0);
        drop(contexts);
        assert_eq!(drops.load(Ordering::SeqCst), 1);
        Ok(())
    }

    #[tokio::test]
    async fn sync_dispatch_retains_runtime_guards_until_settlement()
    -> std::result::Result<(), String> {
        assert_mode_retains_runtime_guards(ExecutionMode::Sync).await
    }

    #[tokio::test]
    async fn fork_dispatch_retains_runtime_guards_until_settlement()
    -> std::result::Result<(), String> {
        assert_mode_retains_runtime_guards(ExecutionMode::Fork).await
    }

    #[tokio::test]
    async fn teammate_dispatch_retains_runtime_guards_until_settlement()
    -> std::result::Result<(), String> {
        assert_mode_retains_runtime_guards(ExecutionMode::Teammate).await
    }

    #[tokio::test]
    async fn dispatch_preserves_rich_tool_events_without_parallel_adapters()
    -> std::result::Result<(), Box<dyn std::error::Error>> {
        let (registry, executor) = make_executor().await;
        registry
            .register(
                SubagentDefinition::new("rich-tool-events", "Rich tool events"),
                Box::new(RichToolEventAgent),
            )
            .await;
        let mut events = registry.event_bus().subscribe();

        let dispatched = executor
            .dispatch(DispatchRequest {
                agent_name: "rich-tool-events".to_string(),
                task: "preserve typed events".to_string(),
                mode_override: None,
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await?;
        assert_eq!(dispatched.output, "done");

        let mut started = None;
        let mut completed = None;
        while let Ok(event) = events.try_recv() {
            match event.as_ref() {
                SubagentEvent::DispatchToolStarted { invocation, .. } => {
                    started = Some(invocation.clone());
                }
                SubagentEvent::DispatchToolCompleted { name, result, .. } => {
                    completed = Some((name.clone(), result.clone()));
                }
                _ => {}
            }
        }

        let Some(invocation) = started else {
            return Err(std::io::Error::other("missing typed tool-start event").into());
        };
        assert_eq!(invocation.requested_name, "requested_tool");
        assert_eq!(invocation.name, "effective_tool");
        assert_eq!(invocation.rewrites, vec![ToolInvocationRewrite::Approval]);
        assert_eq!(
            invocation
                .args
                .get("value")
                .and_then(serde_json::Value::as_str),
            Some("effective")
        );

        let Some((name, result)) = completed else {
            return Err(std::io::Error::other("missing typed tool-result event").into());
        };
        assert_eq!(name, "effective_tool");
        assert_eq!(result.kind, ToolResultKind::Json);
        assert_eq!(result.data, Some(serde_json::json!({"ok": true})));
        assert_eq!(result.mime_type.as_deref(), Some("application/json"));
        assert!(result.truncated);
        assert_eq!(
            result.metadata.get("source").map(String::as_str),
            Some("fixture")
        );
        Ok(())
    }

    fn collect_terminal_events(
        events: &mut tokio::sync::broadcast::Receiver<Arc<SubagentEvent>>,
    ) -> Vec<Arc<SubagentEvent>> {
        let mut terminal_events = Vec::new();
        while let Ok(event) = events.try_recv() {
            if matches!(
                event.as_ref(),
                SubagentEvent::DispatchCompleted { .. }
                    | SubagentEvent::DispatchFailed { .. }
                    | SubagentEvent::DispatchCancelled { .. }
            ) {
                terminal_events.push(event);
            }
        }
        terminal_events
    }

    #[test]
    fn structured_result_terminal_event_matches_runtime_status() -> Result<()> {
        for status in [
            SubagentStatus::Completed,
            SubagentStatus::Failed,
            SubagentStatus::TimedOut,
            SubagentStatus::Cancelled,
            SubagentStatus::Running,
        ] {
            let mut result = SubagentResult::sync_result(
                "child",
                "## Summary\nresult".to_string(),
                std::time::Duration::ZERO,
            );
            result.outcome.status = status;
            let event = SubagentExecutor::terminal_event_for_result(
                "parent",
                "child",
                &mut result,
                Some("attempt-1".to_string()),
                Some("run-1".to_string()),
            );
            let terminal = match &event {
                SubagentEvent::DispatchCompleted { outcome, .. }
                    if status == SubagentStatus::Completed =>
                {
                    outcome.status
                }
                SubagentEvent::DispatchCancelled { outcome, .. }
                    if status == SubagentStatus::Cancelled =>
                {
                    outcome.status
                }
                SubagentEvent::DispatchFailed {
                    status: emitted,
                    outcome,
                    ..
                } if status == SubagentStatus::Running && *emitted == SubagentStatus::Failed => {
                    outcome.status
                }
                SubagentEvent::DispatchFailed {
                    status: emitted,
                    outcome,
                    ..
                } if *emitted == status => outcome.status,
                other => {
                    return Err(ReactError::Other(format!(
                        "incorrect terminal event for {status:?}: {other:?}"
                    )));
                }
            };
            assert_eq!(terminal, result.outcome.status);
            assert_ne!(terminal, SubagentStatus::Running);
        }
        Ok(())
    }

    /// Build a SubagentContext with N numbered user messages and no system prompt.
    #[test]
    fn dispatch_request_uses_nested_delegation_policy_as_depth_authority() {
        let policy = DispatchRequest::policy_from_depth(2);

        assert!(policy.can_spawn_subagents);
        assert_eq!(policy.delegate_depth, 2);
        assert_eq!(policy.max_delegate_depth, 3);

        let child = policy.child_policy().unwrap_or_default();
        assert_eq!(child.delegate_depth, 3);
        assert!(!child.can_delegate());
    }

    #[test]
    fn merge_observed_evidence_keeps_latest_check_result() {
        let mut outcome = SubagentOutcome {
            evidence: vec![SubagentEvidence {
                kind: "verification".to_string(),
                subject: "cargo test".to_string(),
                outcome: Some("passed".to_string()),
                details: "model claim".to_string(),
                source: SubagentEvidenceSource::Reported,
                attributes: serde_json::Value::Null,
            }],
            ..SubagentOutcome::default()
        };
        merge_observed_evidence(
            &mut outcome,
            vec![
                SubagentEvidence {
                    kind: "verification".to_string(),
                    subject: "cargo test".to_string(),
                    outcome: Some("failed".to_string()),
                    details: "first run failed".to_string(),
                    source: SubagentEvidenceSource::Observed,
                    attributes: serde_json::Value::Null,
                },
                SubagentEvidence {
                    kind: "verification".to_string(),
                    subject: "cargo test".to_string(),
                    outcome: Some("passed".to_string()),
                    details: "retry passed".to_string(),
                    source: SubagentEvidenceSource::Observed,
                    attributes: serde_json::Value::Null,
                },
            ],
            Vec::new(),
        );
        assert!(matches!(
            outcome.evidence.as_slice(),
            [SubagentEvidence {
                source: SubagentEvidenceSource::Observed,
                ..
            }]
        ));
        assert_eq!(
            outcome
                .evidence
                .first()
                .and_then(|item| item.outcome.as_deref()),
            Some("passed")
        );
    }

    #[test]
    fn merge_observed_evidence_preserves_distinct_tool_arguments() {
        let mut outcome = SubagentOutcome::default();
        let evidence = ["src/a.rs", "src/b.rs"]
            .into_iter()
            .map(|path| SubagentEvidence {
                kind: "tool_result".to_string(),
                subject: "write_file".to_string(),
                outcome: Some("succeeded".to_string()),
                details: String::new(),
                source: SubagentEvidenceSource::Observed,
                attributes: serde_json::json!({ "args": { "path": path } }),
            })
            .collect();

        merge_observed_evidence(&mut outcome, evidence, Vec::new());

        assert_eq!(outcome.evidence.len(), 2);
    }

    #[tokio::test]
    async fn test_dispatch_sync() {
        let (registry, executor) = make_executor().await;

        let agent = MockAgent::new("subagent").with_response("done");
        let def = super::super::types::SubagentDefinition::new("subagent", "Subagent");
        registry.register(def, Box::new(agent)).await;

        let req = DispatchRequest {
            agent_name: "subagent".into(),
            task: "do work".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let result = executor.dispatch(req).await.unwrap();
        assert_eq!(result.output, "done");
        assert_eq!(result.mode, ExecutionMode::Sync);
    }

    #[tokio::test]
    async fn fork_cancelled_while_queued_never_starts_agent() -> std::result::Result<(), String> {
        let registry = Arc::new(SubagentRegistry::new());
        let agent = MockAgent::new("queued").with_response("should not run");
        let observed = agent.clone();
        let mut definition = SubagentDefinition::new("queued", "Queued agent");
        definition.execution_mode = ExecutionMode::Fork;
        registry.register(definition, Box::new(agent)).await;
        let executor = Arc::new(SubagentExecutor::new(
            registry,
            SubagentExecutorConfig {
                max_concurrent_forks: 1,
                default_timeout_secs: 30,
                ..SubagentExecutorConfig::default()
            },
        ));
        let permit = Arc::clone(&executor.semaphore)
            .acquire_owned()
            .await
            .map_err(|error| error.to_string())?;
        let cancel = CancellationToken::new();
        let request = DispatchRequest {
            agent_name: "queued".to_string(),
            task: "must not start".to_string(),
            mode_override: None,
            cancel: cancel.clone(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };
        let execution = tokio::spawn({
            let executor = Arc::clone(&executor);
            async move { executor.dispatch(request).await }
        });
        tokio::task::yield_now().await;
        cancel.cancel();
        drop(permit);

        let result = tokio::time::timeout(Duration::from_secs(2), execution)
            .await
            .map_err(|_| "cancelled queued dispatch did not terminate".to_string())?
            .map_err(|error| error.to_string())?;
        assert!(result.is_err());
        assert_eq!(observed.call_count(), 0);
        Ok(())
    }

    #[tokio::test]
    async fn dispatch_uses_injected_prompt_compiler() -> Result<()> {
        let registry = Arc::new(SubagentRegistry::new());
        let executor = SubagentExecutor::new(
            registry.clone(),
            SubagentExecutorConfig {
                prompt_compiler: Arc::new(PrefixPromptCompiler),
                ..SubagentExecutorConfig::default()
            },
        );
        let agent = MockAgent::new("compiled").with_response("done");
        registry
            .register(
                super::super::types::SubagentDefinition::new("compiled", "Compiled subagent"),
                Box::new(agent.clone()),
            )
            .await;

        executor
            .dispatch(DispatchRequest {
                agent_name: "compiled".to_string(),
                task: "do work".to_string(),
                mode_override: Some(ExecutionMode::Sync),
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await?;

        assert_eq!(agent.last_task().as_deref(), Some("compiled:do work"));
        Ok(())
    }

    #[tokio::test]
    async fn dispatch_background_returns_before_completion() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let agent = MockAgent::new("slow")
            .with_delay_ms(200)
            .with_response("## Summary\nbg done");
        let def = super::super::types::SubagentDefinition::new("slow", "Slow subagent");
        registry.register(def, Box::new(agent)).await;

        let mut events = registry.event_bus().subscribe();
        let req = DispatchRequest {
            agent_name: "slow".into(),
            task: "take your time".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let started_at = Instant::now();
        let handle = executor.dispatch_background(req).await?;
        assert!(
            started_at.elapsed() < Duration::from_millis(100),
            "dispatch_background must return before the slow subagent finishes"
        );
        assert!(!handle.execution_id.is_empty());
        assert_eq!(handle.agent_name, "slow");
        assert!(handle.execution_id.starts_with("agent_tool-"));
        assert!(!handle.is_finished());

        let mut saw_started_bg = false;
        let mut saw_completed = false;
        let deadline = tokio::time::Instant::now() + Duration::from_secs(3);
        while tokio::time::Instant::now() < deadline && !(saw_started_bg && saw_completed) {
            let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());
            match tokio::time::timeout(remaining, events.recv()).await {
                Ok(Ok(ev)) => match ev.as_ref() {
                    SubagentEvent::DispatchStarted {
                        background: true,
                        execution_id: Some(id),
                        ..
                    } if id == &handle.execution_id => {
                        saw_started_bg = true;
                    }
                    SubagentEvent::DispatchCompleted {
                        output,
                        execution_id: Some(id),
                        ..
                    } if id == &handle.execution_id => {
                        assert!(output.contains("bg done"));
                        saw_completed = true;
                    }
                    _ => {}
                },
                _ => break,
            }
        }
        assert!(
            saw_started_bg,
            "expected DispatchStarted with background=true"
        );
        assert!(
            saw_completed,
            "expected DispatchCompleted after background work"
        );
        let result = handle.join().await?;
        assert!(result.output.contains("bg done"));
        assert!(
            handle.join().await.is_err(),
            "result must only be consumed once"
        );
        Ok(())
    }

    #[tokio::test]
    async fn controlled_dispatch_claims_guidance_once_for_exact_attempt() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let agent = MockAgent::new("guided").with_response("done");
        registry
            .register(
                SubagentDefinition::new("guided", "Guided subagent"),
                Box::new(agent.clone()),
            )
            .await;
        executor
            .queue_guidance("task-guided", 1, "inspect the latest revision")
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let request = DispatchRequest {
            agent_name: "guided".to_string(),
            task: "perform task".to_string(),
            mode_override: Some(ExecutionMode::Sync),
            cancel: CancellationToken::new(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };
        let identity = SubagentAttemptIdentity::new("task-guided", "execution-guided-1", 1)
            .map_err(|error| ReactError::Other(error.to_string()))?;
        executor.dispatch_attempt(request, identity).await?;

        let observed = agent.last_task().unwrap_or_default();
        assert!(observed.contains("perform task"));
        assert!(observed.contains("[queued_guidance]"));
        assert!(observed.contains("inspect the latest revision"));
        assert!(matches!(
            executor.queue_guidance("task-guided", 1, "late"),
            Err(SubagentControlError::AttemptAlreadyStarted { .. })
        ));
        Ok(())
    }

    #[tokio::test]
    async fn background_handle_cancels_dispatch() -> Result<()> {
        let (registry, executor) = make_executor().await;
        registry
            .register(
                super::super::types::SubagentDefinition::new("slow", "Slow subagent"),
                Box::new(MockAgent::new("slow").with_delay_ms(1_000)),
            )
            .await;
        let handle = executor
            .dispatch_background(DispatchRequest {
                agent_name: "slow".into(),
                task: "wait".into(),
                mode_override: None,
                cancel: CancellationToken::new(),
                parent_agent: "parent".into(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await?;
        handle.cancel();
        let result = handle.join().await?;
        assert_eq!(result.outcome.status, SubagentStatus::Cancelled);
        Ok(())
    }

    #[tokio::test]
    async fn controlled_background_interrupt_is_registered_before_handle_returns() -> Result<()> {
        let (registry, executor) = make_executor().await;
        registry
            .register(
                SubagentDefinition::new("controlled", "Controlled subagent"),
                Box::new(MockAgent::new("controlled").with_response("must not escape")),
            )
            .await;
        let request = DispatchRequest {
            agent_name: "controlled".to_string(),
            task: "wait".to_string(),
            mode_override: Some(ExecutionMode::Sync),
            cancel: CancellationToken::new(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };
        let identity = SubagentAttemptIdentity::new("task-controlled", "execution-controlled", 1)
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let handle = executor
            .dispatch_background_attempt(request, identity)
            .await?;

        let interrupted = executor
            .interrupt_subagent("execution-controlled", 1)
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        assert!(interrupted.requested);
        assert!(interrupted.settled);
        assert_eq!(interrupted.terminal_status, Some(SubagentStatus::Cancelled));
        let result = handle.join().await?;
        assert_eq!(result.outcome.status, SubagentStatus::Cancelled);
        assert!(matches!(
            executor
                .send_message_tracked("execution-controlled", 1, "late")
                .await,
            Err(SubagentControlError::AttemptSettled { .. })
        ));
        Ok(())
    }

    #[tokio::test]
    async fn dispatch_started_preserves_chat_identity() -> std::result::Result<(), String> {
        let (registry, executor) = make_executor().await;
        let agent = MockAgent::new("identity").with_response("done");
        let definition =
            super::super::types::SubagentDefinition::new("identity", "Identity subagent");
        registry.register(definition, Box::new(agent)).await;
        let mut events = registry.event_bus().subscribe();
        let mut envelopes = registry.event_bus().subscribe_envelopes();
        let request = DispatchRequest {
            agent_name: "identity".to_string(),
            task: "preserve identity".to_string(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: Some(echo_core::tools::ExternalRunContext {
                conversation_id: Some("conversation-identity".to_string()),
                run_id: None,
                turn_id: Some("turn-identity".to_string()),
                execution_id: Some("agent_tool-identity".to_string()),
                isolation_id: None,
                message_id: Some("message-identity".to_string()),
                cancel: None,
                trace_sink: None,
                delegation_policy: None,
                resource_guards: Vec::new(),
                subagent_lineage: Some(echo_core::tools::SubagentLineage {
                    task_id: Some("task-identity".to_string()),
                    attempt: Some(3),
                    plan_revision: Some(7),
                    ..echo_core::tools::SubagentLineage::default()
                }),
                uplink: None,
            }),
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        executor
            .dispatch(request)
            .await
            .map_err(|error| error.to_string())?;
        let started = events.recv().await.map_err(|error| error.to_string())?;
        match started.as_ref() {
            SubagentEvent::DispatchStarted {
                conversation_id,
                message_id,
                run_id,
                ..
            } => {
                assert_eq!(conversation_id.as_deref(), Some("conversation-identity"));
                assert_eq!(message_id.as_deref(), Some("message-identity"));
                assert!(run_id.is_none());
            }
            other => return Err(format!("expected DispatchStarted, got {other:?}")),
        }
        let started_envelope = envelopes.recv().await.map_err(|error| error.to_string())?;
        assert_eq!(started_envelope.sequence, 1);
        assert_eq!(
            started_envelope
                .conversation_id
                .as_ref()
                .map(|value| value.as_str()),
            Some("conversation-identity")
        );
        assert_eq!(
            started_envelope
                .message_id
                .as_ref()
                .map(|value| value.as_str()),
            Some("message-identity")
        );
        assert_eq!(
            started_envelope.payload.invocation.task_id.as_deref(),
            Some("task-identity")
        );
        assert_eq!(started_envelope.payload.invocation.attempt, Some(3));
        assert_eq!(started_envelope.payload.invocation.plan_revision, Some(7));
        let terminal = envelopes.recv().await.map_err(|error| error.to_string())?;
        assert_eq!(terminal.sequence, 2);
        assert_eq!(
            terminal.parent_event_id,
            Some(started_envelope.event_id.clone())
        );
        assert!(matches!(
            terminal.payload.event,
            SubagentEvent::DispatchCompleted { .. }
        ));
        Ok(())
    }

    // NOTE: a unit test for multimodal dispatch forwarding (verifying a subagent
    // receives the Message via execute_stream_message_with_cancel) is not
    // feasible with MockAgent — the trait-object vtable routes the default
    // trait method rather than MockAgent's override for this added method, so
    // the message path can't be exercised in isolation. Subagent multimodal
    // forwarding is instead verified by: (1) the text-path dispatch tests
    // above, (2) compile-time coverage of the DispatchRequest.message field
    // and execute_agent_streaming branch, and (3) desktop UI manual testing of
    // attachment-bearing complex tasks. MockAgent retains the override +
    // message-recording fields so real agents and future test harnesses can
    // use them.

    #[tokio::test]
    async fn test_dispatch_not_found() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let mut envelopes = registry.event_bus().subscribe_envelopes();

        let req = DispatchRequest {
            agent_name: "missing".into(),
            task: "task".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let err =
            executor.dispatch(req).await.err().ok_or_else(|| {
                ReactError::Other("missing Subagent unexpectedly ran".to_string())
            })?;
        assert!(err.to_string().contains("not found"));
        let started = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let terminal = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        assert_eq!(started.sequence, 1);
        assert_eq!(terminal.sequence, 2);
        assert!(matches!(
            terminal.payload.event,
            SubagentEvent::DispatchFailed { .. }
        ));
        Ok(())
    }

    #[tokio::test]
    async fn test_dispatch_cancelled() -> Result<()> {
        let (registry, executor) = make_executor().await;

        let agent = MockAgent::new("c").with_response("ok");
        let def = super::super::types::SubagentDefinition::new("c", "C");
        registry.register(def, Box::new(agent)).await;
        let mut envelopes = registry.event_bus().subscribe_envelopes();

        let cancel = CancellationToken::new();
        cancel.cancel();

        let req = DispatchRequest {
            agent_name: "c".into(),
            task: "task".into(),
            mode_override: None,
            cancel,
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let result = executor.dispatch(req).await?;
        assert!(result.output.contains("Cancelled"));
        assert_eq!(result.outcome.status, SubagentStatus::Cancelled);
        let started = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let terminal = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        assert_eq!(started.sequence, 1);
        assert_eq!(terminal.sequence, 2);
        assert!(matches!(
            terminal.payload.event,
            SubagentEvent::DispatchCancelled { .. }
        ));
        Ok(())
    }

    #[tokio::test]
    async fn rejected_delegation_depth_emits_one_failed_lifecycle() -> Result<()> {
        let (registry, executor) = make_executor().await;
        registry
            .register(
                SubagentDefinition::new("depth", "Depth guard"),
                Box::new(MockAgent::new("depth").with_response("must not run")),
            )
            .await;
        let mut envelopes = registry.event_bus().subscribe_envelopes();
        let error = executor
            .dispatch(DispatchRequest {
                agent_name: "depth".to_string(),
                task: "reject".to_string(),
                mode_override: Some(ExecutionMode::Sync),
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: NestedDelegationPolicy {
                    can_spawn_subagents: true,
                    delegate_depth: 2,
                    max_delegate_depth: 1,
                },
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .err()
            .ok_or_else(|| ReactError::Other("invalid depth unexpectedly ran".to_string()))?;
        assert!(error.to_string().contains("Delegation depth exceeded"));
        let started = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let terminal = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        assert_eq!((started.sequence, terminal.sequence), (1, 2));
        assert!(matches!(
            terminal.payload.event,
            SubagentEvent::DispatchFailed { .. }
        ));
        Ok(())
    }

    #[tokio::test]
    async fn recovered_dispatch_emits_only_one_terminal_event() -> Result<()> {
        let registry = Arc::new(SubagentRegistry::new());
        let mut hooks = super::super::hooks::SubagentHookRegistry::new();
        hooks.register(Arc::new(DelegateFailedDispatch));
        let executor = SubagentExecutor::with_hooks(
            registry.clone(),
            SubagentExecutorConfig::default(),
            hooks,
        );
        registry
            .register(
                super::super::types::SubagentDefinition::new("primary", "Primary"),
                Box::new(FailingMockAgent::new("primary", "first attempt failed")),
            )
            .await;
        let recovery = MockAgent::new("recovery").with_response("recovered");
        registry
            .register(
                super::super::types::SubagentDefinition::new("recovery", "Recovery"),
                Box::new(recovery.clone()),
            )
            .await;
        let mut events = registry.event_bus().subscribe();
        let mut envelopes = registry.event_bus().subscribe_envelopes();

        let result = executor
            .dispatch(DispatchRequest {
                agent_name: "primary".to_string(),
                task: "recover this task".to_string(),
                mode_override: None,
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: vec!["Preserve the caller boundary".to_string()],
                background: false,
            })
            .await?;
        assert_eq!(result.outcome.status, SubagentStatus::Completed);
        assert!(
            recovery
                .last_task()
                .as_deref()
                .is_some_and(|task| task.contains("Preserve the caller boundary")),
            "delegated recovery must receive the original constraints"
        );

        let terminal_events = collect_terminal_events(&mut events);
        assert_eq!(terminal_events.len(), 1);
        assert!(matches!(
            terminal_events.first().map(AsRef::as_ref),
            Some(SubagentEvent::DispatchCompleted { outcome, .. })
                if outcome.status == SubagentStatus::Completed
        ));
        let mut sequences = Vec::new();
        let mut agents = Vec::new();
        for _ in 0..2 {
            let envelope = envelopes
                .recv()
                .await
                .map_err(|error| ReactError::Other(error.to_string()))?;
            sequences.push(envelope.sequence);
            agents.push(envelope.payload.invocation.agent_name.clone());
        }
        assert_eq!(sequences, vec![1, 2]);
        assert_eq!(agents, vec!["primary", "recovery"]);
        assert!(matches!(
            envelopes.try_recv(),
            Err(tokio::sync::broadcast::error::TryRecvError::Empty)
        ));
        Ok(())
    }

    #[tokio::test]
    async fn failed_dispatch_emits_failed_terminal_status() -> std::result::Result<(), String> {
        let (registry, executor) = make_executor().await;
        registry
            .register(
                super::super::types::SubagentDefinition::new("failing", "Failing"),
                Box::new(FailingMockAgent::new("failing", "boom")),
            )
            .await;
        let mut events = registry.event_bus().subscribe();
        let error = executor
            .dispatch(DispatchRequest {
                agent_name: "failing".to_string(),
                task: "fail".to_string(),
                mode_override: None,
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .err()
            .ok_or_else(|| "failing subagent unexpectedly completed".to_string())?;
        assert_eq!(subagent_status_from_error(&error), SubagentStatus::Failed);
        let terminal_events = collect_terminal_events(&mut events);
        assert!(matches!(
            terminal_events.as_slice(),
            [event]
                if matches!(
                    event.as_ref(),
                    SubagentEvent::DispatchFailed {
                        status: SubagentStatus::Failed,
                        ..
                    }
                )
        ));
        Ok(())
    }

    #[tokio::test]
    async fn running_dispatch_cancel_emits_cancelled_terminal_status()
    -> std::result::Result<(), String> {
        let (registry, executor) = make_executor().await;
        registry
            .register(
                super::super::types::SubagentDefinition::new("slow-cancel", "Slow cancel"),
                Box::new(
                    MockAgent::new("slow-cancel")
                        .with_delay_ms(500)
                        .with_default_success("completed"),
                ),
            )
            .await;
        let mut events = registry.event_bus().subscribe();
        let cancel = CancellationToken::new();
        let trigger = cancel.clone();
        tokio::spawn(async move {
            tokio::time::sleep(Duration::from_millis(20)).await;
            trigger.cancel();
        });
        let error = executor
            .dispatch(DispatchRequest {
                agent_name: "slow-cancel".to_string(),
                task: "wait".to_string(),
                mode_override: None,
                cancel,
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .err()
            .ok_or_else(|| "cancelled subagent unexpectedly completed".to_string())?;
        assert_eq!(
            subagent_status_from_error(&error),
            SubagentStatus::Cancelled
        );
        let terminal_events = collect_terminal_events(&mut events);
        assert!(matches!(
            terminal_events.as_slice(),
            [event]
                if matches!(event.as_ref(), SubagentEvent::DispatchCancelled { outcome, .. }
                    if outcome.status == SubagentStatus::Cancelled)
        ));
        Ok(())
    }

    #[tokio::test]
    async fn timed_out_dispatch_emits_timed_out_terminal_status() -> std::result::Result<(), String>
    {
        let (registry, executor) = make_executor().await;
        let mut definition =
            super::super::types::SubagentDefinition::new("slow-timeout", "Slow timeout");
        definition.timeout_secs = 1;
        registry
            .register(
                definition,
                Box::new(
                    MockAgent::new("slow-timeout")
                        .with_delay_ms(1_500)
                        .with_default_success("completed"),
                ),
            )
            .await;
        let mut events = registry.event_bus().subscribe();
        let error = executor
            .dispatch(DispatchRequest {
                agent_name: "slow-timeout".to_string(),
                task: "wait".to_string(),
                mode_override: None,
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .err()
            .ok_or_else(|| "timed-out subagent unexpectedly completed".to_string())?;
        assert_eq!(subagent_status_from_error(&error), SubagentStatus::TimedOut);
        let terminal_events = collect_terminal_events(&mut events);
        assert!(matches!(
            terminal_events.as_slice(),
            [event]
                if matches!(
                    event.as_ref(),
                    SubagentEvent::DispatchFailed {
                        status: SubagentStatus::TimedOut,
                        outcome,
                        ..
                    } if outcome.status == SubagentStatus::TimedOut
                )
        ));
        Ok(())
    }

    #[tokio::test]
    async fn test_dispatch_mode_override() {
        let (registry, executor) = make_executor().await;

        let agent = MockAgent::new("forker").with_response("forked");
        let mut def = super::super::types::SubagentDefinition::new("forker", "Fork agent");
        def.execution_mode = ExecutionMode::Sync; // Default is Sync
        registry.register(def, Box::new(agent)).await;

        let req = DispatchRequest {
            agent_name: "forker".into(),
            task: "task".into(),
            mode_override: Some(ExecutionMode::Fork),
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let result = executor.dispatch(req).await.unwrap();
        assert_eq!(result.output, "forked");
        assert_eq!(result.mode, ExecutionMode::Fork);
    }

    #[tokio::test]
    async fn sync_dispatch_creates_fresh_agent_per_request() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let mut definition = super::super::types::SubagentDefinition::new("explorer", "Explorer");
        definition.execution_mode = ExecutionMode::Sync;
        registry
            .register(
                definition.clone(),
                Box::new(MockAgent::new("explorer").with_response("cached")),
            )
            .await;

        let creations = Arc::new(AtomicUsize::new(0));
        let factory_creations = Arc::clone(&creations);
        let factory = Arc::new(FnAgentFactory::new(move || {
            let instance = factory_creations
                .fetch_add(1, Ordering::SeqCst)
                .saturating_add(1);
            Box::pin(async move {
                Ok(Box::new(
                    MockAgent::new("explorer")
                        .with_delay_ms(50)
                        .with_response(format!("instance-{instance}")),
                ) as Box<dyn Agent>)
            })
        }));
        assert!(registry.register_factory_sync(definition, factory));
        let mut envelopes = registry.event_bus().subscribe_envelopes();

        let request = || DispatchRequest {
            agent_name: "explorer".to_string(),
            task: "inspect".to_string(),
            mode_override: Some(ExecutionMode::Sync),
            cancel: CancellationToken::new(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let (first, second) =
            tokio::join!(executor.dispatch(request()), executor.dispatch(request()));
        let first = first?;
        let second = second?;

        assert_eq!(creations.load(Ordering::SeqCst), 2);
        assert_ne!(first.output, second.output);
        assert_ne!(first.output, "cached");
        assert_ne!(second.output, "cached");
        let mut sequences_by_stream = HashMap::<String, Vec<u64>>::new();
        for _ in 0..4 {
            let envelope = envelopes
                .recv()
                .await
                .map_err(|error| ReactError::Other(error.to_string()))?;
            sequences_by_stream
                .entry(envelope.stream_id.as_str().to_string())
                .or_default()
                .push(envelope.sequence);
        }
        assert_eq!(sequences_by_stream.len(), 2);
        assert!(
            sequences_by_stream
                .values()
                .all(|sequences| sequences.as_slice() == [1, 2])
        );
        Ok(())
    }

    #[tokio::test]
    async fn sync_timeout_cancels_detached_stream_producer() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let cancellation_seen = Arc::new(tokio::sync::Notify::new());
        let mut definition = super::super::types::SubagentDefinition::new("slow", "Slow stream");
        definition.execution_mode = ExecutionMode::Sync;
        definition.timeout_secs = 1;
        registry
            .register(
                definition,
                Box::new(CancellationAwareStreamAgent {
                    cancellation_seen: Arc::clone(&cancellation_seen),
                }),
            )
            .await;

        let error = executor
            .dispatch(DispatchRequest {
                agent_name: "slow".to_string(),
                task: "wait".to_string(),
                mode_override: Some(ExecutionMode::Sync),
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .err()
            .ok_or_else(|| ReactError::Other("slow Sync unexpectedly completed".to_string()))?;

        assert_eq!(subagent_status_from_error(&error), SubagentStatus::TimedOut);
        tokio::time::timeout(Duration::from_secs(1), cancellation_seen.notified())
            .await
            .map_err(|_| {
                ReactError::Other(
                    "Sync timeout did not cancel the detached stream producer".to_string(),
                )
            })?;
        Ok(())
    }

    #[tokio::test]
    async fn fork_dispatch_creates_fresh_agent_per_request() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let mut definition = super::super::types::SubagentDefinition::new("explorer", "Explorer");
        definition.execution_mode = ExecutionMode::Fork;
        registry
            .register(
                definition.clone(),
                Box::new(MockAgent::new("explorer").with_response("cached")),
            )
            .await;

        let creations = Arc::new(AtomicUsize::new(0));
        let factory_creations = Arc::clone(&creations);
        let factory = Arc::new(FnAgentFactory::new(move || {
            let instance = factory_creations
                .fetch_add(1, Ordering::SeqCst)
                .saturating_add(1);
            Box::pin(async move {
                Ok(Box::new(
                    MockAgent::new("explorer")
                        .with_delay_ms(50)
                        .with_response(format!("instance-{instance}")),
                ) as Box<dyn Agent>)
            })
        }));
        assert!(registry.register_factory_sync(definition, factory));

        let request = || DispatchRequest {
            agent_name: "explorer".to_string(),
            task: "inspect".to_string(),
            mode_override: Some(ExecutionMode::Fork),
            cancel: CancellationToken::new(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let (first, second) =
            tokio::join!(executor.dispatch(request()), executor.dispatch(request()));
        let first = first?;
        let second = second?;

        assert_eq!(creations.load(Ordering::SeqCst), 2);
        assert_ne!(first.output, second.output);
        assert_ne!(first.output, "cached");
        assert_ne!(second.output, "cached");
        Ok(())
    }

    #[tokio::test]
    async fn fork_timeout_cancels_detached_stream_producer() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let cancellation_seen = Arc::new(tokio::sync::Notify::new());
        let mut definition = super::super::types::SubagentDefinition::new("slow", "Slow stream");
        definition.execution_mode = ExecutionMode::Fork;
        definition.timeout_secs = 1;
        registry
            .register(
                definition,
                Box::new(CancellationAwareStreamAgent {
                    cancellation_seen: Arc::clone(&cancellation_seen),
                }),
            )
            .await;

        let error = executor
            .dispatch(DispatchRequest {
                agent_name: "slow".to_string(),
                task: "wait".to_string(),
                mode_override: Some(ExecutionMode::Fork),
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .err()
            .ok_or_else(|| ReactError::Other("slow Fork unexpectedly completed".to_string()))?;

        assert_eq!(subagent_status_from_error(&error), SubagentStatus::TimedOut);
        tokio::time::timeout(Duration::from_secs(1), cancellation_seen.notified())
            .await
            .map_err(|_| {
                ReactError::Other(
                    "Fork timeout did not cancel the detached stream producer".to_string(),
                )
            })?;
        Ok(())
    }

    #[tokio::test]
    async fn test_teammate_dispatch() -> Result<()> {
        let (registry, executor) = make_executor().await;

        let agent = MockAgent::new("tm").with_response("team result");
        let mut def = super::super::types::SubagentDefinition::new("tm", "Teammate");
        def.execution_mode = ExecutionMode::Teammate;
        registry.register(def, Box::new(agent)).await;
        let mut envelopes = registry.event_bus().subscribe_envelopes();

        let req = DispatchRequest {
            agent_name: "tm".into(),
            task: "team task".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "leader".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let handle = executor.dispatch_teammate(req).await?;
        assert_eq!(handle.agent_name, "tm");

        let result = handle.join().await?;
        assert_eq!(result.output, "team result");
        let started = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let terminal = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        assert_eq!(started.sequence, 1);
        assert_eq!(terminal.sequence, 2);
        assert!(matches!(
            terminal.payload.event,
            SubagentEvent::DispatchCompleted { .. }
        ));
        Ok(())
    }

    #[tokio::test]
    async fn teammate_setup_failure_emits_started_and_failed() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let mut envelopes = registry.event_bus().subscribe_envelopes();
        let error = executor
            .dispatch_teammate(DispatchRequest {
                agent_name: "missing-teammate".to_string(),
                task: "fail setup".to_string(),
                mode_override: Some(ExecutionMode::Teammate),
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .err()
            .ok_or_else(|| ReactError::Other("missing teammate unexpectedly ran".to_string()))?;
        assert!(error.to_string().contains("not found"));
        let started = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let failed = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        assert_eq!((started.sequence, failed.sequence), (1, 2));
        assert!(matches!(
            failed.payload.event,
            SubagentEvent::DispatchFailed { .. }
        ));
        Ok(())
    }

    #[tokio::test]
    async fn team_dispatch_rejects_unregistered_member_without_false_completion() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let definition = super::super::builder::SubagentBuilder::new("pipeline-team")
            .team(super::super::team::TeamSpec {
                strategy: super::super::team::TeamStrategy::Pipeline(vec![
                    "missing-member".to_string(),
                ]),
                manager: String::new(),
                subagents: Vec::new(),
                config: super::super::team::TeamConfig::default(),
            })
            .build();
        registry
            .register(definition, Box::new(MockAgent::new("pipeline-team")))
            .await;

        let error = executor
            .dispatch(DispatchRequest {
                agent_name: "pipeline-team".to_string(),
                task: "run pipeline".to_string(),
                mode_override: None,
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .err()
            .ok_or_else(|| {
                ReactError::Other("unregistered Team member completed successfully".to_string())
            })?;
        assert!(error.to_string().contains("not registered"));
        Ok(())
    }

    #[tokio::test]
    async fn team_member_dispatch_preserves_claim_derived_execution_identity() -> Result<()> {
        let (registry, executor) = make_executor().await;
        registry
            .register(
                SubagentDefinition::new("member", "Team member"),
                Box::new(MockAgent::new("member").with_response("member done")),
            )
            .await;
        let definition = super::super::builder::SubagentBuilder::new("pipeline-team")
            .team(super::super::team::TeamSpec {
                strategy: super::super::team::TeamStrategy::Pipeline(vec!["member".to_string()]),
                manager: String::new(),
                subagents: Vec::new(),
                config: super::super::team::TeamConfig {
                    default_timeout_secs: 0,
                    ..super::super::team::TeamConfig::default()
                },
            })
            .build();
        registry
            .register(definition, Box::new(MockAgent::new("pipeline-team")))
            .await;

        let mut events = registry.event_bus().subscribe();
        let request = DispatchRequest {
            agent_name: "pipeline-team".to_string(),
            task: "run the member".to_string(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: Some(echo_core::tools::ExternalRunContext {
                run_id: Some("team-identity-run".to_string()),
                ..echo_core::tools::ExternalRunContext::default()
            }),
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };
        let root_identity = SubagentAttemptIdentity::new("root-task", "team-identity-root", 1)
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let result = executor.dispatch_attempt(request, root_identity).await?;
        assert_eq!(result.outcome.status, SubagentStatus::Completed);
        let team_runtime = executor
            .team_runtime_handles("team-identity-run")
            .first()
            .cloned()
            .ok_or_else(|| {
                ReactError::Other("React Team runtime handle was not retained".to_string())
            })?;
        assert_eq!(team_runtime.run_id(), "team-identity-run");
        assert!(
            team_runtime
                .snapshot()
                .await?
                .tasks
                .iter()
                .all(|task| task.execution.status.is_terminal())
        );

        let mut member_execution = None;
        while let Ok(event) = tokio::time::timeout(Duration::from_secs(1), events.recv()).await {
            let event = event.map_err(|error| ReactError::Other(error.to_string()))?;
            if let SubagentEvent::DispatchStarted {
                agent,
                execution_id: Some(execution_id),
                run_id: Some(run_id),
                ..
            } = event.as_ref()
                && agent == "member"
            {
                member_execution = Some((execution_id.clone(), run_id.clone()));
                break;
            }
        }
        let (execution_id, run_id) = member_execution.ok_or_else(|| {
            ReactError::Other("member DispatchStarted event was not observed".to_string())
        })?;
        assert_eq!(run_id, "team-identity-run");
        assert!(execution_id.starts_with("team-identity-run:"));
        assert!(execution_id.contains(":1:"));
        Ok(())
    }

    #[test]
    fn same_run_team_runtimes_are_retained_by_unique_handle_identity() -> Result<()> {
        let registry = Arc::new(SubagentRegistry::new());
        let executor = SubagentExecutor::new(registry, SubagentExecutorConfig::default());
        let make_handle = || {
            let dispatch: super::super::team::TeamDispatchFn = Arc::new(|request| {
                Box::pin(async move {
                    Ok(SubagentResult::sync_result(
                        &request.member,
                        "done".to_string(),
                        Duration::ZERO,
                    ))
                })
            });
            let controller = super::super::team::closure_dispatch_controller(
                dispatch,
                super::super::team::TeamDispatchControl::default(),
            );
            super::super::team::runtime_handle_for_controller(
                "shared-run".to_string(),
                controller,
                echo_orchestration::tasks::RuntimeTaskServiceConfig::default(),
            )
        };
        let handles = (0..=TEAM_RUNTIME_RETENTION)
            .map(|_| make_handle())
            .collect::<Vec<_>>();
        let active = handles
            .iter()
            .map(|handle| handle.start_execution())
            .collect::<Vec<_>>();
        for handle in &handles {
            executor.retain_team_runtime(handle.clone());
        }

        let retained = executor.team_runtime_handles("shared-run");
        assert_eq!(retained.len(), TEAM_RUNTIME_RETENTION.saturating_add(1));
        let first = handles
            .first()
            .ok_or_else(|| ReactError::Other("first Team handle missing".to_string()))?;
        let last = handles
            .last()
            .ok_or_else(|| ReactError::Other("last Team handle missing".to_string()))?;
        assert!(
            executor
                .team_runtime_handle(first.handle_id())
                .is_some_and(|retained| Arc::ptr_eq(&retained, first))
        );
        assert!(
            executor
                .team_runtime_handle(last.handle_id())
                .is_some_and(|retained| Arc::ptr_eq(&retained, last))
        );
        drop(active);
        prune_team_runtime_index(&executor.team_runtimes);
        assert_eq!(
            executor.team_runtime_handles("shared-run").len(),
            TEAM_RUNTIME_RETENTION
        );
        Ok(())
    }

    #[tokio::test]
    async fn react_team_targeted_abort_drops_non_cooperative_member_future() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let executor = Arc::new(executor);
        let dropped = Arc::new(AtomicBool::new(false));
        registry
            .register(
                SubagentDefinition::new("stuck-member", "Non-cooperative Team member"),
                Box::new(NonCooperativeTeamAgent {
                    dropped: Arc::clone(&dropped),
                }),
            )
            .await;
        let definition = super::super::builder::SubagentBuilder::new("controlled-team")
            .team(super::super::team::TeamSpec {
                strategy: super::super::team::TeamStrategy::Pipeline(vec![
                    "stuck-member".to_string(),
                ]),
                manager: String::new(),
                subagents: Vec::new(),
                config: super::super::team::TeamConfig {
                    default_timeout_secs: 0,
                    ..super::super::team::TeamConfig::default()
                },
            })
            .build();
        registry
            .register(definition, Box::new(MockAgent::new("controlled-team")))
            .await;
        let run_id = "react-team-non-cooperative";
        let request = DispatchRequest {
            agent_name: "controlled-team".to_string(),
            task: "wait forever".to_string(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: Some(echo_core::tools::ExternalRunContext {
                run_id: Some(run_id.to_string()),
                ..echo_core::tools::ExternalRunContext::default()
            }),
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };
        let root_identity =
            SubagentAttemptIdentity::for_run(run_id, "root-task", "react-team-root", 1)
                .map_err(|error| ReactError::Other(error.to_string()))?;
        let execution = tokio::spawn({
            let executor = Arc::clone(&executor);
            async move { executor.dispatch_attempt(request, root_identity).await }
        });
        let observed = tokio::time::timeout(Duration::from_secs(2), async {
            loop {
                if let Some(handle) = executor.team_runtime_handles(run_id).first().cloned()
                    && let Ok(snapshot) = handle.snapshot().await
                    && let Some((task_id, claim)) = snapshot.tasks.iter().find_map(|task| {
                        task.execution
                            .claim
                            .clone()
                            .map(|claim| (task.spec.id.clone(), claim))
                    })
                {
                    break (handle, task_id, claim);
                }
                tokio::task::yield_now().await;
            }
        })
        .await;
        let (handle, task_id, claim) = match observed {
            Ok(observed) => observed,
            Err(_) if execution.is_finished() => {
                let result = execution.await.map_err(|error| {
                    ReactError::Other(format!("React Team task panicked: {error}"))
                })?;
                return Err(ReactError::Other(format!(
                    "React Team finished before claim observation: {result:?}"
                )));
            }
            Err(_) => {
                return Err(ReactError::Other(
                    "React Team claim was not observable".to_string(),
                ));
            }
        };
        assert!(
            handle
                .request_attempt_interrupt(&task_id, &claim)
                .await?
                .requested
        );
        let error = tokio::time::timeout(Duration::from_secs(7), execution)
            .await
            .map_err(|_| ReactError::Other("React Team exact abort did not settle".to_string()))?
            .map_err(|error| ReactError::Other(format!("React Team task panicked: {error}")))?
            .err()
            .ok_or_else(|| ReactError::Other("cancelled React Team succeeded".to_string()))?;
        assert!(
            matches!(
                &error,
                ReactError::Agent(agent_error)
                    if matches!(agent_error.as_ref(), AgentError::Cancelled(_))
            ),
            "unexpected React Team terminal: {error:?}"
        );
        assert!(dropped.load(Ordering::SeqCst));
        Ok(())
    }

    #[tokio::test]
    async fn teammate_dispatch_creates_fresh_agent_per_request() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let mut definition = super::super::types::SubagentDefinition::new("explorer", "Explorer");
        definition.execution_mode = ExecutionMode::Teammate;
        registry
            .register(
                definition.clone(),
                Box::new(MockAgent::new("explorer").with_response("cached")),
            )
            .await;

        let creations = Arc::new(AtomicUsize::new(0));
        let factory_creations = Arc::clone(&creations);
        let factory = Arc::new(FnAgentFactory::new(move || {
            let instance = factory_creations
                .fetch_add(1, Ordering::SeqCst)
                .saturating_add(1);
            Box::pin(async move {
                Ok(Box::new(
                    MockAgent::new("explorer")
                        .with_delay_ms(50)
                        .with_response(format!("instance-{instance}")),
                ) as Box<dyn Agent>)
            })
        }));
        assert!(registry.register_factory_sync(definition, factory));

        let request = || DispatchRequest {
            agent_name: "explorer".to_string(),
            task: "inspect".to_string(),
            mode_override: Some(ExecutionMode::Teammate),
            cancel: CancellationToken::new(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let (first, second) =
            tokio::join!(executor.dispatch(request()), executor.dispatch(request()));
        let first = first?;
        let second = second?;

        assert_eq!(creations.load(Ordering::SeqCst), 2);
        assert_ne!(first.output, second.output);
        assert_ne!(first.output, "cached");
        assert_ne!(second.output, "cached");
        Ok(())
    }

    #[tokio::test]
    async fn teammate_timeout_cancels_detached_stream_producer() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let cancellation_seen = Arc::new(tokio::sync::Notify::new());
        let mut definition = super::super::types::SubagentDefinition::new("slow", "Slow stream");
        definition.execution_mode = ExecutionMode::Teammate;
        definition.timeout_secs = 1;
        registry
            .register(
                definition,
                Box::new(CancellationAwareStreamAgent {
                    cancellation_seen: Arc::clone(&cancellation_seen),
                }),
            )
            .await;

        let error = executor
            .dispatch(DispatchRequest {
                agent_name: "slow".to_string(),
                task: "wait".to_string(),
                mode_override: Some(ExecutionMode::Teammate),
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .err()
            .ok_or_else(|| ReactError::Other("slow Teammate unexpectedly completed".to_string()))?;

        assert_eq!(subagent_status_from_error(&error), SubagentStatus::TimedOut);
        tokio::time::timeout(Duration::from_secs(1), cancellation_seen.notified())
            .await
            .map_err(|_| {
                ReactError::Other(
                    "Teammate timeout did not cancel the detached stream producer".to_string(),
                )
            })?;
        Ok(())
    }

    #[tokio::test]
    async fn teammate_handle_cancel_does_not_cancel_parent() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let definition = super::super::types::SubagentDefinition::new("slow", "Slow stream");
        registry
            .register(
                definition,
                Box::new(CancellationAwareStreamAgent {
                    cancellation_seen: Arc::new(tokio::sync::Notify::new()),
                }),
            )
            .await;

        let parent_cancel = CancellationToken::new();
        let handle = executor
            .dispatch_teammate(DispatchRequest {
                agent_name: "slow".to_string(),
                task: "wait".to_string(),
                mode_override: Some(ExecutionMode::Teammate),
                cancel: parent_cancel.clone(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await?;

        handle.cancel.cancel();
        if parent_cancel.is_cancelled() {
            return Err(ReactError::Other(
                "cancelling a Teammate handle cancelled its parent run".to_string(),
            ));
        }
        let error = handle
            .join()
            .await
            .err()
            .ok_or_else(|| ReactError::Other("cancelled Teammate completed".to_string()))?;
        assert!(
            matches!(error, ReactError::Agent(inner) if matches!(*inner, AgentError::Interrupted))
        );
        Ok(())
    }

    // ── Generic Fork isolation ─────────────────────────────────────────────

    use crate::agent::subagent::{
        IsolationError, IsolationHandle, IsolationOutcome, IsolationProvider, IsolationRequest,
    };
    use std::sync::Mutex as StdMutex;

    /// A mock factory whose `create` always succeeds, records the label, and
    /// whose `finalize` returns a canned diff. `should_fail` toggles hard-fail.
    struct MockIsolationProvider {
        labels: StdMutex<Vec<String>>,
        should_fail: bool,
    }

    impl IsolationProvider for MockIsolationProvider {
        fn isolate(
            &self,
            request: &IsolationRequest,
        ) -> std::result::Result<IsolationHandle, IsolationError> {
            if self.should_fail {
                return Err(IsolationError::new("mock isolation failed"));
            }
            let label = &request.label;
            self.labels.lock().unwrap().push(label.to_string());
            let path = std::path::PathBuf::from(format!("/tmp/mock-wt-{label}"));
            Ok(IsolationHandle {
                path,
                observed: ObservedIsolation::new(&request.kind),
                finalize: Box::new(|| {
                    Ok(IsolationOutcome {
                        summary: "=== mock diff ===\nfoo.rs | 1 +".to_string(),
                        artifacts: Vec::new(),
                        evidence: Vec::new(),
                    })
                }),
            })
        }
    }

    /// Build an executor with a worktree factory wired into its config.
    fn make_executor_with_factory(
        provider: Arc<dyn IsolationProvider>,
    ) -> (Arc<SubagentRegistry>, SubagentExecutor) {
        let registry = Arc::new(SubagentRegistry::new());
        let executor = SubagentExecutor::new(
            registry.clone(),
            SubagentExecutorConfig {
                isolation_provider: Some(provider),
                ..SubagentExecutorConfig::default()
            },
        );
        (registry, executor)
    }

    #[tokio::test]
    async fn fork_provider_binds_path_and_appends_outcome() {
        let factory = Arc::new(MockIsolationProvider {
            labels: StdMutex::new(Vec::new()),
            should_fail: false,
        });
        let factory_obs: Arc<dyn IsolationProvider> = factory.clone();
        let (registry, executor) = make_executor_with_factory(factory_obs);

        let agent = MockAgent::new("writer").with_response("done");
        let def = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            isolation: Some("sandbox".to_string()),
            ..super::super::types::SubagentDefinition::new("writer", "Writer")
        };
        registry.register(def, Box::new(agent.clone())).await;

        let req = DispatchRequest {
            agent_name: "writer".into(),
            task: "edit foo".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let result = executor.dispatch(req).await.unwrap();
        // Output = subagent's answer + appended diff (the diff append is the
        // observable proof that the worktree was created and finalized).
        assert!(result.output.contains("done"));
        assert!(result.output.contains("=== mock diff ==="));
        // Factory was invoked once with a label derived from the agent name.
        let labels = factory.labels.lock().unwrap().clone();
        assert_eq!(labels.len(), 1);
        assert!(labels[0].starts_with("writer-"));
    }

    #[tokio::test]
    async fn fork_worktree_prefers_stable_isolation_identity() -> std::result::Result<(), String> {
        let factory = Arc::new(MockIsolationProvider {
            labels: StdMutex::new(Vec::new()),
            should_fail: false,
        });
        let factory_for_executor: Arc<dyn IsolationProvider> = factory.clone();
        let (registry, executor) = make_executor_with_factory(factory_for_executor);
        let agent = MockAgent::new("writer").with_response("done");
        let definition = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            isolation: Some("sandbox".to_string()),
            ..super::super::types::SubagentDefinition::new("writer", "Writer")
        };
        registry.register(definition, Box::new(agent)).await;

        executor
            .dispatch(DispatchRequest {
                agent_name: "writer".to_string(),
                task: "retry the same logical task".to_string(),
                mode_override: None,
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: Some(echo_core::tools::ExternalRunContext {
                    conversation_id: None,
                    run_id: Some("run-1".to_string()),
                    turn_id: None,
                    execution_id: Some("task-1:2".to_string()),
                    isolation_id: Some("run-1:task-1".to_string()),
                    message_id: None,
                    cancel: None,
                    trace_sink: None,
                    delegation_policy: None,
                    resource_guards: Vec::new(),
                    subagent_lineage: None,
                    uplink: None,
                }),
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .map_err(|error| error.to_string())?;

        let labels = factory
            .labels
            .lock()
            .map_err(|error| error.to_string())?
            .clone();
        if labels != vec!["writer-run-1:task-1".to_string()] {
            return Err(format!("unexpected worktree labels: {labels:?}"));
        }
        Ok(())
    }

    #[tokio::test]
    async fn fork_worktree_observation_precedes_subagent_completion()
    -> std::result::Result<(), String> {
        let factory = Arc::new(MockIsolationProvider {
            labels: StdMutex::new(Vec::new()),
            should_fail: false,
        });
        let factory_obs: Arc<dyn IsolationProvider> = factory;
        let (registry, executor) = make_executor_with_factory(factory_obs);
        let agent = MockAgent::new("writer").with_response("done");
        let def = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            isolation: Some("sandbox".to_string()),
            ..super::super::types::SubagentDefinition::new("writer", "Writer")
        };
        registry.register(def, Box::new(agent)).await;
        let mut events = registry.event_bus().subscribe();
        let req = DispatchRequest {
            agent_name: "writer".into(),
            task: "edit foo".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let result = executor
            .dispatch(req)
            .await
            .map_err(|error| error.to_string())?;
        if result.isolation_observed != ObservedIsolation::new("sandbox") {
            return Err(format!(
                "expected worktree result observation, got {:?}",
                result.isolation_observed
            ));
        }
        let started = events.recv().await.map_err(|error| error.to_string())?;
        let observed = events.recv().await.map_err(|error| error.to_string())?;
        let completed = events.recv().await.map_err(|error| error.to_string())?;
        if !matches!(started.as_ref(), SubagentEvent::DispatchStarted { .. }) {
            return Err(format!("first event was not started: {started:?}"));
        }
        if !matches!(
            observed.as_ref(),
            SubagentEvent::DispatchIsolationObserved { isolation, .. }
                if isolation.as_str() == "sandbox"
        ) {
            return Err(format!(
                "second event was not worktree observation: {observed:?}"
            ));
        }
        if !matches!(completed.as_ref(), SubagentEvent::DispatchCompleted { .. }) {
            return Err(format!("third event was not completed: {completed:?}"));
        }
        Ok(())
    }

    #[tokio::test]
    async fn concurrent_forks_carry_distinct_worktree_invocations()
    -> std::result::Result<(), String> {
        let factory = Arc::new(MockIsolationProvider {
            labels: StdMutex::new(Vec::new()),
            should_fail: false,
        });
        let factory_obs: Arc<dyn IsolationProvider> = factory;
        let (registry, executor) = make_executor_with_factory(factory_obs);
        let agent = MockAgent::new("writer").with_responses(["done-a", "done-b"]);
        let def = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            isolation: Some("sandbox".to_string()),
            ..super::super::types::SubagentDefinition::new("writer", "Writer")
        };
        registry.register(def, Box::new(agent.clone())).await;
        let executor = Arc::new(executor);
        let request = |run_id: &str| DispatchRequest {
            agent_name: "writer".into(),
            task: format!("edit for {run_id}"),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: Some(echo_core::tools::ExternalRunContext {
                conversation_id: None,
                run_id: Some(run_id.to_string()),
                turn_id: None,
                execution_id: Some(format!("execution-{run_id}")),
                isolation_id: None,
                message_id: None,
                cancel: None,
                trace_sink: None,
                delegation_policy: None,
                resource_guards: Vec::new(),
                subagent_lineage: None,
                uplink: None,
            }),
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let first = {
            let executor = Arc::clone(&executor);
            async move { executor.dispatch(request("run-a")).await }
        };
        let second = {
            let executor = Arc::clone(&executor);
            async move { executor.dispatch(request("run-b")).await }
        };
        let (first_result, second_result) = tokio::join!(first, second);
        first_result.map_err(|error| error.to_string())?;
        second_result.map_err(|error| error.to_string())?;

        let invocations = agent.invocation_contexts();
        if invocations.len() != 2 {
            return Err(format!(
                "expected two value-scoped invocations, got {invocations:?}"
            ));
        }
        for invocation in invocations {
            let runtime = invocation
                .runtime
                .ok_or_else(|| "fork invocation missing runtime context".to_string())?;
            let run_id = runtime
                .run_id
                .ok_or_else(|| "fork invocation missing run id".to_string())?;
            let working_dir = invocation
                .working_dir
                .ok_or_else(|| format!("{run_id} missing worktree path"))?;
            let path = working_dir.to_string_lossy();
            if !path.contains(run_id.as_str()) {
                return Err(format!(
                    "cross-worktree invocation: run {} received {}",
                    run_id, path
                ));
            }
        }
        Ok(())
    }

    #[tokio::test]
    async fn fork_isolation_provider_failure_fails_dispatch() {
        // A factory that hard-fails → dispatch must fail, never run unisolated.
        let factory = Arc::new(MockIsolationProvider {
            labels: StdMutex::new(Vec::new()),
            should_fail: true,
        });
        let factory_obs: Arc<dyn IsolationProvider> = factory;
        let (registry, executor) = make_executor_with_factory(factory_obs);

        let agent = MockAgent::new("writer").with_response("done");
        let def = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            isolation: Some("sandbox".to_string()),
            ..super::super::types::SubagentDefinition::new("writer", "Writer")
        };
        registry.register(def, Box::new(agent.clone())).await;

        let req = DispatchRequest {
            agent_name: "writer".into(),
            task: "edit foo".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let err = executor.dispatch(req).await.unwrap_err();
        assert!(
            err.to_string().contains("Isolation 'sandbox'"),
            "got: {err}"
        );
        // The dispatch hard-failed (the safety gate) — never silently continued
        // without isolation. The error message itself is the proof; we don't
        // assert on MockAgent's recorded working_dir_calls because the registry
        // stores the agent behind an Arc<dyn Agent> and the recorded-state
        // sharing across the clone boundary is not reliably observable here.
        let _ = agent; // suppress unused warning
    }

    #[tokio::test]
    async fn fork_isolate_without_factory_hard_fails() {
        // A requested boundary with no provider must hard-fail.
        let (registry, executor) = make_executor().await; // default config, no factory

        let agent = MockAgent::new("writer").with_response("done");
        let def = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            isolation: Some("sandbox".to_string()),
            ..super::super::types::SubagentDefinition::new("writer", "Writer")
        };
        registry.register(def, Box::new(agent.clone())).await;

        let req = DispatchRequest {
            agent_name: "writer".into(),
            task: "edit foo".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let err = executor.dispatch(req).await.unwrap_err();
        assert!(
            err.to_string().contains("no IsolationProvider")
                || err
                    .to_string()
                    .contains("refusing to run without isolation"),
            "got: {err}"
        );
        let _ = agent;
    }

    #[tokio::test]
    async fn fork_without_isolation_does_not_invoke_provider() {
        // A subagent with no isolation request never invokes the provider.
        let factory = Arc::new(MockIsolationProvider {
            labels: StdMutex::new(Vec::new()),
            should_fail: false,
        });
        let factory_obs: Arc<dyn IsolationProvider> = factory.clone();
        let (registry, executor) = make_executor_with_factory(factory_obs);

        let agent = MockAgent::new("reader").with_response("ok");
        let def = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            ..super::super::types::SubagentDefinition::new("reader", "Reader")
        };
        registry.register(def, Box::new(agent.clone())).await;

        let req = DispatchRequest {
            agent_name: "reader".into(),
            task: "read foo".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let result = executor.dispatch(req).await.unwrap();
        assert_eq!(result.output, "ok");
        assert_eq!(result.isolation_observed, ObservedIsolation::new("context"));
        // Factory never invoked — readonly subagents don't request isolation.
        assert!(factory.labels.lock().unwrap().is_empty());
        let _ = agent;
    }

    // A second provider proves the framework treats isolation kinds opaquely.

    /// A second mock provider used with a different opaque isolation kind.
    struct MockWorkspaceFactory {
        labels: StdMutex<Vec<String>>,
        should_fail: bool,
    }

    impl IsolationProvider for MockWorkspaceFactory {
        fn isolate(
            &self,
            request: &IsolationRequest,
        ) -> std::result::Result<IsolationHandle, IsolationError> {
            if self.should_fail {
                return Err(IsolationError::new("mock workspace create failed"));
            }
            let label = &request.label;
            self.labels.lock().unwrap().push(label.to_string());
            Ok(IsolationHandle {
                path: std::path::PathBuf::from(format!("/tmp/mock-ws-{label}")),
                observed: ObservedIsolation::new(&request.kind),
                finalize: Box::new(|| {
                    Ok(IsolationOutcome {
                        summary: "run_001_clean.parquet\nrun_001_stats.json".to_string(),
                        artifacts: Vec::new(),
                        evidence: Vec::new(),
                    })
                }),
            })
        }
    }

    /// Build an executor with a data-workspace factory wired into its config.
    fn make_executor_with_workspace_factory(
        provider: Arc<dyn IsolationProvider>,
    ) -> (Arc<SubagentRegistry>, SubagentExecutor) {
        let registry = Arc::new(SubagentRegistry::new());
        let executor = SubagentExecutor::new(
            registry.clone(),
            SubagentExecutorConfig {
                isolation_provider: Some(provider),
                ..SubagentExecutorConfig::default()
            },
        );
        (registry, executor)
    }

    #[tokio::test]
    async fn fork_arbitrary_isolation_kind_appends_provider_summary() {
        let factory = Arc::new(MockWorkspaceFactory {
            labels: StdMutex::new(Vec::new()),
            should_fail: false,
        });
        let factory_obs: Arc<dyn IsolationProvider> = factory.clone();
        let (registry, executor) = make_executor_with_workspace_factory(factory_obs);

        let agent = MockAgent::new("analyst").with_response("analysis done");
        let def = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            isolation: Some("workspace".to_string()),
            ..super::super::types::SubagentDefinition::new("analyst", "Analyst")
        };
        registry.register(def, Box::new(agent)).await;

        let req = DispatchRequest {
            agent_name: "analyst".into(),
            task: "analyze data".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let result = executor.dispatch(req).await.unwrap();
        assert!(result.output.contains("analysis done"));
        assert!(result.output.contains("run_001_clean.parquet"));
        assert!(result.output.contains("--- isolation outcome ---"));
        assert_eq!(
            result.isolation_observed,
            ObservedIsolation::new("workspace")
        );
        // Factory invoked once with a label derived from the agent name.
        let labels = factory.labels.lock().unwrap().clone();
        assert_eq!(labels.len(), 1);
        assert!(labels[0].starts_with("analyst-"));
    }

    #[tokio::test]
    async fn fork_arbitrary_isolation_kind_propagates_provider_failure() {
        // Workspace factory hard-fails → dispatch fails (safety gate).
        let factory = Arc::new(MockWorkspaceFactory {
            labels: StdMutex::new(Vec::new()),
            should_fail: true,
        });
        let factory_obs: Arc<dyn IsolationProvider> = factory;
        let (registry, executor) = make_executor_with_workspace_factory(factory_obs);

        let agent = MockAgent::new("analyst").with_response("ok");
        let def = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            isolation: Some("workspace".to_string()),
            ..super::super::types::SubagentDefinition::new("analyst", "Analyst")
        };
        registry.register(def, Box::new(agent)).await;

        let req = DispatchRequest {
            agent_name: "analyst".into(),
            task: "analyze".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let err = executor.dispatch(req).await.unwrap_err();
        assert!(
            err.to_string().contains("Isolation 'workspace'"),
            "got: {err}"
        );
    }

    #[tokio::test]
    async fn fork_uses_only_the_configured_provider() {
        let ws_factory = Arc::new(MockWorkspaceFactory {
            labels: StdMutex::new(Vec::new()),
            should_fail: false,
        });
        let wt_factory = Arc::new(MockIsolationProvider {
            labels: StdMutex::new(Vec::new()),
            should_fail: false,
        });
        let registry = Arc::new(SubagentRegistry::new());
        let executor = SubagentExecutor::new(
            registry.clone(),
            SubagentExecutorConfig {
                isolation_provider: Some(wt_factory.clone()),
                ..SubagentExecutorConfig::default()
            },
        );

        let agent = MockAgent::new("w").with_response("done");
        let def = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            isolation: Some("sandbox".to_string()),
            ..super::super::types::SubagentDefinition::new("w", "Writer")
        };
        registry.register(def, Box::new(agent)).await;

        let req = DispatchRequest {
            agent_name: "w".into(),
            task: "work".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let result = executor.dispatch(req).await.unwrap();
        // Worktree was used (mock diff appended), workspace was NOT.
        assert!(result.output.contains("=== mock diff ==="));
        assert!(
            ws_factory.labels.lock().unwrap().is_empty(),
            "workspace factory must not be invoked when worktree is active"
        );
        assert!(
            !wt_factory.labels.lock().unwrap().is_empty(),
            "worktree factory should have been invoked"
        );
    }
}
