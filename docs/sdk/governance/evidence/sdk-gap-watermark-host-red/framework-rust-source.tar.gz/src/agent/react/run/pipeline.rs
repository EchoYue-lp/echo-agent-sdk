//! Tool execution pipeline — composable stages for tool call processing.
//!
//! Replaces the monolithic `execute_tool_feedback_raw` with a configurable
//! pipeline of discrete internal stages coordinated by `ToolExecutionPipeline`.

use super::context::HookMessageBatches;
use crate::agent::{ToolInvocation, ToolInvocationRewrite};
use crate::error::{ReactError, Result};
use crate::tools::{ToolParameters, ToolResult, ToolStreamEvent, is_write_tool};
use async_trait::async_trait;
use echo_core::tools::permission::{PermissionDecision, PermissionMode, ToolApprovalReceipt};
use serde_json::Value;
use tokio::sync::mpsc;
use tracing::debug;

// Complete tool results stay inline so the pipeline preserves the same typed
// stream event without adding an allocation to every streamed item.
#[allow(clippy::large_enum_variant)]
pub(crate) enum ToolPipelineEvent {
    Invocation {
        call_id: String,
        invocation: ToolInvocation,
    },
    Stream {
        call_id: String,
        name: String,
        event: ToolStreamEvent,
    },
}

// ── ToolExecutionContext ────────────────────────────────────────────

/// Mutable context that flows through the pipeline stages.
pub(crate) struct ToolExecutionContext {
    /// Unique call ID linking the canonical ToolCall and typed ToolResult.
    pub call_id: String,
    /// Original model-requested tool name.
    pub requested_tool_name: String,
    /// Original model-requested arguments.
    pub requested_input: Value,
    /// Name of the tool being executed.
    pub tool_name: String,
    /// Parsed tool parameters.
    pub params: ToolParameters,
    /// Raw JSON input from the LLM.
    pub input: Value,
    /// Messages accumulated by hooks (pre/post).
    pub hook_messages: HookMessageBatches,
    /// Filled by the Execute stage.
    pub result: Option<ToolResult>,
    /// Final output string (after output guard + truncation).
    pub output: Option<String>,
    /// Guarded diagnostic for audit when a failure has no tool output.
    pub audit_error_output: Option<String>,
    /// Whether a stage has blocked execution.
    pub blocked: bool,
    /// Reason for blocking (if blocked).
    pub block_reason: Option<String>,
    /// Structured terminal facts when execution is blocked before the tool starts.
    pub block_failure: Option<crate::tools::ToolFailure>,
    /// Execution duration in milliseconds.
    pub duration_ms: u64,
    /// Whether the agent is in plan mode (read-only tools only).
    pub plan_mode: bool,
    /// Permission decision returned by PreToolUse hooks for this call only.
    pub permission_decision: Option<PermissionDecision>,
    /// Approval proof bound to the final effective invocation.
    pub approval_receipt: Option<ToolApprovalReceipt>,
    /// Permission mode override returned by hooks for this call only.
    pub permission_mode_override: Option<PermissionMode>,
    /// Ordered provenance for policy rewrites applied before execution.
    pub rewrites: Vec<ToolInvocationRewrite>,
    /// Whether the canonical invocation event has been emitted.
    pub invocation_emitted: bool,
    /// Whether callbacks observed the start of this invocation.
    pub callback_started: bool,
    /// An execution error that interrupted a tool before it returned a result.
    pub interrupted_execution_error: Option<ReactError>,
    /// Incremental tool events, tagged with their stable invocation identity.
    pub stream_tx: Option<mpsc::Sender<ToolPipelineEvent>>,
}

impl ToolExecutionContext {
    fn block(&mut self, category: crate::tools::ToolFailureCategory, reason: String) {
        self.blocked = true;
        self.block_reason = Some(reason.clone());
        self.block_failure = Some(crate::tools::ToolFailure::new(category));
        self.output = Some(reason);
    }

    fn replace_input(&mut self, input: Value, rewrite: ToolInvocationRewrite) -> Result<()> {
        let Value::Object(map) = &input else {
            return Err(ReactError::Other(format!(
                "Tool '{}' rewrite returned non-object arguments",
                self.tool_name
            )));
        };
        if input != self.input {
            self.rewrites.push(rewrite);
        }
        self.params = map
            .iter()
            .map(|(key, value)| (key.clone(), value.clone()))
            .collect();
        self.input = input;
        Ok(())
    }

    fn issue_approval_receipt(&mut self) -> Result<()> {
        self.approval_receipt = Some(
            ToolApprovalReceipt::issue(&self.tool_name, &self.input).map_err(|error| {
                ReactError::Other(format!("failed to canonicalize approval input: {error}"))
            })?,
        );
        Ok(())
    }

    async fn emit_invocation(&mut self) -> Result<()> {
        if self.call_id.is_empty() {
            self.call_id = format!("call_{}", uuid::Uuid::new_v4());
        }
        if self.invocation_emitted {
            return Ok(());
        }
        if let Some(stream_tx) = self.stream_tx.as_ref() {
            stream_tx
                .send(ToolPipelineEvent::Invocation {
                    call_id: self.call_id.clone(),
                    invocation: ToolInvocation {
                        requested_name: self.requested_tool_name.clone(),
                        requested_args: self.requested_input.clone(),
                        name: self.tool_name.clone(),
                        args: self.input.clone(),
                        rewrites: self.rewrites.clone(),
                    },
                })
                .await
                .map_err(|_| ReactError::Other("Tool event receiver closed".to_string()))?;
        }
        self.invocation_emitted = true;
        Ok(())
    }
}

// ── PipelineStage trait ────────────────────────────────────────────

/// A single stage in the tool execution pipeline.
///
/// Each stage receives a mutable [`ToolExecutionContext`] and may modify it.
/// Returning `Err` short-circuits the pipeline (tool execution failure).
/// Setting `ctx.blocked = true` causes subsequent stages to be skipped.
#[async_trait]
pub(crate) trait PipelineStage: Send + Sync {
    /// Human-readable name for logging and debugging.
    fn name(&self) -> &str;

    /// Execute this stage.
    async fn run(
        &self,
        ctx: &mut ToolExecutionContext,
        snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    ) -> Result<()>;

    /// Whether this stage must still run after `ctx.blocked` is set.
    ///
    /// Execution-gating stages stop the pipeline as before, but observation
    /// stages that record what already happened (trace, terminal callbacks)
    /// opt in so a blocked call still leaves a faithful record (#102).
    fn runs_after_block(&self) -> bool {
        false
    }
}

// ── Stage implementations ──────────────────────────────────────────

/// Intervention callback stage — checks intervention callbacks before all other stages.
///
/// This is the highest-priority decision point. Intervention callbacks can
/// block, cancel, redirect, modify arguments, or inject context.
pub struct InterventionStage;

#[async_trait]
impl PipelineStage for InterventionStage {
    fn name(&self) -> &str {
        "intervention"
    }

    async fn run(
        &self,
        ctx: &mut ToolExecutionContext,
        snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    ) -> Result<()> {
        for intervention in &snapshot.tools.intervention_callbacks {
            let result = intervention
                .on_tool_call(&snapshot.config.agent_name, &ctx.tool_name, &ctx.input)
                .await;
            if result.cancel {
                return Err(ReactError::Other(format!(
                    "Agent execution cancelled by intervention: tool {}",
                    ctx.tool_name
                )));
            }
            if result.block {
                let reason = result
                    .block_reason
                    .unwrap_or_else(|| "blocked by intervention callback".into());
                ctx.block(
                    crate::tools::ToolFailureCategory::Permanent,
                    format!("Tool {} blocked by intervention: {}", ctx.tool_name, reason),
                );
                return Ok(());
            }
            if let Some(redirect) = result.redirect_to {
                if redirect != ctx.tool_name {
                    ctx.rewrites
                        .push(ToolInvocationRewrite::InterventionRedirect);
                }
                ctx.tool_name = redirect;
            }
            if let Some(modified) = result.modified_args {
                ctx.replace_input(modified, ToolInvocationRewrite::InterventionArguments)?;
            }
            if let Some(injected) = result.injected_context {
                ctx.hook_messages.pre.push(injected);
            }
        }
        Ok(())
    }
}

/// Enforces the invocation-scoped tool surface at execution time.
pub struct ToolVisibilityStage;

#[async_trait]
impl PipelineStage for ToolVisibilityStage {
    fn name(&self) -> &str {
        "tool_visibility"
    }

    async fn run(
        &self,
        ctx: &mut ToolExecutionContext,
        snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    ) -> Result<()> {
        if snapshot.tools.disabled_tools.contains(&ctx.tool_name) {
            snapshot.tools.tool_manager.record_tool_selection_failure();
            ctx.block(
                crate::tools::ToolFailureCategory::Unavailable,
                format!(
                    "Tool '{}' is not available in this invocation",
                    ctx.tool_name
                ),
            );
        } else if snapshot
            .tools
            .visibility
            .as_ref()
            .is_some_and(|visibility| !visibility.is_visible(&ctx.tool_name))
        {
            snapshot.tools.tool_manager.record_tool_selection_failure();
            ctx.block(
                crate::tools::ToolFailureCategory::Unavailable,
                format!(
                    "Tool '{}' is not activated in this invocation; use tool_search first",
                    ctx.tool_name
                ),
            );
        }
        Ok(())
    }
}

/// Runs PreToolUse hooks.
pub struct PreToolUseHookStage;

#[async_trait]
impl PipelineStage for PreToolUseHookStage {
    fn name(&self) -> &str {
        "pre_tool_use_hook"
    }

    async fn run(
        &self,
        ctx: &mut ToolExecutionContext,
        snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    ) -> Result<()> {
        let has_hooks = {
            let hook_reg = snapshot.tools.hook_registry.read().await;
            !hook_reg.is_empty()
        };
        if !has_hooks {
            return Ok(());
        }

        let hook_reg = {
            let guard = snapshot.tools.hook_registry.read().await;
            guard.clone()
        };
        let hook_result = hook_reg
            .run_pre_tool_use(
                &ctx.tool_name,
                &ctx.input,
                snapshot.config.session_id.as_deref().unwrap_or(""),
            )
            .await;
        ctx.hook_messages.pre = hook_result.messages.clone();
        ctx.permission_decision = hook_result.permission_decision.clone();
        ctx.permission_mode_override = hook_result.permission_mode_override;

        if hook_result.block {
            let reason = hook_result
                .block_reason
                .unwrap_or_else(|| format!("Tool {} blocked by hook", ctx.tool_name));
            snapshot
                .record_permission_decision(
                    &ctx.tool_name,
                    &PermissionDecision::Deny {
                        reason: reason.clone(),
                    },
                    "pre_tool_use_hook",
                )
                .await;
            ctx.block(crate::tools::ToolFailureCategory::Permanent, reason);
            return Ok(());
        }

        if let Some(updated) = hook_result.updated_input {
            ctx.replace_input(updated, ToolInvocationRewrite::PreToolUseHook)?;
        }
        Ok(())
    }
}

impl crate::agent::snapshot::AgentRunSnapshot {
    pub(crate) async fn record_permission_decision(
        &self,
        tool: &str,
        decision: &PermissionDecision,
        source: &str,
    ) {
        let (decision, reason) = match decision {
            PermissionDecision::Allow => ("allow", source.to_string()),
            PermissionDecision::Deny { reason } => ("deny", format!("{source}: {reason}")),
            PermissionDecision::RequireApproval => ("ask", format!("{source}: requires approval")),
            PermissionDecision::Ask { .. } => ("ask", format!("{source}: requires user input")),
        };
        self.record_event(crate::trace::RunEvent::PermissionDecision {
            tool: tool.to_string(),
            decision: decision.to_string(),
            reason,
        })
        .await;
    }
}

/// Checks tool approval (PermissionService).
pub struct PermissionStage;

#[async_trait]
impl PipelineStage for PermissionStage {
    fn name(&self) -> &str {
        "permission"
    }

    async fn run(
        &self,
        ctx: &mut ToolExecutionContext,
        snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    ) -> Result<()> {
        #[cfg(feature = "human-loop")]
        if let Some(decision) = snapshot
            .permission_service
            .as_ref()
            .and_then(|service| service.protected_path_decision(&ctx.tool_name, &ctx.input))
        {
            snapshot
                .record_permission_decision(&ctx.tool_name, &decision, "protected_paths")
                .await;
            if let PermissionDecision::Deny { reason } = decision {
                ctx.block(crate::tools::ToolFailureCategory::Permanent, reason);
                return Ok(());
            }
        }
        if let Some(decision) = ctx.permission_decision.take() {
            snapshot
                .record_permission_decision(&ctx.tool_name, &decision, "pre_tool_use_hook")
                .await;
            match decision {
                PermissionDecision::Allow => {
                    ctx.issue_approval_receipt()?;
                    return Ok(());
                }
                PermissionDecision::Deny { reason } => {
                    ctx.block(crate::tools::ToolFailureCategory::Permanent, reason);
                    return Ok(());
                }
                PermissionDecision::Ask { .. } | PermissionDecision::RequireApproval => {}
            }
        }

        let permission_hook = {
            let registry = snapshot.tools.hook_registry.read().await.clone();
            let context = crate::skills::hooks::HookContext::for_permission_request(
                &ctx.tool_name,
                &ctx.input,
                snapshot.config.session_id.as_deref().unwrap_or(""),
                &snapshot.config.agent_name,
            );
            registry.run_lifecycle_hooks(&context).await
        };
        ctx.hook_messages.pre.extend(permission_hook.messages);
        if permission_hook.block {
            let reason = permission_hook
                .block_reason
                .unwrap_or_else(|| format!("Tool {} blocked by permission hook", ctx.tool_name));
            snapshot
                .record_permission_decision(
                    &ctx.tool_name,
                    &PermissionDecision::Deny {
                        reason: reason.clone(),
                    },
                    "permission_request_hook",
                )
                .await;
            ctx.block(crate::tools::ToolFailureCategory::Permanent, reason);
            return Ok(());
        }
        if let Some(mode) = permission_hook.permission_mode_override {
            ctx.permission_mode_override = Some(mode);
        }
        if let Some(updated) = permission_hook.updated_input {
            ctx.replace_input(updated, ToolInvocationRewrite::Approval)?;
            #[cfg(feature = "human-loop")]
            if let Some(decision) = snapshot
                .permission_service
                .as_ref()
                .and_then(|service| service.protected_path_decision(&ctx.tool_name, &ctx.input))
            {
                snapshot
                    .record_permission_decision(&ctx.tool_name, &decision, "protected_paths")
                    .await;
                if let PermissionDecision::Deny { reason } = decision {
                    ctx.block(crate::tools::ToolFailureCategory::Permanent, reason);
                    return Ok(());
                }
            }
        }
        if let Some(decision) = permission_hook.permission_decision {
            snapshot
                .record_permission_decision(&ctx.tool_name, &decision, "permission_request_hook")
                .await;
            match decision {
                PermissionDecision::Allow => {
                    ctx.issue_approval_receipt()?;
                    return Ok(());
                }
                PermissionDecision::Deny { reason } => {
                    ctx.block(crate::tools::ToolFailureCategory::Permanent, reason);
                    return Ok(());
                }
                PermissionDecision::Ask { .. } | PermissionDecision::RequireApproval => {}
            }
        }

        #[cfg(feature = "human-loop")]
        let approval_check = snapshot
            .check_tool_approval_with_receipt(
                &ctx.call_id,
                &ctx.tool_name,
                &ctx.input,
                ctx.permission_mode_override,
            )
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;

        #[cfg(not(feature = "human-loop"))]
        let approval_check = snapshot
            .check_tool_approval_with_receipt(
                &ctx.call_id,
                &ctx.tool_name,
                &ctx.input,
                ctx.permission_mode_override,
            )
            .await
            .map_err(|_| ReactError::Other("Permission check failed".into()))?;

        if let Some(check) = approval_check {
            let echo_orchestration::human_loop::PermissionCheck {
                decision,
                updated_input,
                approval_receipt,
            } = check;
            if let Some(modified) = updated_input {
                ctx.replace_input(modified, ToolInvocationRewrite::Approval)?;
            }
            match decision {
                PermissionDecision::Allow => {
                    if let Some(receipt) = approval_receipt {
                        if receipt.matches(&ctx.tool_name, &ctx.input) {
                            ctx.approval_receipt = Some(receipt);
                        } else {
                            return Err(ReactError::Other(
                                "permission approval receipt does not match effective tool input"
                                    .to_string(),
                            ));
                        }
                    }
                }
                PermissionDecision::Deny { reason } => {
                    ctx.block(crate::tools::ToolFailureCategory::Permanent, reason);
                }
                PermissionDecision::RequireApproval | PermissionDecision::Ask { .. } => {
                    ctx.block(
                        crate::tools::ToolFailureCategory::Permanent,
                        format!("Tool '{}' requires user approval", ctx.tool_name),
                    );
                }
            }
        }
        Ok(())
    }
}

/// Enforces read-before-edit policy.
pub struct ReadBeforeEditStage;

#[async_trait]
impl PipelineStage for ReadBeforeEditStage {
    fn name(&self) -> &str {
        "read_before_edit"
    }

    async fn run(
        &self,
        ctx: &mut ToolExecutionContext,
        snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    ) -> Result<()> {
        if !snapshot.config.force_read_before_edit {
            return Ok(());
        }
        if !is_write_tool(&ctx.tool_name) {
            return Ok(());
        }
        let paths = extract_path_params(&ctx.tool_name, &ctx.params);
        let ttl = std::time::Duration::from_secs(30 * 60);
        let mut files = snapshot
            .recently_read_files
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        for path in paths {
            let canonical = resolve_tracking_path(&path, snapshot.config.working_dir.as_deref());
            let read = match files.get(&canonical) {
                Some(instant) if instant.elapsed() < ttl => true,
                Some(_) => {
                    files.remove(&canonical);
                    false
                }
                None => false,
            };
            if !read {
                ctx.block(crate::tools::ToolFailureCategory::Unavailable, format!(
                    "Read-before-edit is enabled. File '{path}' has not been read. Use read_file first."
                ));
                break;
            }
        }
        Ok(())
    }
}

/// Checks skill-based tool permissions (skill_allowed_tools whitelist).
pub struct SkillPermissionStage;

#[async_trait]
impl PipelineStage for SkillPermissionStage {
    fn name(&self) -> &str {
        "skill_permission"
    }

    async fn run(
        &self,
        ctx: &mut ToolExecutionContext,
        snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    ) -> Result<()> {
        // Check if a skill is activated and has tool restrictions
        if !snapshot.tools.is_skill_tool_allowed(&ctx.tool_name) {
            let reason = format!(
                "Tool '{}' is not permitted by the activated skill's allowed_tools whitelist",
                ctx.tool_name
            );
            snapshot
                .record_permission_decision(
                    &ctx.tool_name,
                    &PermissionDecision::Deny {
                        reason: reason.clone(),
                    },
                    "skill_allowed_tools",
                )
                .await;
            ctx.block(crate::tools::ToolFailureCategory::Unavailable, reason);
        }
        Ok(())
    }
}

/// Checks the final effective tool arguments immediately before invocation.
///
/// Tool input guards are intentionally block-only.  Permission approval and
/// its receipt are already bound to `ctx.input` at this point; accepting a
/// transformed payload here would authorize one value and execute another.
pub struct ToolInputGuardStage;

#[async_trait]
impl PipelineStage for ToolInputGuardStage {
    fn name(&self) -> &str {
        "tool_input_guard"
    }

    async fn run(
        &self,
        ctx: &mut ToolExecutionContext,
        snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    ) -> Result<()> {
        let Some(guard_manager) = snapshot.guard.guard_manager.as_ref() else {
            return Ok(());
        };

        let content = match serde_json::to_string(&ctx.input) {
            Ok(content) => content,
            Err(error) => {
                let reason =
                    format!("Tool input guard could not serialize effective input: {error}");
                record_tool_input_guard_block(snapshot, &reason).await;
                ctx.block(crate::tools::ToolFailureCategory::Permanent, reason);
                return Ok(());
            }
        };
        let result = match guard_manager
            .check_all(&content, crate::guard::GuardDirection::ToolInput)
            .await
        {
            Ok(result) => result,
            Err(error) => {
                let reason = format!("Tool input guard failed closed: {error}");
                record_tool_input_guard_block(snapshot, &reason).await;
                ctx.block(crate::tools::ToolFailureCategory::Permanent, reason);
                return Ok(());
            }
        };

        match result {
            crate::guard::GuardResult::Pass | crate::guard::GuardResult::Warn { .. } => {}
            crate::guard::GuardResult::Block { reason } => {
                let reason = format!("Tool input blocked by guard: {reason}");
                record_tool_input_guard_block(snapshot, &reason).await;
                ctx.block(crate::tools::ToolFailureCategory::Permanent, reason);
            }
            crate::guard::GuardResult::Transform { reasons, .. } => {
                let detail = if reasons.is_empty() {
                    "guard returned a transform".to_string()
                } else {
                    reasons.join("; ")
                };
                let reason = format!("Tool input guard returned unsupported transform: {detail}");
                record_tool_input_guard_block(snapshot, &reason).await;
                ctx.block(crate::tools::ToolFailureCategory::Permanent, reason);
            }
        }
        Ok(())
    }
}

async fn record_tool_input_guard_block(
    snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    reason: &str,
) {
    if snapshot.guard.audit_logger.is_some() {
        let event = crate::audit::AuditEvent::now(
            snapshot.config.session_id.clone(),
            snapshot.config.agent_name.clone(),
            crate::audit::AuditEventType::GuardBlock {
                guard: "guard_manager".to_string(),
                direction: crate::guard::GuardDirection::ToolInput,
                reason: reason.to_string(),
            },
        );
        snapshot.record_audit_event(event).await;
    }
}

/// Records the settled tool outcome in the configured audit logger.
pub struct AuditStage;

#[async_trait]
impl PipelineStage for AuditStage {
    fn name(&self) -> &str {
        "audit"
    }

    fn runs_after_block(&self) -> bool {
        true
    }

    async fn run(
        &self,
        ctx: &mut ToolExecutionContext,
        snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    ) -> Result<()> {
        if let (Some(_), Some(result)) = (&snapshot.guard.audit_logger, &ctx.result) {
            // A post-use hook can reject an effect that has already happened.
            // Retain that output while reporting the final failure status.
            let output = if !result.success && result.output.is_empty() {
                ctx.audit_error_output.as_deref().unwrap_or("")
            } else {
                ctx.output.as_deref().unwrap_or(&result.output)
            };
            let ev = crate::audit::AuditEvent::now(
                snapshot.config.session_id.clone(),
                snapshot.config.agent_name.clone(),
                crate::audit::AuditEventType::ToolCall {
                    call_id: Some(ctx.call_id.clone()),
                    tool: ctx.tool_name.clone(),
                    input: ctx.input.clone(),
                    output: output.to_string(),
                    success: result.success,
                    duration_ms: ctx.duration_ms,
                },
            );
            snapshot.record_audit_event(ev).await;
        }
        Ok(())
    }
}

/// Publishes the one canonical requested/effective invocation before execution.
pub struct InvocationStage;

#[async_trait]
impl PipelineStage for InvocationStage {
    fn name(&self) -> &str {
        "invocation"
    }

    async fn run(
        &self,
        ctx: &mut ToolExecutionContext,
        _snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    ) -> Result<()> {
        ctx.emit_invocation().await
    }
}

/// Executes the tool via ToolManager.
pub struct ExecuteStage;

#[async_trait]
impl PipelineStage for ExecuteStage {
    fn name(&self) -> &str {
        "execute"
    }

    async fn run(
        &self,
        ctx: &mut ToolExecutionContext,
        snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    ) -> Result<()> {
        let execution_start = std::time::Instant::now();

        if ctx.call_id.is_empty() {
            ctx.call_id = format!("call_{}", uuid::Uuid::new_v4());
        }
        snapshot.mark_tool_execution_started(&ctx.call_id);
        // Record ToolCall trace event (redaction handled by new_tool_call)
        snapshot
            .record_event(crate::trace::RunEvent::new_tool_call(
                ctx.call_id.clone(),
                ctx.tool_name.clone(),
                Some(ctx.input.clone()),
                None,
                0,
            ))
            .await;

        // Execute tool; on infrastructure error, convert to ToolResult{success:false}
        // so downstream stages (trace, post-hook, callback) still execute.
        //
        // Build a per-agent ToolContext from the snapshot's RuntimeConfig so
        // the (shared, stateless) ToolManager receives the correct working_dir
        // for THIS agent/session — avoiding cross-session cwd contamination.
        let effect_sink: Option<echo_core::tools::ToolEffectSinkFn> =
            if snapshot.run_store.is_some() && snapshot.trace_run_id.is_some() {
                let invocation = snapshot.clone();
                let tool_name = ctx.tool_name.clone();
                let call_id = ctx.call_id.clone();
                Some(std::sync::Arc::new(move |effect| {
                    let invocation = invocation.clone();
                    let tool_name = tool_name.clone();
                    let call_id = call_id.clone();
                    Box::pin(async move {
                        invocation
                            .record_tool_effect(&effect, &tool_name, &call_id)
                            .await;
                    })
                }))
            } else {
                None
            };
        let tool_ctx = echo_core::tools::ToolContext {
            working_dir: snapshot.config.working_dir.clone(),
            conversation_id: snapshot.config.conversation_id.clone(),
            run_id: snapshot.current_run_id.clone(),
            turn_id: snapshot.current_turn_id.clone(),
            message_id: snapshot.current_message_id.clone(),
            execution_id: snapshot.current_execution_id.clone(),
            call_id: Some(ctx.call_id.clone()),
            approval_receipt: ctx.approval_receipt.clone(),
            effect_sink,
            active_message: snapshot.current_message.clone(),
            output_artifacts: snapshot.config.tool_output_artifacts.clone(),
            tool_visibility: snapshot.tools.visibility.clone(),
            script_execution_profile: None,
            cancel: snapshot.external_cancel.clone(),
            trace_sink: snapshot.external_trace_sink.clone(),
            delegation_policy: snapshot.external_delegation_policy,
            resource_guards: snapshot.resource_guards.clone(),
            subagent_lineage: snapshot.subagent_lineage.clone(),
            uplink: snapshot.external_uplink.clone(),
        };

        let call_plan_mode =
            ctx.plan_mode || ctx.permission_mode_override == Some(PermissionMode::Plan);
        let admission_denial = std::sync::atomic::AtomicU8::new(0);
        let admission = |tool: &dyn echo_core::tools::Tool| -> Result<()> {
            if !tool.capabilities().is_read_only() {
                let denial_kind = if call_plan_mode || snapshot.tools.is_plan_mode() {
                    1
                } else if snapshot.tools.readonly_tools {
                    2
                } else {
                    0
                };
                if denial_kind == 0 {
                    return Ok(());
                }
                admission_denial.store(denial_kind, std::sync::atomic::Ordering::Release);
                let (reason, _) = read_only_surface_denial(tool.name(), denial_kind == 1);
                return Err(echo_core::error::ToolError::AccessDenied {
                    path: tool.name().to_string(),
                    reason,
                }
                .into());
            }
            Ok(())
        };

        let execution_result = if snapshot
            .tools
            .tool_manager
            .supports_streaming(&ctx.tool_name)
        {
            if let Some(stream_tx) = ctx.stream_tx.as_ref() {
                // A guard cannot approve a chunk before seeing the complete
                // result: policy matches may span chunk boundaries. The
                // terminal ToolResult remains the guarded output authority.
                let guarded_stream = snapshot.guard.guard_manager.is_some();
                let (event_tx, mut event_rx) = mpsc::channel(64);
                let mut execution = Box::pin(
                    snapshot
                        .tools
                        .tool_manager
                        .execute_tool_stream_with_context_draining_started_checked(
                            &ctx.tool_name,
                            ctx.params.clone(),
                            &tool_ctx,
                            Some(event_tx),
                            &admission,
                        ),
                );
                let mut stream_open = true;
                let result = loop {
                    tokio::select! {
                        biased;
                        event = event_rx.recv(), if stream_open => {
                            match event {
                                Some(event) => {
                                    if !guarded_stream && !matches!(event, ToolStreamEvent::Complete(_)) {
                                        stream_tx
                                            .send(ToolPipelineEvent::Stream {
                                                call_id: ctx.call_id.clone(),
                                                name: ctx.tool_name.clone(),
                                                event,
                                            })
                                            .await
                                            .map_err(|_| ReactError::Other("Tool stream receiver closed".into()))?;
                                    }
                                }
                                None => stream_open = false,
                            }
                        }
                        result = &mut execution => break result,
                    }
                };
                while let Some(event) = event_rx.recv().await {
                    if !guarded_stream && !matches!(event, ToolStreamEvent::Complete(_)) {
                        stream_tx
                            .send(ToolPipelineEvent::Stream {
                                call_id: ctx.call_id.clone(),
                                name: ctx.tool_name.clone(),
                                event,
                            })
                            .await
                            .map_err(|_| ReactError::Other("Tool stream receiver closed".into()))?;
                    }
                }
                result
            } else {
                snapshot
                    .tools
                    .tool_manager
                    .execute_tool_stream_with_context_draining_started_checked(
                        &ctx.tool_name,
                        ctx.params.clone(),
                        &tool_ctx,
                        None,
                        &admission,
                    )
                    .await
            }
        } else {
            snapshot
                .tools
                .tool_manager
                .execute_tool_with_context_draining_started_checked(
                    &ctx.tool_name,
                    ctx.params.clone(),
                    &tool_ctx,
                    &admission,
                )
                .await
        };

        let denial_kind = admission_denial.load(std::sync::atomic::Ordering::Acquire);
        let denial = match denial_kind {
            1 | 2 => Some(read_only_surface_denial(&ctx.tool_name, denial_kind == 1)),
            _ => None,
        };
        if let Some((reason, source)) = denial.as_ref() {
            snapshot
                .record_permission_decision(
                    &ctx.tool_name,
                    &PermissionDecision::Deny {
                        reason: reason.clone(),
                    },
                    source,
                )
                .await;
        }

        let may_have_side_effects = snapshot
            .tools
            .tool_manager
            .get_tool(&ctx.tool_name)
            .is_none_or(|tool| tool.risk_level() != crate::tools::ToolRiskLevel::ReadOnly);
        let result = match execution_result {
            Ok(r) => r,
            Err(e) => {
                let err_msg = e.to_string();
                let failure = crate::tools::ToolFailure::from_error(&e, may_have_side_effects);
                if matches!(
                    failure.category,
                    crate::tools::ToolFailureCategory::Cancelled
                        | crate::tools::ToolFailureCategory::Timeout
                ) && failure.side_effect == crate::tools::ToolSideEffect::Possible
                {
                    ctx.interrupted_execution_error = Some(e);
                }
                ToolResult {
                    kind: echo_core::tools::ToolResultKind::StructuredError {
                        error_code: "tool_execution_failed".into(),
                    },
                    success: false,
                    output: String::new(),
                    error: Some(err_msg),
                    failure: Some(failure),
                    data: None,
                    truncated: false,
                    mime_type: None,
                    artifact: None,
                    metadata: std::collections::HashMap::new(),
                    effects: Vec::new(),
                    model_content: Vec::new(),
                }
            }
        };

        ctx.duration_ms = u64::try_from(execution_start.elapsed().as_millis()).unwrap_or(u64::MAX);
        #[cfg(feature = "telemetry")]
        {
            crate::telemetry::Metrics::record_tool_execution(
                &ctx.tool_name,
                if result.success { "success" } else { "error" },
            );
            crate::telemetry::Metrics::record_tool_latency(
                &ctx.tool_name,
                execution_start.elapsed().as_secs_f64() * 1000.0,
            );
        }
        ctx.result = Some(result.clone());

        // A late policy denial remains blocked and unavailable while its
        // failed result still flows through terminal observation stages.
        if let Some((reason, _)) = denial {
            ctx.block(
                crate::tools::ToolFailureCategory::Unavailable,
                reason.clone(),
            );
            let block_failure = ctx.block_failure.clone();
            if let Some(result) = ctx.result.as_mut() {
                result.success = false;
                result.error = Some(reason);
                result.failure = block_failure;
            }
        }

        // Confirmed effects belong to the tool, not post-use presentation.
        // Persist them before a hook can stall or reject the returned result.
        for effect in &result.effects {
            snapshot
                .record_tool_effect(effect, &ctx.tool_name, &ctx.call_id)
                .await;
        }

        // The resolved path is a tool-owned fact; model arguments may be
        // relative or rewritten and cannot establish a successful read.
        if result.success {
            for effect in &result.effects {
                if let echo_core::tools::ToolEffect::FileRead { path } = effect {
                    snapshot.record_file_read(path);
                }
            }
        }

        Ok(())
    }
}

/// Runs PostToolUse or PostToolUseFailure hooks according to the tool result.
pub struct PostToolUseHookStage;

#[async_trait]
impl PipelineStage for PostToolUseHookStage {
    fn name(&self) -> &str {
        "post_tool_use_hook"
    }

    async fn run(
        &self,
        ctx: &mut ToolExecutionContext,
        snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    ) -> Result<()> {
        let hook_reg = {
            let guard = snapshot.tools.hook_registry.read().await;
            if guard.is_empty() {
                return Ok(());
            }
            guard.clone()
        };
        let Some(tool_result) = ctx.result.as_ref() else {
            return Ok(());
        };
        let post_result = if tool_result.success {
            hook_reg
                .run_post_tool_use(
                    &ctx.tool_name,
                    &ctx.input,
                    &tool_result.output,
                    snapshot.config.session_id.as_deref().unwrap_or(""),
                )
                .await
        } else {
            let error = tool_result
                .error
                .as_deref()
                .filter(|value| !value.is_empty())
                .unwrap_or(&tool_result.output);
            hook_reg
                .run_post_tool_use_failure(
                    &ctx.tool_name,
                    &ctx.input,
                    error,
                    snapshot.config.session_id.as_deref().unwrap_or(""),
                )
                .await
        };
        ctx.hook_messages.post = post_result.messages;
        if post_result.block {
            let reason = post_result.block_reason.unwrap_or_else(|| {
                format!("Tool {} output blocked by post-use hook", ctx.tool_name)
            });
            // The policy rejected an already executed call, not the execution
            // itself. Keep its output/artifact and recovery facts for settlement.
            let mut failure = tool_result.failure.clone().unwrap_or_else(|| {
                crate::tools::ToolFailure::new(crate::tools::ToolFailureCategory::PartialSideEffect)
            });
            if tool_result.success {
                failure = failure.with_postcondition(
                    "Tool execution succeeded before the post-use hook rejected the result",
                );
            }
            ctx.blocked = true;
            ctx.block_reason = Some(reason.clone());
            ctx.block_failure = Some(failure.clone());
            if let Some(result) = ctx.result.as_mut() {
                result.success = false;
                result.error = Some(reason);
                result.failure = Some(failure);
            }
        }
        Ok(())
    }
}

/// Runs output guard checks.
pub struct OutputGuardStage;

#[async_trait]
impl PipelineStage for OutputGuardStage {
    fn name(&self) -> &str {
        "output_guard"
    }

    fn runs_after_block(&self) -> bool {
        true
    }

    async fn run(
        &self,
        ctx: &mut ToolExecutionContext,
        snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    ) -> Result<()> {
        let Some(result) = ctx.result.as_ref() else {
            return Ok(());
        };
        let raw_output = result.output.clone();
        let raw_error = result.error.clone();
        let raw_idempotency_key = result
            .failure
            .as_ref()
            .and_then(|failure| failure.idempotency_key.clone());
        let raw_postcondition = result
            .failure
            .as_ref()
            .and_then(|failure| failure.postcondition.clone());
        let error_only = !result.success && raw_output.is_empty();
        let guard_configured = snapshot.guard.guard_manager.is_some();
        let metadata_has_content = !result.metadata.is_empty();
        let kind_has_content = matches!(
            result.kind,
            echo_core::tools::ToolResultKind::Image { .. }
                | echo_core::tools::ToolResultKind::Table { .. }
                | echo_core::tools::ToolResultKind::Diff { .. }
                | echo_core::tools::ToolResultKind::FileReference { .. }
                | echo_core::tools::ToolResultKind::SkillActivation { .. }
                | echo_core::tools::ToolResultKind::StructuredError { .. }
        );
        let raw_data = guard_configured
            .then(|| {
                result
                    .data
                    .as_ref()
                    .and_then(|data| serde_json::to_string(data).ok())
            })
            .flatten();
        let data_unserializable = guard_configured && result.data.is_some() && raw_data.is_none();
        let raw_metadata = (guard_configured && metadata_has_content)
            .then(|| serde_json::to_string(&result.metadata).ok())
            .flatten();
        let raw_kind = (guard_configured && kind_has_content)
            .then(|| serde_json::to_string(&result.kind).ok())
            .flatten();
        let raw_mime_type = guard_configured.then(|| result.mime_type.clone()).flatten();

        let guarded_output = if error_only {
            None
        } else {
            snapshot.check_tool_output_guard(&raw_output).await
        };
        let guarded_error = match raw_error.as_deref() {
            Some(error) if error == raw_output => guarded_output.clone(),
            Some(error) => snapshot.check_tool_output_guard(error).await,
            None => None,
        };
        let guarded_data = match raw_data.as_deref() {
            Some(data) => snapshot.check_tool_output_guard(data).await,
            None => None,
        };
        let guarded_metadata = match raw_metadata.as_deref() {
            Some(metadata) => snapshot.check_tool_output_guard(metadata).await,
            None => None,
        };
        let guarded_kind = match raw_kind.as_deref() {
            Some(kind) => snapshot.check_tool_output_guard(kind).await,
            None => None,
        };
        let guarded_mime_type = match raw_mime_type.as_deref() {
            Some(mime_type) => snapshot.check_tool_output_guard(mime_type).await,
            None => None,
        };
        let guarded_idempotency_key = if guard_configured {
            match raw_idempotency_key.as_deref() {
                Some(key) => snapshot.check_tool_output_guard(key).await,
                None => None,
            }
        } else {
            None
        };
        let guarded_postcondition = if guard_configured {
            match raw_postcondition.as_deref() {
                Some(postcondition) => snapshot.check_tool_output_guard(postcondition).await,
                None => None,
            }
        } else {
            None
        };
        let content_replaced = guarded_output.is_some()
            || guarded_error.is_some()
            || guarded_data.is_some()
            || guarded_metadata.is_some()
            || guarded_kind.is_some()
            || guarded_mime_type.is_some()
            || data_unserializable
            || (guard_configured && metadata_has_content && raw_metadata.is_none())
            || (guard_configured && kind_has_content && raw_kind.is_none());

        if let Some(output) = guarded_output {
            ctx.output = Some(output);
        }
        if let Some(error) = raw_error {
            let diagnostic = guarded_error.unwrap_or(error);
            if error_only {
                ctx.audit_error_output = Some(diagnostic.clone());
            }
            // Both output and error are caller-visible; filtering only one
            // leaves ToolError, callbacks, and transcript with raw content.
            if let Some(result) = ctx.result.as_mut() {
                result.error = Some(diagnostic);
            }
        }
        if ctx.output.is_none()
            && let Some(data_projection) = guarded_data
        {
            ctx.output = Some(data_projection);
        }
        if guard_configured && let Some(result) = ctx.result.as_mut() {
            // Image URLs/data URLs may describe opaque pixels; a text guard
            // cannot approve the image payload. A pre-guard artifact can
            // likewise refer to bytes beyond the checked inline text.
            let had_rich_content = !result.model_content.is_empty();
            result.model_content.clear();
            result.artifact = None;
            if had_rich_content {
                result.mime_type = None;
            }
            if matches!(
                result.kind,
                echo_core::tools::ToolResultKind::Image { .. }
                    | echo_core::tools::ToolResultKind::FileReference { .. }
            ) {
                result.kind = echo_core::tools::ToolResultKind::Text;
            }
        }
        if content_replaced && let Some(result) = ctx.result.as_mut() {
            // A textual guard decision cannot attest to parallel structured
            // or rich payloads. Keep typed execution facts, retire alternate
            // renderable projections and their stale artifact capability.
            if !matches!(
                result.kind,
                echo_core::tools::ToolResultKind::CommandOutput { .. }
            ) {
                result.kind = echo_core::tools::ToolResultKind::Text;
            }
            result.data = None;
            result.model_content.clear();
            result.mime_type = None;
            result.artifact = None;
            result.metadata.clear();
        }
        if let Some(failure) = ctx
            .result
            .as_mut()
            .and_then(|result| result.failure.as_mut())
        {
            // A changed key is no longer the tool's true retry identity.
            // Removing it also prevents accidental automatic replay.
            if guarded_idempotency_key.is_some() {
                failure.idempotency_key = None;
            }
            if let Some(postcondition) = guarded_postcondition {
                failure.postcondition = Some(postcondition);
            }
        }
        if ctx.blocked {
            // A post-use hook reason may quote raw tool output. Once its
            // error has been guarded, that error owns caller and telemetry
            // failure text; the pre-guard reason must not escape separately.
            if let Some(error) = ctx.result.as_ref().and_then(|result| result.error.clone()) {
                ctx.block_reason = Some(error);
            } else if let Some(raw_reason) = ctx.block_reason.as_deref() {
                ctx.block_reason = Some(
                    snapshot
                        .check_tool_output_guard(raw_reason)
                        .await
                        .unwrap_or_else(|| raw_reason.to_string()),
                );
            }
            if let Some(failure) = ctx
                .result
                .as_ref()
                .and_then(|result| result.failure.clone())
            {
                ctx.block_failure = Some(failure);
            }
        }
        Ok(())
    }
}

/// Truncates tool output based on token budget.
pub struct TruncationStage;

#[async_trait]
impl PipelineStage for TruncationStage {
    fn name(&self) -> &str {
        "truncation"
    }

    fn runs_after_block(&self) -> bool {
        true
    }

    async fn run(
        &self,
        ctx: &mut ToolExecutionContext,
        snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    ) -> Result<()> {
        let raw = ctx
            .output
            .as_deref()
            .or_else(|| ctx.result.as_ref().map(|r| r.output.as_str()))
            .unwrap_or("");
        let existing_artifact = ctx
            .result
            .as_ref()
            .and_then(|result| result.artifact.clone());
        let processed = snapshot.process_tool_output_for_call(
            raw.to_string(),
            &ctx.call_id,
            &ctx.tool_name,
            existing_artifact,
        );
        if let Some(result) = ctx.result.as_mut() {
            result.truncated = result.truncated || processed.truncated;
            result.artifact = processed.artifact;
            result.metadata.extend(processed.metadata);
            snapshot.tools.tool_manager.record_tool_result(
                &ctx.tool_name,
                result,
                processed.output.len(),
                ctx.duration_ms,
            );
        }
        ctx.output = Some(processed.output);
        Ok(())
    }
}

/// Fires callbacks (on_tool_start, on_tool_end, on_tool_error).
pub struct CallbackStage {
    phase: CallbackPhase,
}

pub enum CallbackPhase {
    Start,
    End,
}

impl CallbackStage {
    pub const START: Self = Self {
        phase: CallbackPhase::Start,
    };
    pub const END: Self = Self {
        phase: CallbackPhase::End,
    };
}

#[async_trait]
impl PipelineStage for CallbackStage {
    fn name(&self) -> &str {
        match self.phase {
            CallbackPhase::Start => "callback_start",
            CallbackPhase::End => "callback_end",
        }
    }

    // CallbackEnd is the caller's terminal observation: it must fire with the
    // real outcome even when a post-effect block occurred (#102).
    fn runs_after_block(&self) -> bool {
        matches!(self.phase, CallbackPhase::End)
    }

    async fn run(
        &self,
        ctx: &mut ToolExecutionContext,
        snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    ) -> Result<()> {
        let agent_name = &snapshot.config.agent_name;
        for cb in &snapshot.config.callbacks {
            match self.phase {
                CallbackPhase::Start => {
                    cb.on_tool_start_with_id(agent_name, &ctx.call_id, &ctx.tool_name, &ctx.input)
                        .await;
                }
                CallbackPhase::End => {
                    let output = ctx
                        .output
                        .as_deref()
                        .or_else(|| ctx.result.as_ref().map(|r| r.output.as_str()))
                        .unwrap_or("");
                    // A typed cancellation/timeout before a tool result is an
                    // interrupted attempt, not a completed tool failure.
                    let failure = ctx.result.as_ref().filter(|result| !result.success);
                    if let Some(result) = failure {
                        if let Some(interruption) = ctx.interrupted_execution_error.as_ref() {
                            let terminal_message = result.error.as_deref().unwrap_or(output);
                            let rewritten = (terminal_message != interruption.to_string())
                                .then(|| ReactError::Other(terminal_message.to_string()));
                            let error = rewritten.as_ref().unwrap_or(interruption);
                            cb.on_tool_interrupted_with_id(
                                agent_name,
                                &ctx.call_id,
                                &ctx.tool_name,
                                &ctx.input,
                                error,
                            )
                            .await;
                        } else {
                            let error = ReactError::Other(
                                result.error.clone().unwrap_or_else(|| output.to_string()),
                            );
                            cb.on_tool_error_with_id(
                                agent_name,
                                &ctx.call_id,
                                &ctx.tool_name,
                                &error,
                            )
                            .await;
                        }
                    } else {
                        cb.on_tool_end_with_id(agent_name, &ctx.call_id, &ctx.tool_name, output)
                            .await;
                    }
                }
            }
        }
        if matches!(self.phase, CallbackPhase::Start) {
            ctx.callback_started = true;
        }
        Ok(())
    }
}

/// Records trace events for tool results/errors.
pub struct TraceRecordingStage;

#[async_trait]
impl PipelineStage for TraceRecordingStage {
    fn name(&self) -> &str {
        "trace_recording"
    }

    // A blocked call may already have produced an external effect; the trace
    // must still record the actual result (and ToolError for failures).
    fn runs_after_block(&self) -> bool {
        true
    }

    async fn run(
        &self,
        ctx: &mut ToolExecutionContext,
        snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    ) -> Result<()> {
        if let Some(ref result) = ctx.result {
            // Always record ToolResult — success determines the outcome.
            // ToolError is additionally recorded for failure details.
            snapshot
                .record_event(crate::trace::RunEvent::ToolResult {
                    call_id: ctx.call_id.clone(),
                    name: ctx.tool_name.clone(),
                    success: result.success,
                    output_preview: Some(
                        ctx.output
                            .as_deref()
                            .unwrap_or(&result.output)
                            .chars()
                            .take(200)
                            .collect(),
                    ),
                    output_truncated: result.truncated,
                    duration_ms: ctx.duration_ms,
                    original_bytes: metadata_u64(result, "original_bytes"),
                    returned_bytes: metadata_u64(result, "returned_bytes"),
                    estimated_tokens: metadata_usize(result, "estimated_tokens"),
                    output_handling: result.metadata.get("output_handling").cloned(),
                    artifact: result.artifact.clone(),
                })
                .await;
            if !result.success {
                snapshot
                    .record_event(crate::trace::RunEvent::ToolError {
                        call_id: ctx.call_id.clone(),
                        name: ctx.tool_name.clone(),
                        message: result.error.clone().unwrap_or_default(),
                        failure: result.failure.clone(),
                    })
                    .await;
            }
        }
        Ok(())
    }
}

fn metadata_u64(result: &crate::tools::ToolResult, key: &str) -> u64 {
    result
        .metadata
        .get(key)
        .and_then(|value| value.parse::<u64>().ok())
        .unwrap_or(0)
}

fn metadata_usize(result: &crate::tools::ToolResult, key: &str) -> usize {
    result
        .metadata
        .get(key)
        .and_then(|value| value.parse::<usize>().ok())
        .unwrap_or(0)
}

// ── ToolExecutionPipeline ──────────────────────────────────────────

/// Composable pipeline for tool execution stages.
///
/// # Example
///
/// ```rust,ignore
/// let pipeline = ToolExecutionPipeline::default();
/// let mut ctx = ToolExecutionContext { ... };
/// pipeline.run(&mut ctx, &agent).await?;
/// ```
pub struct ToolExecutionPipeline {
    stages: Vec<Box<dyn PipelineStage>>,
}

impl ToolExecutionPipeline {
    /// Build a pipeline with all standard stages in the correct order.
    pub fn default_pipeline() -> Self {
        Self {
            stages: vec![
                Box::new(InterventionStage),
                Box::new(ToolVisibilityStage),
                Box::new(PlanModeStage),
                Box::new(PreToolUseHookStage),
                Box::new(PermissionStage),
                Box::new(ReadBeforeEditStage),
                Box::new(SkillPermissionStage),
                Box::new(ToolInputGuardStage),
                Box::new(InvocationStage),
                Box::new(CallbackStage::START),
                Box::new(ExecuteStage),
                Box::new(PostToolUseHookStage),
                Box::new(OutputGuardStage),
                Box::new(TruncationStage),
                Box::new(TraceRecordingStage),
                Box::new(AuditStage),
                Box::new(CallbackStage::END),
            ],
        }
    }

    /// Run all stages in order. Short-circuits if `ctx.blocked` is set.
    pub(crate) async fn run(
        &self,
        ctx: &mut ToolExecutionContext,
        snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    ) -> Result<()> {
        for (index, stage) in self.stages.iter().enumerate() {
            if ctx.blocked && !stage.runs_after_block() {
                ctx.emit_invocation().await?;
                debug!(
                    agent = %snapshot.config.agent_name,
                    stage = stage.name(),
                    reason = ?ctx.block_reason,
                    "Pipeline stage skipped (blocked)"
                );
                if ctx.result.is_none() {
                    break;
                }
                continue;
            }
            debug!(
                agent = %snapshot.config.agent_name,
                stage = stage.name(),
                tool = %ctx.tool_name,
                "Pipeline stage running"
            );
            if let Err(error) = stage.run(ctx, snapshot).await {
                ctx.emit_invocation().await?;
                if ctx.callback_started {
                    let message = error.to_string();
                    let failure = crate::tools::ToolFailure::from_error(&error, true);
                    if let Some(result) = ctx.result.as_mut() {
                        result.success = false;
                        result.error = Some(message.clone());
                        result.failure = Some(failure);
                    } else {
                        ctx.result = Some(crate::tools::ToolResult {
                            kind: echo_core::tools::ToolResultKind::StructuredError {
                                error_code: "tool_pipeline_failed".to_string(),
                            },
                            success: false,
                            output: String::new(),
                            error: Some(message),
                            failure: Some(failure),
                            data: None,
                            truncated: false,
                            mime_type: None,
                            artifact: None,
                            metadata: std::collections::HashMap::new(),
                            effects: Vec::new(),
                            model_content: Vec::new(),
                        });
                    }
                    ctx.blocked = true;
                    for remaining in self.stages.iter().skip(index.saturating_add(1)) {
                        if remaining.runs_after_block() {
                            remaining.run(ctx, snapshot).await?;
                        }
                    }
                    return Ok(());
                }
                return Err(error);
            }
        }
        Ok(())
    }
}

// ── PlanModeStage ──────────────────────────────────────────────────

fn read_only_surface_denial(tool_name: &str, plan_mode: bool) -> (String, &'static str) {
    if plan_mode {
        (
            format!(
                "Plan mode: '{tool_name}' is blocked. Read and analyze only. Use /plan off to enable writes."
            ),
            "plan_mode",
        )
    } else {
        (
            format!("Tool '{tool_name}' is blocked by the read-only Agent"),
            "readonly_tools",
        )
    }
}

/// In plan mode or a read-only Agent, only locally classified read-only tools may execute.
pub struct PlanModeStage;

#[async_trait]
impl PipelineStage for PlanModeStage {
    fn name(&self) -> &str {
        "plan_mode"
    }

    async fn run(
        &self,
        ctx: &mut ToolExecutionContext,
        snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    ) -> Result<()> {
        let plan_mode = ctx.plan_mode || snapshot.tools.is_plan_mode();
        if !plan_mode && !snapshot.tools.readonly_tools {
            return Ok(());
        }
        if !snapshot.tools.is_tool_read_only(&ctx.tool_name) {
            let (reason, source) = read_only_surface_denial(&ctx.tool_name, plan_mode);
            snapshot
                .record_permission_decision(
                    &ctx.tool_name,
                    &PermissionDecision::Deny {
                        reason: reason.clone(),
                    },
                    source,
                )
                .await;
            ctx.block(crate::tools::ToolFailureCategory::Unavailable, reason);
        }
        Ok(())
    }
}

impl Default for ToolExecutionPipeline {
    fn default() -> Self {
        Self::default_pipeline()
    }
}

// ── Helpers ────────────────────────────────────────────────────────

fn extract_path_params(tool_name: &str, params: &ToolParameters) -> Vec<String> {
    if tool_name == "apply_patch" {
        #[cfg(feature = "files")]
        return params
            .get("patch")
            .and_then(Value::as_str)
            .and_then(|patch| echo_tools::files::apply_patch::existing_file_paths(patch).ok())
            .unwrap_or_default();
        #[cfg(not(feature = "files"))]
        return Vec::new();
    }
    params
        .get("path")
        .or_else(|| params.get("file_path"))
        .and_then(Value::as_str)
        .map(|path| vec![path.to_string()])
        .unwrap_or_default()
}

fn resolve_tracking_path(path: &str, working_dir: Option<&std::path::Path>) -> String {
    let path = std::path::Path::new(path);
    let resolved = if path.is_absolute() {
        path.to_path_buf()
    } else if let Some(working_dir) = working_dir {
        working_dir.join(path)
    } else {
        path.to_path_buf()
    };
    std::fs::canonicalize(&resolved)
        .unwrap_or(resolved)
        .to_string_lossy()
        .to_string()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::agent::AgentEvent;
    use echo_core::tools::{InvocationResourceGuard, Tool, ToolContext, ToolOutputChannel};
    use futures::Stream;
    use std::collections::HashMap;
    use std::pin::Pin;
    use std::sync::Arc;

    #[test]
    fn test_is_write_tool() {
        assert!(is_write_tool("apply_patch"));
        assert!(is_write_tool("write_file"));
        assert!(!is_write_tool("read_file"));
    }

    #[test]
    fn test_extract_write_path_param() {
        let params = vec![("path".to_string(), Value::String("src/main.rs".to_string()))]
            .into_iter()
            .collect();
        assert_eq!(
            extract_path_params("write_file", &params),
            vec!["src/main.rs".to_string()]
        );
    }

    #[cfg(feature = "files")]
    #[test]
    fn test_extract_apply_patch_paths() {
        let patch_params = HashMap::from([(
            "patch".to_string(),
            Value::String(
                "*** Begin Patch\n*** Update File: src/lib.rs\n@@\n-old\n+new\n*** Delete File: stale.txt\n*** End Patch"
                    .to_string(),
            ),
        )]);
        assert_eq!(
            extract_path_params("apply_patch", &patch_params),
            vec!["src/lib.rs".to_string(), "stale.txt".to_string()]
        );
    }

    struct InterleavingTool;

    struct InvalidResultTool;

    struct FailedOutputTool;

    struct ErrorOnlyTool;

    struct StructuredRichTool;

    impl Tool for StructuredRichTool {
        fn name(&self) -> &str {
            "structured_rich"
        }

        fn description(&self) -> &str {
            "returns several projections of one guarded tool result"
        }

        fn parameters(&self) -> serde_json::Value {
            serde_json::json!({"type": "object"})
        }

        fn execute<'a>(
            &'a self,
            _parameters: ToolParameters,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<ToolResult>> {
            Box::pin(async {
                Ok(ToolResult::success_with_kind(
                    echo_core::tools::ToolResultKind::Table {
                        columns: vec!["payload".to_string()],
                        rows: vec![vec!["raw-secret".to_string()]],
                    },
                    "safe summary",
                )
                .with_data(serde_json::json!({"payload": "raw-secret"}))
                .with_model_content(echo_core::tools::ToolResultContent::ImageUrl {
                    url: "data:image/png;base64,raw-secret".to_string(),
                    detail: None,
                })
                .with_meta("payload", "raw-secret")
                .with_mime_type("image/raw-secret")
                .with_effect(echo_core::tools::ToolEffect::FileEdit {
                    path: "src/structured-rich.rs".to_string(),
                }))
            })
        }
    }

    struct OutputAndErrorTool;

    struct PartialFailureTool;

    impl Tool for PartialFailureTool {
        fn name(&self) -> &str {
            "partial_failure"
        }

        fn description(&self) -> &str {
            "returns typed recovery facts and free-text verification hints"
        }

        fn parameters(&self) -> serde_json::Value {
            serde_json::json!({"type": "object"})
        }

        fn execute<'a>(
            &'a self,
            _parameters: ToolParameters,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<ToolResult>> {
            Box::pin(async {
                let failure = crate::tools::ToolFailure::new(
                    crate::tools::ToolFailureCategory::PartialSideEffect,
                )
                .with_idempotency_key("raw-secret-idempotency")
                .with_postcondition("verify /private/raw-secret-path before retry");
                Ok(ToolResult::failure(
                    crate::tools::ToolFailureCategory::PartialSideEffect,
                    "safe failure summary",
                )
                .with_output("safe output summary")
                .with_failure(failure)
                .with_effect(echo_core::tools::ToolEffect::FileEdit {
                    path: "src/partial-failure.rs".to_string(),
                }))
            })
        }
    }

    impl Tool for OutputAndErrorTool {
        fn name(&self) -> &str {
            "output_and_error"
        }

        fn description(&self) -> &str {
            "returns independent output and error diagnostics"
        }

        fn parameters(&self) -> serde_json::Value {
            serde_json::json!({"type": "object"})
        }

        fn execute<'a>(
            &'a self,
            _parameters: ToolParameters,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<ToolResult>> {
            Box::pin(async {
                Ok(ToolResult::error("raw-secret-error")
                    .with_output("raw-secret-output")
                    .with_effect(echo_core::tools::ToolEffect::FileEdit {
                        path: "src/output-error.rs".to_string(),
                    }))
            })
        }
    }

    impl Tool for ErrorOnlyTool {
        fn name(&self) -> &str {
            "error_only"
        }

        fn description(&self) -> &str {
            "returns a sensitive error without tool output"
        }

        fn parameters(&self) -> serde_json::Value {
            serde_json::json!({"type": "object"})
        }

        fn execute<'a>(
            &'a self,
            _parameters: ToolParameters,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<ToolResult>> {
            Box::pin(async {
                Ok(ToolResult::error("Bearer sensitive-token").with_effect(
                    echo_core::tools::ToolEffect::FileEdit {
                        path: "src/error-only.rs".to_string(),
                    },
                ))
            })
        }
    }

    impl Tool for FailedOutputTool {
        fn name(&self) -> &str {
            "failed_output"
        }

        fn description(&self) -> &str {
            "returns an unsuccessful result with output"
        }

        fn parameters(&self) -> serde_json::Value {
            serde_json::json!({"type": "object"})
        }

        fn execute<'a>(
            &'a self,
            _parameters: ToolParameters,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<ToolResult>> {
            Box::pin(async {
                Ok(ToolResult::failure(
                    crate::tools::ToolFailureCategory::Permanent,
                    "execution failed",
                )
                .with_output("sensitive raw output"))
            })
        }
    }

    struct ResourceGuardStreamingTool {
        observed_guard_count: Arc<std::sync::atomic::AtomicUsize>,
    }

    impl Tool for InvalidResultTool {
        fn name(&self) -> &str {
            "invalid_result"
        }

        fn description(&self) -> &str {
            "returns a classified unsuccessful result"
        }

        fn parameters(&self) -> serde_json::Value {
            serde_json::json!({"type": "object"})
        }

        fn execute<'a>(
            &'a self,
            _parameters: ToolParameters,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<ToolResult>> {
            Box::pin(async {
                Ok(ToolResult::failure(
                    crate::tools::ToolFailureCategory::InvalidArguments,
                    "missing query",
                ))
            })
        }

        fn permissions(&self) -> Vec<echo_core::tools::permission::ToolPermission> {
            vec![echo_core::tools::permission::ToolPermission::Execute]
        }
    }

    impl Tool for InterleavingTool {
        fn name(&self) -> &str {
            "interleaving"
        }

        fn description(&self) -> &str {
            "test stream interleaving"
        }

        fn parameters(&self) -> serde_json::Value {
            serde_json::json!({"type": "object"})
        }

        fn execute<'a>(
            &'a self,
            _parameters: ToolParameters,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<ToolResult>> {
            Box::pin(async { Ok(ToolResult::success("unused")) })
        }

        fn execute_stream_with_context<'a>(
            &'a self,
            params: ToolParameters,
            _ctx: &ToolContext,
        ) -> futures::future::BoxFuture<
            'a,
            crate::error::Result<Pin<Box<dyn Stream<Item = ToolStreamEvent> + Send + 'a>>>,
        > {
            Box::pin(async move {
                let label = params
                    .get("label")
                    .and_then(Value::as_str)
                    .unwrap_or("unknown")
                    .to_string();
                let initial_delay = params
                    .get("initial_delay")
                    .and_then(Value::as_u64)
                    .unwrap_or(0);
                let finish_delay = params
                    .get("finish_delay")
                    .and_then(Value::as_u64)
                    .unwrap_or(0);
                let events = futures::stream::unfold(
                    (0_u8, label, initial_delay, finish_delay),
                    |(state, label, initial_delay, finish_delay)| async move {
                        match state {
                            0 => {
                                tokio::time::sleep(std::time::Duration::from_millis(initial_delay))
                                    .await;
                                Some((
                                    ToolStreamEvent::Output {
                                        channel: ToolOutputChannel::Stdout,
                                        chunk: format!("{label}-1"),
                                    },
                                    (1, label, initial_delay, finish_delay),
                                ))
                            }
                            1 => {
                                tokio::time::sleep(std::time::Duration::from_millis(finish_delay))
                                    .await;
                                Some((
                                    ToolStreamEvent::Output {
                                        channel: ToolOutputChannel::Stdout,
                                        chunk: format!("{label}-2"),
                                    },
                                    (2, label, initial_delay, finish_delay),
                                ))
                            }
                            2 => Some((
                                ToolStreamEvent::Complete(ToolResult::success(label.clone())),
                                (3, label, initial_delay, finish_delay),
                            )),
                            _ => None,
                        }
                    },
                );
                Ok(Box::pin(events) as Pin<Box<dyn Stream<Item = ToolStreamEvent> + Send + 'a>>)
            })
        }

        fn supports_streaming(&self) -> bool {
            true
        }
    }

    impl Tool for ResourceGuardStreamingTool {
        fn name(&self) -> &str {
            "resource_guard_stream"
        }

        fn description(&self) -> &str {
            "captures invocation resource guards on the streaming path"
        }

        fn parameters(&self) -> serde_json::Value {
            serde_json::json!({"type": "object"})
        }

        fn execute<'a>(
            &'a self,
            _parameters: ToolParameters,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<ToolResult>> {
            Box::pin(async { Ok(ToolResult::success("fallback")) })
        }

        fn supports_streaming(&self) -> bool {
            true
        }

        fn execute_stream_with_context<'a>(
            &'a self,
            _parameters: ToolParameters,
            context: &ToolContext,
        ) -> futures::future::BoxFuture<
            'a,
            crate::error::Result<Pin<Box<dyn Stream<Item = ToolStreamEvent> + Send + 'a>>>,
        > {
            self.observed_guard_count.store(
                context.resource_guards.len(),
                std::sync::atomic::Ordering::SeqCst,
            );
            Box::pin(async {
                Ok(Box::pin(futures::stream::iter([ToolStreamEvent::Complete(
                    ToolResult::success("streamed"),
                )]))
                    as Pin<Box<dyn Stream<Item = ToolStreamEvent> + Send>>)
            })
        }
    }

    fn streaming_context(
        call_id: &str,
        label: &str,
        initial_delay: u64,
        finish_delay: u64,
        stream_tx: mpsc::Sender<ToolPipelineEvent>,
    ) -> ToolExecutionContext {
        let input = serde_json::json!({
            "label": label,
            "initial_delay": initial_delay,
            "finish_delay": finish_delay,
        });
        let params = match &input {
            Value::Object(map) => map.clone().into_iter().collect(),
            _ => ToolParameters::new(),
        };
        ToolExecutionContext {
            call_id: call_id.to_string(),
            requested_tool_name: "interleaving".to_string(),
            requested_input: input.clone(),
            tool_name: "interleaving".to_string(),
            params,
            input,
            hook_messages: HookMessageBatches::default(),
            result: None,
            output: None,
            audit_error_output: None,
            blocked: false,
            block_reason: None,
            block_failure: None,
            duration_ms: 0,
            plan_mode: false,
            permission_decision: None,
            approval_receipt: None,
            permission_mode_override: None,
            rewrites: Vec::new(),
            invocation_emitted: false,
            callback_started: false,
            interrupted_execution_error: None,
            stream_tx: Some(stream_tx),
        }
    }

    fn completed_context(output: String) -> ToolExecutionContext {
        ToolExecutionContext {
            call_id: "call-output-budget".to_string(),
            requested_tool_name: "shell".to_string(),
            requested_input: serde_json::json!({}),
            tool_name: "shell".to_string(),
            params: ToolParameters::new(),
            input: serde_json::json!({}),
            hook_messages: HookMessageBatches::default(),
            result: Some(ToolResult::success(output)),
            output: None,
            audit_error_output: None,
            blocked: false,
            block_reason: None,
            block_failure: None,
            duration_ms: 0,
            plan_mode: false,
            permission_decision: None,
            approval_receipt: None,
            permission_mode_override: None,
            rewrites: Vec::new(),
            invocation_emitted: false,
            callback_started: false,
            interrupted_execution_error: None,
            stream_tx: None,
        }
    }

    #[tokio::test]
    async fn permission_hooks_trace_real_allow_and_deny_on_the_main_path() -> Result<()> {
        use crate::skills::hooks::{HookAction, HookEvent, HookRule, HooksDefinition};
        use crate::trace::{InMemoryRunStore, RunEvent, RunStore};

        for event in [HookEvent::PreToolUse, HookEvent::PermissionRequest] {
            for decision in ["allow", "deny"] {
                let store = Arc::new(InMemoryRunStore::new());
                let agent = crate::agent::ReactAgentBuilder::new()
                    .model("test-model")
                    .with_run_store(store.clone())
                    .tool(Box::new(EffectTool))
                    .build()?;
                let mut definition = HooksDefinition::default();
                definition.add_rules(
                    event,
                    vec![HookRule {
                        matcher: "shell".to_string(),
                        hooks: vec![HookAction::Permission {
                            decision: decision.to_string(),
                            reason: Some("reviewed decision".to_string()),
                            suggestions: Vec::new(),
                        }],
                    }],
                );
                agent
                    .hook_registry()
                    .write()
                    .await
                    .register_user_hooks(definition);
                let legacy = agent.capture_legacy_external_context();
                let run_id = agent
                    .start_legacy_trace_run("permission trace", &legacy)
                    .await
                    .ok_or_else(|| ReactError::Other("trace did not start".to_string()))?;
                let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
                let result = snapshot
                    .execute_tool_with_policy(
                        "permission-call".to_string(),
                        "shell",
                        &ToolParameters::new(),
                        &serde_json::json!({}),
                        None,
                    )
                    .await;
                assert_eq!(result.is_ok(), decision == "allow");
                let run = store
                    .load(&run_id)
                    .await?
                    .ok_or_else(|| ReactError::Other("trace disappeared".to_string()))?;
                let decisions: Vec<_> = run
                    .events
                    .iter()
                    .filter_map(|event| match event {
                        RunEvent::PermissionDecision { decision, .. } => Some(decision.as_str()),
                        _ => None,
                    })
                    .collect();
                assert_eq!(decisions, vec![decision]);
                let permission = run
                    .events
                    .iter()
                    .position(|event| matches!(event, RunEvent::PermissionDecision { .. }));
                let execution = run
                    .events
                    .iter()
                    .position(|event| matches!(event, RunEvent::ToolCall { .. }));
                if decision == "allow" {
                    assert!(matches!((permission, execution), (Some(p), Some(e)) if p < e));
                } else {
                    assert!(execution.is_none());
                }
            }
        }
        Ok(())
    }

    #[cfg(all(feature = "human-loop", feature = "shell", not(windows)))]
    #[tokio::test]
    async fn permission_service_receipt_reaches_real_shell_effect_boundary() -> Result<()> {
        struct AllowProvider;

        impl crate::human_loop::HumanLoopProvider for AllowProvider {
            fn request(
                &self,
                _request: crate::human_loop::HumanLoopRequest,
            ) -> futures::future::BoxFuture<
                '_,
                crate::error::Result<crate::human_loop::HumanLoopResponse>,
            > {
                Box::pin(async { Ok(crate::human_loop::HumanLoopResponse::Approved) })
            }
        }

        let permission_service = Arc::new(crate::human_loop::PermissionService::from_provider(
            Arc::new(AllowProvider),
        ));
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .permission_service(permission_service)
            .tool(Box::new(crate::tools::shell::ShellTool::new()))
            .build()?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let input = serde_json::json!({"command": "python3 --version"});
        let params = ToolParameters::from([(
            "command".to_string(),
            Value::String("python3 --version".to_string()),
        )]);

        let result = snapshot
            .execute_tool_with_policy("approved-shell".to_string(), "shell", &params, &input, None)
            .await
            .map_err(|failure| ReactError::Other(failure.error.to_string()))?;
        assert!(
            result.result.success,
            "approved shell failed: {:?}",
            result.result
        );
        assert!(result.result.output.contains("Python"));
        Ok(())
    }

    #[cfg(all(feature = "human-loop", feature = "shell", not(windows)))]
    #[tokio::test]
    async fn permission_request_hook_allow_rewrite_binds_receipt_to_final_shell_args() -> Result<()>
    {
        use crate::skills::hooks::HookEvent;
        use echo_core::hooks::HookResult;

        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .permission_service(Arc::new(crate::human_loop::PermissionService::new()))
            .tool(Box::new(crate::tools::shell::ShellTool::new()))
            .build()?;
        agent.hook_registry().write().await.set_programmatic_hook(
            "permission-rewrite",
            &[HookEvent::PermissionRequest],
            Arc::new(|_| {
                Box::pin(async {
                    HookResult {
                        updated_input: Some(serde_json::json!({"command": "python3 --version"})),
                        permission_decision: Some(PermissionDecision::Allow),
                        ..HookResult::default()
                    }
                })
            }),
        );
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let input = serde_json::json!({"command": "echo original"});
        let params = ToolParameters::from([(
            "command".to_string(),
            Value::String("echo original".to_string()),
        )]);

        let result = snapshot
            .execute_tool_with_policy(
                "hook-rewrite-shell".to_string(),
                "shell",
                &params,
                &input,
                None,
            )
            .await
            .map_err(|failure| ReactError::Other(failure.error.to_string()))?;
        assert!(result.result.output.contains("Python"));
        assert!(!result.result.output.contains("original"));
        Ok(())
    }

    #[cfg(feature = "human-loop")]
    struct PermissionAuditProbe(
        tokio::sync::mpsc::UnboundedSender<crate::human_loop::PermissionAuditEntry>,
    );

    #[cfg(all(feature = "human-loop", not(windows)))]
    struct ProtectedPathExecutionProbe(Arc<std::sync::atomic::AtomicUsize>);

    #[cfg(all(feature = "human-loop", not(windows)))]
    impl Tool for ProtectedPathExecutionProbe {
        fn name(&self) -> &str {
            "shell"
        }

        fn description(&self) -> &str {
            "count protected-path probe executions"
        }

        fn parameters(&self) -> serde_json::Value {
            serde_json::json!({"type": "object"})
        }

        fn execute<'a>(
            &'a self,
            _parameters: ToolParameters,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<ToolResult>> {
            Box::pin(async move {
                self.0.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                Ok(ToolResult::success("executed"))
            })
        }
    }

    #[cfg(feature = "human-loop")]
    #[async_trait::async_trait]
    impl crate::human_loop::PermissionAuditSink for PermissionAuditProbe {
        async fn record(&self, entry: crate::human_loop::PermissionAuditEntry) {
            let _ = self.0.send(entry);
        }
    }

    #[cfg(feature = "human-loop")]
    #[tokio::test]
    async fn hook_allow_cannot_override_protected_path() -> Result<()> {
        use crate::skills::hooks::{HookAction, HookEvent, HookRule, HooksDefinition};

        for event in [
            None,
            Some(HookEvent::PreToolUse),
            Some(HookEvent::PermissionRequest),
        ] {
            let (audit_tx, mut audit_rx) = tokio::sync::mpsc::unbounded_channel();
            let agent = crate::agent::ReactAgentBuilder::new()
                .model("test-model")
                .permission_service(Arc::new(
                    crate::human_loop::PermissionService::new()
                        .with_audit_sink(Arc::new(PermissionAuditProbe(audit_tx))),
                ))
                .tool(Box::new(EffectTool))
                .build()?;
            let mut definition = HooksDefinition::default();
            if let Some(event) = event {
                definition.add_rules(
                    event,
                    vec![HookRule {
                        matcher: "shell".to_string(),
                        hooks: vec![HookAction::Permission {
                            decision: "allow".to_string(),
                            reason: None,
                            suggestions: Vec::new(),
                        }],
                    }],
                );
                agent
                    .hook_registry()
                    .write()
                    .await
                    .register_user_hooks(definition);
            }

            let input = serde_json::json!({"command": "cat .env"});
            let params = ToolParameters::from([(
                "command".to_string(),
                Value::String("cat .env".to_string()),
            )]);
            let result = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent)
                .execute_tool_with_policy(
                    "protected-path".to_string(),
                    "shell",
                    &params,
                    &input,
                    None,
                )
                .await;
            let Err(failure) = result else {
                return Err(ReactError::Other(format!(
                    "{event:?} allow executed a protected-path tool"
                )));
            };
            assert!(
                failure
                    .result
                    .error
                    .as_deref()
                    .is_some_and(|reason| reason.contains(".env"))
            );
            let audit = tokio::time::timeout(std::time::Duration::from_secs(1), audit_rx.recv())
                .await
                .map_err(|_| ReactError::Other("protected-path audit missing".to_string()))?
                .ok_or_else(|| {
                    ReactError::Other("protected-path audit channel closed".to_string())
                })?;
            assert_eq!(audit.decision, "deny");
            assert_eq!(audit.reason, "protected_path");
            assert_eq!(audit.source, "protected_paths");
            assert_eq!(audit.tool_name, "shell");
            assert!(
                tokio::time::timeout(std::time::Duration::from_millis(50), audit_rx.recv())
                    .await
                    .is_err(),
                "protected path produced duplicate audit records"
            );
        }
        Ok(())
    }

    #[cfg(all(feature = "human-loop", not(windows)))]
    #[tokio::test]
    async fn hook_allow_rewrite_to_protected_path_is_denied_and_audited_once() -> Result<()> {
        use crate::skills::hooks::HookEvent;
        use echo_core::hooks::HookResult;

        let executions = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let (audit_tx, mut audit_rx) = tokio::sync::mpsc::unbounded_channel();
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .permission_service(Arc::new(
                crate::human_loop::PermissionService::new()
                    .with_audit_sink(Arc::new(PermissionAuditProbe(audit_tx))),
            ))
            .tool(Box::new(ProtectedPathExecutionProbe(Arc::clone(
                &executions,
            ))))
            .build()?;
        agent.hook_registry().write().await.set_programmatic_hook(
            "protected-rewrite",
            &[HookEvent::PreToolUse],
            Arc::new(|_| {
                Box::pin(async {
                    HookResult {
                        updated_input: Some(serde_json::json!({"command": "cat .env"})),
                        ..HookResult::allow()
                    }
                })
            }),
        );

        let input = serde_json::json!({"command": "echo ordinary"});
        let params = ToolParameters::from([(
            "command".to_string(),
            Value::String("echo ordinary".to_string()),
        )]);
        let result = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent)
            .execute_tool_with_policy(
                "protected-rewrite".to_string(),
                "shell",
                &params,
                &input,
                None,
            )
            .await;
        let Err(failure) = result else {
            return Err(ReactError::Other("protected rewrite executed".to_string()));
        };
        assert!(
            failure
                .result
                .error
                .as_deref()
                .is_some_and(|reason| reason.contains(".env"))
        );
        assert_eq!(executions.load(std::sync::atomic::Ordering::SeqCst), 0);
        let audit = tokio::time::timeout(std::time::Duration::from_secs(1), audit_rx.recv())
            .await
            .map_err(|_| ReactError::Other("rewritten-path audit missing".to_string()))?
            .ok_or_else(|| ReactError::Other("rewritten-path audit channel closed".to_string()))?;
        assert_eq!(audit.decision, "deny");
        assert_eq!(audit.reason, "protected_path");
        assert!(
            tokio::time::timeout(std::time::Duration::from_millis(50), audit_rx.recv())
                .await
                .is_err(),
            "protected rewrite produced duplicate audit records"
        );
        Ok(())
    }

    #[tokio::test]
    async fn tool_outputs_do_not_invent_file_or_test_effects() -> Result<()> {
        use crate::trace::{InMemoryRunStore, RunEvent, RunStore};

        let store = Arc::new(InMemoryRunStore::new());
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .with_run_store(store.clone())
            .build()?;
        let legacy = agent.capture_legacy_external_context();
        let run_id = agent
            .start_legacy_trace_run("effects", &legacy)
            .await
            .ok_or_else(|| ReactError::Other("trace did not start".to_string()))?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        for (tool, kind, success) in [
            ("write_file", echo_core::tools::ToolResultKind::Text, true),
            (
                "apply_patch",
                echo_core::tools::ToolResultKind::Diff {
                    unified_diff: "--- a/file\n+++ b/file\n-old\n+new".to_string(),
                },
                true,
            ),
            (
                "shell",
                echo_core::tools::ToolResultKind::CommandOutput { exit_code: Some(0) },
                true,
            ),
            (
                "shell",
                echo_core::tools::ToolResultKind::CommandOutput { exit_code: Some(1) },
                false,
            ),
        ] {
            let mut ctx = completed_context("test result: 2 passed; 1 failed".to_string());
            ctx.tool_name = tool.to_string();
            ctx.input = serde_json::json!({"command": "cargo test", "path": "file"});
            if let Some(result) = ctx.result.as_mut() {
                result.kind = kind;
                result.success = success;
            }
            TraceRecordingStage.run(&mut ctx, &snapshot).await?;
        }
        let run = store
            .load(&run_id)
            .await?
            .ok_or_else(|| ReactError::Other("trace disappeared".to_string()))?;
        assert_eq!(
            run.events
                .iter()
                .filter(|event| matches!(event, RunEvent::ToolResult { .. }))
                .count(),
            4
        );
        assert!(!run.events.iter().any(|event| matches!(
            event,
            RunEvent::FileRead { .. }
                | RunEvent::FileEdit { .. }
                | RunEvent::TestRun { .. }
                | RunEvent::SubagentRun { .. }
                | RunEvent::Error { .. }
        )));
        Ok(())
    }

    #[tokio::test]
    async fn permission_hook_decisions_are_traced_before_execution() -> Result<()> {
        use crate::trace::{InMemoryRunStore, RunEvent, RunStore};

        for (decision, expected, blocked) in [
            (PermissionDecision::Allow, "allow", false),
            (
                PermissionDecision::Deny {
                    reason: "explicit denial 中文".to_string(),
                },
                "deny",
                true,
            ),
            (PermissionDecision::RequireApproval, "ask", false),
            (
                PermissionDecision::Ask {
                    suggestions: Vec::new(),
                },
                "ask",
                false,
            ),
        ] {
            let store = Arc::new(InMemoryRunStore::new());
            let agent = crate::agent::ReactAgentBuilder::new()
                .model("test-model")
                .with_run_store(store.clone())
                .build()?;
            let legacy = agent.capture_legacy_external_context();
            let run_id = agent
                .start_legacy_trace_run("permission trace", &legacy)
                .await
                .ok_or_else(|| ReactError::Other("trace did not start".to_string()))?;
            let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
            let mut ctx = completed_context(String::new());
            ctx.result = None;
            ctx.permission_decision = Some(decision);

            PermissionStage.run(&mut ctx, &snapshot).await?;

            assert_eq!(ctx.blocked, blocked);
            let run = store
                .load(&run_id)
                .await?
                .ok_or_else(|| ReactError::Other("trace disappeared".to_string()))?;
            let decisions: Vec<_> = run
                .events
                .iter()
                .filter_map(|event| match event {
                    RunEvent::PermissionDecision {
                        tool,
                        decision,
                        reason,
                    } => Some((tool.as_str(), decision.as_str(), reason.as_str())),
                    _ => None,
                })
                .collect();
            assert_eq!(decisions.len(), 1);
            let (tool, decision, reason) = decisions
                .first()
                .copied()
                .ok_or_else(|| ReactError::Other("missing permission decision".to_string()))?;
            assert_eq!(tool, "shell");
            assert_eq!(decision, expected);
            assert!(reason.starts_with("pre_tool_use_hook"));
            if blocked {
                assert!(reason.contains("explicit denial 中文"));
            }
            assert!(!run.events.iter().any(|event| matches!(
                event,
                RunEvent::ToolCall { .. }
                    | RunEvent::FileRead { .. }
                    | RunEvent::FileEdit { .. }
                    | RunEvent::TestRun { .. }
                    | RunEvent::Error { .. }
            )));
        }
        Ok(())
    }

    #[tokio::test]
    async fn unsuccessful_result_runs_failure_hook_instead_of_success_hook() -> Result<()> {
        use crate::skills::hooks::{HookAction, HookEvent, HookRule, HooksDefinition};

        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .build()?;
        let mut definition = HooksDefinition::default();
        definition.add_rules(
            HookEvent::PostToolUse,
            vec![HookRule {
                matcher: "invalid_result".to_string(),
                hooks: vec![HookAction::Prompt {
                    prompt: "success-hook".to_string(),
                }],
            }],
        );
        definition.add_rules(
            HookEvent::PostToolUseFailure,
            vec![HookRule {
                matcher: "invalid_result".to_string(),
                hooks: vec![HookAction::Prompt {
                    prompt: "failure-hook".to_string(),
                }],
            }],
        );
        agent
            .hook_registry()
            .write()
            .await
            .register_user_hooks(definition);
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let mut ctx = completed_context(String::new());
        ctx.tool_name = "invalid_result".to_string();
        ctx.result = Some(ToolResult::failure(
            crate::tools::ToolFailureCategory::InvalidArguments,
            "missing query",
        ));

        PostToolUseHookStage.run(&mut ctx, &snapshot).await?;

        assert_eq!(ctx.hook_messages.post, vec!["failure-hook"]);
        Ok(())
    }

    #[cfg(feature = "human-loop")]
    #[tokio::test]
    async fn permission_stage_consumes_call_scoped_mode_override() -> Result<()> {
        let service = Arc::new(
            crate::human_loop::PermissionService::new()
                .with_mode(echo_core::tools::permission::PermissionMode::Default),
        );
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .tool(Box::new(InvalidResultTool))
            .permission_service(service.clone())
            .build()?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let mut ctx = completed_context(String::new());
        ctx.tool_name = "invalid_result".to_string();
        ctx.permission_mode_override =
            Some(echo_core::tools::permission::PermissionMode::BypassPermissions);

        PermissionStage.run(&mut ctx, &snapshot).await?;

        assert!(!ctx.blocked);
        assert_eq!(
            service.mode().await,
            echo_core::tools::permission::PermissionMode::Default
        );
        Ok(())
    }

    #[tokio::test]
    async fn invocation_disabled_tool_is_blocked_before_execution() -> Result<()> {
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .build()?;
        let invocation = echo_core::agent::AgentInvocationContext {
            disabled_tools: Some(std::collections::HashSet::from(["hidden_tool".to_string()])),
            ..Default::default()
        };
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent_with_invocation(
            &agent,
            &invocation,
        );
        let mut ctx = completed_context(String::new());
        ctx.tool_name = "hidden_tool".to_string();

        ToolVisibilityStage.run(&mut ctx, &snapshot).await?;

        assert!(ctx.blocked);
        assert!(
            ctx.block_reason
                .as_deref()
                .is_some_and(|reason| reason.contains("not available in this invocation"))
        );
        Ok(())
    }

    #[cfg(feature = "files")]
    #[tokio::test]
    async fn truncation_stage_spills_without_token_limit_and_read_artifact_can_recover()
    -> Result<()> {
        let working_dir =
            tempfile::tempdir().map_err(|error| ReactError::Other(error.to_string()))?;
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .working_dir(working_dir.path())
            .tool_output_artifacts(
                echo_core::tools::artifact::ToolOutputArtifactConfig::new(
                    working_dir.path(),
                    "test",
                )
                .threshold_bytes(8),
            )
            .build()?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let original = format!("{}END", "中文🙂\n".repeat(3_000));
        let mut ctx = completed_context(original.clone());

        TruncationStage.run(&mut ctx, &snapshot).await?;

        let result = ctx
            .result
            .as_ref()
            .ok_or_else(|| ReactError::Other("truncation stage lost tool result".to_string()))?;
        assert!(result.truncated);
        assert_eq!(
            result.metadata.get("output_handling").map(String::as_str),
            Some("spilled")
        );
        let artifact = result
            .artifact
            .as_ref()
            .ok_or_else(|| ReactError::Other("spill result lacks typed artifact".to_string()))?;
        let artifact_path = &artifact.path;
        let physical_root = working_dir
            .path()
            .canonicalize()
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let physical_artifact = artifact_path
            .canonicalize()
            .map_err(|error| ReactError::Other(error.to_string()))?;
        assert!(physical_artifact.starts_with(physical_root));
        let artifact_path_text = artifact_path.to_string_lossy();
        assert!(ctx.output.as_deref().is_some_and(|output| {
            output.contains("Tool output preview only")
                && output.contains("not a summary")
                && output.contains("Full output artifact")
                && output.contains("Use read_artifact with this exact path")
                && output.contains(artifact_path_text.as_ref())
        }));

        let read_tool = crate::tools::files::artifact::ReadArtifactTool;
        let tool_context = ToolContext {
            working_dir: Some(working_dir.path().to_path_buf()),
            output_artifacts: agent.tool_output_artifacts(),
            ..ToolContext::default()
        };
        let mut cursor = None;
        let mut recovered = String::new();
        loop {
            let mut params = ToolParameters::from([
                (
                    "path".to_string(),
                    Value::String(artifact_path_text.to_string()),
                ),
                ("max_tokens".to_string(), Value::from(500_u64)),
            ]);
            if let Some(value) = cursor.clone() {
                params.insert("cursor".to_string(), Value::String(value));
            }
            let page = read_tool
                .execute_with_context(params, &tool_context)
                .await?;
            assert!(page.success);
            let (content, _) = page.output.split_once("\n\n[Artifact ").ok_or_else(|| {
                ReactError::Other("read_artifact page omitted its cursor notice".to_string())
            })?;
            recovered.push_str(content);
            cursor = page.metadata.get("next_cursor").cloned();
            if cursor.is_none() {
                break;
            }
        }
        assert_eq!(recovered, original);
        assert_eq!(
            std::fs::read_to_string(artifact_path).ok().as_deref(),
            Some(original.as_str())
        );
        assert_eq!(artifact.sha256.len(), 64);
        assert_eq!(artifact.retention, "test");
        Ok(())
    }

    #[tokio::test]
    async fn spill_projection_uses_artifact_reader_outside_working_dir() -> Result<()> {
        let working_dir =
            tempfile::tempdir().map_err(|error| ReactError::Other(error.to_string()))?;
        let artifact_dir =
            tempfile::tempdir().map_err(|error| ReactError::Other(error.to_string()))?;
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .working_dir(working_dir.path())
            .tool_output_artifacts(
                echo_core::tools::artifact::ToolOutputArtifactConfig::new(
                    artifact_dir.path(),
                    "test",
                )
                .threshold_bytes(8),
            )
            .build()?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let mut ctx = completed_context("large complete output".to_string());

        TruncationStage.run(&mut ctx, &snapshot).await?;

        let output = ctx
            .output
            .as_deref()
            .ok_or_else(|| ReactError::Other("truncation stage produced no output".to_string()))?;
        assert!(output.contains("Use read_artifact with this exact path"));
        assert!(!output.contains("Use read_file with this exact path"));
        Ok(())
    }

    #[tokio::test]
    async fn token_budget_spills_even_below_byte_threshold() -> Result<()> {
        let artifact_dir =
            tempfile::tempdir().map_err(|error| ReactError::Other(error.to_string()))?;
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .max_tool_output_tokens(20)
            .tool_output_artifacts(
                echo_core::tools::artifact::ToolOutputArtifactConfig::new(
                    artifact_dir.path(),
                    "test",
                )
                .threshold_bytes(1024 * 1024),
            )
            .build()?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let mut ctx = completed_context("small but token-heavy 中文🙂".repeat(100));

        TruncationStage.run(&mut ctx, &snapshot).await?;

        let result = ctx
            .result
            .as_ref()
            .ok_or_else(|| ReactError::Other("truncation stage lost tool result".to_string()))?;
        assert_eq!(
            result.metadata.get("output_handling").map(String::as_str),
            Some("spilled")
        );
        assert!(result.artifact.is_some());
        Ok(())
    }

    #[tokio::test]
    async fn truncation_stage_preserves_tool_level_truncation() -> Result<()> {
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .build()?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let mut ctx = completed_context("partial page".to_string());
        if let Some(result) = ctx.result.as_mut() {
            result.truncated = true;
        }

        TruncationStage.run(&mut ctx, &snapshot).await?;

        assert!(ctx.result.as_ref().is_some_and(|result| result.truncated));
        Ok(())
    }

    #[tokio::test]
    async fn truncation_stage_is_utf8_safe() -> Result<()> {
        let config = crate::agent::AgentConfig::new("test-model", "test-agent", "test")
            .max_tool_output_tokens(20)
            .tool_output_artifacts(None);
        let agent = crate::agent::ReactAgent::new(config);
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let mut ctx = completed_context("中文🙂abc".repeat(500));

        TruncationStage.run(&mut ctx, &snapshot).await?;

        let output = ctx
            .output
            .as_deref()
            .ok_or_else(|| ReactError::Other("truncation stage produced no output".to_string()))?;
        assert!(output.contains("Output truncated"));
        assert!(ctx.result.as_ref().is_some_and(|result| result.truncated));
        let result = ctx
            .result
            .as_ref()
            .ok_or_else(|| ReactError::Other("truncation stage lost tool result".to_string()))?;
        assert_eq!(
            result.metadata.get("output_handling").map(String::as_str),
            Some("truncated")
        );
        assert!(metadata_u64(result, "original_bytes") > metadata_u64(result, "returned_bytes"));
        assert!(metadata_usize(result, "estimated_tokens") > 20);
        Ok(())
    }

    #[tokio::test]
    async fn truncation_stage_records_inline_output_metrics() -> Result<()> {
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .max_tool_output_tokens(100)
            .build()?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let mut ctx = completed_context("short output".to_string());

        TruncationStage.run(&mut ctx, &snapshot).await?;

        let result = ctx
            .result
            .as_ref()
            .ok_or_else(|| ReactError::Other("truncation stage lost tool result".to_string()))?;
        assert!(!result.truncated);
        assert_eq!(
            result.metadata.get("output_handling").map(String::as_str),
            Some("inline")
        );
        assert_eq!(metadata_u64(result, "original_bytes"), 12);
        assert_eq!(metadata_u64(result, "returned_bytes"), 12);
        assert!(metadata_usize(result, "estimated_tokens") > 0);
        Ok(())
    }

    #[tokio::test]
    async fn truncation_stage_falls_back_when_spill_directory_is_unwritable() -> Result<()> {
        let working_dir_file =
            tempfile::NamedTempFile::new().map_err(|error| ReactError::Other(error.to_string()))?;
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .working_dir(working_dir_file.path())
            .tool_output_artifacts(echo_core::tools::artifact::ToolOutputArtifactConfig::new(
                working_dir_file.path().join("artifacts"),
                "test",
            ))
            .build()?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let mut ctx = completed_context("失败回退🙂".repeat(300_000));

        TruncationStage.run(&mut ctx, &snapshot).await?;

        let result = ctx
            .result
            .as_ref()
            .ok_or_else(|| ReactError::Other("truncation stage lost tool result".to_string()))?;
        assert!(result.truncated);
        assert_eq!(
            result.metadata.get("output_handling").map(String::as_str),
            Some("spill_failed_truncated")
        );
        assert!(result.metadata.contains_key("spill_error"));
        assert!(
            ctx.output
                .as_deref()
                .is_some_and(|output| output.contains("Output truncated"))
        );
        Ok(())
    }

    #[test]
    fn default_pipeline_records_trace_after_output_budgeting() {
        let pipeline = ToolExecutionPipeline::default_pipeline();
        let names: Vec<&str> = pipeline.stages.iter().map(|stage| stage.name()).collect();
        let truncation = names.iter().position(|name| *name == "truncation");
        let trace = names.iter().position(|name| *name == "trace_recording");
        assert!(matches!((truncation, trace), (Some(left), Some(right)) if left < right));
    }

    #[tokio::test]
    async fn unsuccessful_tool_result_remains_a_terminal_failure() -> crate::error::Result<()> {
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .enable_tools()
            .tool(Box::new(InvalidResultTool))
            .build()?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let result = snapshot
            .execute_tool_with_policy(
                "call-invalid".to_string(),
                "invalid_result",
                &ToolParameters::new(),
                &serde_json::json!({}),
                None,
            )
            .await;
        let failure = match result {
            Ok(_) => {
                return Err(crate::error::ReactError::Other(
                    "unsuccessful ToolResult was projected as success".to_string(),
                ));
            }
            Err(failure) => failure,
        };

        assert_eq!(
            failure.result.failure.map(|failure| failure.category),
            Some(crate::tools::ToolFailureCategory::InvalidArguments)
        );
        Ok(())
    }

    #[tokio::test]
    async fn streaming_pipeline_forwards_invocation_resource_guards() -> crate::error::Result<()> {
        let observed = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .enable_tools()
            .tool(Box::new(ResourceGuardStreamingTool {
                observed_guard_count: Arc::clone(&observed),
            }))
            .build()?;
        let invocation = echo_core::agent::AgentInvocationContext {
            resource_guards: vec![InvocationResourceGuard::new("stream-lease".to_string())],
            ..echo_core::agent::AgentInvocationContext::default()
        };
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent_with_invocation(
            &agent,
            &invocation,
        );
        let (stream_tx, _stream_rx) = mpsc::channel(4);
        let execution = snapshot
            .execute_tool_with_policy(
                "guard-stream-call".to_string(),
                "resource_guard_stream",
                &ToolParameters::new(),
                &serde_json::json!({}),
                Some(stream_tx),
            )
            .await;
        if let Err(failure) = execution {
            return Err(crate::error::ReactError::Other(format!(
                "streaming guard tool failed: {}",
                failure.result.output
            )));
        }
        assert_eq!(observed.load(std::sync::atomic::Ordering::SeqCst), 1);
        Ok(())
    }

    /// Two single-tool ExecuteStage instances run concurrently; this test
    /// pins per-stream identity and that terminal events reflect actual
    /// completion order (execution fact). This is NOT the batch-contract
    /// test: the concurrent batch path (multiple tool calls in one turn)
    /// emits results in CALL order and is covered by
    /// `concurrent_batch_results_follow_call_order` in stream_channel.rs
    /// (F-RCT-04-P1-01).
    #[tokio::test]
    async fn multiplexed_streams_preserve_identity_and_terminal_order() -> crate::error::Result<()>
    {
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .enable_tools()
            .tool(Box::new(InterleavingTool))
            .build()?;
        let snapshot = Arc::new(crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent));
        let (stream_tx, mut stream_rx) = mpsc::channel(64);
        let (completion_tx, mut completion_rx) = mpsc::channel(2);

        for mut ctx in [
            streaming_context("call-a", "a", 0, 60, stream_tx.clone()),
            streaming_context("call-b", "b", 10, 10, stream_tx.clone()),
        ] {
            let snapshot = Arc::clone(&snapshot);
            let completion_tx = completion_tx.clone();
            tokio::spawn(async move {
                let result = ExecuteStage.run(&mut ctx, &snapshot).await;
                let _ = completion_tx
                    .send((
                        ctx.call_id.clone(),
                        ctx.tool_name.clone(),
                        result,
                        ctx.result,
                    ))
                    .await;
            });
        }
        drop(stream_tx);
        drop(completion_tx);

        let mut events = Vec::new();
        let mut terminal_count = 0;
        while terminal_count < 2 {
            tokio::select! {
                biased;
                Some(event) = stream_rx.recv() => {
                    if let ToolPipelineEvent::Stream { call_id, name, event } = event {
                        events.push(AgentEvent::ToolStream { call_id, name, event });
                    }
                }
                Some((call_id, name, execution, result)) = completion_rx.recv() => {
                    execution?;
                    let result = result.ok_or_else(|| {
                        ReactError::Other("execute stage did not set a result".to_string())
                    })?;
                    events.push(AgentEvent::ToolResult {
                        call_id,
                        name,
                        result,
                    });
                    terminal_count += 1;
                }
            }
        }
        events.push(AgentEvent::ToolBatchEnd);

        let stream_chunks: Vec<(String, String)> = events
            .iter()
            .filter_map(|event| match event {
                AgentEvent::ToolStream {
                    call_id,
                    event: ToolStreamEvent::Output { chunk, .. },
                    ..
                } => Some((call_id.clone(), chunk.clone())),
                _ => None,
            })
            .collect();
        assert_eq!(
            stream_chunks,
            vec![
                ("call-a".into(), "a-1".into()),
                ("call-b".into(), "b-1".into()),
                ("call-b".into(), "b-2".into()),
                ("call-a".into(), "a-2".into()),
            ]
        );

        let terminal_ids: Vec<String> = events
            .iter()
            .filter_map(|event| match event {
                AgentEvent::ToolResult { call_id, .. } => Some(call_id.clone()),
                _ => None,
            })
            .collect();
        assert_eq!(terminal_ids, vec!["call-b", "call-a"]);
        assert!(matches!(events.last(), Some(AgentEvent::ToolBatchEnd)));
        Ok(())
    }

    /// Records which terminal callback methods fire for one pipeline run.
    #[derive(Default)]
    struct RecordingCallback {
        tool_end_calls: std::sync::atomic::AtomicUsize,
        tool_error_calls: std::sync::atomic::AtomicUsize,
        tool_interrupted_calls: std::sync::atomic::AtomicUsize,
        tool_error_messages: std::sync::Mutex<Vec<String>>,
        interrupted_inputs: std::sync::Mutex<Vec<Value>>,
        interrupted_errors: std::sync::Mutex<Vec<String>>,
    }

    impl echo_core::agent::AgentCallback for RecordingCallback {
        fn on_tool_end<'a>(
            &'a self,
            _agent: &'a str,
            _tool: &'a str,
            _result: &'a str,
        ) -> futures::future::BoxFuture<'a, ()> {
            Box::pin(async {
                self.tool_end_calls
                    .fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            })
        }

        fn on_tool_error<'a>(
            &'a self,
            _agent: &'a str,
            _tool: &'a str,
            err: &'a ReactError,
        ) -> futures::future::BoxFuture<'a, ()> {
            Box::pin(async move {
                self.tool_error_calls
                    .fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                self.tool_error_messages
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .push(err.to_string());
            })
        }

        fn on_tool_interrupted_with_id<'a>(
            &'a self,
            _agent: &'a str,
            _call_id: &'a str,
            _tool: &'a str,
            input: &'a Value,
            error: &'a ReactError,
        ) -> futures::future::BoxFuture<'a, ()> {
            Box::pin(async move {
                self.tool_interrupted_calls
                    .fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                self.interrupted_inputs
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .push(input.clone());
                self.interrupted_errors
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .push(error.to_string());
            })
        }
    }

    struct InterruptedErrorTool {
        returns_result: bool,
    }

    impl Tool for InterruptedErrorTool {
        fn name(&self) -> &str {
            "interrupted_error"
        }

        fn description(&self) -> &str {
            "test stub for interrupted execution classification"
        }

        fn parameters(&self) -> Value {
            serde_json::json!({"type": "object"})
        }

        fn execute<'a>(
            &'a self,
            _parameters: ToolParameters,
        ) -> futures::future::BoxFuture<'a, Result<ToolResult>> {
            Box::pin(async move {
                if self.returns_result {
                    Ok(ToolResult::failure(
                        crate::tools::ToolFailureCategory::Cancelled,
                        "completed cancellation result",
                    ))
                } else {
                    Err(ReactError::from(crate::error::ToolError::Cancelled(
                        "reverse extension call".into(),
                    )))
                }
            })
        }
    }

    #[tokio::test]
    async fn typed_execution_interruption_preserves_input_without_reclassifying_returned_result()
    -> Result<()> {
        for returns_result in [false, true] {
            let callback = Arc::new(RecordingCallback::default());
            let agent = crate::agent::ReactAgentBuilder::new()
                .model("test-model")
                .callback(callback.clone())
                .tool(Box::new(InterruptedErrorTool { returns_result }))
                .build()?;
            let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
            let mut ctx = completed_context(String::new());
            ctx.result = None;
            ctx.tool_name = "interrupted_error".to_string();
            ctx.input = serde_json::json!({"admitted": "canonical input"});
            ctx.params =
                HashMap::from([("admitted".to_string(), serde_json::json!("canonical input"))]);
            ToolExecutionPipeline::default_pipeline()
                .run(&mut ctx, &snapshot)
                .await?;

            assert_eq!(
                ctx.result.as_ref().map(|result| result.success),
                Some(false)
            );
            assert_eq!(
                callback
                    .tool_interrupted_calls
                    .load(std::sync::atomic::Ordering::SeqCst),
                usize::from(!returns_result)
            );
            assert_eq!(
                callback
                    .tool_error_calls
                    .load(std::sync::atomic::Ordering::SeqCst),
                usize::from(returns_result)
            );
            if !returns_result {
                assert_eq!(
                    callback
                        .interrupted_inputs
                        .lock()
                        .unwrap_or_else(|error| error.into_inner())
                        .as_slice(),
                    &[serde_json::json!({"admitted": "canonical input"})]
                );
            }
        }
        Ok(())
    }

    #[tokio::test]
    async fn post_use_rejection_keeps_interrupted_callback_and_trace_on_one_terminal_reason()
    -> Result<()> {
        use crate::skills::hooks::{HookAction, HookEvent, HookRule, HooksDefinition};
        use crate::trace::{InMemoryRunStore, RunEvent, RunStore};

        let callback = Arc::new(RecordingCallback::default());
        let audit = Arc::new(crate::audit::InMemoryAuditLogger::new());
        let store = Arc::new(InMemoryRunStore::new());
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .callback(callback.clone())
            .callback(Arc::new(crate::audit::AuditCallback::new(
                audit.clone(),
                "test-agent",
                None,
            )))
            .with_run_store(store.clone())
            .tool(Box::new(InterruptedErrorTool {
                returns_result: false,
            }))
            .build()?;
        let (command, shell) = if cfg!(target_os = "windows") {
            (
                "[Console]::In.ReadToEnd() | Out-Null; exit 2",
                Some("powershell".to_string()),
            )
        } else {
            ("read -r hook_context; exit 2", None)
        };
        let mut hooks = HooksDefinition::default();
        hooks.add_rules(
            HookEvent::PostToolUseFailure,
            vec![HookRule {
                matcher: "interrupted_error".to_string(),
                hooks: vec![HookAction::Command {
                    command: command.to_string(),
                    shell,
                    timeout: 10,
                }],
            }],
        );
        agent
            .hook_registry()
            .write()
            .await
            .register_user_hooks(hooks);
        let legacy = agent.capture_legacy_external_context();
        let run_id = agent
            .start_legacy_trace_run("interrupted post-hook", &legacy)
            .await
            .ok_or_else(|| ReactError::Other("trace run did not start".into()))?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let input = serde_json::json!({"admitted": "canonical input"});
        let params =
            HashMap::from([("admitted".to_string(), serde_json::json!("canonical input"))]);
        let failure = snapshot
            .execute_tool_with_policy(
                "post-interruption".to_string(),
                "interrupted_error",
                &params,
                &input,
                None,
            )
            .await
            .err()
            .ok_or_else(|| ReactError::Other("post-use block was not enforced".into()))?;
        let final_reason = failure
            .result
            .error
            .as_deref()
            .ok_or_else(|| ReactError::Other("terminal reason missing".into()))?;
        assert!(failure.error.to_string().contains(final_reason));
        assert_eq!(
            failure.result.failure.as_ref().map(|value| value.category),
            Some(crate::tools::ToolFailureCategory::Cancelled)
        );
        assert_eq!(
            callback
                .tool_interrupted_calls
                .load(std::sync::atomic::Ordering::SeqCst),
            1
        );
        assert_eq!(
            callback
                .tool_error_calls
                .load(std::sync::atomic::Ordering::SeqCst),
            0
        );
        assert_eq!(
            callback
                .interrupted_errors
                .lock()
                .unwrap_or_else(|error| error.into_inner())
                .as_slice(),
            &[final_reason.to_string()]
        );
        assert_eq!(
            callback
                .interrupted_inputs
                .lock()
                .unwrap_or_else(|error| error.into_inner())
                .as_slice(),
            &[input]
        );
        let run = store
            .load(&run_id)
            .await?
            .ok_or_else(|| ReactError::Other("trace run missing".into()))?;
        assert!(run.events.iter().any(|event| matches!(
            event,
            RunEvent::ToolError { message, failure, .. }
                if message == final_reason
                    && failure.as_ref().is_some_and(|value| value.category == crate::tools::ToolFailureCategory::Cancelled)
        )));
        assert!(
            !run.events
                .iter()
                .any(|event| matches!(event, RunEvent::ToolExecutionSkipped { .. }))
        );
        assert!(audit.snapshot().iter().any(|event| matches!(
            &event.event_type,
            crate::audit::AuditEventType::ToolCall { output, success: false, .. }
                if output == final_reason
        )));
        Ok(())
    }

    /// Deterministic success tool so the pipeline exercises the success
    /// PostToolUse path without touching the filesystem or shell.
    struct EffectTool;

    struct TypedEffectTool;

    impl Tool for TypedEffectTool {
        fn name(&self) -> &str {
            "shell"
        }

        fn description(&self) -> &str {
            "test stub returning confirmed typed effects"
        }

        fn parameters(&self) -> serde_json::Value {
            serde_json::json!({"type": "object"})
        }

        fn execute<'a>(
            &'a self,
            _parameters: ToolParameters,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<ToolResult>> {
            Box::pin(async {
                Ok(ToolResult::success("opaque output")
                    .with_effect(echo_core::tools::ToolEffect::FileRead {
                        path: "src/read.rs".to_string(),
                    })
                    .with_effect(echo_core::tools::ToolEffect::FileEdit {
                        path: "src/lib.rs".to_string(),
                    })
                    .with_effect(echo_core::tools::ToolEffect::TestRun {
                        command: "cargo test".to_string(),
                        passed: false,
                        failure_count: Some(2),
                    }))
            })
        }
    }

    struct PendingPostStage;

    #[async_trait::async_trait]
    impl PipelineStage for PendingPostStage {
        fn name(&self) -> &str {
            "post_tool_use_hook"
        }

        async fn run(
            &self,
            _ctx: &mut ToolExecutionContext,
            _snapshot: &crate::agent::snapshot::AgentRunSnapshot,
        ) -> Result<()> {
            std::future::pending().await
        }
    }

    struct EmptyOutputGuard;

    struct BlockOutputGuard;

    struct ReplaceOutputGuard;

    impl crate::guard::Guard for ReplaceOutputGuard {
        fn name(&self) -> &str {
            "replace_tool_output"
        }

        fn check<'a>(
            &'a self,
            _content: &'a str,
            direction: crate::guard::GuardDirection,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<crate::guard::GuardResult>>
        {
            Box::pin(async move {
                if direction == crate::guard::GuardDirection::ToolOutput {
                    Ok(crate::guard::GuardResult::Transform {
                        content: "filtered output".to_string(),
                        reasons: vec!["redacted tool output".to_string()],
                    })
                } else {
                    Ok(crate::guard::GuardResult::Pass)
                }
            })
        }
    }

    struct FailOutputGuard;

    struct BlockSensitiveProjection;

    impl crate::guard::Guard for BlockSensitiveProjection {
        fn name(&self) -> &str {
            "block_sensitive_projection"
        }

        fn check<'a>(
            &'a self,
            content: &'a str,
            direction: crate::guard::GuardDirection,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<crate::guard::GuardResult>>
        {
            Box::pin(async move {
                if direction == crate::guard::GuardDirection::ToolOutput
                    && content.contains("raw-secret")
                {
                    Ok(crate::guard::GuardResult::Block {
                        reason: "sensitive projection rejected".to_string(),
                    })
                } else {
                    Ok(crate::guard::GuardResult::Pass)
                }
            })
        }
    }

    impl crate::guard::Guard for FailOutputGuard {
        fn name(&self) -> &str {
            "fail_tool_output"
        }

        fn check<'a>(
            &'a self,
            _content: &'a str,
            direction: crate::guard::GuardDirection,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<crate::guard::GuardResult>>
        {
            Box::pin(async move {
                if direction == crate::guard::GuardDirection::ToolOutput {
                    Err(ReactError::Other("guard backend unavailable".to_string()))
                } else {
                    Ok(crate::guard::GuardResult::Pass)
                }
            })
        }
    }

    impl crate::guard::Guard for BlockOutputGuard {
        fn name(&self) -> &str {
            "block_tool_output"
        }

        fn check<'a>(
            &'a self,
            _content: &'a str,
            direction: crate::guard::GuardDirection,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<crate::guard::GuardResult>>
        {
            Box::pin(async move {
                if direction == crate::guard::GuardDirection::ToolOutput {
                    Ok(crate::guard::GuardResult::Block {
                        reason: "tool result policy rejected output".to_string(),
                    })
                } else {
                    Ok(crate::guard::GuardResult::Pass)
                }
            })
        }
    }

    struct ToolInputBlockGuard;

    impl crate::guard::Guard for ToolInputBlockGuard {
        fn name(&self) -> &str {
            "tool_input_block"
        }

        fn check<'a>(
            &'a self,
            _content: &'a str,
            direction: crate::guard::GuardDirection,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<crate::guard::GuardResult>>
        {
            Box::pin(async move {
                if direction == crate::guard::GuardDirection::ToolInput {
                    Ok(crate::guard::GuardResult::Block {
                        reason: "tool input policy rejected the effective arguments".to_string(),
                    })
                } else {
                    Ok(crate::guard::GuardResult::Pass)
                }
            })
        }
    }

    struct ErrorGuard;

    impl crate::guard::Guard for ErrorGuard {
        fn name(&self) -> &str {
            "tool_input_error"
        }

        fn check<'a>(
            &'a self,
            _content: &'a str,
            _direction: crate::guard::GuardDirection,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<crate::guard::GuardResult>>
        {
            Box::pin(async {
                Err(crate::error::ReactError::Other(
                    "tool guard backend unavailable".to_string(),
                ))
            })
        }
    }

    struct DirectionRecordingGuard {
        directions: Arc<std::sync::Mutex<Vec<crate::guard::GuardDirection>>>,
    }

    impl crate::guard::Guard for DirectionRecordingGuard {
        fn name(&self) -> &str {
            "direction_recording"
        }

        fn check<'a>(
            &'a self,
            _content: &'a str,
            direction: crate::guard::GuardDirection,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<crate::guard::GuardResult>>
        {
            let directions = Arc::clone(&self.directions);
            Box::pin(async move {
                directions
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .push(direction);
                Ok(crate::guard::GuardResult::Pass)
            })
        }
    }

    struct ToolInputTransformGuard;

    impl crate::guard::Guard for ToolInputTransformGuard {
        fn name(&self) -> &str {
            "tool_input_transform"
        }

        fn check<'a>(
            &'a self,
            _content: &'a str,
            direction: crate::guard::GuardDirection,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<crate::guard::GuardResult>>
        {
            Box::pin(async move {
                if direction == crate::guard::GuardDirection::ToolInput {
                    Ok(crate::guard::GuardResult::Transform {
                        content: "{}".to_string(),
                        reasons: vec!["rewrite is not allowed after approval".to_string()],
                    })
                } else {
                    Ok(crate::guard::GuardResult::Pass)
                }
            })
        }
    }

    struct GuardProbeTool {
        executions: Arc<std::sync::atomic::AtomicUsize>,
    }

    impl Tool for GuardProbeTool {
        fn name(&self) -> &str {
            "guard_probe"
        }

        fn description(&self) -> &str {
            "records whether tool input guard allowed execution"
        }

        fn parameters(&self) -> serde_json::Value {
            serde_json::json!({"type": "object"})
        }

        fn execute<'a>(
            &'a self,
            _parameters: ToolParameters,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<ToolResult>> {
            self.executions
                .fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            Box::pin(async { Ok(ToolResult::success("executed")) })
        }

        fn supports_streaming(&self) -> bool {
            true
        }

        fn execute_stream_with_context<'a>(
            &'a self,
            _parameters: ToolParameters,
            _context: &ToolContext,
        ) -> futures::future::BoxFuture<
            'a,
            crate::error::Result<Pin<Box<dyn Stream<Item = ToolStreamEvent> + Send + 'a>>>,
        > {
            self.executions
                .fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            Box::pin(async {
                Ok(Box::pin(futures::stream::iter([ToolStreamEvent::Complete(
                    ToolResult::success("executed"),
                )]))
                    as Pin<Box<dyn Stream<Item = ToolStreamEvent> + Send>>)
            })
        }
    }

    impl crate::guard::Guard for EmptyOutputGuard {
        fn name(&self) -> &str {
            "empty_output"
        }

        fn check<'a>(
            &'a self,
            _content: &'a str,
            direction: crate::guard::GuardDirection,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<crate::guard::GuardResult>>
        {
            Box::pin(async move {
                if direction == crate::guard::GuardDirection::ToolOutput {
                    Ok(crate::guard::GuardResult::Transform {
                        content: String::new(),
                        reasons: vec!["redacted".to_string()],
                    })
                } else {
                    Ok(crate::guard::GuardResult::Pass)
                }
            })
        }
    }

    impl Tool for EffectTool {
        fn name(&self) -> &str {
            "shell"
        }

        fn description(&self) -> &str {
            "test stub producing a successful effect result"
        }

        fn parameters(&self) -> serde_json::Value {
            serde_json::json!({"type": "object"})
        }

        fn execute<'a>(
            &'a self,
            _parameters: ToolParameters,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<ToolResult>> {
            Box::pin(async { Ok(ToolResult::success("real effect")) })
        }
    }

    #[tokio::test]
    async fn audit_does_not_restore_output_cleared_by_guard() -> Result<()> {
        let audit = Arc::new(crate::audit::InMemoryAuditLogger::new());
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .audit_logger(audit.clone())
            .guard(Arc::new(EmptyOutputGuard))
            .tool(Box::new(EffectTool))
            .build()?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let outcome = snapshot
            .execute_tool_with_policy(
                "guard-clears-output".to_string(),
                "shell",
                &ToolParameters::new(),
                &serde_json::json!({}),
                None,
            )
            .await
            .map_err(|failure| {
                ReactError::Other(format!(
                    "tool unexpectedly failed: {}",
                    failure.result.output
                ))
            })?;
        assert_eq!(outcome.result.output, "");
        let terminal_outputs: Vec<_> = audit
            .snapshot()
            .into_iter()
            .filter_map(|event| match event.event_type {
                crate::audit::AuditEventType::ToolCall {
                    output, success, ..
                } => Some((output, success)),
                _ => None,
            })
            .collect();
        assert_eq!(terminal_outputs, vec![(String::new(), true)]);
        Ok(())
    }

    #[tokio::test]
    async fn tool_input_guard_blocks_streaming_and_non_streaming_before_execution() -> Result<()> {
        for streaming in [false, true] {
            let executions = Arc::new(std::sync::atomic::AtomicUsize::new(0));
            let audit = Arc::new(crate::audit::InMemoryAuditLogger::new());
            let agent = crate::agent::ReactAgentBuilder::new()
                .model("test-model")
                .audit_logger(audit.clone())
                .guard(Arc::new(ToolInputBlockGuard))
                .tool(Box::new(GuardProbeTool {
                    executions: Arc::clone(&executions),
                }))
                .build()?;
            let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
            let (stream_tx, _stream_rx) = if streaming {
                let (stream_tx, stream_rx) = mpsc::channel(4);
                (Some(stream_tx), Some(stream_rx))
            } else {
                (None, None)
            };
            let failure = snapshot
                .execute_tool_with_policy(
                    format!("guard-block-{streaming}"),
                    "guard_probe",
                    &ToolParameters::new(),
                    &serde_json::json!({"blocked": true}),
                    stream_tx,
                )
                .await
                .err()
                .ok_or_else(|| ReactError::Other("tool input guard allowed execution".into()))?;
            assert!(
                failure.result.output.contains("tool input policy rejected")
                    || failure
                        .error
                        .to_string()
                        .contains("tool input policy rejected"),
                "unexpected guard failure output={:?} error={}",
                failure.result.output,
                failure.error
            );
            assert_eq!(executions.load(std::sync::atomic::Ordering::SeqCst), 0);
            let guard_blocks = audit
                .snapshot()
                .into_iter()
                .filter(|event| {
                    matches!(
                        event.event_type,
                        crate::audit::AuditEventType::GuardBlock {
                            direction: crate::guard::GuardDirection::ToolInput,
                            ..
                        }
                    )
                })
                .count();
            assert_eq!(guard_blocks, 1);
        }
        Ok(())
    }

    #[tokio::test]
    async fn tool_input_guard_fails_closed_on_error_and_transform() -> Result<()> {
        for guard in [
            Arc::new(ErrorGuard) as Arc<dyn crate::guard::Guard>,
            Arc::new(ToolInputTransformGuard) as Arc<dyn crate::guard::Guard>,
        ] {
            let executions = Arc::new(std::sync::atomic::AtomicUsize::new(0));
            let agent = crate::agent::ReactAgentBuilder::new()
                .model("test-model")
                .guard(guard)
                .tool(Box::new(GuardProbeTool {
                    executions: Arc::clone(&executions),
                }))
                .build()?;
            let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
            let failure = snapshot
                .execute_tool_with_policy(
                    "guard-fail-closed".to_string(),
                    "guard_probe",
                    &ToolParameters::new(),
                    &serde_json::json!({"value": "effective"}),
                    None,
                )
                .await
                .err()
                .ok_or_else(|| ReactError::Other("guard failure was not terminal".into()))?;
            assert!(!failure.result.success);
            assert_eq!(executions.load(std::sync::atomic::Ordering::SeqCst), 0);
        }
        Ok(())
    }

    #[tokio::test]
    async fn tool_output_and_final_answer_use_distinct_directions() -> Result<()> {
        let directions = Arc::new(std::sync::Mutex::new(Vec::new()));
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .guard(Arc::new(DirectionRecordingGuard {
                directions: Arc::clone(&directions),
            }))
            .build()?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let _ = snapshot.check_tool_output_guard("tool result").await;
        let final_answer = snapshot.check_final_answer_guard("final answer").await?;
        assert_eq!(final_answer, "final answer");
        assert_eq!(
            directions
                .lock()
                .unwrap_or_else(|error| error.into_inner())
                .as_slice(),
            &[
                crate::guard::GuardDirection::ToolOutput,
                crate::guard::GuardDirection::Output
            ]
        );
        Ok(())
    }

    #[tokio::test]
    async fn tool_output_block_replaces_caller_projection_and_audits_direction() -> Result<()> {
        let audit = Arc::new(crate::audit::InMemoryAuditLogger::new());
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .audit_logger(audit.clone())
            .guard(Arc::new(BlockOutputGuard))
            .tool(Box::new(EffectTool))
            .build()?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let outcome = snapshot
            .execute_tool_with_policy(
                "tool-output-block".to_string(),
                "shell",
                &ToolParameters::new(),
                &serde_json::json!({}),
                None,
            )
            .await
            .map_err(|failure| ReactError::Other(failure.error.to_string()))?;
        assert!(!outcome.result.output.contains("real effect"));
        assert!(
            outcome
                .result
                .output
                .contains("tool result policy rejected")
        );
        let guard_blocks = audit
            .snapshot()
            .into_iter()
            .filter(|event| {
                matches!(
                    event.event_type,
                    crate::audit::AuditEventType::GuardBlock {
                        direction: crate::guard::GuardDirection::ToolOutput,
                        ..
                    }
                )
            })
            .count();
        assert_eq!(guard_blocks, 1);
        Ok(())
    }

    #[tokio::test]
    async fn guarded_text_replacement_retires_structured_and_rich_projections() -> Result<()> {
        for (guard, expected) in [
            (
                Arc::new(BlockOutputGuard) as Arc<dyn crate::guard::Guard>,
                "Output content filtered by safety guard: tool result policy rejected output",
            ),
            (
                Arc::new(ReplaceOutputGuard) as Arc<dyn crate::guard::Guard>,
                "filtered output",
            ),
        ] {
            let agent = crate::agent::ReactAgentBuilder::new()
                .model("test-model")
                .guard(guard)
                .tool(Box::new(StructuredRichTool))
                .build()?;
            let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
            let outcome = snapshot
                .execute_tool_with_policy(
                    "structured-rich".to_string(),
                    "structured_rich",
                    &ToolParameters::new(),
                    &serde_json::json!({}),
                    None,
                )
                .await
                .map_err(|failure| ReactError::Other(failure.error.to_string()))?;
            assert_eq!(outcome.result.output, expected);
            assert!(outcome.result.data.is_none());
            assert!(outcome.result.model_content.is_empty());
            assert!(matches!(
                outcome.result.kind,
                echo_core::tools::ToolResultKind::Text
            ));
            assert!(outcome.result.mime_type.is_none());
            assert!(!outcome.result.metadata.contains_key("payload"));
            assert!(outcome.result.effects.iter().any(|effect| matches!(
                effect,
                echo_core::tools::ToolEffect::FileEdit { path }
                    if path == "src/structured-rich.rs"
            )));
        }
        Ok(())
    }

    #[tokio::test]
    async fn output_pass_does_not_approve_independent_structured_content() -> Result<()> {
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .guard(Arc::new(BlockSensitiveProjection))
            .tool(Box::new(StructuredRichTool))
            .build()?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let outcome = snapshot
            .execute_tool_with_policy(
                "structured-disjoint".to_string(),
                "structured_rich",
                &ToolParameters::new(),
                &serde_json::json!({}),
                None,
            )
            .await
            .map_err(|failure| ReactError::Other(failure.error.to_string()))?;
        assert!(!outcome.result.output.contains("raw-secret"));
        assert!(
            outcome
                .result
                .output
                .contains("sensitive projection rejected"),
            "unexpected guarded output: {:?}",
            outcome.result.output
        );
        assert!(outcome.result.data.is_none());
        assert!(outcome.result.model_content.is_empty());
        assert!(!outcome.result.metadata.contains_key("payload"));
        assert!(matches!(
            outcome.result.kind,
            echo_core::tools::ToolResultKind::Text
        ));
        assert!(outcome.result.effects.iter().any(|effect| matches!(
            effect,
            echo_core::tools::ToolEffect::FileEdit { path }
                if path == "src/structured-rich.rs"
        )));
        Ok(())
    }

    #[tokio::test]
    async fn rich_projection_without_guard_stays_live_and_guard_pass_keeps_safe_structures()
    -> Result<()> {
        for with_guard in [false, true] {
            let directions = Arc::new(std::sync::Mutex::new(Vec::new()));
            let mut builder = crate::agent::ReactAgentBuilder::new()
                .model("test-model")
                .tool(Box::new(StructuredRichTool));
            if with_guard {
                builder = builder.guard(Arc::new(DirectionRecordingGuard {
                    directions: Arc::clone(&directions),
                }));
            }
            let agent = builder.build()?;
            let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
            let outcome = snapshot
                .execute_tool_with_policy(
                    format!("rich-{with_guard}"),
                    "structured_rich",
                    &ToolParameters::new(),
                    &serde_json::json!({}),
                    None,
                )
                .await
                .map_err(|failure| ReactError::Other(failure.error.to_string()))?;
            assert_eq!(outcome.result.output, "safe summary");
            assert!(outcome.result.data.is_some());
            assert!(outcome.result.metadata.contains_key("payload"));
            assert!(matches!(
                outcome.result.kind,
                echo_core::tools::ToolResultKind::Table { .. }
            ));
            assert_eq!(outcome.result.model_content.is_empty(), with_guard);
            if with_guard {
                assert!(outcome.result.mime_type.is_none());
                assert!(
                    directions
                        .lock()
                        .unwrap_or_else(|error| error.into_inner())
                        .len()
                        >= 4
                );
            }
        }
        Ok(())
    }

    #[tokio::test]
    async fn metadata_kind_and_mime_are_checked_when_output_passes() -> Result<()> {
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .guard(Arc::new(BlockSensitiveProjection))
            .build()?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);

        for field in ["metadata", "kind", "mime"] {
            let mut ctx = completed_context("safe summary".to_string());
            let result = ctx
                .result
                .as_mut()
                .ok_or_else(|| ReactError::Other("missing test tool result".to_string()))?;
            match field {
                "metadata" => {
                    result
                        .metadata
                        .insert("payload".to_string(), "raw-secret".to_string());
                }
                "kind" => {
                    result.kind = echo_core::tools::ToolResultKind::Diff {
                        unified_diff: "raw-secret".to_string(),
                    };
                }
                "mime" => {
                    result.mime_type = Some("image/raw-secret".to_string());
                }
                _ => {}
            }
            OutputGuardStage.run(&mut ctx, &snapshot).await?;
            TruncationStage.run(&mut ctx, &snapshot).await?;
            let result = ctx
                .result
                .as_ref()
                .ok_or_else(|| ReactError::Other("guard lost tool result".to_string()))?;
            assert_eq!(ctx.output.as_deref(), Some("safe summary"));
            assert!(
                !result
                    .metadata
                    .values()
                    .any(|value| value.contains("raw-secret"))
            );
            assert!(matches!(
                result.kind,
                echo_core::tools::ToolResultKind::Text
            ));
            assert!(result.mime_type.is_none());
        }
        Ok(())
    }

    #[tokio::test]
    async fn failed_tool_with_output_guards_independent_error_diagnostic() -> Result<()> {
        use crate::trace::{InMemoryRunStore, RunEvent, RunStore};

        for guard in [
            Arc::new(BlockOutputGuard) as Arc<dyn crate::guard::Guard>,
            Arc::new(ReplaceOutputGuard) as Arc<dyn crate::guard::Guard>,
            Arc::new(FailOutputGuard) as Arc<dyn crate::guard::Guard>,
        ] {
            let callback = Arc::new(RecordingCallback::default());
            let store = Arc::new(InMemoryRunStore::new());
            let agent = crate::agent::ReactAgentBuilder::new()
                .model("test-model")
                .with_run_store(store.clone())
                .callback(callback.clone())
                .guard(guard)
                .tool(Box::new(OutputAndErrorTool))
                .build()?;
            let legacy = agent.capture_legacy_external_context();
            let run_id = agent
                .start_legacy_trace_run("output and error", &legacy)
                .await
                .ok_or_else(|| ReactError::Other("trace did not start".to_string()))?;
            let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
            let failure = snapshot
                .execute_tool_with_policy(
                    "output-and-error".to_string(),
                    "output_and_error",
                    &ToolParameters::new(),
                    &serde_json::json!({}),
                    None,
                )
                .await
                .err()
                .ok_or_else(|| {
                    ReactError::Other("failed tool unexpectedly succeeded".to_string())
                })?;
            assert!(!failure.result.output.contains("raw-secret"));
            assert!(
                failure
                    .result
                    .error
                    .as_deref()
                    .is_some_and(|error| !error.contains("raw-secret"))
            );
            assert!(!failure.error.to_string().contains("raw-secret"));
            let run = store
                .load(&run_id)
                .await?
                .ok_or_else(|| ReactError::Other("trace run disappeared".to_string()))?;
            assert!(run.events.iter().any(|event| matches!(
                event,
                RunEvent::ToolError { message, .. } if !message.contains("raw-secret")
            )));
            assert!(
                callback
                    .tool_error_messages
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .iter()
                    .all(|error| !error.contains("raw-secret"))
            );
            assert!(failure.result.effects.iter().any(|effect| matches!(
                effect,
                echo_core::tools::ToolEffect::FileEdit { path } if path == "src/output-error.rs"
            )));
        }
        Ok(())
    }

    #[tokio::test]
    async fn partial_failure_free_text_is_guarded_without_losing_typed_recovery() -> Result<()> {
        use crate::trace::{InMemoryRunStore, RunEvent, RunStore};

        let store = Arc::new(InMemoryRunStore::new());
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .with_run_store(store.clone())
            .guard(Arc::new(BlockSensitiveProjection))
            .tool(Box::new(PartialFailureTool))
            .build()?;
        let legacy = agent.capture_legacy_external_context();
        let run_id = agent
            .start_legacy_trace_run("partial failure", &legacy)
            .await
            .ok_or_else(|| ReactError::Other("trace did not start".to_string()))?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let result = snapshot
            .execute_tool_with_policy(
                "partial-failure".to_string(),
                "partial_failure",
                &ToolParameters::new(),
                &serde_json::json!({}),
                None,
            )
            .await
            .err()
            .ok_or_else(|| {
                ReactError::Other("partial failure unexpectedly succeeded".to_string())
            })?;
        let failure = result
            .result
            .failure
            .as_ref()
            .ok_or_else(|| ReactError::Other("typed failure missing".to_string()))?;
        assert_eq!(
            failure.category,
            crate::tools::ToolFailureCategory::PartialSideEffect
        );
        assert_eq!(
            failure.recovery,
            echo_core::tools::ToolRecoveryAction::VerifyThenRetry
        );
        assert_eq!(
            failure.side_effect,
            echo_core::tools::ToolSideEffect::Possible
        );
        assert!(
            !failure
                .idempotency_key
                .as_deref()
                .unwrap_or("")
                .contains("raw-secret")
        );
        assert!(
            !failure
                .postcondition
                .as_deref()
                .unwrap_or("")
                .contains("raw-secret")
        );
        assert!(result.result.effects.iter().any(|effect| matches!(
            effect,
            echo_core::tools::ToolEffect::FileEdit { path } if path == "src/partial-failure.rs"
        )));
        let run = store
            .load(&run_id)
            .await?
            .ok_or_else(|| ReactError::Other("trace run disappeared".to_string()))?;
        assert!(run.events.iter().any(|event| matches!(
            event,
            RunEvent::ToolError { failure: Some(failure), .. }
                if failure.category == crate::tools::ToolFailureCategory::PartialSideEffect
                    && failure.idempotency_key.as_deref().is_none_or(|text| !text.contains("raw-secret"))
                    && failure.postcondition.as_deref().is_none_or(|text| !text.contains("raw-secret"))
        )));
        Ok(())
    }

    #[tokio::test]
    async fn guarded_stream_never_emits_raw_chunks_before_terminal_projection() -> Result<()> {
        for (guard, expected_chunks, expected_terminal) in [
            (
                None,
                vec!["raw-1".to_string(), "raw-2".to_string()],
                "raw".to_string(),
            ),
            (
                Some(Arc::new(BlockOutputGuard) as Arc<dyn crate::guard::Guard>),
                Vec::new(),
                "Output content filtered by safety guard: tool result policy rejected output"
                    .to_string(),
            ),
            (
                Some(Arc::new(ReplaceOutputGuard) as Arc<dyn crate::guard::Guard>),
                Vec::new(),
                "filtered output".to_string(),
            ),
        ] {
            let mut builder = crate::agent::ReactAgentBuilder::new()
                .model("test-model")
                .tool(Box::new(InterleavingTool));
            if let Some(guard) = guard {
                builder = builder.guard(guard);
            }
            let agent = builder.build()?;
            let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
            let input = serde_json::json!({
                "label": "raw",
                "initial_delay": 0,
                "finish_delay": 0,
            });
            let params = ToolParameters::from([
                ("label".to_string(), Value::String("raw".to_string())),
                ("initial_delay".to_string(), Value::from(0)),
                ("finish_delay".to_string(), Value::from(0)),
            ]);
            let (stream_tx, mut stream_rx) = mpsc::channel(16);
            let outcome = snapshot
                .execute_tool_with_policy(
                    "guarded-stream".to_string(),
                    "interleaving",
                    &params,
                    &input,
                    Some(stream_tx),
                )
                .await
                .map_err(|failure| ReactError::Other(failure.error.to_string()))?;
            let mut chunks = Vec::new();
            let mut stream_events = 0;
            while let Ok(event) = stream_rx.try_recv() {
                if let ToolPipelineEvent::Stream { event, .. } = event {
                    stream_events += 1;
                    if let ToolStreamEvent::Output { chunk, .. } = event {
                        chunks.push(chunk);
                    }
                }
            }
            assert_eq!(chunks, expected_chunks);
            if expected_chunks.is_empty() {
                assert_eq!(stream_events, 0);
            }
            assert_eq!(outcome.result.output, expected_terminal);
        }
        Ok(())
    }

    #[tokio::test]
    async fn output_guard_retires_pre_guard_artifact_capability() -> Result<()> {
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .guard(Arc::new(EmptyOutputGuard))
            .build()?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let mut ctx = completed_context("raw secret output".to_string());
        if let Some(result) = ctx.result.as_mut() {
            result.artifact = Some(echo_core::tools::artifact::ToolOutputArtifactRef {
                path: std::path::PathBuf::from("/private/raw-output.txt"),
                artifact_bytes: 17,
                payload_bytes: 17,
                sha256: "a".repeat(64),
                retention: "test".to_string(),
            });
        }

        OutputGuardStage.run(&mut ctx, &snapshot).await?;
        TruncationStage.run(&mut ctx, &snapshot).await?;

        assert_eq!(ctx.output.as_deref(), Some(""));
        assert!(
            ctx.result
                .as_ref()
                .is_some_and(|result| result.artifact.is_none())
        );
        Ok(())
    }

    #[tokio::test]
    async fn typed_tool_effects_are_projected_without_name_or_output_inference() -> Result<()> {
        use crate::trace::{InMemoryRunStore, RunEvent, RunStore};

        let store = Arc::new(InMemoryRunStore::new());
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .with_run_store(store.clone())
            .tool(Box::new(TypedEffectTool))
            .build()?;
        let legacy = agent.capture_legacy_external_context();
        let run_id = agent
            .start_legacy_trace_run("typed effects", &legacy)
            .await
            .ok_or_else(|| ReactError::Other("trace did not start".to_string()))?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let mut ctx = completed_context("opaque output".to_string());
        ExecuteStage.run(&mut ctx, &snapshot).await?;
        TraceRecordingStage.run(&mut ctx, &snapshot).await?;
        let run = store
            .load(&run_id)
            .await?
            .ok_or_else(|| ReactError::Other("trace disappeared".to_string()))?;
        assert!(run.events.iter().any(|event| matches!(
            event,
            RunEvent::FileRead { tool, path } if tool == "shell" && path == "src/read.rs"
        )));
        assert!(run.events.iter().any(|event| matches!(
            event,
            RunEvent::FileEdit { tool, path } if tool == "shell" && path == "src/lib.rs"
        )));
        assert!(run.events.iter().any(|event| matches!(
            event,
            RunEvent::TestRun { command, passed: false, failure_count: Some(2) }
            if command == "cargo test"
        )));
        Ok(())
    }

    #[tokio::test]
    async fn confirmed_effects_survive_stalled_post_use_stage() -> Result<()> {
        use crate::trace::{InMemoryRunStore, RunEvent, RunStore};

        let store = Arc::new(InMemoryRunStore::new());
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .with_run_store(store.clone())
            .tool(Box::new(TypedEffectTool))
            .build()?;
        let legacy = agent.capture_legacy_external_context();
        let run_id = agent
            .start_legacy_trace_run("effect before post hook", &legacy)
            .await
            .ok_or_else(|| ReactError::Other("trace did not start".to_string()))?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let mut ctx = completed_context(String::new());
        let pipeline = ToolExecutionPipeline {
            stages: vec![Box::new(ExecuteStage), Box::new(PendingPostStage)],
        };
        assert!(
            tokio::time::timeout(
                std::time::Duration::from_millis(50),
                pipeline.run(&mut ctx, &snapshot),
            )
            .await
            .is_err()
        );
        let run = store
            .load(&run_id)
            .await?
            .ok_or_else(|| ReactError::Other("trace disappeared".to_string()))?;
        assert_eq!(
            run.events
                .iter()
                .filter(
                    |event| matches!(event, RunEvent::FileEdit { path, .. } if path == "src/lib.rs")
                )
                .count(),
            1
        );
        assert!(run.events.iter().any(|event| matches!(
            event,
            RunEvent::TestRun {
                failure_count: Some(2),
                ..
            }
        )));
        assert!(
            !run.events
                .iter()
                .any(|event| matches!(event, RunEvent::ToolResult { .. }))
        );
        Ok(())
    }

    #[tokio::test]
    async fn failed_tool_output_is_guarded_before_caller_and_audit() -> Result<()> {
        let audit = Arc::new(crate::audit::InMemoryAuditLogger::new());
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .audit_logger(audit.clone())
            .guard(Arc::new(EmptyOutputGuard))
            .tool(Box::new(FailedOutputTool))
            .build()?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let failure = snapshot
            .execute_tool_with_policy(
                "failed-output".to_string(),
                "failed_output",
                &ToolParameters::new(),
                &serde_json::json!({}),
                None,
            )
            .await
            .err()
            .ok_or_else(|| ReactError::Other("failed tool unexpectedly succeeded".to_string()))?;
        assert_eq!(failure.result.error.as_deref(), Some(""));
        assert_eq!(failure.result.output, "");
        let terminal_outputs: Vec<_> = audit
            .snapshot()
            .into_iter()
            .filter_map(|event| match event.event_type {
                crate::audit::AuditEventType::ToolCall {
                    output, success, ..
                } => Some((output, success)),
                _ => None,
            })
            .collect();
        assert_eq!(terminal_outputs, vec![(String::new(), false)]);
        Ok(())
    }

    #[tokio::test]
    async fn error_only_diagnostic_is_guarded_for_caller_trace_audit_and_callback() -> Result<()> {
        use crate::trace::{InMemoryRunStore, RunEvent, RunStore};

        for (guard, expected) in [
            (
                Arc::new(EmptyOutputGuard) as Arc<dyn crate::guard::Guard>,
                "".to_string(),
            ),
            (
                Arc::new(BlockOutputGuard) as Arc<dyn crate::guard::Guard>,
                "Output content filtered by safety guard: tool result policy rejected output"
                    .to_string(),
            ),
            (
                Arc::new(FailOutputGuard) as Arc<dyn crate::guard::Guard>,
                "Output content blocked: guard check error (guard backend unavailable)".to_string(),
            ),
        ] {
            let audit = Arc::new(crate::audit::InMemoryAuditLogger::new());
            let callback = Arc::new(RecordingCallback::default());
            let store = Arc::new(InMemoryRunStore::new());
            let agent = crate::agent::ReactAgentBuilder::new()
                .model("test-model")
                .with_run_store(store.clone())
                .audit_logger(audit.clone())
                .callback(callback.clone())
                .guard(guard)
                .tool(Box::new(ErrorOnlyTool))
                .build()?;
            let legacy = agent.capture_legacy_external_context();
            let run_id = agent
                .start_legacy_trace_run("error-only tool", &legacy)
                .await
                .ok_or_else(|| ReactError::Other("trace did not start".to_string()))?;
            let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
            let failure = snapshot
                .execute_tool_with_policy(
                    "error-only".to_string(),
                    "error_only",
                    &ToolParameters::new(),
                    &serde_json::json!({}),
                    None,
                )
                .await
                .err()
                .ok_or_else(|| {
                    ReactError::Other("error-only tool unexpectedly succeeded".to_string())
                })?;
            assert_eq!(failure.result.error.as_deref(), Some(expected.as_str()));
            assert!(!failure.error.to_string().contains("sensitive-token"));
            assert_eq!(failure.result.output, "");
            assert!(failure.result.effects.iter().any(|effect| matches!(
                effect,
                echo_core::tools::ToolEffect::FileEdit { path } if path == "src/error-only.rs"
            )));
            let run = store
                .load(&run_id)
                .await?
                .ok_or_else(|| ReactError::Other("trace run disappeared".to_string()))?;
            assert!(run.events.iter().any(|event| matches!(
                event,
                RunEvent::ToolError { message, .. } if message == &expected
            )));
            assert!(run.events.iter().any(|event| matches!(
                event,
                RunEvent::FileEdit { path, .. } if path == "src/error-only.rs"
            )));
            assert!(audit.snapshot().iter().any(|event| matches!(
                &event.event_type,
                crate::audit::AuditEventType::ToolCall { output, success: false, .. }
                    if output == &expected
            )));
            let callback_errors = callback
                .tool_error_messages
                .lock()
                .unwrap_or_else(|error| error.into_inner());
            assert_eq!(callback_errors.len(), 1);
            assert!(
                callback_errors
                    .iter()
                    .all(|error| !error.contains("sensitive-token"))
            );
        }
        Ok(())
    }

    #[tokio::test]
    async fn pre_execution_block_does_not_emit_success_callback() -> Result<()> {
        let callback = Arc::new(RecordingCallback::default());
        let audit = Arc::new(crate::audit::InMemoryAuditLogger::new());
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .callback(callback.clone())
            .audit_logger(audit.clone())
            .tool(Box::new(EffectTool))
            .build()?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let mut ctx = completed_context(String::new());
        ctx.result = None;
        ctx.block(
            crate::tools::ToolFailureCategory::Permanent,
            "denied".to_string(),
        );
        ToolExecutionPipeline::default_pipeline()
            .run(&mut ctx, &snapshot)
            .await?;
        assert!(ctx.result.is_none());
        assert_eq!(
            callback
                .tool_end_calls
                .load(std::sync::atomic::Ordering::SeqCst),
            0
        );
        assert_eq!(
            callback
                .tool_error_calls
                .load(std::sync::atomic::Ordering::SeqCst),
            0
        );
        assert!(audit.snapshot().is_empty());
        Ok(())
    }

    /// #102: a failed ToolResult must reach on_tool_error, not on_tool_end.
    #[tokio::test]
    async fn failed_tool_result_routes_to_on_tool_error_not_on_tool_end() -> Result<()> {
        let callback = Arc::new(RecordingCallback::default());
        let audit = Arc::new(crate::audit::InMemoryAuditLogger::new());

        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .callback(callback.clone())
            .audit_logger(audit.clone())
            .tool(Box::new(InvalidResultTool))
            .build()?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let mut ctx = completed_context(String::new());
        ctx.result = None;
        ctx.tool_name = "invalid_result".to_string();
        ToolExecutionPipeline::default_pipeline()
            .run(&mut ctx, &snapshot)
            .await?;

        assert_eq!(
            callback
                .tool_error_calls
                .load(std::sync::atomic::Ordering::SeqCst),
            1,
            "failure must reach on_tool_error"
        );
        assert_eq!(
            callback
                .tool_end_calls
                .load(std::sync::atomic::Ordering::SeqCst),
            0,
            "failure must not be reported as on_tool_end success"
        );
        assert_eq!(
            audit
                .snapshot()
                .iter()
                .filter(|event| matches!(
                    event.event_type,
                    crate::audit::AuditEventType::ToolCall { success: false, .. }
                ))
                .count(),
            1,
        );
        assert!(audit.snapshot().iter().any(|event| matches!(
            &event.event_type,
            crate::audit::AuditEventType::ToolCall { output, success: false, .. }
            if output.contains("missing query")
        )));
        Ok(())
    }

    /// #102: a PostToolUse block after a real effect must not short-circuit
    /// the remaining observation stages (OutputGuard/Truncation/Trace/End).
    /// Uses the exit-code-2 block convention implemented in hooks.rs:1428.
    #[tokio::test]
    async fn post_hook_block_after_effect_still_records_full_observations() -> Result<()> {
        use crate::skills::hooks::{HookAction, HookEvent, HookRule, HooksDefinition};

        use crate::trace::{InMemoryRunStore, Run, RunStatus, RunStore};

        let callback = Arc::new(RecordingCallback::default());
        let audit = Arc::new(crate::audit::InMemoryAuditLogger::new());
        let store = Arc::new(InMemoryRunStore::new());
        store
            .save(Run {
                run_id: "post-block".to_string(),
                parent_run_id: None,
                agent_name: "test".to_string(),
                model: "test-model".to_string(),
                provider: None,
                turn_id: None,
                execution_id: None,
                session_id: "test".to_string(),
                status: RunStatus::Running,
                input: String::new(),
                events: Vec::new(),
                final_output: None,
                error: None,
                token_usage: Default::default(),
                timings: Default::default(),
                started_at: chrono::Utc::now(),
                finished_at: None,
            })
            .await?;
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .callback(callback.clone())
            .audit_logger(audit.clone())
            .with_run_store(store.clone())
            .tool(Box::new(EffectTool))
            .build()?;
        let mut snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        snapshot.trace_run_id = Some("post-block".to_string());
        // Drain the hook context before exiting so stdin delivery cannot race
        // the explicit block signal and turn it into a sandbox error.
        let (command, shell) = if cfg!(target_os = "windows") {
            (
                "[Console]::In.ReadToEnd() | Out-Null; exit 2",
                Some("powershell".to_string()),
            )
        } else {
            ("read -r hook_context; exit 2", None)
        };
        let mut definition = HooksDefinition::default();
        definition.add_rules(
            HookEvent::PostToolUse,
            vec![HookRule {
                matcher: "shell".to_string(),
                hooks: vec![HookAction::Command {
                    command: command.to_string(),
                    shell,
                    timeout: 10,
                }],
            }],
        );
        snapshot
            .tools
            .hook_registry
            .write()
            .await
            .register_user_hooks(definition);

        let outcome = snapshot
            .execute_tool_with_policy(
                "call-post-block".to_string(),
                "shell",
                &ToolParameters::new(),
                &serde_json::json!({}),
                None,
            )
            .await;
        let failure = outcome.err().ok_or_else(|| {
            ReactError::Other("post-use rejection incorrectly returned success".to_string())
        })?;
        let result = failure.result;
        assert!(!result.success);
        assert!(
            result
                .failure
                .as_ref()
                .is_some_and(|failure| failure.category
                    == crate::tools::ToolFailureCategory::PartialSideEffect
                    && failure.postcondition.is_some())
        );
        assert_eq!(
            callback
                .tool_error_calls
                .load(std::sync::atomic::Ordering::SeqCst),
            1,
            "post-effect policy failure must fire on_tool_error exactly once"
        );
        assert_eq!(
            callback
                .tool_end_calls
                .load(std::sync::atomic::Ordering::SeqCst),
            0
        );
        assert_eq!(result.output, "real effect");
        assert!(result.metadata.contains_key("returned_bytes"));
        let run = store
            .load("post-block")
            .await?
            .ok_or_else(|| ReactError::Other("missing trace run".to_string()))?;
        let terminals: Vec<_> = run
            .events
            .iter()
            .filter_map(|event| match event {
                crate::trace::RunEvent::ToolResult {
                    call_id, success, ..
                } => Some((call_id.as_str(), *success)),
                _ => None,
            })
            .collect();
        assert_eq!(terminals, vec![("call-post-block", false)]);
        assert!(run.events.iter().any(|event| matches!(
            event,
            crate::trace::RunEvent::ToolResult { output_preview: Some(preview), .. }
            if preview == "real effect"
        )));
        assert!(run.events.iter().any(|event| matches!(event,
            crate::trace::RunEvent::ToolError { failure, .. } if failure == &result.failure
        )));
        let audit_events = audit.snapshot();
        let audit_terminals: Vec<_> = audit_events
            .iter()
            .filter_map(|event| match &event.event_type {
                crate::audit::AuditEventType::ToolCall {
                    success, output, ..
                } => Some((*success, output.as_str())),
                _ => None,
            })
            .collect();
        assert_eq!(audit_terminals, vec![(false, "real effect")]);
        Ok(())
    }

    #[tokio::test]
    async fn post_hook_block_reason_uses_guarded_terminal_diagnostic() -> Result<()> {
        use crate::skills::hooks::{HookAction, HookEvent, HookRule, HooksDefinition};
        use crate::trace::{InMemoryRunStore, RunEvent, RunStore};

        let callback = Arc::new(RecordingCallback::default());
        let store = Arc::new(InMemoryRunStore::new());
        let agent = crate::agent::ReactAgentBuilder::new()
            .model("test-model")
            .callback(callback.clone())
            .with_run_store(store.clone())
            .guard(Arc::new(BlockOutputGuard))
            .tool(Box::new(TypedEffectTool))
            .build()?;
        let (command, shell) = if cfg!(target_os = "windows") {
            (
                "$context=[Console]::In.ReadToEnd(); [Console]::Error.WriteLine($context); exit 2",
                Some("powershell".to_string()),
            )
        } else {
            (
                "read -r hook_context; printf '%s\\n' \"$hook_context\" >&2; exit 2",
                None,
            )
        };
        let mut hooks = HooksDefinition::default();
        hooks.add_rules(
            HookEvent::PostToolUse,
            vec![HookRule {
                matcher: "shell".to_string(),
                hooks: vec![HookAction::Command {
                    command: command.to_string(),
                    shell,
                    timeout: 10,
                }],
            }],
        );
        agent
            .hook_registry()
            .write()
            .await
            .register_user_hooks(hooks);
        let legacy = agent.capture_legacy_external_context();
        let run_id = agent
            .start_legacy_trace_run("guarded post-hook block", &legacy)
            .await
            .ok_or_else(|| ReactError::Other("trace did not start".to_string()))?;
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let failure = snapshot
            .execute_tool_with_policy(
                "post-hook-guard".to_string(),
                "shell",
                &ToolParameters::new(),
                &serde_json::json!({}),
                None,
            )
            .await
            .err()
            .ok_or_else(|| ReactError::Other("post-hook block was not enforced".to_string()))?;
        let diagnostic = failure
            .result
            .error
            .as_deref()
            .ok_or_else(|| ReactError::Other("guarded terminal reason missing".to_string()))?;
        assert!(!diagnostic.contains("opaque output"));
        assert!(!failure.error.to_string().contains("opaque output"));
        assert!(failure.error.to_string().contains(diagnostic));
        assert!(failure.result.failure.as_ref().is_some_and(|value| {
            value.category == crate::tools::ToolFailureCategory::PartialSideEffect
        }));
        assert!(failure.result.effects.iter().any(|effect| matches!(
            effect,
            echo_core::tools::ToolEffect::FileEdit { path } if path == "src/lib.rs"
        )));
        let run = store
            .load(&run_id)
            .await?
            .ok_or_else(|| ReactError::Other("trace run disappeared".to_string()))?;
        assert!(run.events.iter().any(|event| matches!(
            event,
            RunEvent::ToolError { message, .. } if message == diagnostic
        )));
        assert!(run.events.iter().any(|event| matches!(
            event,
            RunEvent::FileEdit { path, .. } if path == "src/lib.rs"
        )));
        let callback_errors = callback
            .tool_error_messages
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        assert_eq!(callback_errors.len(), 1);
        assert!(
            callback_errors
                .iter()
                .all(|error| !error.contains("opaque output"))
        );
        Ok(())
    }
}
