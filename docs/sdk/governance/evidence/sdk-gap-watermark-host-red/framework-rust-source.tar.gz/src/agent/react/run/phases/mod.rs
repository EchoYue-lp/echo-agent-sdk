//! Phase functions for `AgentRunSnapshot::run_core_loop`.
//!
//! `run_core_loop` is the **single, unified core loop** — both the streaming
//! and non-streaming entry points spawn the same loop body. To keep that body
//! reviewable, the per-iteration work is split into focused phase functions:
//!
//! ```text
//! prepare_turn  →  ┌─ run_compact ─→ run_think ─→ ┬─ run_tools (verifier-pass → finalize_completed_run)
//!                  │                              ├─ verify_final_text (verifier-pass → emit_final_text)
//!                  │                              └─ NoResponse → finalize_no_response
//!                  └─ (loop continues …)         max_iterations exhausted → finalize_max_iterations
//! ```
//!
//! Phase fns are `pub(crate) async fn` and all return `Result<…>`. The
//! `yield_event!` / `yield_final_event!` / `try_send!` macros from
//! `super::super::stream_macros` short-circuit the **enclosing function** with
//! `return Ok(())` when the receiver is closed, so phases must return
//! `Result<…>` for that "abandon stream" behavior to bubble up to the loop
//! driver — which then exits with `Ok(())`.

use crate::agent::AgentEvent;
use crate::agent::snapshot::AgentRunSnapshot;
use crate::error::ReactError;
use crate::llm::types::{Message, ResponseFormat};
use std::collections::HashMap;

pub(crate) mod compact;
pub(crate) mod finalize;
pub(crate) mod prepare;
pub(crate) mod think;
pub(crate) mod tools;
pub(crate) mod verify;

pub(crate) fn cancellation_requested(snap: &AgentRunSnapshot) -> bool {
    snap.cancel_token
        .as_ref()
        .is_some_and(tokio_util::sync::CancellationToken::is_cancelled)
        || snap
            .external_cancel
            .as_ref()
            .is_some_and(|cancel| cancel.is_cancelled())
}

pub(crate) async fn wait_for_cancellation(snap: &AgentRunSnapshot) {
    let invocation = async {
        match snap.cancel_token.as_ref() {
            Some(cancel) => cancel.cancelled().await,
            None => std::future::pending::<()>().await,
        }
    };
    let external = async {
        match snap.external_cancel.as_ref() {
            Some(cancel) => cancel.cancelled().await,
            None => std::future::pending::<()>().await,
        }
    };
    tokio::select! {
        _ = invocation => {}
        _ = external => {}
    }
}

pub(crate) fn pre_model_block_terminal(
    format: Option<&ResponseFormat>,
    source: &str,
    reason: String,
) -> AgentEvent {
    if format.is_some_and(ResponseFormat::is_json) {
        AgentEvent::from_error(source, &ReactError::Other(reason))
    } else {
        AgentEvent::FinalAnswer(reason)
    }
}

// ── Loop-level mutable state ─────────────────────────────────────────

/// Mutable per-turn state shared between phase invocations.
///
/// `agent` and `callbacks` are read directly from `snap.config` instead of
/// being mirrored here — they're cheap to clone and never mutated.
pub(crate) struct LoopState {
    /// Whether the `Stop` lifecycle hook has already been allowed to inject a
    /// continue_reason this turn. The hook is one-shot to avoid loops.
    pub stop_hook_continued: bool,
    /// Number of times the verifier has rejected an answer this turn.
    pub verifier_retry_count: usize,
    /// JSON/schema repair attempts are independent of the optional critic.
    pub schema_retry_count: usize,
    /// Invocation-local budget counters. They remain in the loop state while
    /// HITL approval awaits and therefore are preserved across pause/resume.
    pub budget: RunBudgetState,
}

#[derive(Default)]
pub(crate) struct RunBudgetState {
    pub reported_model_tokens: usize,
    pub usage_complete: bool,
    pub wind_down_emitted: bool,
    pub final_only_emitted: bool,
    pub final_only: bool,
}

impl RunBudgetState {
    pub(crate) fn record_usage(&mut self, tokens: usize, reported: bool) {
        self.reported_model_tokens = self.reported_model_tokens.saturating_add(tokens);
        self.usage_complete = self.usage_complete && reported;
    }
}

impl LoopState {
    pub(crate) fn new() -> Self {
        Self {
            stop_hook_continued: false,
            verifier_retry_count: 0,
            schema_retry_count: 0,
            budget: RunBudgetState {
                usage_complete: true,
                ..RunBudgetState::default()
            },
        }
    }
}

// ── Outcome enums ────────────────────────────────────────────────────

/// What `prepare_turn` decided.
pub(crate) enum PrepareOutcome {
    /// Proceed into the iteration loop.
    Continue,
    /// `UserPromptSubmit` hook returned `block: true`. A `FinalAnswer` event
    /// has already been yielded and `SessionEnd("blocked")` has been fired.
    BlockedAndDone,
    /// Channel was closed mid-prepare; loop driver returns `Ok(())`.
    Abandoned,
}

/// What `run_compact` produced for this iteration.
#[derive(Debug)]
pub(crate) enum CompactOutcome {
    /// Prepared LLM messages ready for the think phase.
    Continue(Vec<Message>),
    /// Channel closed; loop driver returns `Ok(())`.
    Abandoned,
    /// Context preparation failed after emitting an error terminal.
    Failed,
}

/// What `run_think` produced for this iteration.
pub(crate) enum ThinkOutcome {
    /// Stream consumed; tool calls / content / token usage extracted.
    Continue(ThinkOutput),
    /// Channel closed mid-think.
    Abandoned,
    /// This phase already settled persistence, trace, and one terminal event.
    TerminalSettled {
        outcome: crate::agent::AgentSteerTurnOutcome,
    },
}

/// Output of the think phase, fed into the tools or verify branches.
pub(crate) struct ThinkOutput {
    /// Plain assistant text accumulated from streaming chunks.
    pub content_buffer: String,
    /// DeepSeek/Qwen reasoning accumulated for assistant-message replay.
    pub reasoning_buffer: String,
    /// Signed/redacted reasoning blocks required for provider-valid replay.
    pub reasoning_blocks: Vec<crate::llm::types::ReasoningBlock>,
    /// Tool calls accumulated by index → (tool_call_id, function_name, args).
    pub tool_call_map: HashMap<u32, (String, String, String)>,
    /// Prompt tokens reported by the LLM.
    pub pt: usize,
    /// Completion tokens reported by the LLM.
    pub ct: usize,
    /// Whether the provider supplied usage metadata for this response.
    pub usage_reported: bool,
}

/// What a single iteration body decided.
pub(crate) enum IterOutcome {
    /// Verifier-fail or hook-continue: go to the next iteration.
    Continue,
    /// Tools branch: every tool result was durably settled. The driver owns
    /// steer/cancellation fences before selecting a final-answer candidate.
    FinishCandidates { outputs: Vec<String> },
    /// Text-only branch: the LLM produced a content answer that passed
    /// verification. The driver invokes `phases::finalize::emit_final_text`.
    FinalText {
        answer: String,
        reasoning_content: String,
        reasoning_blocks: Vec<crate::llm::types::ReasoningBlock>,
    },
    /// LLM produced neither tool calls nor content. Terminal failure.
    NoResponse,
    /// Channel closed mid-iteration (a yield/try_send macro fired
    /// `return Ok(())`). The driver returns `Ok(())` immediately.
    Abandoned,
    /// A phase already settled persistence, trace, and exactly one terminal.
    TerminalSettled {
        outcome: crate::agent::AgentSteerTurnOutcome,
    },
}

pub(crate) fn with_reasoning_content(
    mut message: Message,
    reasoning_content: String,
    reasoning_blocks: Vec<crate::llm::types::ReasoningBlock>,
) -> Message {
    if !reasoning_content.is_empty() {
        message.reasoning_content = Some(reasoning_content);
    }
    if !reasoning_blocks.is_empty() {
        message.reasoning_blocks = Some(reasoning_blocks);
    }
    message
}

#[cfg(test)]
mod budget_tests {
    use super::LoopState;

    #[tokio::test]
    async fn budget_counters_survive_async_pause_resume_boundary() {
        let mut state = LoopState::new();
        state.budget.record_usage(12, true);

        // HITL approval pauses inside the same run future. Crossing an await
        // boundary must not reset invocation-local counters.
        tokio::task::yield_now().await;
        state.budget.record_usage(8, false);

        assert_eq!(state.budget.reported_model_tokens, 20);
        assert!(!state.budget.usage_complete);
    }
}
