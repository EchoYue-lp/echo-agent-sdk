//! Echo Tools — Domain tools for the echo-agent framework
//!
//! Feature-gated tool modules that can be registered via
//! [`register_all_tools`] into any [`ToolRegistrar`](echo_core::tools::ToolRegistrar).
//!
//! # Features
//!
//! | Feature   | Tools                                     |
//! |-----------|-------------------------------------------|
//! | `artifact`| Verified, paged reads of spilled tool output |
//! | `files`   | Artifact reader and filesystem tools      |
//! | `web`     | `web` (WebFetchTool, WebSearchTool, WebExtractTool, providers) |
//! | `chart`   | `chart` (GenerateChartTool)               |
//! | `data`    | `data` (11 data-analysis tools), `data_quality` (3 data-quality tools) |
//! | `statistics`| `statistics` (`exploratory_statistics`; formal inference uses sandboxed `run_code`) |
//! | `database`| `database` (SqlQueryTool, …)              |
//! | `media`   | `excel`, `image`, `pdf`, `word`, `text`, `media` |
//! | `git`     | `git` (6 git CLI tools)                   |
//! | `rag`     | `rag` (RagIndexTool, RagSearchTool, …)    |
//! | `full`    | All of the above                          |

/// Sandboxed inline or persisted-script execution (`run_code`). Gated under
/// `shell` because it is the same execute/risk class (spawns an interpreter).
#[cfg(feature = "shell")]
#[cfg_attr(docsrs, doc(cfg(feature = "shell")))]
pub mod code;
#[cfg(any(feature = "artifact", feature = "files"))]
#[cfg_attr(docsrs, doc(cfg(any(feature = "artifact", feature = "files"))))]
pub mod files;
pub mod git_checkpoint;
#[cfg(any(feature = "web", feature = "media", feature = "research"))]
mod http_body;
#[cfg(feature = "git")]
mod process;
pub mod security;
#[cfg(feature = "shell")]
#[cfg_attr(docsrs, doc(cfg(feature = "shell")))]
pub mod shell;
#[cfg(any(feature = "files", feature = "shell"))]
pub mod skills;

#[cfg(feature = "chart")]
#[cfg_attr(docsrs, doc(cfg(feature = "chart")))]
pub mod chart;
#[cfg(feature = "data")]
#[cfg_attr(docsrs, doc(cfg(feature = "data")))]
pub mod data;
#[cfg(feature = "data")]
#[cfg_attr(docsrs, doc(cfg(feature = "data")))]
pub mod data_quality;
#[cfg(feature = "database")]
#[cfg_attr(docsrs, doc(cfg(feature = "database")))]
pub mod database;
#[cfg(any(feature = "files", feature = "git"))]
mod diff_pagination;
#[cfg(feature = "media")]
#[cfg_attr(docsrs, doc(cfg(feature = "media")))]
pub mod excel;
#[cfg(feature = "git")]
#[cfg_attr(docsrs, doc(cfg(feature = "git")))]
pub mod git;
#[cfg(feature = "git")]
#[cfg_attr(docsrs, doc(cfg(feature = "git")))]
pub mod git_worktree;
#[cfg(feature = "media")]
#[cfg_attr(docsrs, doc(cfg(feature = "media")))]
pub mod image;
#[cfg(feature = "media")]
#[cfg_attr(docsrs, doc(cfg(feature = "media")))]
pub mod media;
#[cfg(feature = "media")]
#[cfg_attr(docsrs, doc(cfg(feature = "media")))]
pub mod pdf;
#[cfg(feature = "rag")]
#[cfg_attr(docsrs, doc(cfg(feature = "rag")))]
pub mod rag;
#[cfg(feature = "research")]
#[cfg_attr(docsrs, doc(cfg(feature = "research")))]
pub mod research;
#[cfg(feature = "statistics")]
#[cfg_attr(docsrs, doc(cfg(feature = "statistics")))]
pub mod statistics;
#[cfg(feature = "media")]
#[cfg_attr(docsrs, doc(cfg(feature = "media")))]
pub mod text;
#[cfg(feature = "web")]
#[cfg_attr(docsrs, doc(cfg(feature = "web")))]
pub mod web;
#[cfg(feature = "media")]
#[cfg_attr(docsrs, doc(cfg(feature = "media")))]
pub mod word;
#[cfg(feature = "git")]
#[cfg_attr(docsrs, doc(cfg(feature = "git")))]
pub mod worktree_tool;

mod registry;
pub use registry::{
    StandardToolPack, register_all_tools, register_all_tools_with_cells, register_readonly_tools,
};
