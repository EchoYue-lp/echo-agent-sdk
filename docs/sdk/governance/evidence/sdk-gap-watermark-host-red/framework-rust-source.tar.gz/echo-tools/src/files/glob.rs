//! Glob tool — find files by name pattern
//!
//! Walks a directory tree and returns file paths matching a glob pattern.

use echo_core::error::{Result, ToolError};
use echo_core::tools::pagination::PageRequest;
use echo_core::tools::{Tool, ToolParameters, ToolResult};
use futures::future::BoxFuture;
use serde_json::{Value, json};
use std::path::PathBuf;
use tokio::fs;

// ── GlobTool ────────────────────────────────────────────────────────────────

/// Find files by name pattern.
///
/// Walks the directory tree from `path` (default: `.`) and returns
/// file paths matching the `pattern` glob (e.g. `**/*.rs`, `src/**/*.ts`).
pub struct GlobTool {
    base_dir: Option<PathBuf>,
}

impl GlobTool {
    pub fn new() -> Self {
        Self { base_dir: None }
    }

    pub fn with_base_dir(base: impl Into<PathBuf>) -> Self {
        Self {
            base_dir: Some(base.into()),
        }
    }
}

impl Default for GlobTool {
    fn default() -> Self {
        Self::new()
    }
}

impl Tool for GlobTool {
    fn name(&self) -> &str {
        "glob"
    }

    fn description(&self) -> &str {
        "Find files by name pattern. Returns file paths matching a glob pattern (e.g. '**/*.rs', 'src/**/*.ts', '*.md'). Supports ** for recursive directory matching."
    }

    fn permissions(&self) -> Vec<echo_core::tools::permission::ToolPermission> {
        vec![echo_core::tools::permission::ToolPermission::Read]
    }
    fn risk_level(&self) -> echo_core::tools::ToolRiskLevel {
        echo_core::tools::ToolRiskLevel::ReadOnly
    }

    fn parameters(&self) -> Value {
        json!({
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Glob pattern to match file names (e.g. '**/*.rs', 'src/**/*.ts', '*.md')"
                },
                "path": {
                    "type": "string",
                    "description": "Directory to search in (default: current directory)"
                },
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 200,
                    "description": "Results per page (default 100)"
                },
                "cursor": {
                    "type": "string",
                    "description": "Cursor from the previous page"
                }
            },
            "required": ["pattern"]
        })
    }

    fn execute_with_context<'a>(
        &'a self,
        parameters: ToolParameters,
        ctx: &'a echo_core::tools::ToolContext,
    ) -> BoxFuture<'a, Result<ToolResult>> {
        Box::pin(async move {
            let pattern_str = parameters
                .get("pattern")
                .and_then(|v| v.as_str())
                .ok_or_else(|| ToolError::MissingParameter("pattern".to_string()))?;

            let path_str = parameters
                .get("path")
                .and_then(|v| v.as_str())
                .unwrap_or(".");

            let page_request = match PageRequest::from_parameters(&parameters, 100, 200) {
                Ok(request) => request,
                Err(error) => return Ok(ToolResult::invalid_arguments(error.to_string())),
            };

            // Effective base: construction-time base_dir (with confinement)
            // takes priority; otherwise fall back to runtime working_dir
            // (CWD override, no confinement check).
            let effective_base: Option<PathBuf> = self
                .base_dir
                .clone()
                .or_else(|| ctx.working_dir.as_ref().map(|p| p.to_path_buf()));

            let search_path = if let Some(ref base) = effective_base {
                let resolved = if std::path::Path::new(path_str).is_absolute() {
                    PathBuf::from(path_str)
                } else {
                    base.join(path_str)
                };
                if !resolved.starts_with(base) {
                    return Ok(ToolResult::invalid_arguments(format!(
                        "Path '{}' is outside the allowed directory scope",
                        path_str
                    )));
                }
                resolved
            } else {
                PathBuf::from(path_str)
            };

            if !search_path.exists() {
                return Ok(ToolResult::invalid_arguments(format!(
                    "Path does not exist: {}",
                    search_path.display()
                )));
            }

            if !search_path.is_dir() {
                return Ok(ToolResult::invalid_arguments(format!(
                    "Path is not a directory: {}",
                    search_path.display()
                )));
            }

            let mut results = Vec::new();
            walk_glob(&search_path, pattern_str, &mut results).await;
            let query = serde_json::json!({
                "pattern": pattern_str,
                "path": search_path,
            });
            let (page, page_info) = match page_request.paginate(results, &query) {
                Ok(page) => page,
                Err(error) => return Ok(ToolResult::invalid_arguments(error.to_string())),
            };
            let output = if page.is_empty() {
                format!("No files matching '{pattern_str}' found.")
            } else {
                format!(
                    "{}\n\n{} files returned ({} total)",
                    page.join("\n"),
                    page_info.returned,
                    page_info.total.unwrap_or(0)
                )
            };
            let mut result = ToolResult::success(output);
            page_info.apply_to(&mut result);
            Ok(result)
        })
    }
}

async fn walk_glob(dir: &std::path::Path, pattern: &str, results: &mut Vec<String>) {
    let mut entries = match fs::read_dir(dir).await {
        Ok(e) => e,
        Err(_) => return,
    };

    let mut entry_paths: Vec<PathBuf> = Vec::new();
    while let Ok(Some(entry)) = entries.next_entry().await {
        entry_paths.push(entry.path());
    }
    entry_paths.sort();

    for path in entry_paths {
        // Skip hidden and common ignored directories
        if path.is_dir()
            && let Some(name) = path.file_name().and_then(|n| n.to_str())
            && (name.starts_with('.')
                || name == "target"
                || name == "node_modules"
                || name == "__pycache__"
                || name == ".git"
                || name == "vendor"
                || name == "build"
                || name == "dist")
        {
            continue;
        }

        if path.is_dir() {
            Box::pin(walk_glob(&path, pattern, results)).await;
        } else if path.is_file()
            && let Some(name) = path.file_name().and_then(|n| n.to_str())
            && glob_pattern_matches(pattern, name, &path)
        {
            results.push(path.display().to_string());
        }
    }
}

/// Match a glob pattern against a file name.
///
/// Supports:
/// - `*` matches any sequence of characters (except /)
/// - `**` matches any path prefix (handled by walking)
/// - `?` matches any single character
/// - `{a,b}` matches a or b
/// - `[abc]` matches any character in the set
fn glob_pattern_matches(pattern: &str, name: &str, full_path: &std::path::Path) -> bool {
    // Handle ** patterns (recursive) — they match at any directory level
    if pattern.contains("**") {
        return glob_with_doublestar(pattern, full_path);
    }

    // For simple patterns, just match the file name
    let name_pattern = if pattern.contains('/') {
        // If pattern contains /, match against relative path components
        pattern.to_string()
    } else {
        pattern.to_string()
    };

    if pattern.contains('/') {
        // Match against path suffix
        glob_match_advanced(&name_pattern, &full_path.display().to_string())
    } else {
        glob_match_advanced(&name_pattern, name)
    }
}

fn glob_with_doublestar(pattern: &str, full_path: &std::path::Path) -> bool {
    let path_str = full_path.display().to_string();

    // Split pattern on ** and try matching at each directory level
    let parts: Vec<&str> = pattern.split("**").collect();

    if parts.len() == 2 {
        let Some(prefix) = parts.first().copied() else {
            return false;
        };
        let Some(suffix) = parts.get(1).copied() else {
            return false;
        };

        // Try matching at each level
        if prefix.is_empty() && suffix.is_empty() {
            return true;
        }

        if prefix.is_empty() {
            // **/*.rs — match any path ending with suffix
            return path_str.ends_with(suffix.trim_start_matches('/'))
                || path_str.ends_with(suffix.trim_start_matches('/').trim_start_matches('\\'));
        }

        if suffix.is_empty() {
            return path_str.contains(prefix.trim_end_matches('/'));
        }

        // src/**/*.rs — match paths starting with prefix and ending with suffix
        let suffix_clean = suffix.trim_start_matches('/');
        let prefix_clean = prefix.trim_end_matches('/');
        if let Some(pos) = path_str.find(prefix_clean)
            && let Some(rest) = path_str
                .get(pos..)
                .and_then(|tail| tail.strip_prefix(prefix_clean))
        {
            return rest.ends_with(suffix_clean);
        }
        return false;
    }

    // Fallback: simple match
    glob_match_advanced(pattern, &path_str)
}

/// Advanced glob matching with * ? {a,b} [abc]
fn glob_match_advanced(pattern: &str, text: &str) -> bool {
    let mut pi = 0;
    let mut ti = 0;
    let p_chars: Vec<char> = pattern.chars().collect();
    let t_chars: Vec<char> = text.chars().collect();

    while let (Some(pattern_character), Some(text_character)) =
        (p_chars.get(pi).copied(), t_chars.get(ti).copied())
    {
        match pattern_character {
            '*' => {
                // Match any sequence
                pi = pi.saturating_add(1);
                if pi == p_chars.len() {
                    return true;
                }
                for skip in ti..=t_chars.len() {
                    // UTF-8-safe slicing: pi/skip are char indices (from
                    // p_chars/t_chars), NOT byte indices. Using &pattern[pi..]
                    // would panic on multibyte chars (e.g. paths like
                    // screenshot_北京.png). Reconstruct via char iterators.
                    let pat_rest: String = p_chars.get(pi..).unwrap_or_default().iter().collect();
                    let txt_rest: String = t_chars.get(skip..).unwrap_or_default().iter().collect();
                    if glob_match_advanced(&pat_rest, &txt_rest) {
                        return true;
                    }
                }
                return false;
            }
            '?' => {
                pi = pi.saturating_add(1);
                ti = ti.saturating_add(1);
            }
            '[' => {
                // Character class
                pi = pi.saturating_add(1);
                let mut found = false;
                let negated = p_chars.get(pi).is_some_and(|character| *character == '!');
                if negated {
                    pi = pi.saturating_add(1);
                }
                while p_chars.get(pi).is_some_and(|character| *character != ']') {
                    if p_chars.get(pi) == t_chars.get(ti) {
                        found = true;
                    }
                    pi = pi.saturating_add(1);
                }
                if pi < p_chars.len() {
                    pi = pi.saturating_add(1); // skip ]
                }
                if negated {
                    found = !found;
                }
                if !found {
                    return false;
                }
                ti = ti.saturating_add(1);
            }
            '{' => {
                // Brace expansion
                let close = p_chars
                    .get(pi..)
                    .and_then(|remainder| remainder.iter().position(|character| *character == '}'));
                if let Some(close_offset) = close {
                    let close_index = pi.saturating_add(close_offset);
                    let brace_content: String = p_chars
                        .get(pi.saturating_add(1)..close_index)
                        .unwrap_or_default()
                        .iter()
                        .collect();
                    let alternatives: Vec<&str> = brace_content.split(',').collect();
                    let after_brace: String = p_chars
                        .get(close_index.saturating_add(1)..)
                        .unwrap_or_default()
                        .iter()
                        .collect();
                    let before_brace: String =
                        p_chars.get(..pi).unwrap_or_default().iter().collect();
                    for alt in alternatives {
                        let full = format!("{}{}{}", before_brace, alt.trim(), after_brace);
                        if glob_match_advanced(&full, text) {
                            return true;
                        }
                    }
                    return false;
                }
                // No closing brace, treat as literal
                if pattern_character == text_character {
                    pi = pi.saturating_add(1);
                    ti = ti.saturating_add(1);
                } else {
                    return false;
                }
            }
            c => {
                if c == text_character {
                    pi = pi.saturating_add(1);
                    ti = ti.saturating_add(1);
                } else {
                    return false;
                }
            }
        }
    }

    // Consume trailing * in pattern
    while p_chars.get(pi).is_some_and(|character| *character == '*') {
        pi = pi.saturating_add(1);
    }

    pi == p_chars.len() && ti == t_chars.len()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_glob_match_star() {
        assert!(glob_match_advanced("*.rs", "main.rs"));
        assert!(glob_match_advanced("*.rs", "lib.rs"));
        assert!(!glob_match_advanced("*.rs", "main.py"));
    }

    #[test]
    fn test_glob_match_brace() {
        assert!(glob_match_advanced("*.{rs,ts}", "main.rs"));
        assert!(glob_match_advanced("*.{rs,ts}", "app.ts"));
        assert!(!glob_match_advanced("*.{rs,ts}", "main.py"));
    }

    #[test]
    fn test_glob_match_question() {
        assert!(glob_match_advanced("?.rs", "a.rs"));
        assert!(!glob_match_advanced("?.rs", "ab.rs"));
    }

    #[test]
    fn test_glob_match_bracket() {
        assert!(glob_match_advanced("[abc].rs", "a.rs"));
        assert!(!glob_match_advanced("[abc].rs", "d.rs"));
    }

    #[test]
    fn test_glob_match_exact() {
        assert!(glob_match_advanced("main.rs", "main.rs"));
        assert!(!glob_match_advanced("main.rs", "lib.rs"));
    }

    #[test]
    fn test_glob_match_multibyte_path() {
        // Regression: paths with multibyte UTF-8 chars (e.g. Chinese) must not
        // panic. Previously `&pattern[pi..]` / `&text[skip..]` used byte slicing
        // on char-index values, panicking on paths like screenshot_北京.png.
        assert!(glob_match_advanced("*.png", "screenshot_北京.png"));
        assert!(glob_match_advanced("screenshot_*", "screenshot_北京.png"));
        assert!(glob_match_advanced(
            "*/北京*",
            "/Users/ls/照片/北京/景山.png"
        ));
        assert!(!glob_match_advanced("*.rs", "screenshot_北京.png"));
        // Sanity: plain ASCII still works after the fix.
        assert!(glob_match_advanced("*.png", "screenshot_shanghai.png"));
    }
}
