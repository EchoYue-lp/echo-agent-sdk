//! Web search tool
//!
//! Provides [`WebSearchTool`] with support for multiple search engines via [`SearchProvider`].
//! Defaults to [`DuckDuckGoProvider`] (free, no API key required).
//!
//! # Usage
//!
//! ```text

use super::providers::SearchProvider;
use super::providers::brave::BraveSearchProvider;
use super::providers::duckduckgo::DuckDuckGoProvider;
use super::providers::tavily::TavilyProvider;
use echo_core::error::{Result, ToolError};
use echo_core::tools::pagination::PageRequest;
use echo_core::tools::permission::ToolPermission;
use echo_core::tools::{Tool, ToolFailure, ToolFailureCategory, ToolParameters, ToolResult};
use futures::future::BoxFuture;
use serde_json::Value;

const DEFAULT_MAX_RESULTS: usize = 5;
const MAX_ALLOWED_RESULTS: usize = 10;

/// Web search tool
///
/// Supports web search through different search engine Providers.
/// Built-in DuckDuckGo as the free fallback option.
pub struct WebSearchTool {
    provider: Box<dyn SearchProvider>,
    default_max_results: usize,
}

impl WebSearchTool {
    /// Create with a custom Provider
    pub fn new(provider: Box<dyn SearchProvider>) -> Self {
        Self {
            provider,
            default_max_results: DEFAULT_MAX_RESULTS,
        }
    }

    /// Create with DuckDuckGo (free fallback)
    pub fn with_duckduckgo() -> Self {
        Self::new(Box::new(DuckDuckGoProvider::new()))
    }

    /// Create with Brave Search (requires API key)
    pub fn with_brave(api_key: impl Into<String>) -> Self {
        Self::new(Box::new(BraveSearchProvider::new(api_key)))
    }

    /// Create with Tavily (requires API key, AI-optimized search)
    pub fn with_tavily(api_key: impl Into<String>) -> Self {
        Self::new(Box::new(TavilyProvider::new(api_key)))
    }

    /// Auto-select the best available Provider
    ///
    /// Priority: Tavily > Brave > DuckDuckGo
    ///
    /// Reads API keys from environment variables:
    /// - `TAVILY_API_KEY` → Tavily (AI-optimized, highest quality)
    /// - `BRAVE_SEARCH_API_KEY` → Brave Search (high quality)
    /// - No key → DuckDuckGo (free fallback)
    pub fn auto() -> Self {
        if let Some(provider) = TavilyProvider::from_env() {
            tracing::info!("WebSearch: auto-selected Tavily Provider");
            return Self::new(Box::new(provider));
        }
        if let Some(provider) = BraveSearchProvider::from_env() {
            tracing::info!("WebSearch: auto-selected Brave Provider");
            return Self::new(Box::new(provider));
        }
        tracing::info!("WebSearch: no API key, falling back to DuckDuckGo Provider");
        Self::with_duckduckgo()
    }

    /// Set the default maximum number of results
    pub fn with_max_results(mut self, n: usize) -> Self {
        self.default_max_results = n.clamp(1, MAX_ALLOWED_RESULTS);
        self
    }

    /// Get the current Provider name
    pub fn provider_name(&self) -> &str {
        self.provider.name()
    }
}

impl Tool for WebSearchTool {
    fn name(&self) -> &str {
        "web_search"
    }

    fn permissions(&self) -> Vec<ToolPermission> {
        vec![ToolPermission::Network]
    }

    fn description(&self) -> &str {
        "Search for information on the internet. Returns search result titles, links, and snippets. \
         Results use cursor pagination; repeat the same query and limit with page.next_cursor."
    }

    fn parameters(&self) -> Value {
        serde_json::json!({
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search keywords"
                },
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": MAX_ALLOWED_RESULTS,
                    "description": format!("Results per page (default {}, max {})", DEFAULT_MAX_RESULTS, MAX_ALLOWED_RESULTS)
                },
                "cursor": {
                    "type": "string",
                    "description": "Cursor from the previous page"
                }
            },
            "required": ["query"]
        })
    }

    fn execute(&self, parameters: ToolParameters) -> BoxFuture<'_, Result<ToolResult>> {
        Box::pin(async move {
            let query = parameters
                .get("query")
                .and_then(|v| v.as_str())
                .ok_or_else(|| ToolError::MissingParameter("query".to_string()))?;

            if query.trim().is_empty() {
                return Ok(ToolResult::failure(
                    ToolFailureCategory::InvalidArguments,
                    "Search query cannot be empty",
                ));
            }

            let page_request = match PageRequest::from_parameters(
                &parameters,
                self.default_max_results,
                MAX_ALLOWED_RESULTS,
            ) {
                Ok(request) => request,
                Err(error) => return Ok(ToolResult::invalid_arguments(error.to_string())),
            };

            tracing::info!(
                "WebSearch: query='{}', page_limit={}, provider={}",
                query,
                page_request.limit,
                self.provider.name()
            );
            match self.provider.search(query, MAX_ALLOWED_RESULTS).await {
                Ok(results) => {
                    let query_identity = serde_json::json!({
                        "query": query,
                        "provider": self.provider.name(),
                    });
                    let (page, page_info) = match page_request.paginate(results, &query_identity) {
                        Ok(page) => page,
                        Err(error) => {
                            return Ok(ToolResult::invalid_arguments(error.to_string()));
                        }
                    };
                    let data =
                        serde_json::to_value(page).map_err(|error| ToolError::ExecutionFailed {
                            tool: "web_search".to_string(),
                            message: format!("Failed to serialize search results: {error}"),
                        })?;
                    let mut result = ToolResult::success_json(data);
                    page_info.apply_to(&mut result);
                    Ok(result)
                }
                Err(error) => Ok(ToolResult::error(format!(
                    "Search provider '{}' failed: {error}",
                    self.provider.name()
                ))
                .with_failure(
                    ToolFailure::new(ToolFailureCategory::Transient)
                        .retryable()
                        .with_retry_after(1_000),
                )),
            }
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::web::providers::SearchResult;
    use std::sync::Arc;
    use std::sync::atomic::{AtomicU32, Ordering};

    #[test]
    fn test_empty_results_json() {
        let results: Vec<SearchResult> = vec![];
        let json = serde_json::to_value(&results).unwrap();
        assert!(json.as_array().unwrap().is_empty());
    }

    #[test]
    fn test_results_json_structure() {
        let results = vec![
            SearchResult {
                title: "Rust".into(),
                url: "https://rust-lang.org".into(),
                snippet: "A programming language".into(),
            },
            SearchResult {
                title: "Cargo".into(),
                url: "https://doc.rust-lang.org/cargo".into(),
                snippet: String::new(),
            },
        ];

        let json = serde_json::to_value(&results).unwrap();
        let arr = json.as_array().unwrap();
        assert_eq!(arr.len(), 2);
        assert_eq!(arr[0]["title"], "Rust");
        assert_eq!(arr[0]["url"], "https://rust-lang.org");
        assert_eq!(arr[0]["snippet"], "A programming language");
        assert_eq!(arr[1]["title"], "Cargo");
        assert_eq!(arr[1]["snippet"], "");
    }

    /// Mock provider that fails N times then succeeds
    struct FailNTimesProvider {
        fail_count: u32,
        call_count: Arc<AtomicU32>,
    }

    impl FailNTimesProvider {
        fn new(fail_count: u32) -> (Self, Arc<AtomicU32>) {
            let counter = Arc::new(AtomicU32::new(0));
            (
                Self {
                    fail_count,
                    call_count: counter.clone(),
                },
                counter,
            )
        }
    }

    #[async_trait::async_trait]
    impl SearchProvider for FailNTimesProvider {
        fn name(&self) -> &str {
            "mock-fail-n"
        }

        async fn search(&self, _query: &str, _max_results: usize) -> Result<Vec<SearchResult>> {
            let call = self.call_count.fetch_add(1, Ordering::SeqCst);
            if call < self.fail_count {
                Err(echo_core::error::ToolError::ExecutionFailed {
                    tool: "mock".to_string(),
                    message: format!("Simulated failure #{}", call + 1),
                }
                .into())
            } else {
                Ok(vec![SearchResult {
                    title: "Success".into(),
                    url: "https://example.com".into(),
                    snippet: format!("Succeeded on attempt {}", call + 1),
                }])
            }
        }
    }

    /// Provider that always fails
    struct AlwaysFailProvider;

    #[async_trait::async_trait]
    impl SearchProvider for AlwaysFailProvider {
        fn name(&self) -> &str {
            "mock-always-fail"
        }

        async fn search(&self, _query: &str, _max_results: usize) -> Result<Vec<SearchResult>> {
            Err(echo_core::error::ToolError::ExecutionFailed {
                tool: "mock".to_string(),
                message: "Always fails".to_string(),
            }
            .into())
        }
    }

    #[tokio::test]
    async fn transient_failure_is_returned_to_the_central_retry_policy() {
        let (provider, counter) = FailNTimesProvider::new(2);
        let tool = WebSearchTool::new(Box::new(provider));

        let mut params = std::collections::HashMap::new();
        params.insert("query".to_string(), serde_json::json!("test"));

        let result = tool.execute(params).await.unwrap();
        assert!(!result.success);
        assert_eq!(counter.load(Ordering::SeqCst), 1);
        assert!(
            result
                .failure
                .as_ref()
                .is_some_and(ToolFailure::allows_automatic_retry)
        );
    }

    #[tokio::test]
    async fn provider_failure_is_classified_as_transient() {
        let tool = WebSearchTool::new(Box::new(AlwaysFailProvider));

        let mut params = std::collections::HashMap::new();
        params.insert("query".to_string(), serde_json::json!("test"));

        let result = tool.execute(params).await.unwrap();
        assert!(!result.success);
        assert_eq!(
            result.failure.map(|failure| failure.category),
            Some(ToolFailureCategory::Transient)
        );
    }
}
