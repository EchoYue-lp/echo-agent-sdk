use echo_agent::prelude::*;
use echo_agent::tool;

#[tool(name = "add", description = "两数相加")]
async fn add(a: f64, b: f64) -> Result<ToolResult> {
    Ok(ToolResult::success(format!("{} + {} = {}", a, b, a + b)))
}

#[tool(name = "subtract", description = "两数相减")]
async fn subtract(a: f64, b: f64) -> Result<ToolResult> {
    Ok(ToolResult::success(format!("{} - {} = {}", a, b, a - b)))
}

#[tool(name = "multiply", description = "两数相乘")]
async fn multiply(a: f64, b: f64) -> Result<ToolResult> {
    Ok(ToolResult::success(format!("{} * {} = {}", a, b, a * b)))
}

#[tool(name = "divide", description = "两数相除")]
async fn divide(a: f64, b: f64) -> Result<ToolResult> {
    if b == 0.0 {
        return Ok(ToolResult::error("除数不能为 0".to_string()));
    }
    Ok(ToolResult::success(format!("{} / {} = {}", a, b, a / b)))
}

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt()
        .with_max_level(tracing::Level::INFO)
        .init();

    let system_prompt = r#"你是一个具有规划能力的智能助手，本示例用于测试任务规划与任务状态流转。

对于复杂任务，你应该：
1. 使用 task_create 一次性创建完整子任务图：
   - 互相独立的任务不设依赖，让它们并行执行
   - 只有真正需要其他任务结果时才设置 dependencies
   - 尽量构建宽而浅的任务 DAG，而非线性链
3. 执行任务时，在一次回复中尽量并行调用多个工具
4. 完成后用 task_update 原子更新任务状态
5. 所有任务完成后，用 final_answer 给出答案
"#;

    // 使用 AgentBuilder 创建 Agent（启用任务规划）
    let mut agent = ReactAgentBuilder::new()
        .model("qwen3-max")
        .name("planning_agent")
        .system_prompt(system_prompt)
        .enable_tools()
        .max_iterations(30)
        .build()?;

    // 添加领域工具
    agent.add_tool(Box::new(AddTool));
    agent.add_tool(Box::new(MultiplyTool));
    agent.add_tool(Box::new(SubtractTool));
    agent.add_tool(Box::new(DivideTool));

    // 任务规划示例
    let result = agent
        .execute(
            "我有 1200 元。买了 8 个 18 元的本子、12 支 9 元的笔、3 个 120 元的玩具、1 件 400 元外套。\
            先计算原价总和，再对总价打 95 折，最后算剩余金额。",
        )
        .await?;
    if result.trim().is_empty() {
        return Err(echo_agent::error::ReactError::Other(
            "demo02 验收失败：任务规划示例返回空结果".to_string(),
        ));
    }

    println!("\n✅ 最终结果:\n{}", result);
    Ok(())
}
