//! Framework task relation tools backed by [`TaskRevisionService`].

use std::sync::Arc;

use echo_core::error::Result;
use echo_core::tools::pagination::PageRequest;
use echo_core::tools::{Tool, ToolContext, ToolParameters, ToolResult, ToolRiskLevel};
use futures::future::BoxFuture;

use super::{
    Task, TaskCreateInput, TaskDraft, TaskGraphExecutionMode, TaskPlanPatchInputOp,
    TaskRevisionError, TaskRevisionService, TaskSpecPatch, TaskStatus, TaskUpdateInput,
};

pub struct TaskCreateTool {
    service: Arc<TaskRevisionService>,
}

impl TaskCreateTool {
    pub fn new(service: Arc<TaskRevisionService>) -> Self {
        Self { service }
    }
}

impl Tool for TaskCreateTool {
    fn name(&self) -> &str {
        "task_create"
    }

    fn description(&self) -> &str {
        "Atomically create the complete task graph in one call. Always put every task in the tasks array, including a single task; never split one graph across concurrent task_create calls. Dependencies are optional; use base_revision when adding tasks to an existing graph."
    }

    fn parameters(&self) -> serde_json::Value {
        task_create_schema(&self.service)
    }

    fn allows_parallel_batch_execution(&self) -> bool {
        false
    }

    fn execute_with_context<'a>(
        &'a self,
        params: ToolParameters,
        context: &'a ToolContext,
    ) -> BoxFuture<'a, Result<ToolResult>> {
        Box::pin(async move {
            let input = match parse_task_create_input(
                &params,
                &self.service.task_input_schema_extensions(),
            ) {
                Ok(input) => input,
                Err(message) => return Ok(ToolResult::error(message)),
            };
            let base_revision = input.base_revision;
            match self.service.create_from_tool(input, context).await {
                Ok(outcome) if outcome.appended => Ok(ToolResult::success(format!(
                    "Created task graph revision {} with {} total task(s)",
                    outcome.graph.snapshot.revision,
                    outcome.graph.snapshot.tasks.len()
                ))),
                Ok(outcome) => Ok(ToolResult::success(format!(
                    "Created task graph revision 1 with {} task(s). Call task_execute with revision=1.",
                    outcome.created_count
                ))),
                Err(TaskRevisionError::InvalidInput { message })
                | Err(TaskRevisionError::PolicyRejected { message }) => {
                    Ok(ToolResult::error(message))
                }
                Err(error) if base_revision.is_some() => Ok(ToolResult::error(format!(
                    "Failed to add tasks to revision {}: {error}",
                    base_revision.unwrap_or_default()
                ))),
                Err(error) => Ok(ToolResult::error(format!(
                    "Failed to create task graph: {error}"
                ))),
            }
        })
    }
}

pub struct TaskUpdateTool {
    service: Arc<TaskRevisionService>,
}

impl TaskUpdateTool {
    pub fn new(service: Arc<TaskRevisionService>) -> Self {
        Self { service }
    }
}

impl Tool for TaskUpdateTool {
    fn name(&self) -> &str {
        "task_update"
    }

    fn description(&self) -> &str {
        "Atomically update task specifications, dependency relations, ordering, or skip state using optimistic concurrency. Only pending or blocked task specifications may change while a run is active."
    }

    fn parameters(&self) -> serde_json::Value {
        task_update_schema(&self.service)
    }

    fn allows_parallel_batch_execution(&self) -> bool {
        false
    }

    fn execute_with_context<'a>(
        &'a self,
        params: ToolParameters,
        context: &'a ToolContext,
    ) -> BoxFuture<'a, Result<ToolResult>> {
        Box::pin(async move {
            let input = match parse_task_update_input(
                &params,
                &self.service.task_input_schema_extensions(),
                self.service.allow_manual_progress_updates(),
            ) {
                Ok(input) => input,
                Err(message) => return Ok(ToolResult::error(message)),
            };
            match self.service.update_from_tool(input, context).await {
                Ok(graph) => Ok(ToolResult::success(format!(
                    "Committed task graph revision {} with {} task(s)",
                    graph.snapshot.revision,
                    graph.snapshot.tasks.len()
                ))),
                Err(TaskRevisionError::GraphNotFound { .. }) => Ok(ToolResult::error(
                    "task_update requires existing tasks; call task_create first",
                )),
                Err(TaskRevisionError::PolicyRejected { message }) => {
                    Ok(ToolResult::error(message))
                }
                Err(error) => Ok(ToolResult::error(format!(
                    "Failed to update tasks: {error}"
                ))),
            }
        })
    }
}

pub struct TaskListTool {
    service: Arc<TaskRevisionService>,
}

const TASK_LIST_DEFAULT_LIMIT: usize = 20;
const TASK_LIST_MAX_LIMIT: usize = 100;

impl TaskListTool {
    pub fn new(service: Arc<TaskRevisionService>) -> Self {
        Self { service }
    }
}

impl Tool for TaskListTool {
    fn name(&self) -> &str {
        "task_list"
    }

    fn description(&self) -> &str {
        "List the current TaskRun's tasks, dependency-aware graph revision, and runtime status. Results are bounded; use limit, cursor, and detail_level=full to page through the same committed graph without creating another task store."
    }

    fn risk_level(&self) -> ToolRiskLevel {
        ToolRiskLevel::ReadOnly
    }

    fn parameters(&self) -> serde_json::Value {
        serde_json::json!({
            "type": "object",
            "additionalProperties": false,
            "properties": {
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": TASK_LIST_MAX_LIMIT,
                    "default": TASK_LIST_DEFAULT_LIMIT,
                    "description": "Maximum tasks returned in one page."
                },
                "cursor": {
                    "type": "string",
                    "description": "Opaque cursor returned in the previous page metadata."
                },
                "detail_level": {
                    "type": "string",
                    "enum": ["summary", "full"],
                    "default": "summary",
                    "description": "Summary returns id/title/status; full also includes dependencies, retry count, and status detail."
                }
            }
        })
    }

    fn execute_with_context<'a>(
        &'a self,
        params: ToolParameters,
        context: &'a ToolContext,
    ) -> BoxFuture<'a, Result<ToolResult>> {
        Box::pin(async move {
            let page_request = match PageRequest::from_parameters(
                &params,
                TASK_LIST_DEFAULT_LIMIT,
                TASK_LIST_MAX_LIMIT,
            ) {
                Ok(request) => request,
                Err(error) => return Ok(ToolResult::error(error.to_string())),
            };
            let detail_level = match params.get("detail_level") {
                None => "summary",
                Some(value) => match value.as_str() {
                    Some("summary") => "summary",
                    Some("full") => "full",
                    Some(other) => {
                        return Ok(ToolResult::error(format!(
                            "detail_level must be 'summary' or 'full', received '{other}'"
                        )));
                    }
                    None => {
                        return Ok(ToolResult::error(
                            "detail_level must be a string ('summary' or 'full')",
                        ));
                    }
                },
            };
            let scope_id = match self.service.resolve_scope(context).await {
                Ok(scope_id) => scope_id,
                Err(error) => return Ok(ToolResult::error(error.to_string())),
            };
            match self.service.load(&scope_id).await {
                Ok(Some(graph)) => {
                    let query = serde_json::json!({
                        "scope_id": scope_id,
                        "detail_level": detail_level,
                    });
                    let (tasks, page_info) =
                        match page_request.paginate(graph.snapshot.tasks.clone(), &query) {
                            Ok(page) => page,
                            Err(error) => return Ok(ToolResult::error(error.to_string())),
                        };
                    let lines = tasks
                        .iter()
                        .map(|task| render_task_list_row(task, detail_level))
                        .collect::<Vec<_>>();
                    let mut result = ToolResult::success(format!(
                        "Task graph revision {} — Tasks ({}):\n{}",
                        graph.snapshot.revision,
                        page_info.total.unwrap_or(graph.snapshot.tasks.len()),
                        lines.join("\n")
                    ));
                    page_info.apply_to(&mut result);
                    Ok(result)
                }
                Ok(None) => Ok(ToolResult::error("No tasks; call task_create first")),
                Err(error) => Ok(ToolResult::error(format!("Failed: {error}"))),
            }
        })
    }
}

pub fn build_task_tools(service: Arc<TaskRevisionService>) -> Vec<Box<dyn Tool>> {
    vec![
        Box::new(TaskCreateTool::new(service.clone())),
        Box::new(TaskUpdateTool::new(service.clone())),
        Box::new(TaskListTool::new(service)),
    ]
}

pub fn build_task_create_tool(service: Arc<TaskRevisionService>) -> Box<dyn Tool> {
    Box::new(TaskCreateTool::new(service))
}

pub fn build_task_update_tool(service: Arc<TaskRevisionService>) -> Box<dyn Tool> {
    Box::new(TaskUpdateTool::new(service))
}

pub fn build_task_list_tool(service: Arc<TaskRevisionService>) -> Box<dyn Tool> {
    Box::new(TaskListTool::new(service))
}

fn task_create_schema(service: &TaskRevisionService) -> serde_json::Value {
    let task_schema = task_input_schema(service);
    serde_json::json!({
        "type": "object",
        "additionalProperties": false,
        "properties": {
            "tasks": {
                "type": "array",
                "minItems": 1,
                "description": "The complete atomic task graph. Include every related task in this one array, even when it contains only one task. Dependency ids may refer to this batch or existing tasks.",
                "items": task_schema
            },
            "base_revision": {
                "type": "integer",
                "minimum": 1,
                "description": "Required when the current TaskRun already has tasks."
            },
            "reason": { "type": "string", "description": "Why these tasks are being added" },
            "assumptions": { "type": "array", "items": { "type": "string" } },
            "risks": { "type": "array", "items": { "type": "string" } },
            "execution_mode": { "type": "string", "enum": ["parallel", "sequential"] }
        },
        "required": ["tasks"]
    })
}

fn task_update_schema(service: &TaskRevisionService) -> serde_json::Value {
    let task_schema = task_input_schema(service);
    let task_patch_schema = task_patch_schema(service);
    let mut operation_schemas = vec![
        serde_json::json!({
            "type": "object",
            "additionalProperties": false,
            "properties": {
                "op": { "const": "insert" },
                "after_task_id": { "type": ["string", "null"] },
                "task": task_schema
            },
            "required": ["op", "task"]
        }),
        serde_json::json!({
            "type": "object",
            "additionalProperties": false,
            "properties": {
                "op": { "const": "update" },
                "task_id": { "type": "string" },
                "patch": task_patch_schema
            },
            "required": ["op", "task_id", "patch"]
        }),
        serde_json::json!({
            "type": "object",
            "additionalProperties": false,
            "properties": {
                "op": { "const": "skip" },
                "task_id": { "type": "string" }
            },
            "required": ["op", "task_id"]
        }),
        serde_json::json!({
            "type": "object",
            "additionalProperties": false,
            "properties": {
                "op": { "const": "reorder" },
                "task_ids": { "type": "array", "items": { "type": "string" } }
            },
            "required": ["op", "task_ids"]
        }),
    ];
    if service.allow_manual_progress_updates() {
        operation_schemas.push(serde_json::json!({
            "type": "object",
            "additionalProperties": false,
            "properties": {
                "op": { "const": "set_status" },
                "task_id": { "type": "string" },
                "status": { "type": "string", "enum": ["pending", "in_progress", "completed", "cancelled"] }
            },
            "required": ["op", "task_id", "status"]
        }));
    }
    serde_json::json!({
        "type": "object",
        "properties": {
            "base_revision": { "type": "integer", "minimum": 1 },
            "reason": { "type": "string", "description": "Why runtime evidence requires this revision" },
            "operations": {
                "type": "array",
                "minItems": 1,
                "items": { "oneOf": operation_schemas }
            }
        },
        "required": ["base_revision", "reason", "operations"]
    })
}

fn task_input_schema(service: &TaskRevisionService) -> serde_json::Value {
    let mut properties = serde_json::Map::from_iter([
        (
            "id".to_string(),
            serde_json::json!({ "type": "string", "description": "Stable task id unique within this run" }),
        ),
        (
            "title".to_string(),
            serde_json::json!({ "type": "string", "description": "User-visible task title in the user's current language; keep technical identifiers unchanged" }),
        ),
        (
            "description".to_string(),
            serde_json::json!({ "type": "string", "description": "Subagent brief in the user's current language; keep code, paths, commands, and technical identifiers unchanged" }),
        ),
        (
            "depends_on".to_string(),
            serde_json::json!({ "type": "array", "items": { "type": "string" } }),
        ),
        (
            "max_retries".to_string(),
            serde_json::json!({ "type": "integer", "minimum": 0, "maximum": 10 }),
        ),
    ]);
    for (key, schema) in service.task_input_schema_extensions() {
        properties.insert(key, schema);
    }
    let mut required = vec![
        "id".to_string(),
        "title".to_string(),
        "description".to_string(),
    ];
    required.extend(service.required_task_input_extensions());
    serde_json::json!({
        "type": "object",
        "additionalProperties": false,
        "properties": properties,
        "required": required
    })
}

fn task_patch_schema(service: &TaskRevisionService) -> serde_json::Value {
    let mut properties = serde_json::Map::from_iter([
        (
            "title".to_string(),
            serde_json::json!({ "type": "string", "description": "User-visible task title in the user's current language" }),
        ),
        (
            "description".to_string(),
            serde_json::json!({ "type": "string", "description": "Subagent brief in the user's current language" }),
        ),
        (
            "depends_on".to_string(),
            serde_json::json!({ "type": "array", "items": { "type": "string" } }),
        ),
        (
            "max_retries".to_string(),
            serde_json::json!({ "type": "integer", "minimum": 0, "maximum": 10 }),
        ),
    ]);
    for (key, schema) in service.task_input_schema_extensions() {
        properties.insert(key, schema);
    }
    serde_json::json!({
        "type": "object",
        "additionalProperties": false,
        "properties": properties
    })
}

pub fn parse_task_create_input(
    params: &ToolParameters,
    extension_schemas: &serde_json::Map<String, serde_json::Value>,
) -> std::result::Result<TaskCreateInput, String> {
    let raw_tasks = params
        .get("tasks")
        .ok_or_else(|| "task_create requires one atomic tasks array".to_string())?
        .as_array()
        .ok_or_else(|| "task_create tasks must be an array".to_string())?;
    if raw_tasks.is_empty() {
        return Err("task_create requires at least one task".to_string());
    }
    let tasks = raw_tasks
        .iter()
        .enumerate()
        .map(|(index, value)| parse_task_draft(value, index, extension_schemas))
        .collect::<std::result::Result<Vec<_>, _>>()?;
    let execution_mode = match params
        .get("execution_mode")
        .and_then(serde_json::Value::as_str)
    {
        Some("sequential") => TaskGraphExecutionMode::Sequential,
        _ => TaskGraphExecutionMode::Parallel,
    };
    Ok(TaskCreateInput {
        tasks,
        base_revision: params
            .get("base_revision")
            .and_then(serde_json::Value::as_u64),
        reason: params
            .get("reason")
            .and_then(serde_json::Value::as_str)
            .map(str::to_string),
        assumptions: string_array_in_parameters(params, "assumptions"),
        risks: string_array_in_parameters(params, "risks"),
        execution_mode,
    })
}

pub fn parse_task_update_input(
    params: &ToolParameters,
    extension_schemas: &serde_json::Map<String, serde_json::Value>,
    allow_manual_progress_updates: bool,
) -> std::result::Result<TaskUpdateInput, String> {
    let base_revision = params
        .get("base_revision")
        .and_then(serde_json::Value::as_u64)
        .ok_or_else(|| "task_update requires base_revision".to_string())?;
    let reason = params
        .get("reason")
        .and_then(serde_json::Value::as_str)
        .unwrap_or_default()
        .trim()
        .to_string();
    let raw_operations = params
        .get("operations")
        .ok_or_else(|| "task_update requires operations".to_string())?
        .as_array()
        .ok_or_else(|| "task_update operations must be an array".to_string())?;
    let mut operations = Vec::with_capacity(raw_operations.len());
    for (index, operation) in raw_operations.iter().enumerate() {
        let op = operation
            .get("op")
            .and_then(serde_json::Value::as_str)
            .ok_or_else(|| format!("operations[{index}].op is required"))?;
        let parsed = match op {
            "insert" => {
                let task = operation
                    .get("task")
                    .ok_or_else(|| format!("operations[{index}].task is required"))?;
                TaskPlanPatchInputOp::Insert {
                    after_task_id: operation
                        .get("after_task_id")
                        .and_then(serde_json::Value::as_str)
                        .map(str::to_string),
                    task: parse_task_draft(task, index, extension_schemas)?,
                }
            }
            "update" => TaskPlanPatchInputOp::Update {
                task_id: required_task_id(operation, index)?,
                patch: operation
                    .get("patch")
                    .ok_or_else(|| format!("operations[{index}].patch is required"))
                    .and_then(|patch| parse_task_spec_patch(patch, extension_schemas))?,
            },
            "skip" => TaskPlanPatchInputOp::Skip {
                task_id: required_task_id(operation, index)?,
            },
            "reorder" => TaskPlanPatchInputOp::Reorder {
                task_ids: string_array_in(operation, "task_ids"),
            },
            "set_status" if allow_manual_progress_updates => {
                let status = operation
                    .get("status")
                    .and_then(serde_json::Value::as_str)
                    .ok_or_else(|| format!("operations[{index}].status is required"))?;
                let status = match status {
                    "pending" => TaskStatus::Pending,
                    "in_progress" => TaskStatus::Running,
                    "completed" => TaskStatus::Completed,
                    "cancelled" => TaskStatus::Cancelled,
                    other => {
                        return Err(format!("operations[{index}] has unknown status '{other}'"));
                    }
                };
                TaskPlanPatchInputOp::SetStatus {
                    task_id: required_task_id(operation, index)?,
                    status,
                }
            }
            other => return Err(format!("operations[{index}] has unknown op '{other}'")),
        };
        operations.push(parsed);
    }
    Ok(TaskUpdateInput {
        base_revision,
        reason,
        operations,
    })
}

fn parse_task_draft(
    value: &serde_json::Value,
    index: usize,
    extension_schemas: &serde_json::Map<String, serde_json::Value>,
) -> std::result::Result<TaskDraft, String> {
    let field = |key: &str| {
        value
            .get(key)
            .and_then(serde_json::Value::as_str)
            .map(str::trim)
            .filter(|item| !item.is_empty())
            .map(str::to_string)
            .ok_or_else(|| format!("tasks[{index}].{key} is required"))
    };
    let max_retries = value
        .get("max_retries")
        .and_then(serde_json::Value::as_u64)
        .and_then(|count| u32::try_from(count).ok())
        .unwrap_or(3);
    let mut extensions = serde_json::Map::new();
    for key in extension_schemas.keys() {
        if let Some(extension) = value.get(key) {
            if key == "extension" {
                let fields = extension
                    .as_object()
                    .ok_or_else(|| format!("tasks[{index}].extension must be an object"))?;
                extensions.extend(fields.clone());
            } else {
                extensions.insert(key.clone(), extension.clone());
            }
        }
    }
    Ok(TaskDraft {
        id: field("id")?,
        title: field("title")?,
        description: field("description")?,
        depends_on: string_array_in(value, "depends_on"),
        max_retries,
        extension: serde_json::Value::Object(extensions),
    })
}

fn parse_task_spec_patch(
    value: &serde_json::Value,
    extension_schemas: &serde_json::Map<String, serde_json::Value>,
) -> std::result::Result<TaskSpecPatch, String> {
    let object = value
        .as_object()
        .ok_or_else(|| "task patch must be an object".to_string())?;
    let mut extension = serde_json::Map::new();
    for key in extension_schemas.keys() {
        if let Some(value) = object.get(key) {
            if key == "extension" {
                let fields = value
                    .as_object()
                    .ok_or_else(|| "task patch extension must be an object".to_string())?;
                extension.extend(fields.clone());
            } else {
                extension.insert(key.clone(), value.clone());
            }
        }
    }
    Ok(TaskSpecPatch {
        title: optional_string_in(value, "title"),
        description: optional_string_in(value, "description"),
        depends_on: object
            .contains_key("depends_on")
            .then(|| string_array_in(value, "depends_on")),
        max_retries: object
            .get("max_retries")
            .and_then(serde_json::Value::as_u64)
            .map(u32::try_from)
            .transpose()
            .map_err(|_| "max_retries exceeds u32".to_string())?,
        extension: (!extension.is_empty()).then_some(serde_json::Value::Object(extension)),
    })
}

fn optional_string_in(value: &serde_json::Value, key: &str) -> Option<String> {
    value
        .get(key)
        .and_then(serde_json::Value::as_str)
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .map(str::to_string)
}

fn required_task_id(
    operation: &serde_json::Value,
    index: usize,
) -> std::result::Result<String, String> {
    operation
        .get("task_id")
        .and_then(serde_json::Value::as_str)
        .map(str::trim)
        .filter(|task_id| !task_id.is_empty())
        .map(str::to_string)
        .ok_or_else(|| format!("operations[{index}].task_id is required"))
}

fn string_array_in(value: &serde_json::Value, key: &str) -> Vec<String> {
    value
        .get(key)
        .and_then(serde_json::Value::as_array)
        .map(|items| {
            items
                .iter()
                .filter_map(serde_json::Value::as_str)
                .map(str::trim)
                .filter(|item| !item.is_empty())
                .map(str::to_string)
                .collect()
        })
        .unwrap_or_default()
}

fn string_array_in_parameters(value: &ToolParameters, key: &str) -> Vec<String> {
    value
        .get(key)
        .and_then(serde_json::Value::as_array)
        .map(|items| {
            items
                .iter()
                .filter_map(serde_json::Value::as_str)
                .map(str::trim)
                .filter(|item| !item.is_empty())
                .map(str::to_string)
                .collect()
        })
        .unwrap_or_default()
}

fn status_name(status: &TaskStatus) -> &'static str {
    match status {
        TaskStatus::Pending => "pending",
        TaskStatus::Running => "running",
        TaskStatus::Blocked(_) => "blocked",
        TaskStatus::Completed => "completed",
        TaskStatus::Failed(_) => "failed",
        TaskStatus::Skipped => "skipped",
        TaskStatus::Cancelled => "cancelled",
        TaskStatus::TimedOut { .. } => "timed_out",
        TaskStatus::Retrying { .. } => "retrying",
        TaskStatus::Paused(_) => "paused",
    }
}

fn render_task_list_row(task: &Task, detail_level: &str) -> String {
    let mut row = format!(
        "[{}] {} — {}",
        status_name(&task.execution.status),
        task.spec.id,
        task.spec.title
    );
    if detail_level == "full" {
        if !task.spec.depends_on.is_empty() {
            row.push_str(&format!("; depends_on={}", task.spec.depends_on.join(",")));
        }
        row.push_str(&format!(
            "; retry={}/{}",
            task.execution.retry_count, task.spec.max_retries
        ));
        let detail = match &task.execution.status {
            TaskStatus::Blocked(detail)
            | TaskStatus::Failed(detail)
            | TaskStatus::Paused(detail) => Some(detail.as_str()),
            TaskStatus::TimedOut { error } => Some(error.as_str()),
            TaskStatus::Retrying { last_error, .. } => Some(last_error.as_str()),
            TaskStatus::Pending
            | TaskStatus::Running
            | TaskStatus::Completed
            | TaskStatus::Skipped
            | TaskStatus::Cancelled => None,
        };
        if let Some(detail) = detail.filter(|detail| !detail.is_empty()) {
            row.push_str(&format!("; detail={detail}"));
        }
    }
    row
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::tasks::{DefaultTaskToolPolicy, InMemoryRevisionedTaskStore};

    fn service() -> Arc<TaskRevisionService> {
        Arc::new(TaskRevisionService::new(
            Arc::new(InMemoryRevisionedTaskStore::new()),
            Arc::new(DefaultTaskToolPolicy::new("tool-test")),
        ))
    }

    fn parameters(value: serde_json::Value) -> std::result::Result<ToolParameters, String> {
        serde_json::from_value(value).map_err(|error| error.to_string())
    }

    #[tokio::test]
    async fn tools_create_update_and_list_one_graph() -> std::result::Result<(), String> {
        let service = service();
        let create = TaskCreateTool::new(service.clone());
        let created = create
            .execute(parameters(serde_json::json!({
                "tasks": [{
                    "id": "分析",
                    "title": "分析问题",
                    "description": "检查输入"
                }]
            }))?)
            .await
            .map_err(|error| error.to_string())?;
        assert!(created.success);

        let update = TaskUpdateTool::new(service.clone());
        let updated = update
            .execute(parameters(serde_json::json!({
                "base_revision": 1,
                "reason": "开始",
                "operations": [{"op": "set_status", "task_id": "分析", "status": "in_progress"}]
            }))?)
            .await
            .map_err(|error| error.to_string())?;
        assert!(updated.success);

        let list = TaskListTool::new(service);
        let listed = list
            .execute(parameters(
                serde_json::json!({"detail_level": "full", "limit": 5}),
            )?)
            .await
            .map_err(|error| error.to_string())?;
        assert!(listed.success);
        assert!(listed.output.contains("revision 2"));
        assert!(listed.output.contains("分析问题"));
        assert!(listed.output.contains("retry=0/3"));
        assert_eq!(listed.metadata.get("page.returned"), Some(&"1".to_string()));
        Ok(())
    }

    #[test]
    fn task_list_schema_exposes_bounded_paging_and_detail() {
        let schema = TaskListTool::new(service()).parameters();
        let properties = schema
            .get("properties")
            .and_then(serde_json::Value::as_object);
        assert!(properties.is_some_and(|properties| {
            properties.contains_key("limit")
                && properties.contains_key("cursor")
                && properties.contains_key("detail_level")
        }));
    }

    #[tokio::test]
    async fn task_list_cursor_continuation_is_bounded_and_exact() -> std::result::Result<(), String>
    {
        let service = service();
        let create = TaskCreateTool::new(service.clone());
        let created = create
            .execute(parameters(serde_json::json!({
                "tasks": [
                    {"id": "first", "title": "First", "description": "one"},
                    {"id": "second", "title": "Second", "description": "two"},
                    {"id": "third", "title": "Third", "description": "three"}
                ]
            }))?)
            .await
            .map_err(|error| error.to_string())?;
        assert!(created.success);

        let list = TaskListTool::new(service);
        let first_page = list
            .execute(parameters(serde_json::json!({"limit": 2}))?)
            .await
            .map_err(|error| error.to_string())?;
        assert!(first_page.success);
        assert!(first_page.truncated);
        assert!(first_page.output.contains("first"));
        assert!(first_page.output.contains("second"));
        assert!(!first_page.output.contains("third"));
        let cursor = first_page
            .metadata
            .get("page.next_cursor")
            .cloned()
            .ok_or_else(|| "first page omitted next cursor".to_string())?;

        let second_page = list
            .execute(parameters(serde_json::json!({
                "limit": 2,
                "cursor": cursor,
            }))?)
            .await
            .map_err(|error| error.to_string())?;
        assert!(second_page.success);
        assert!(!second_page.truncated);
        assert!(!second_page.output.contains("first"));
        assert!(!second_page.output.contains("second"));
        assert!(second_page.output.contains("third"));
        Ok(())
    }

    #[tokio::test]
    async fn task_list_rejects_invalid_cursor() -> std::result::Result<(), String> {
        let service = service();
        let create = TaskCreateTool::new(service.clone());
        let created = create
            .execute(parameters(serde_json::json!({
                "tasks": [{"id": "task-1", "title": "Task", "description": "one"}]
            }))?)
            .await
            .map_err(|error| error.to_string())?;
        assert!(created.success);

        let list = TaskListTool::new(service);
        let result = list
            .execute(parameters(serde_json::json!({
                "limit": 2,
                "cursor": "not-hex",
            }))?)
            .await
            .map_err(|error| error.to_string())?;
        assert!(!result.success);
        assert!(result.error.is_some());
        Ok(())
    }

    #[test]
    fn default_schema_exposes_manual_status_updates() {
        let schema = task_update_schema(&service());
        assert!(schema.to_string().contains("set_status"));
    }

    #[test]
    fn default_schema_exposes_product_neutral_extension() {
        let schema = task_input_schema(&service());
        assert!(
            schema
                .pointer("/properties/extension/type")
                .is_some_and(|value| value == "object")
        );
    }

    #[test]
    fn default_parser_preserves_product_neutral_extension() -> std::result::Result<(), String> {
        let service = service();
        let input = parameters(serde_json::json!({
            "tasks": [{
                "id": "task-1",
                "title": "Inspect",
                "description": "Inspect the input",
                "extension": { "domain": "research", "priority": 4 }
            }]
        }))?;
        let parsed = parse_task_create_input(&input, &service.task_input_schema_extensions())?;
        assert_eq!(
            parsed.tasks.first().map(|task| &task.extension),
            Some(&serde_json::json!({ "domain": "research", "priority": 4 }))
        );
        Ok(())
    }

    #[test]
    fn task_create_schema_requires_one_atomic_tasks_array() {
        let tool = TaskCreateTool::new(service());
        let schema = tool.parameters();
        assert_eq!(schema.get("required"), Some(&serde_json::json!(["tasks"])));
        assert!(
            schema
                .get("properties")
                .and_then(serde_json::Value::as_object)
                .is_some_and(|properties| {
                    properties.contains_key("tasks") && !properties.contains_key("task")
                })
        );
        assert!(!tool.allows_parallel_batch_execution());
    }

    #[test]
    fn task_create_rejects_the_removed_singular_shape() -> std::result::Result<(), String> {
        let input = parameters(serde_json::json!({
            "task": {
                "id": "analysis",
                "title": "Analyze",
                "description": "Inspect input"
            }
        }))?;
        let result = parse_task_create_input(&input, &serde_json::Map::new());
        assert_eq!(
            result.err().as_deref(),
            Some("task_create requires one atomic tasks array")
        );
        Ok(())
    }
}
