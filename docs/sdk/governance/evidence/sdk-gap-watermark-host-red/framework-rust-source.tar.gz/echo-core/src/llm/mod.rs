//! LLM client core trait and request/response types

pub mod cache;
pub mod capabilities;
pub mod thinking;
pub mod types;

use crate::error::Result;
pub use thinking::{ThinkingConfig, ThinkingLevel, ThinkingProtocol};
pub use types::{
    ChatCompletionChunk, ChatCompletionRequest, ChatCompletionResponse, DeltaMessage, FunctionCall,
    FunctionSpec, JsonSchemaSpec, Message, ResponseFormat, Role, ThinkingTypeBlock, ToolCall,
    ToolDefinition,
};

use futures::future::BoxFuture;
use futures::stream::BoxStream;
use std::time::Duration;
use tokio_util::sync::CancellationToken;

const DEFAULT_REQUEST_TIMEOUT: Duration = Duration::from_secs(120);
const DEFAULT_FIRST_CHUNK_TIMEOUT: Duration = Duration::from_secs(30);
const DEFAULT_IDLE_TIMEOUT: Duration = Duration::from_secs(60);

mod optional_duration_millis {
    use serde::{Deserialize, Deserializer, Serialize, Serializer};
    use std::time::Duration;

    pub fn serialize<S>(value: &Option<Duration>, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        value
            .map(|duration| u64::try_from(duration.as_millis()).unwrap_or(u64::MAX))
            .serialize(serializer)
    }

    pub fn deserialize<'de, D>(deserializer: D) -> Result<Option<Duration>, D::Error>
    where
        D: Deserializer<'de>,
    {
        Ok(Option::<u64>::deserialize(deserializer)?
            .filter(|millis| *millis > 0)
            .map(Duration::from_millis))
    }
}

fn default_request_timeout() -> Option<Duration> {
    Some(DEFAULT_REQUEST_TIMEOUT)
}

fn default_first_chunk_timeout() -> Option<Duration> {
    Some(DEFAULT_FIRST_CHUNK_TIMEOUT)
}

fn default_idle_timeout() -> Option<Duration> {
    Some(DEFAULT_IDLE_TIMEOUT)
}

fn normalize_timeout(timeout: Duration) -> Option<Duration> {
    (!timeout.is_zero()).then_some(timeout)
}

/// Provider-neutral timeout policy for LLM requests and streaming responses.
///
/// `request` applies to non-streaming calls. Streaming calls use independent
/// first-chunk, idle, and overall boundaries so a long healthy stream is not
/// mistaken for a stalled request. A `None` boundary is disabled; zero values
/// are normalized to `None`. Serialized values use milliseconds.
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(default)]
pub struct LlmTimeouts {
    #[serde(default = "default_request_timeout", with = "optional_duration_millis")]
    request: Option<Duration>,
    #[serde(
        default = "default_first_chunk_timeout",
        with = "optional_duration_millis"
    )]
    first_chunk: Option<Duration>,
    #[serde(default = "default_idle_timeout", with = "optional_duration_millis")]
    idle: Option<Duration>,
    #[serde(default, with = "optional_duration_millis")]
    overall: Option<Duration>,
}

impl Default for LlmTimeouts {
    fn default() -> Self {
        Self {
            request: default_request_timeout(),
            first_chunk: default_first_chunk_timeout(),
            idle: default_idle_timeout(),
            overall: None,
        }
    }
}

impl LlmTimeouts {
    /// Return the non-streaming request timeout.
    pub fn request_timeout(self) -> Option<Duration> {
        self.request
    }

    /// Return the timeout from request start through the first response bytes.
    pub fn first_chunk_timeout(self) -> Option<Duration> {
        self.first_chunk
    }

    /// Return the maximum idle duration between streaming byte chunks.
    pub fn idle_timeout(self) -> Option<Duration> {
        self.idle
    }

    /// Return the timeout covering the complete stream, including startup.
    pub fn overall_timeout(self) -> Option<Duration> {
        self.overall
    }

    /// Configure the non-streaming request timeout. Zero disables it.
    pub fn with_request_timeout(mut self, timeout: Duration) -> Self {
        self.request = normalize_timeout(timeout);
        self
    }

    /// Disable the non-streaming request timeout.
    pub fn without_request_timeout(mut self) -> Self {
        self.request = None;
        self
    }

    /// Configure the request-to-first-chunk timeout. Zero disables it.
    pub fn with_first_chunk_timeout(mut self, timeout: Duration) -> Self {
        self.first_chunk = normalize_timeout(timeout);
        self
    }

    /// Disable the request-to-first-chunk timeout.
    pub fn without_first_chunk_timeout(mut self) -> Self {
        self.first_chunk = None;
        self
    }

    /// Configure the inter-chunk idle timeout. Zero disables it.
    pub fn with_idle_timeout(mut self, timeout: Duration) -> Self {
        self.idle = normalize_timeout(timeout);
        self
    }

    /// Disable the inter-chunk idle timeout.
    pub fn without_idle_timeout(mut self) -> Self {
        self.idle = None;
        self
    }

    /// Configure the complete-stream timeout. Zero disables it.
    pub fn with_overall_timeout(mut self, timeout: Duration) -> Self {
        self.overall = normalize_timeout(timeout);
        self
    }

    /// Disable the complete-stream timeout.
    pub fn without_overall_timeout(mut self) -> Self {
        self.overall = None;
        self
    }
}

#[cfg(test)]
mod timeout_tests {
    use super::LlmTimeouts;
    use std::time::Duration;

    #[test]
    fn timeout_defaults_and_millisecond_wire_shape_are_stable() -> Result<(), String> {
        let defaults = LlmTimeouts::default();
        assert_eq!(defaults.request_timeout(), Some(Duration::from_secs(120)));
        assert_eq!(
            defaults.first_chunk_timeout(),
            Some(Duration::from_secs(30))
        );
        assert_eq!(defaults.idle_timeout(), Some(Duration::from_secs(60)));
        assert_eq!(defaults.overall_timeout(), None);

        let configured = defaults
            .with_request_timeout(Duration::from_millis(2_500))
            .with_first_chunk_timeout(Duration::from_millis(750))
            .without_idle_timeout()
            .with_overall_timeout(Duration::from_secs(10));
        let encoded = serde_json::to_value(configured).map_err(|error| error.to_string())?;
        assert_eq!(
            encoded.get("request").and_then(serde_json::Value::as_u64),
            Some(2_500)
        );
        assert_eq!(
            encoded
                .get("first_chunk")
                .and_then(serde_json::Value::as_u64),
            Some(750)
        );
        assert!(encoded.get("idle").is_some_and(serde_json::Value::is_null));
        assert_eq!(
            encoded.get("overall").and_then(serde_json::Value::as_u64),
            Some(10_000)
        );
        Ok(())
    }

    #[test]
    fn zero_millisecond_timeouts_deserialize_as_disabled() -> Result<(), String> {
        let decoded = serde_json::from_value::<LlmTimeouts>(serde_json::json!({
            "request": 0,
            "first_chunk": 0,
            "idle": 0,
            "overall": 0
        }))
        .map_err(|error| error.to_string())?;
        assert_eq!(decoded.request_timeout(), None);
        assert_eq!(decoded.first_chunk_timeout(), None);
        assert_eq!(decoded.idle_timeout(), None);
        assert_eq!(decoded.overall_timeout(), None);
        Ok(())
    }
}

/// Input modalities accepted by one configured model.
///
/// Provider transports describe how content is encoded; this model-level set
/// describes what a concrete model is allowed to receive.
#[derive(
    Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, serde::Serialize, serde::Deserialize,
)]
#[serde(rename_all = "snake_case")]
pub enum ModelInputModality {
    Text,
    Image,
    Audio,
    Video,
}

impl ModelInputModality {
    /// Text-only defaults keep unknown models conservative.
    pub fn text_only() -> Vec<Self> {
        vec![Self::Text]
    }

    /// Preserve the framework constructors' historical multimodal behavior.
    pub fn all_supported() -> Vec<Self> {
        vec![Self::Text, Self::Image, Self::Audio, Self::Video]
    }
}

/// HTTP API protocol used by an LLM provider endpoint.
///
/// This is deliberately separate from provider identity. A provider selects a
/// default protocol, while custom and compatible endpoints can explicitly
/// select any supported wire format.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum LlmApiProtocol {
    /// OpenAI-compatible `/chat/completions` request and stream schema.
    #[default]
    ChatCompletions,
    /// OpenAI Responses request and semantic SSE event schema.
    Responses,
    /// Anthropic Messages request and semantic SSE event schema.
    Anthropic,
}

impl LlmApiProtocol {
    /// Standard endpoint path appended to a provider API root.
    pub const fn endpoint_path(self) -> &'static str {
        match self {
            Self::ChatCompletions => "chat/completions",
            Self::Responses => "responses",
            Self::Anthropic => "messages",
        }
    }

    /// Identify the protocol spoken by a complete endpoint URL.
    ///
    /// Returns `None` for provider roots such as `https://api.example.com/v1`
    /// because selecting a wire protocol from an incomplete path would turn the
    /// Chat Completions fallback into a false positive.
    pub fn try_from_endpoint(endpoint: &str) -> Option<Self> {
        let path = endpoint
            .split(['?', '#'])
            .next()
            .unwrap_or(endpoint)
            .trim_end_matches('/');
        if path.ends_with("/responses") {
            Some(Self::Responses)
        } else if path.ends_with("/messages") {
            Some(Self::Anthropic)
        } else if path.ends_with("/chat/completions") {
            Some(Self::ChatCompletions)
        } else {
            None
        }
    }

    /// Infer the protocol from a complete endpoint URL.
    pub fn from_endpoint(endpoint: &str) -> Self {
        if let Some(protocol) = Self::try_from_endpoint(endpoint) {
            protocol
        } else if endpoint
            .split(['?', '#'])
            .next()
            .unwrap_or(endpoint)
            .contains("anthropic.com/")
        {
            Self::Anthropic
        } else {
            Self::ChatCompletions
        }
    }
}

#[cfg(test)]
mod protocol_tests {
    use super::LlmApiProtocol;

    #[test]
    fn infers_all_supported_wire_protocols() {
        assert_eq!(
            LlmApiProtocol::from_endpoint("https://api.openai.com/v1/responses?trace=true"),
            LlmApiProtocol::Responses
        );
        assert_eq!(
            LlmApiProtocol::from_endpoint("https://api.anthropic.com/v1/messages"),
            LlmApiProtocol::Anthropic
        );
        assert_eq!(
            LlmApiProtocol::from_endpoint("https://gateway.example/v1/chat/completions"),
            LlmApiProtocol::ChatCompletions
        );
    }

    #[test]
    fn complete_endpoint_detection_does_not_guess_from_provider_roots() {
        assert_eq!(
            LlmApiProtocol::try_from_endpoint("https://gateway.example/v1/responses?trace=true"),
            Some(LlmApiProtocol::Responses)
        );
        assert_eq!(
            LlmApiProtocol::try_from_endpoint("https://gateway.example/v1/messages#debug"),
            Some(LlmApiProtocol::Anthropic)
        );
        assert_eq!(
            LlmApiProtocol::try_from_endpoint("https://gateway.example/v1/chat/completions/"),
            Some(LlmApiProtocol::ChatCompletions)
        );
        assert_eq!(
            LlmApiProtocol::try_from_endpoint("https://gateway.example/v1"),
            None
        );
        assert_eq!(
            LlmApiProtocol::from_endpoint(
                "https://gateway.example/v1?upstream=https://api.anthropic.com/v1/"
            ),
            LlmApiProtocol::ChatCompletions
        );
    }
}

/// Options for [`LlmClient::chat_simple_with_options`].
#[derive(Debug, Clone)]
pub struct SimpleChatOptions {
    /// Sampling temperature (0.0–2.0). Defaults to `0.7`.
    pub temperature: Option<f32>,
    /// Maximum tokens to generate. Defaults to `2048`.
    pub max_tokens: Option<u32>,
}

impl Default for SimpleChatOptions {
    fn default() -> Self {
        Self {
            temperature: Some(0.7),
            max_tokens: Some(2048),
        }
    }
}

impl SimpleChatOptions {
    /// Create options with a specific temperature.
    pub fn with_temperature(mut self, temp: f32) -> Self {
        self.temperature = Some(temp);
        self
    }

    /// Create options with a specific max_tokens.
    pub fn with_max_tokens(mut self, max: u32) -> Self {
        self.max_tokens = Some(max);
        self
    }
}

/// LLM client unified interface
pub trait LlmClient: Send + Sync {
    /// Execute a non-streaming chat request.
    fn chat(&self, request: ChatRequest) -> BoxFuture<'_, Result<ChatResponse>>;

    /// Execute a streaming chat request.
    ///
    /// The returned stream is `'static` (does not borrow `&self`): all
    /// provider implementations produce an owned, boxed stream so the caller
    /// can move it across awaits / into spawned tasks. This also lets the
    /// streaming core loop route through a trait object (`Arc<dyn LlmClient>`)
    /// and have the resulting stream outlive the trait-method borrow — which
    /// is what makes the loop testable with a mock client.
    fn chat_stream(
        &self,
        request: ChatRequest,
    ) -> BoxFuture<'_, Result<BoxStream<'static, Result<ChatChunk>>>>;

    /// Convenience helper for simple text-only calls.
    ///
    /// Accepts optional overrides via [`SimpleChatOptions`]; defaults are
    /// `temperature: 0.7` and `max_tokens: 2048`.
    fn chat_simple(&self, messages: Vec<Message>) -> BoxFuture<'_, Result<String>> {
        self.chat_simple_with_options(messages, SimpleChatOptions::default())
    }

    /// Convenience helper with configurable options.
    fn chat_simple_with_options(
        &self,
        messages: Vec<Message>,
        options: SimpleChatOptions,
    ) -> BoxFuture<'_, Result<String>> {
        Box::pin(async move {
            let response = self
                .chat(ChatRequest {
                    messages,
                    temperature: options.temperature,
                    max_tokens: options.max_tokens,
                    ..Default::default()
                })
                .await?;
            Ok(response.content().unwrap_or_default().to_string())
        })
    }

    /// Model identifier used by this client.
    fn model_name(&self) -> &str;

    /// Stable provider identity used by the model-fact resolver, when known.
    fn provider_name(&self) -> Option<&str> {
        None
    }

    /// Immutable wire behavior implemented by this client adapter.
    fn protocol_capabilities(&self) -> capabilities::ProviderCapabilityOverride {
        capabilities::ProviderCapabilityOverride::default()
    }

    /// Resolve and retain provider/model policy with provenance.
    fn model_profile_resolution(&self) -> capabilities::ModelProfileResolution {
        let now = std::time::SystemTime::now();
        let provider = self.provider_name().unwrap_or("");
        let declared_capabilities = self.capabilities();
        let protocol_facts = capabilities::ModelFactSet::new_partial(
            capabilities::ModelFactMetadata::new(
                capabilities::ModelFactSource::ProviderAdapter,
                "LlmClient::protocol_capabilities",
                "llm-client-protocol-v1",
                now,
                None,
                capabilities::ModelFactConfidence::VERIFIED,
            ),
            self.protocol_capabilities(),
            capabilities::ModelProfileOverride::default(),
        );
        let mut resolver = capabilities::ModelProfileResolver::new()
            .register_protocol_facts(provider, protocol_facts);
        if declared_capabilities != capabilities::ProviderCapabilities::conservative_unknown() {
            resolver = resolver.register_provider_facts(
                provider,
                capabilities::ModelFactSet::new(
                    capabilities::ModelFactMetadata::new(
                        capabilities::ModelFactSource::ProviderAdapter,
                        "LlmClient::capabilities compatibility override",
                        "llm-client-capabilities-v1",
                        now,
                        None,
                        capabilities::ModelFactConfidence::VERIFIED,
                    ),
                    Some(declared_capabilities),
                    capabilities::ModelProfileOverride::default(),
                ),
            );
        }
        resolver.resolve_at(provider, self.model_name(), now)
    }

    /// Provider capabilities for this client.
    ///
    /// The default is conservative: custom clients must explicitly publish
    /// protocol/model facts rather than inheriting OpenAI capabilities.
    fn capabilities(&self) -> capabilities::ProviderCapabilities {
        capabilities::ProviderCapabilities::conservative_unknown()
    }
}

#[cfg(test)]
mod client_capability_tests {
    use super::*;
    use crate::error::LlmError;

    struct UnknownClient;
    struct DeclaredClient;

    impl LlmClient for UnknownClient {
        fn chat(&self, _request: ChatRequest) -> BoxFuture<'_, Result<ChatResponse>> {
            Box::pin(async {
                Err(LlmError::InvalidResponse("not used by this test".to_string()).into())
            })
        }

        fn chat_stream(
            &self,
            _request: ChatRequest,
        ) -> BoxFuture<'_, Result<BoxStream<'static, Result<ChatChunk>>>> {
            Box::pin(async {
                Ok(Box::pin(futures::stream::empty()) as BoxStream<'static, Result<ChatChunk>>)
            })
        }

        fn model_name(&self) -> &str {
            "unknown-model"
        }
    }

    impl LlmClient for DeclaredClient {
        fn chat(&self, request: ChatRequest) -> BoxFuture<'_, Result<ChatResponse>> {
            UnknownClient.chat(request)
        }

        fn chat_stream(
            &self,
            request: ChatRequest,
        ) -> BoxFuture<'_, Result<BoxStream<'static, Result<ChatChunk>>>> {
            UnknownClient.chat_stream(request)
        }

        fn model_name(&self) -> &str {
            "declared-model"
        }

        fn capabilities(&self) -> capabilities::ProviderCapabilities {
            capabilities::ProviderCapabilities::openai_compatible()
        }
    }

    #[test]
    fn unknown_clients_do_not_inherit_openai_capabilities() {
        assert_eq!(
            UnknownClient.capabilities(),
            capabilities::ProviderCapabilities::conservative_unknown()
        );
    }

    #[test]
    fn legacy_custom_capability_override_enters_the_resolution_receipt() {
        let resolution = DeclaredClient.model_profile_resolution();
        assert!(resolution.profile.capabilities.structured_output);
        assert!(
            resolution.applied_facts.iter().any(|metadata| {
                metadata.source == capabilities::ModelFactSource::ProviderAdapter
            })
        );
    }
}

/// Controls how the model uses tools during inference.
///
/// Maps to provider-specific APIs:
/// - OpenAI: `"auto"`, `"none"`, `"required"`, `{"type": "function", "function": {"name": "..."}}`
/// - Anthropic: `{"type": "auto"}`, `{"type": "any"}`, `{"type": "tool", "name": "..."}`
#[derive(Debug, Clone, Default, PartialEq)]
pub enum ToolChoice {
    /// Let the model decide whether to call tools (default).
    #[default]
    Auto,
    /// Force the model NOT to call any tools.
    None,
    /// Require the model to call at least one tool.
    Required,
    /// Force the model to call a specific tool by name.
    Function { name: String },
}

impl ToolChoice {
    /// Create a ToolChoice that forces a specific function call.
    pub fn function(name: impl Into<String>) -> Self {
        Self::Function { name: name.into() }
    }

    /// Convert to the OpenAI wire format (`"auto"`, `"none"`, `"required"`,
    /// or `{"type":"function","function":{"name":"..."}}`).
    pub fn to_openai_value(&self) -> serde_json::Value {
        match self {
            Self::Auto => serde_json::Value::String("auto".into()),
            Self::None => serde_json::Value::String("none".into()),
            Self::Required => serde_json::Value::String("required".into()),
            Self::Function { name } => serde_json::json!({
                "type": "function",
                "function": {"name": name}
            }),
        }
    }
}

/// Chat request parameters
#[derive(Debug, Clone, Default)]
pub struct ChatRequest {
    /// Ordered chat history sent to the model.
    pub messages: Vec<Message>,
    /// Optional sampling temperature.
    pub temperature: Option<f32>,
    /// Optional response token limit.
    pub max_tokens: Option<u32>,
    /// Optional tool definitions exposed to the model.
    pub tools: Option<Vec<ToolDefinition>>,
    /// Controls how the model uses tools (OpenAI wire format).
    /// Prefer [`ToolChoice`] for type-safe construction; convert via
    /// [`ToolChoice::to_openai_value`] when building a [`ChatCompletionRequest`].
    pub tool_choice: Option<String>,
    /// Optional structured output format hint.
    pub response_format: Option<ResponseFormat>,
    /// Optional reasoning-depth / "thinking" control.
    ///
    /// When set, providers translate it to their native thinking wire field
    /// (`reasoning_effort` for OpenAI reasoning models, `thinking.budget_tokens`
    /// for Claude 3.7–4.5, `enable_thinking` for Qwen3/GLM). Models that do not
    /// support a thinking control silently drop it (with a `warn!`). `None`
    /// (the default) means "use the model's default behavior" — no field sent.
    pub thinking: Option<ThinkingConfig>,
    /// Optional cancellation token for aborting in-flight requests.
    /// When set and cancelled, streaming responses stop at the next SSE boundary and
    /// non-streaming requests abort while waiting for headers, reading the body, or
    /// decoding the JSON response.
    pub cancel_token: Option<CancellationToken>,
    /// Optional timeout override for this call.
    ///
    /// `None` uses the provider client's configured default. The same value
    /// controls non-streaming and streaming boundaries.
    pub timeouts: Option<LlmTimeouts>,
    /// Optional user identifier for KVCache isolation (DeepSeek, etc.).
    /// A stable, session-scoped ID enables the provider to reuse prompt cache
    /// entries across requests. Without this, cache hit rate can drop to <1%.
    pub user_id: Option<String>,
    /// Optional cache hints (breakpoint targets, stable prefix hash, segment ranges).
    /// Providers consume this to place cache breakpoints and log diagnostics.
    pub cache_hints: Option<crate::llm::cache::CacheHints>,
}

impl ChatRequest {
    /// Create a request from a message list.
    pub fn new(messages: Vec<Message>) -> Self {
        Self {
            messages,
            ..Default::default()
        }
    }

    /// Attach tool definitions to the request.
    pub fn with_tools(mut self, tools: Vec<ToolDefinition>) -> Self {
        self.tools = Some(tools);
        self
    }

    /// Override the provider client's timeout policy for this request.
    pub fn with_timeouts(mut self, timeouts: LlmTimeouts) -> Self {
        self.timeouts = Some(timeouts);
        self
    }
}

/// Chat response
#[derive(Debug, Clone)]
pub struct ChatResponse {
    /// Primary assistant message returned by the provider.
    pub message: Message,
    /// Provider-specific finish reason.
    pub finish_reason: Option<String>,
    /// Provider-normalized token usage, symmetric with [`ChatChunk::usage`].
    pub usage: Option<types::Usage>,
    /// Raw provider response for callers needing extra metadata.
    pub raw: ChatCompletionResponse,
}

impl ChatResponse {
    /// Extract the assistant text content.
    pub fn content(&self) -> Option<String> {
        self.message.content.as_text()
    }

    /// Borrow tool calls if the assistant emitted any.
    pub fn tool_calls(&self) -> Option<&Vec<ToolCall>> {
        self.message.tool_calls.as_ref()
    }

    /// Whether the response includes at least one tool call.
    pub fn has_tool_calls(&self) -> bool {
        self.message
            .tool_calls
            .as_ref()
            .is_some_and(|t| !t.is_empty())
    }
}

/// Streaming response chunk
#[derive(Debug, Clone)]
pub struct ChatChunk {
    /// Incremental message delta.
    pub delta: DeltaMessage,
    /// Finish reason emitted with the chunk, if any.
    pub finish_reason: Option<String>,
    /// Token usage (present in the final chunk when stream_options.include_usage is set).
    pub usage: Option<types::Usage>,
}
